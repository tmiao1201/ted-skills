// 新场景模板：复制到项目 scenes/ 下改名。draw(ctx, t) 必须是 t 的纯函数（不能依赖上一帧状态）。
import {
  W, H, INK, FONT_CN, FONT_EN, clamp, lerp, ease, p, kf, hash, rng, TAU,
  shape, rrect, circle, ellipse, line, text, typed, paper, grain, camera, pop, iris,
  sparkle, starfield, puff, callout, drawOn, arcPath, measure,
} from '../engine/core.js';
import { drawTuanzi, autoBlink } from '../engine/mascot.js';

// 分镜表：每个镜头一段 [开始, 结束]，改时间只改这里
const SHOT = {
  intro: [0, 3],
  main: [3, 8],
  outro: [8, 10],
};
const inShot = (t, [a, b]) => t >= a && t < b;

export default {
  name: 'my-scene', duration: 10, fps: 30, width: W, height: H,
  draw(ctx, t) {
    paper(ctx, '#f3eee4');

    if (inShot(t, SHOT.intro)) {
      const k = p(t, 0.2, 0.9, ease.backOut);
      pop(ctx, 640, 360, k, () => {
        rrect(ctx, 340, 220, 600, 280, { r: 18, fill: '#fbf8f1', shadow: true, seed: 1 });
        text(ctx, typed('你好，这是第一个镜头', t, 0.8, 10), 400, 360, { size: 40 });
      });
    }

    if (inShot(t, SHOT.main)) {
      const x = kf(t, [[3, -120], [5, 640, ease.out]]);
      drawTuanzi(ctx, { x, y: 560, scale: 1, walk: t < 5 ? t * 13 : null, blink: autoBlink(t), mood: t > 5.5 ? 'happy' : 'normal', armL: t > 5.5 ? { angle: -2.4, wave: 10 } : undefined });
      line(ctx, [[0, 560], [W, 560]], { lw: 1.4 });
    }

    if (t >= SHOT.outro[0]) {
      const r = lerp(0, 1500, p(t, 8, 9, ease.in));
      iris(ctx, 640, 360, r, () => { ctx.fillStyle = '#2b2260'; ctx.fillRect(0, 0, W, H); starfield(ctx, { seed: 3 }); }, { width: 6 });
    }

    grain(ctx, 0.07);
  },
};
