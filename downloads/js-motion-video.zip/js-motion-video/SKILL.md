---
name: js-motion-video
description: 用纯 JavaScript（Canvas 2D）做手绘风动画短视频并导出 MP4：纸张质感、线条抖动、原创吉祥物「团子」、镜头推拉、圆形传送门转场、X 光剖面、原理图标注、打字机效果、UI 演示。支持拆解参考视频后复刻镜头语言。触发词：代码做视频、JS 动画视频、手绘风动画、复刻这个视频、做个科普动画、产品演示动画、code to video、js-motion-video。用户给出参考视频要求"学习/复刻/仿照"，或给出脚本/选题要求做成动画短片时使用。不适用：真人实拍剪辑、给已有视频加字幕/配乐、3D 渲染。
---

# JS 手绘动画视频

把每一帧写成时间的纯函数 `draw(ctx, t)`，在浏览器里实时预览，再用无头 Chromium 逐帧截图，通过管道交给 ffmpeg 编码成 MP4。

- 引擎：`engine/`（core.js 图元、mascot.js 吉祥物、player.html 预览器、render.mjs 渲染器）
- 示例：`examples/editor.js`（纸面 UI 叙事，30 秒）、`examples/rocket.js`（插画科普，42 秒）
- 手册：`references/style-guide.md`（配色、镜头、节奏）、`references/api.md`（函数速查）

## 工作流

### 1. 建项目
```bash
bash ~/.claude/skills/js-motion-video/scripts/new-project.sh <项目目录> --examples
```
依赖：Node 18+、ffmpeg。如果 Playwright 没找到浏览器，渲染器会自动回退到系统 Chrome 或本地已缓存的 Chromium；都找不到时运行 `npx playwright install chromium`。

### 2. 有参考视频时，先拆解再写
```bash
bash ~/.claude/skills/js-motion-video/scripts/analyze.sh <参考.mp4> <项目>/analysis
```
读取每秒一帧的拼图和场景切换关键帧，整理一张**分镜表**再动手写代码：

| 时间 | 画面 | 动作/镜头 | 转场 | 文字/标注 |
|---|---|---|---|---|

学的是镜头语言、节奏和质感，不照搬角色和品牌。参考片里的 IP 形象一律换成团子或新的原创角色。

### 3. 写场景
- 从 `templates/scene-template.js` 开始（建项目时已复制为 `scenes/main.js`）。先读 `references/api.md`；做类似效果前先翻示例里对应的段落：
  - 代码打字窗口、UI 面板逐个弹出、时间轴、拖拽、滑杆、Ctrl+Z 笑点、拉远出成片 → `examples/editor.js`
  - 草图逐步画出、传送门转场、黄昏场景、X 光剖面、原理图、烟雾、太空、分离、着陆、地球仪 → `examples/rocket.js`
- 顶部用 `SHOT` 对象集中管理各镜头的时间区间，改节奏只动这一处。
- 硬性规则：
  - 禁止 `Math.random()` 和跨帧状态，随机一律用 `hash()`/`rng(seed)`。
  - 每个物体固定一个 `seed`。
  - 每帧第一步画背景，最后一步 `grain()`。
  - 中文用 `FONT_CN`，英文标注用 `FONT_EN`。字体来自 Google Fonts，播放器会先预热全片来加载字形。

### 4. 迭代：静帧 → 预览 → 成片
```bash
node engine/render.mjs scenes/main.js out/stills --stills 1,3.5,6,9   # 每个镜头抽 1 帧看
node engine/render.mjs scenes/main.js --serve                         # 浏览器里看动态效果
node engine/render.mjs scenes/main.js out/main.mp4 [--audio bgm.mp3]
```
每改一轮都导出静帧并**亲自看图**，重点检查：元素是否互相遮挡、文字是否出画、镜头推近后标注是否被裁掉。

### 5. 交付前验证
```bash
ffmpeg -v error -y -i out/main.mp4 -vf "fps=1,scale=320:-1,tile=6x6" -frames:v 1 out/sheet.png
```
查看拼图，确认全片没有黑帧、跳帧，所有镜头都出现了。向用户交付时附上 MP4 路径和拼图。

## 常见坑
- 写在 `draw` 外面的"累计变量"会让预览和渲染结果不一致，必须改成由 `t` 推导。
- 伸长手臂 `{ to: [x, y] }` 用的是**世界坐标**；角色若放在 `camera()` 里，就用同一坐标系下的点。
- `iris()` 内部如果要让某个点落在圆心，相机中心取 `x = 世界点.x - (圆心.x - 640) / zoom`（见 rocket.js 的 B 段）。
- 粒子（烟雾、星星）数量过多会拖慢渲染：烟雾控制在 40–60 团以内。
- 需要音效时，先把画面导出，再用 ffmpeg 或剪辑软件按关键时间点对齐音效（分镜表里的时间就是卡点）。
