#!/usr/bin/env bash
# 拆解参考视频: bash analyze.sh <video.mp4> [输出目录]
# 产出: 元信息、每秒一帧拼图、场景切换点及其关键帧、音量信息
set -euo pipefail
V="${1:?请给出视频路径}"; OUT="${2:-analysis}"; mkdir -p "$OUT"
NAME="$(basename "${V%.*}")"
echo "== 元信息"; ffprobe -v error -show_entries format=duration:stream=codec_type,width,height,r_frame_rate -of compact "$V"
DUR=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$V"); N=$(printf '%.0f' "$DUR"); ROWS=$(( (N + 5) / 6 ))
ffmpeg -v error -y -i "$V" -vf "fps=1,scale=320:-1,tile=6x${ROWS}" -frames:v 1 "$OUT/${NAME}_sheet.png"
echo "== 每秒拼图: $OUT/${NAME}_sheet.png  (6 列，从左到右、从上到下 = 第 0,1,2… 秒)"
echo "== 场景切换点 (scene > 0.3)"
ffmpeg -v info -i "$V" -vf "select='gt(scene,0.3)',showinfo,scale=640:-1" -vsync vfr "$OUT/${NAME}_cut_%03d.jpg" 2>&1 | grep -o 'pts_time:[0-9.]*' | sed 's/pts_time:/  t=/' || true
echo "== 关键帧: $OUT/${NAME}_cut_*.jpg"
ffmpeg -v error -i "$V" -af volumedetect -f null - 2>&1 | grep -E 'mean_volume|max_volume' || echo "  (无音轨)"
