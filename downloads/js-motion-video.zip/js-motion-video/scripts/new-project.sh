#!/usr/bin/env bash
# 用法: bash new-project.sh <项目目录> [--examples]
# 建一个可直接渲染的视频项目：engine/ + scenes/ + out/，并安装 playwright。
set -euo pipefail
SKILL="$(cd "$(dirname "$0")/.." && pwd)"
DIR="${1:?请给出项目目录}"
mkdir -p "$DIR/scenes" "$DIR/out" "$DIR/analysis"
cp -R "$SKILL/engine" "$DIR/"
cp "$SKILL/templates/scene-template.js" "$DIR/scenes/main.js"
if [[ "${2:-}" == "--examples" ]]; then cp "$SKILL/examples/"*.js "$DIR/scenes/"; fi
cd "$DIR"
[[ -f package.json ]] || npm init -y >/dev/null
npm pkg set type=module >/dev/null
npm pkg set scripts.dev="node engine/render.mjs scenes/main.js --serve --port 5173" >/dev/null
npm pkg set scripts.render="node engine/render.mjs scenes/main.js out/main.mp4" >/dev/null
npm i -D playwright --silent
echo "✅ 项目已就绪: $DIR"
echo "   预览: npm run dev   (浏览器打开输出的地址，空格播放、拖动进度条)"
echo "   静帧: node engine/render.mjs scenes/main.js out/stills --stills 1,3,5"
echo "   成片: npm run render"
