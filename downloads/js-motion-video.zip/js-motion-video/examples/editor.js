// 复刻视频 1：「团子写代码 → 钻进剪辑软件 → 拖转场 / 撤销 / 调参 / 卡点 → 30 秒成片」
import {
  W, H, INK, FONT_CN, FONT_EN, clamp, lerp, ease, p, kf, hash, TAU,
  shape, rrect, circle, ellipse, line, text, typed, paper, grain, camera, pop, sparkle, puff, arcPath, measure,
} from '../engine/core.js';
import { drawTuanzi, autoBlink } from '../engine/mascot.js';

const C = {
  bg: '#f4efe4', panel: '#fbf8f1', teal: '#3fa6a0', yellow: '#f2c14e', pink: '#f6c1cc', mint: '#bfe8d6',
  sky: '#cfe6f5', lav: '#d9cff3', cream: '#f7ecc9', navy: '#343a6e', red: '#e0474c', purple: '#6b5bb8', gray: '#e9e4da',
};

// ---------- 时间轴布局 ----------
const TL = { x: 30, y: 420, w: 1220, h: 290, x0: 130, pps: 90 };
const secX = s => TL.x0 + s * TL.pps;
const TRACK = { text: 490, video: 548, audio: 648 };
const CLIPS = [
  { name: '夜景.mp4', s: 0, d: 2.2, fill: C.navy, kind: 'night' },
  { name: '拉面.mp4', s: 2.2, d: 2.6, fill: C.cream, kind: 'ramen' },
  { name: '小狗.mov', s: 4.8, d: 2.2, fill: C.mint, kind: 'dog' },
  { name: '团子蹦迪.mp4', s: 7.0, d: 2.6, fill: C.lav, kind: 'disco' },
];
const clipAt = s => CLIPS.find(c => s >= c.s && s < c.s + c.d) || CLIPS[CLIPS.length - 1];

// ---------- 预览画面（手机里的内容） ----------
function drawContent(ctx, kind, x, y, w, h, t, o = {}) {
  ctx.save();
  ctx.beginPath(); ctx.rect(x, y, w, h); ctx.clip();
  if (o.filter) ctx.filter = o.filter;
  const cx = x + w / 2;
  if (kind === 'night') {
    const g = ctx.createLinearGradient(0, y, 0, y + h); g.addColorStop(0, '#1d2250'); g.addColorStop(1, '#474f8f');
    ctx.fillStyle = g; ctx.fillRect(x, y, w, h);
    for (let i = 0; i < 26; i++) sparkle(ctx, x + ((hash(i, 1) + 1) / 2) * w, y + ((hash(i, 2) + 1) / 2) * h * 0.5, 2 + (i % 3), '#fff6c8');
    circle(ctx, cx + w * 0.18, y + h * 0.2, w * 0.1, { fill: '#ffe9a0', lw: 0 });
    circle(ctx, cx + w * 0.22, y + h * 0.18, w * 0.09, { fill: '#1f2452', lw: 0 });
    for (let i = 0; i < 8; i++) {
      const bw = w / 7, bh = h * (0.22 + ((hash(i, 5) + 1) / 2) * 0.3), bx = x + i * bw - bw * 0.3;
      rrect(ctx, bx, y + h - bh, bw * 0.92, bh + 10, { r: 3, fill: '#262b5c', lw: 1.5, stroke: '#151838', seed: 200 + i });
      for (let r = 0; r < 8; r++) for (let q = 0; q < 3; q++) if (hash(i * 31 + r, q) > 0.1) {
        ctx.fillStyle = '#ffd86b'; ctx.fillRect(bx + 6 + q * bw * 0.26, y + h - bh + 10 + r * 16, 5, 7);
      }
    }
  } else if (kind === 'ramen') {
    const g = ctx.createLinearGradient(0, y, 0, y + h); g.addColorStop(0, '#fbe7a8'); g.addColorStop(1, '#f5cf78');
    ctx.fillStyle = g; ctx.fillRect(x, y, w, h);
    ctx.fillStyle = '#c98a4b'; ctx.fillRect(x, y + h * 0.78, w, h * 0.22);
    const by = y + h * 0.62, br = w * 0.4;
    for (let i = 0; i < 3; i++) { // 蒸汽
      const k = (t * 0.6 + i / 3) % 1;
      line(ctx, [[cx - 30 + i * 30, by - 60 - k * 60], [cx - 22 + i * 30, by - 80 - k * 60], [cx - 30 + i * 30, by - 100 - k * 60]], { stroke: `rgba(255,255,255,${1 - k})`, lw: 4, jitter: 0 });
    }
    ellipse(ctx, cx, by, br, br * 0.25, { fill: '#e9a55c', lw: 2.5, seed: 210 });
    [['#f5b5c0', -0.45], ['#ffe08a', -0.1], ['#7fbf6a', 0.25], ['#3f3a34', 0.5]].forEach(([f, dx], i) => circle(ctx, cx + dx * br, by - 4, br * 0.14, { fill: f, lw: 2, seed: 220 + i }));
    const lift = Math.sin(t * 4) * 8;
    for (let i = 0; i < 5; i++) line(ctx, [[cx + 10 + i * 4, by - 6], [cx + 14 + i * 4, by - 50 - lift], [cx + 26 + i * 3, by - 90 - lift]], { stroke: '#fff3c4', lw: 3, jitter: 0.3, seed: 230 + i });
    line(ctx, [[cx + 18, by - 90 - lift], [cx + w * 0.45, by - h * 0.45]], { lw: 5, stroke: '#7a4a2a', jitter: 0 });
    line(ctx, [[cx + 30, by - 88 - lift], [cx + w * 0.5, by - h * 0.4]], { lw: 5, stroke: '#7a4a2a', jitter: 0 });
    shape(ctx, [[cx - br, by], [cx + br, by], [cx + br * 0.75, by + br * 0.7], [cx - br * 0.75, by + br * 0.7]], { fill: '#fff', lw: 2.6, seed: 240 });
    for (let i = 0; i < 7; i++) rrect(ctx, cx - br * 0.8 + i * br * 0.24, by + br * 0.18, br * 0.14, br * 0.14, { r: 2, fill: null, stroke: C.red, lw: 2, jitter: 0 });
  } else if (kind === 'dog') {
    ctx.fillStyle = '#d7f0e4'; ctx.fillRect(x, y, w, h);
    const hy = y + h * 0.5 + Math.sin(t * 5) * 4, r = w * 0.3;
    [-1, 1].forEach(d => shape(ctx, [[cx + d * r * 0.5, hy - r * 0.6], [cx + d * r * 0.95, hy - r * 1.25], [cx + d * r * 1.05, hy - r * 0.2]], { fill: '#d8894a', lw: 2.6, seed: 250 + d }));
    ellipse(ctx, cx, hy, r, r * 0.88, { fill: '#e39a55', lw: 2.8, seed: 253 });
    ellipse(ctx, cx, hy + r * 0.35, r * 0.62, r * 0.45, { fill: '#fff6ea', lw: 0, seed: 254 });
    [-1, 1].forEach(d => circle(ctx, cx + d * r * 0.36, hy - r * 0.1, 5, { fill: INK, lw: 0 }));
    ellipse(ctx, cx, hy + r * 0.18, 7, 5, { fill: INK, lw: 0 });
    line(ctx, [[cx - 9, hy + r * 0.34], [cx, hy + r * 0.28], [cx + 9, hy + r * 0.34]], { lw: 2.4, jitter: 0 });
    const hk = (t * 0.8) % 1;
    ctx.save(); ctx.globalAlpha = 1 - hk; text(ctx, '♥', cx + r * 0.9, hy - r - hk * 50, { size: 30, color: '#f06a8a', font: 'sans-serif', align: 'center' }); ctx.restore();
  } else if (kind === 'disco') {
    const g = ctx.createLinearGradient(0, y, 0, y + h); g.addColorStop(0, '#4a3f95'); g.addColorStop(0.6, '#8c6ad0'); g.addColorStop(1, '#2d2b62');
    ctx.fillStyle = g; ctx.fillRect(x, y, w, h);
    const fy = y + h * 0.7;
    const cols = ['#f47bb0', '#6fd3ff', '#ffd86b', '#8a7ff0', '#3b3a8a'];
    for (let r = 0; r < 6; r++) for (let q = -6; q < 7; q++) {
      const z0 = r / 6, z1 = (r + 1) / 6, xa = s => cx + (q + s) * (40 + z0 * 60), xb = s => cx + (q + s) * (40 + z1 * 60);
      ctx.fillStyle = cols[Math.abs(q * 3 + r + Math.floor(t * 4)) % cols.length];
      ctx.beginPath(); ctx.moveTo(xa(0), fy + z0 * z0 * h * 0.3); ctx.lineTo(xa(1), fy + z0 * z0 * h * 0.3); ctx.lineTo(xb(1), fy + z1 * z1 * h * 0.3); ctx.lineTo(xb(0), fy + z1 * z1 * h * 0.3); ctx.fill();
    }
    ctx.save(); ctx.globalAlpha = 0.25; ctx.fillStyle = '#fff';
    for (let i = 0; i < 3; i++) { const a = -0.5 + i * 0.5 + Math.sin(t * 2) * 0.2; ctx.beginPath(); ctx.moveTo(cx, y + 50); ctx.lineTo(cx + Math.sin(a) * h - 40, y + h); ctx.lineTo(cx + Math.sin(a) * h + 40, y + h); ctx.fill(); }
    ctx.restore();
    line(ctx, [[cx, y], [cx, y + 30]], { lw: 2, jitter: 0, stroke: '#ddd' });
    circle(ctx, cx, y + 52, 24, { fill: '#e8e8f4', lw: 2.4, seed: 260 });
    for (let i = 0; i < 4; i++) line(ctx, [[cx - 24, y + 40 + i * 8], [cx + 24, y + 40 + i * 8]], { stroke: '#a9a9c9', lw: 1.2, jitter: 0 });
    for (let i = 0; i < 7; i++) sparkle(ctx, x + ((hash(i, 8) + 1) / 2) * w, y + ((hash(i, 9) + 1) / 2) * h * 0.6, 5 + 4 * Math.abs(Math.sin(t * 3 + i)), '#fff');
    const beat = Math.abs(Math.sin(t * Math.PI * 2));
    drawTuanzi(ctx, { x: cx, y: fy + 30, scale: w / 360, squash: beat * 0.35 - 0.1, mood: 'happy', hop: beat * 10, armL: { angle: -2.3 + beat * 0.5 }, armR: { angle: -0.8 - beat * 0.5 } });
  }
  ctx.restore();
}

// 手机外框 + 内容
function drawPhone(ctx, x, y, w, h, content, t, o = {}) {
  rrect(ctx, x, y, w, h, { r: 34, fill: '#2a2626', lw: 3, shadow: true, seed: 300 });
  const pad = 10;
  ctx.save();
  ctx.beginPath(); ctx.roundRect(x + pad, y + pad, w - pad * 2, h - pad * 2, 26); ctx.clip();
  content(x + pad, y + pad, w - pad * 2, h - pad * 2);
  if (o.flash) { ctx.fillStyle = `rgba(255,255,255,${o.flash})`; ctx.fillRect(x, y, w, h); }
  ctx.restore();
  rrect(ctx, x + w / 2 - 34, y + pad + 6, 68, 18, { r: 9, fill: '#1a1717', lw: 0 });
}

// 转场格子图标
function tileIcon(ctx, name, cx, cy, s = 1) {
  ctx.save(); ctx.translate(cx, cy); ctx.scale(s, s);
  if (name === '旋转') { circle(ctx, 0, 0, 16, { fill: C.teal, lw: 2 }); line(ctx, [[0, 0], [6, -4], [8, 4], [0, 9], [-9, 2], [-6, -10], [6, -13]], { lw: 2, stroke: '#fff' }); }
  if (name === '翻页') { rrect(ctx, -12, -16, 24, 32, { r: 3, fill: '#fff', lw: 2 }); [-8, -2, 4].forEach(y => line(ctx, [[-7, y], [7, y]], { lw: 1.6, jitter: 0 })); shape(ctx, [[4, 16], [12, 8], [12, 16]], { fill: '#ddd', lw: 1.6 }); }
  if (name === '故障') { rrect(ctx, -18, -12, 36, 24, { r: 6, fill: '#b8a2e8', lw: 2 }); [[-10, -2], [2, 4]].forEach(([a, b]) => rrect(ctx, a, b - 3, 10, 5, { r: 1, fill: '#fff', lw: 1 })); }
  if (name === '缩放') { circle(ctx, -3, -3, 12, { fill: '#fff', lw: 2.4 }); line(ctx, [[6, 6], [15, 15]], { lw: 4, jitter: 0 }); line(ctx, [[-8, -3], [2, -3]], { lw: 2 }); line(ctx, [[-3, -8], [-3, 2]], { lw: 2 }); }
  if (name === '滑动') { rrect(ctx, -2, -14, 22, 28, { r: 4, fill: C.teal, lw: 2 }); line(ctx, [[4, -5], [11, 0], [4, 5]], { lw: 2, stroke: '#fff' }); [-8, -4, 0].forEach(y => line(ctx, [[-18, y * 2 + 4], [-8, y * 2 + 4]], { lw: 2 })); }
  if (name === '溶解') { rrect(ctx, -14, -14, 20, 20, { r: 3, fill: '#9f8fe0', lw: 2 }); rrect(ctx, -4, -4, 20, 20, { r: 3, fill: 'rgba(255,255,255,0.6)', lw: 2, dash: [3, 3] }); }
  ctx.restore();
}
const TILES = [['旋转', C.gray], ['翻页', C.mint], ['故障', C.pink], ['缩放', C.sky], ['滑动', C.cream], ['溶解', C.gray]];
const tilePos = i => [48 + (i % 2) * 160, 80 + Math.floor(i / 2) * 105];

// ---------- 剪辑软件各块 ----------
function drawLeftPanel(ctx, t) {
  rrect(ctx, 30, 20, 330, 390, { r: 14, fill: C.panel, lw: 2.5, shadow: true, seed: 10 });
  ['素材', '转场', '文字'].forEach((s, i) => {
    rrect(ctx, 44 + i * 104, 32, 92, 32, { r: 8, fill: i === 1 ? C.yellow : '#f3efe6', lw: 2, seed: 11 + i });
    text(ctx, s, 90 + i * 104, 48, { size: 20, align: 'center' });
  });
  TILES.forEach(([name, fill], i) => {
    const [x, y] = tilePos(i), dim = name === '旋转';
    rrect(ctx, x, y, 140, 80, { r: 8, fill, lw: 2, alpha: dim ? 0.6 : 1, seed: 20 + i });
    tileIcon(ctx, name, x + 70, y + 36);
    text(ctx, name, x + 70, y + 92, { size: 15, align: 'center', alpha: dim ? 0.5 : 1 });
  });
}

function drawTimeline(ctx, t, S) {
  rrect(ctx, TL.x, TL.y, TL.w, TL.h, { r: 16, fill: C.panel, lw: 2.5, shadow: true, seed: 30 });
  // 刻度
  line(ctx, [[TL.x0 - 30, 470], [TL.x + TL.w - 20, 470]], { lw: 1.6, jitter: 0.3 });
  for (let s = 0; s <= 12.5; s += 0.25) {
    const x = secX(s), major = s % 2 === 0;
    line(ctx, [[x, 470], [x, major ? 452 : s % 1 === 0 ? 460 : 464]], { lw: major ? 1.8 : 1, jitter: 0 });
    if (major) text(ctx, `0:${String(s).padStart(2, '0')}`, x, 440, { size: 15, align: 'center', font: FONT_EN, color: '#6b5d55' });
  }
  // 轨道头
  [['T', TRACK.text + 18, C.cream], ['▶', TRACK.video + 40, C.sky], ['♪', TRACK.audio + 22, C.lav]].forEach(([s, y, f], i) => {
    rrect(ctx, 44, y - 20, 44, 40, { r: 8, fill: f, lw: 2, seed: 31 + i }); text(ctx, s, 66, y + 1, { size: 20, align: 'center', font: 'sans-serif' });
  });
  // 文字轨
  if (S.textClip > 0) {
    const k = S.textClip, y = TRACK.text + (1 - ease.bounceOut(k)) * -70;
    rrect(ctx, secX(6.2), y, 240, 34, { r: 8, fill: C.yellow, lw: 2.2, alpha: clamp(k * 3), seed: 35 });
    text(ctx, 'T  前方高能预警', secX(6.2) + 18, y + 17, { size: 18, alpha: clamp(k * 3) });
  }
  // 视频片段
  CLIPS.forEach((c, i) => {
    const k = S.clipIn[i]; if (k <= 0) return;
    let x = secX(c.s) + (1 - k) * 600, y = TRACK.video, rot = 0, alpha = clamp(k * 2);
    if (S.flying && S.flying.i === i) { [x, y] = S.flying.pos; rot = S.flying.rot; }
    const w = c.d * TL.pps - 4, h = 80;
    ctx.save(); ctx.globalAlpha *= alpha;
    ctx.translate(x + w / 2, y + h / 2); ctx.rotate(rot); ctx.translate(-w / 2, -h / 2);
    rrect(ctx, 0, 0, w, h, { r: 8, fill: c.fill, lw: 2.4, seed: 40 + i });
    ctx.save(); ctx.beginPath(); ctx.roundRect(3, 3, w - 6, h - 6, 6); ctx.clip();
    for (let q = 0; q * 64 < w; q++) drawContent(ctx, c.kind, 4 + q * 64, 4, 62, h - 8, 0.3 * q);
    ctx.restore();
    rrect(ctx, 6, 6, measure(ctx, c.name, 13) + 14, 20, { r: 5, fill: '#fff', lw: 1.6, seed: 45 + i });
    text(ctx, c.name, 13, 16, { size: 13 });
    ctx.restore();
  });
  // 转场角标
  S.badges.forEach(([sec, name, k]) => pop(ctx, secX(sec), TRACK.video + 40, ease.backOut(k), () => {
    circle(ctx, secX(sec), TRACK.video + 40, 17, { fill: '#fff', lw: 2.2 }); tileIcon(ctx, name, secX(sec), TRACK.video + 40, 0.6);
  }));
  // 音频波形
  const wk = S.wave;
  if (wk > 0) {
    rrect(ctx, secX(0), TRACK.audio, 1080 * wk, 44, { r: 8, fill: '#e6def8', lw: 2.2, seed: 50 });
    text(ctx, '♪ bgm_团子.wav', secX(0) + 12, TRACK.audio + 12, { size: 13, alpha: wk });
    ctx.fillStyle = '#9b8bd6';
    for (let x = 10; x < 1080 * wk - 6; x += 5) { const a = Math.abs(hash(x, 3)) * 14 + (x > 300 ? Math.abs(Math.sin(x * 0.05)) * 6 : 2); ctx.fillRect(secX(0) + x, TRACK.audio + 28 - a / 2, 2.4, a); }
  }
  // 卡点三角
  S.beats.forEach(([x, k]) => { if (k > 0) pop(ctx, x, 700, ease.backOut(k), () => shape(ctx, [[x - 8, 694], [x + 8, 694], [x, 706]], { fill: '#d9d2c4', lw: 1.6, jitter: 0 })); });
  // 播放头
  const px = secX(S.head);
  line(ctx, [[px, 462], [px, 705]], { stroke: C.red, lw: 2.2, jitter: 0 });
  shape(ctx, [[px - 9, 452], [px + 9, 452], [px + 9, 464], [px, 472], [px - 9, 464]], { fill: C.red, lw: 1.8, stroke: '#9e2d31', jitter: 0 });
}

function drawAdjust(ctx, x, S) {
  rrect(ctx, x, 15, 360, 330, { r: 14, fill: C.panel, lw: 2.5, shadow: true, seed: 60 });
  text(ctx, '调整', x + 20, 48, { size: 26 }); sparkle(ctx, x + 88, 46, 10, C.yellow); 
  S.sliders.forEach(([name, val, max, fmt], i) => {
    const y = 90 + i * 64, k = val / max, tx = x + 28, tw = 300, hot = name === '饱和度' && val > 150;
    text(ctx, name, tx, y, { size: 18 });
    text(ctx, fmt(val), tx + tw, y, { size: 18, align: 'right', font: FONT_EN, color: hot ? C.red : '#6b5d55' });
    rrect(ctx, tx, y + 22, tw, 10, { r: 5, fill: '#e8e3d8', lw: 1.6, jitter: 0.3, seed: 61 + i });
    if (k > 0.01) rrect(ctx, tx, y + 22, tw * k, 10, { r: 5, fill: C.teal, lw: 0, jitter: 0 });
    circle(ctx, tx + tw * k, y + 27, hot ? 13 : 11, { fill: hot ? C.yellow : '#fff', lw: 2.2, seed: 65 + i });
  });
}
const knobPos = (x, i, k) => [x + 28 + 300 * k, 90 + i * 64 + 27];

// ---------- 主绘制 ----------
function editorState(t) {
  const sat = kf(t, [[15.9, 100], [17.2, 225, ease.inOut]]);
  const flash = kf(t, [[17.3, 30], [18.1, 70]]);
  const head = kf(t, [[4.4, 2.6], [9.6, 1.4], [11.0, 3.2, ease.inOut], [14.0, 3.2], [14.6, 7.6], [19.0, 8.2], [23.5, 10.4, ease.linear]]);
  // 扔错片段
  let flying = null;
  const trash = [640, 350];
  if (t > 11.0 && t < 13.2) {
    const home = [secX(4.8), TRACK.video];
    const k = t < 12.4 ? p(t, 11.0, 11.7, ease.inOut) : 1 - p(t, 12.4, 13.1, ease.inOut);
    flying = { i: 2, pos: arcPath(home, trash, k, 160), rot: k * 1.4 };
  }
  return {
    head, flying, trash, sat, flash,
    clipIn: CLIPS.map((_, i) => p(t, 5.0 + i * 0.15, 5.6 + i * 0.15, ease.backOut)),
    wave: p(t, 5.5, 6.6, ease.out),
    badges: [[2.2, '翻页', p(t, 9.6, 10.0)], ...(t > 19 ? [[4.8, '溶解', p(t, 19.0, 19.3)], [7.0, '故障', p(t, 19.1, 19.4)]] : [])],
    textClip: p(t, 18.2, 18.9, ease.linear),
    beats: Array.from({ length: 22 }, (_, i) => [140 + i * 50, p(t, 19.4 + i * 0.05, 19.7 + i * 0.05)]),
    sliders: [['闪光', flash, 100, v => `${Math.round(v)}%`], ['饱和度', sat, 250, v => `${Math.round(v)}%`], ['缩放冲击', kf(t, [[19.5, 0], [20.2, 60]]), 100, v => `${Math.round(v)}%`], ['速度', 1, 2, v => `${v.toFixed(1)}x`]],
  };
}

function drawEditor(ctx, t, S, reveal = 1) {
  const pin = (a, fn) => { const k = p(t, a, a + 0.55, ease.backOut); if (reveal >= 1) pop(ctx, W / 2, H / 2, lerp(0.9, 1, k), fn, clamp(k * 2)); else fn(); };
  pin(4.35, () => drawLeftPanel(ctx, t));
  // 手机预览
  pin(4.5, () => {
    const beat = t > 20.3 && t < 23.5 ? Math.pow(1 - ((t - 20.3) % 0.5) / 0.5, 3) : 0;
    const s = 1 + beat * 0.05;
    pop(ctx, 820, 205, s, () => drawPhone(ctx, 700, 20, 240, 370, (x, y, w, h) => {
      const c = clipAt(S.head);
      // 翻页转场：9.9~10.6 播放头跨过 2.2s 时
      if (t > 9.9 && t < 10.7) {
        const k = p(t, 9.9, 10.7, ease.inOut);
        drawContent(ctx, 'ramen', x, y, w, h, t);
        ctx.save(); ctx.beginPath(); ctx.rect(x, y, w * (1 - k), h); ctx.clip(); drawContent(ctx, 'night', x, y, w, h, t); ctx.restore();
        line(ctx, [[x + w * (1 - k), y], [x + w * (1 - k), y + h]], { stroke: '#fff', lw: 6, jitter: 0 });
      } else {
        const filter = S.sat > 101 ? `saturate(${S.sat / 100}) contrast(${1 + (S.sat - 100) / 600})` : null;
        drawContent(ctx, c.kind, x, y, w, h, t, { filter });
      }
      if (S.textClip > 0.3 && S.head > 6.2) text(ctx, '前方高能', x + w / 2, y + 70, { size: 34, align: 'center', color: '#ffe066', stroke: { color: '#d8324a', lw: 7 }, rot: -0.06, alpha: clamp((S.textClip - 0.3) * 3) });
    }, t, { flash: beat * 0.35 + (S.flash > 31 ? Math.max(0, Math.sin(t * 9)) * 0.08 : 0) }));
    // 播放控制
    text(ctx, '⏮   ⏯   ⏭', 820, 407, { size: 18, align: 'center', font: 'sans-serif', color: '#5d4f47' });
  });
  pin(4.65, () => drawTimeline(ctx, t, S));
}

function drawCodeCard(ctx, t) {
  rrect(ctx, 120, 205, 1040, 310, { r: 16, fill: '#fbf8f1', lw: 3, shadow: true, seed: 2 });
  line(ctx, [[122, 250], [1158, 250]], { lw: 2, jitter: 0.4 });
  ['#ec6a5e', '#f4bf4f', '#61c554'].forEach((f, i) => circle(ctx, 152 + i * 24, 228, 8, { fill: f, lw: 1.8 }));
  text(ctx, '团子.js — 终端', 640, 228, { size: 18, align: 'center', color: '#6b5d55' });
  const lines = [
    [['const ', '#7a6fd0', FONT_EN], ['剪辑软件', C.teal], [' = ', INK], ['团子', C.red], ['.写代码()', INK]],
    [['剪辑软件', C.teal], ['.画出(', INK], ['时间轴, 预览, 面板', '#d19a1c'], [')', INK]],
    [['团子', C.red], ['.钻进去(', INK]],
  ];
  let start = 0.35;
  lines.forEach((toks, li) => {
    const y = 300 + li * 66;
    text(ctx, String(li + 1), 172, y, { size: 22, color: '#b3a79d', font: FONT_EN });
    let x = 215, chars = Math.floor((t - start) * 16);
    toks.forEach(([s, color, font]) => {
      const vis = Array.from(s).slice(0, Math.max(0, chars)).join(''); chars -= Array.from(s).length;
      if (vis) { text(ctx, vis, x, y, { size: 38, color, font: font ?? FONT_CN }); x += measure(ctx, vis, 38, font ?? FONT_CN); }
    });
    const total = toks.reduce((a, [s]) => a + Array.from(s).length, 0);
    const typing = t > start && t < start + total / 16 + 0.15;
    if ((typing || (li === 2 && t > start)) && Math.floor(t * 2.5) % 2 === 0) { ctx.fillStyle = C.red; ctx.fillRect(x + 4, y - 20, 14, 40); }
    start += total / 16 + 0.15;
  });
}

export default {
  name: 'editor', duration: 30, fps: 30, width: W, height: H,
  draw(ctx, t) {
    paper(ctx, C.bg);
    const S = editorState(t);

    // ===== A/B：代码窗口 + 钻进去 =====
    if (t < 4.4) {
      const zoom = kf(t, [[3.4, 1], [4.4, 7, ease.in]]);
      const fade = 1 - p(t, 4.0, 4.4);
      ctx.save(); ctx.globalAlpha = fade;
      camera(ctx, { x: lerp(640, 470, p(t, 3.4, 4.4)), y: lerp(360, 432, p(t, 3.4, 4.4)), zoom }, () => {
        // 团子从窗口顶部探头 → 跳进光标
        const peek = p(t, 0.2, 0.8, ease.backOut);
        const jump = p(t, 2.9, 3.5, ease.inOut);
        const pos = jump > 0 ? arcPath([1040, 212], [470, 460], jump, 140) : [1040, 212 + (1 - peek) * 90];
        const behind = jump < 0.5;
        const mascot = () => drawTuanzi(ctx, {
          x: pos[0], y: pos[1], scale: lerp(0.8, 0.25, jump), blink: autoBlink(t), look: [t > 1.2 && t < 2.8 ? -1 : 0, 0.6],
          squash: jump > 0 ? -0.4 * Math.sin(jump * Math.PI) : 0, mood: jump > 0.2 ? 'wow' : 'normal',
          armL: { angle: -2.2 }, armR: { angle: -0.9 },
        });
        if (behind) mascot();
        drawCodeCard(ctx, t);
        if (!behind) mascot();
      });
      ctx.restore();
    }

    // ===== C~G：剪辑软件 =====
    if (t >= 4.0) {
      const k = p(t, 4.0, 4.6, ease.out);
      const out = p(t, 23.5, 24.6, ease.inOut);
      ctx.save(); ctx.globalAlpha = k;
      camera(ctx, { zoom: lerp(1.4, 1, k) * lerp(1, 0.86, out), x: 640, y: 360 }, () => {
        drawEditor(ctx, t, S);
        // 调整面板
        const ax = kf(t, [[14.0, 1320], [14.6, 890, ease.backOut]]);
        if (t > 14) drawAdjust(ctx, ax, S);
        // 垃圾桶
        const tk = p(t, 10.8, 11.1, ease.backOut) * (1 - p(t, 13.4, 13.7));
        pop(ctx, S.trash[0] + 50, S.trash[1] + 30, tk, () => {
          shape(ctx, [[S.trash[0] + 25, S.trash[1] + 5], [S.trash[0] + 75, S.trash[1] + 5], [S.trash[0] + 70, S.trash[1] + 60], [S.trash[0] + 30, S.trash[1] + 60]], { fill: '#c9c2b6', lw: 2.4 });
          rrect(ctx, S.trash[0] + 18, S.trash[1] - 6, 64, 10, { r: 4, fill: '#b2aa9d', lw: 2.2 });
        });
        // Ctrl+Z 键帽 + 已撤销印章
        const kk = p(t, 11.9, 12.2, ease.backOut) * (1 - p(t, 13.6, 13.9));
        const press = t > 12.35 && t < 12.55 ? 5 : 0;
        pop(ctx, 480, 330, kk, () => {
          rrect(ctx, 420, 306 + press, 120, 50, { r: 10, fill: '#fff', lw: 2.6, shadow: { y: 6 - press, blur: 0, color: '#bdb4a6' } });
          text(ctx, 'Ctrl+Z', 480, 331 + press, { size: 28, align: 'center', font: FONT_EN, weight: 'bold' });
        });
        const st = p(t, 13.05, 13.3, ease.backOut) * (1 - p(t, 13.8, 14.0));
        pop(ctx, 560, 520, lerp(2, 1, st), () => {
          rrect(ctx, 505, 500, 110, 40, { r: 8, fill: 'rgba(220,245,230,0.9)', stroke: '#3a9a6a', lw: 2.6 });
          text(ctx, '已撤销', 560, 520, { size: 22, align: 'center', color: '#2f8a5c', rot: 0 });
        }, clamp(st * 3));

        // ---- 团子在剪辑软件里的表演 ----
        const walkX = kf(t, [[4.4, 470], [5.0, 560, ease.out], [14.3, 560], [15.4, 1040, ease.inOut], [23.5, 1040]]);
        const land = p(t, 4.2, 4.8, ease.bounceOut);
        const walking = (t > 14.3 && t < 15.4);
        let armR = { angle: -0.5, wave: 0 }, armL = { angle: Math.PI + 0.6 }, holding = null, mood = 'normal', look = [0, 0], squash = 0;
        const scale = lerp(0.3, 0.9, land) * (t > 15 ? kf(t, [[15, 0.9], [15.4, 1.05]]) : 1);
        const y = t > 15.0 ? kf(t, [[15, 540], [15.4, 690]]) : 540;
        // 拖转场：伸手→抓→拉回→放下
        if (t > 7.4 && t < 9.8) {
          const tile = [tilePos(1)[0] + 70, tilePos(1)[1] + 40], drop = [secX(2.2), TRACK.video + 40];
          const reach = p(t, 7.4, 8.1, ease.out), back = p(t, 8.3, 9.5, ease.inOut);
          const hand = back > 0 ? arcPath(tile, drop, back, 90) : [lerp(walkX + 60, tile[0], reach), lerp(470, tile[1], reach)];
          armR = { to: hand, bend: 0.1 }; mood = 'focus'; look = [-1, -0.8];
          if (t > 8.15) holding = () => {};
          if (t > 8.15) pop(ctx, hand[0], hand[1], 0.8, () => { rrect(ctx, hand[0] - 40, hand[1] - 26, 80, 52, { r: 8, fill: C.mint, lw: 2 }); tileIcon(ctx, '翻页', hand[0], hand[1]); }, 0.95);
        }
        if (t > 10.9 && t < 11.3) { mood = 'surprised'; squash = 0.3; armR = { angle: -0.3 }; }
        if (t > 11.3 && t < 12.3) { mood = 'surprised'; look = [-0.6, -1]; }
        if (t > 12.3 && t < 12.6) { armL = { to: [480, 340], bend: -0.2 }; mood = 'focus'; }
        if (t > 13.1 && t < 14.0) { mood = 'happy'; armL = { angle: -2.4, wave: 12 }; }
        // 拉滑杆
        if (t > 15.5 && t < 18.3) {
          const i = t < 17.3 ? 1 : 0, sl = S.sliders[i];
          const target = knobPos(890, i, sl[1] / sl[2]);
          const reach = p(t, i === 1 ? 15.5 : 17.3, i === 1 ? 15.9 : 17.6, ease.out);
          armR = { to: [lerp(walkX + 50, target[0], reach), lerp(y - 90, target[1], reach)], bend: -0.08 };
          mood = S.sat > 180 ? 'wow' : 'focus'; look = [0.6, -1];
        }
        if (t > 18.3 && t < 19.2) { mood = 'happy'; }
        if (t > 19.2 && t < 23.5) {
          const b = Math.abs(Math.sin((t - 19.2) * Math.PI * 2));
          squash = b * 0.25; mood = 'happy'; armL = { angle: -2.5 + b * 0.6 }; armR = { angle: -0.6 - b * 0.6 };
        }
        const hop = t > 19.2 && t < 23.5 ? Math.abs(Math.sin((t - 19.2) * Math.PI * 2)) * 12 : 0;
        if (t < 23.8) drawTuanzi(ctx, {
          x: walkX, y, scale, walk: walking ? t * 14 : null, blink: autoBlink(t, 2), look, mood, squash: squash + (1 - land) * -0.3, hop,
          armR, armL, flip: false,
        });
      });
      ctx.restore();

      // ===== H：拉远成片 =====
      if (out > 0) {
        ctx.save(); ctx.fillStyle = `rgba(244,239,228,${out * 0.62})`; ctx.fillRect(0, 0, W, H); ctx.restore();
        // 窗口标题栏
        pop(ctx, 640, 30, 1, () => {
          rrect(ctx, 14, 10, 1252, 700, { r: 18, fill: null, lw: 2.5, alpha: out });
          line(ctx, [[16, 52], [1264, 52]], { lw: 2, alpha: out, jitter: 0.3 });
          ['#ec6a5e', '#f4bf4f', '#61c554'].forEach((f, i) => circle(ctx, 40 + i * 22, 31, 7, { fill: f, lw: 1.6, alpha: out }));
          text(ctx, '🎬 团子剪辑_最终版_打死不改(3).mp4', 120, 31, { size: 17, alpha: out, color: '#5d4f47' });
          const secs = Math.min(28, Math.floor(lerp(9, 28, p(t, 24, 27.5, ease.out))));
          rrect(ctx, 548, 17, 184, 28, { r: 8, fill: '#e6e0d4', lw: 1.6, alpha: out });
          text(ctx, `00:00:${String(secs).padStart(2, '0')}:00`, 640, 31, { size: 18, align: 'center', font: FONT_EN, alpha: out });
          rrect(ctx, 1090, 17, 160, 28, { r: 8, fill: C.teal, lw: 1.6, alpha: out });
          text(ctx, '完成  ✓', 1170, 31, { size: 17, align: 'center', color: '#fff', alpha: out });
        });
        // 成片手机
        const pk = p(t, 23.8, 24.8, ease.backOut);
        pop(ctx, 640, 380, lerp(0.8, 1, pk), () => drawPhone(ctx, 500, 90, 280, 480, (x, y, w, h) => {
          drawContent(ctx, 'disco', x, y, w, h, t, { filter: 'saturate(1.25)' });
          const icons = [['♥', '9.4w', '#f06a8a'], ['💬', '2255', '#fff'], ['↗', '分享', '#fff']];
          icons.forEach(([ic, n, col], i) => { text(ctx, ic, x + w - 26, y + 150 + i * 62, { size: 24, align: 'center', color: col, font: 'sans-serif' }); text(ctx, n, x + w - 26, y + 176 + i * 62, { size: 12, align: 'center', color: '#fff', font: 'sans-serif' }); });
          text(ctx, '@团子 · 纯 JS 生成', x + 16, y + h - 44, { size: 17, color: '#fff' });
          text(ctx, '#代码做视频 #手绘动画', x + 16, y + h - 20, { size: 13, color: '#fff', alpha: 0.9 });
        }, t), clamp(pk * 2));
        // 便签
        const nk = p(t, 24.4, 25.1, ease.backOut);
        pop(ctx, 180, 260, nk, () => {
          ctx.save(); ctx.translate(180, 260); ctx.rotate(-0.04); ctx.translate(-180, -260);
          rrect(ctx, 40, 150, 290, 240, { r: 6, fill: '#fffdf6', lw: 2.4, shadow: true });
          [210, 260, 310, 360].forEach(y => line(ctx, [[60, y + 12], [310, y + 12]], { stroke: '#e3ddd0', lw: 1.4, jitter: 0 }));
          rrect(ctx, 130, 138, 80, 22, { r: 3, fill: 'rgba(242,193,78,0.75)', lw: 0 });
          text(ctx, typed('30 秒剪完，', t, 25.1, 8), 64, 205, { size: 30 });
          text(ctx, typed('一帧没手动拖。', t, 26.4, 8), 64, 255, { size: 30 });
          text(ctx, typed('— 全靠 JS', t, 27.6, 8), 150, 320, { size: 24, color: '#8b7b70' });
          ctx.restore();
        });
        // 墨镜团子
        const mk = p(t, 25.2, 25.9, ease.backOut);
        drawTuanzi(ctx, {
          x: lerp(1400, 1030, mk), y: 640, scale: 1.25, mood: 'happy', sunglasses: p(t, 26.1, 26.5, ease.bounceOut),
          squash: Math.max(0, Math.sin(t * 6)) * 0.1 * mk, armL: { angle: -2.6, wave: t > 27 ? 10 : 0 }, armR: { angle: 0.9 },
        });
        if (t > 26.3) for (let i = 0; i < 4; i++) sparkle(ctx, 1030 + Math.cos(i * 1.7 + t) * 110, 470 + Math.sin(i * 2.3 + t) * 40, 7 + 3 * Math.sin(t * 4 + i), C.yellow);
      }
    }
    grain(ctx, 0.07);
  },
};
