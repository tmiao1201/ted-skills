// 复刻视频 2：纸面开场 → 传送门 → 火箭发射全流程科普 → 回到纸面
import {
  W, H, INK, FONT_CN, FONT_EN, clamp, lerp, ease, p, kf, hash, rng, TAU,
  shape, rrect, circle, ellipse, line, text, typed, paper, grain, camera, pop, iris, sparkle, starfield, puff, callout, drawOn,
} from '../engine/core.js';
import { drawTuanzi, autoBlink } from '../engine/mascot.js';

const PAPER = '#ebe7df';
const LABEL = '#f4efff';

// ---------- 火箭 ----------
// 局部坐标：原点在一级底部中心，向上为负 y。总高约 505。
function flameShape(ctx, len, width, t, seed = 1, cols = ['#ff8a3d', '#ffd166', '#fffbe8']) {
  if (len <= 1) return;
  const n = 1 + hash(Math.floor(t * 24), seed) * 0.08;
  cols.forEach((c, i) => {
    const k = 1 - i * 0.3, L = len * k * n, w = width * k;
    ctx.save(); ctx.globalAlpha *= 0.9;
    const g = ctx.createLinearGradient(0, 0, 0, L); g.addColorStop(0, c); g.addColorStop(1, 'rgba(255,140,60,0)');
    ctx.fillStyle = i === 0 ? g : c;
    ctx.beginPath(); ctx.moveTo(-w, 0); ctx.bezierCurveTo(-w * 1.2, L * 0.35, -w * 0.3, L * 0.8, 0, L); ctx.bezierCurveTo(w * 0.3, L * 0.8, w * 1.2, L * 0.35, w, 0); ctx.closePath(); ctx.fill();
    ctx.restore();
  });
  ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = 0.35;
  const gl = ctx.createRadialGradient(0, len * 0.2, 0, 0, len * 0.2, len * 0.9); gl.addColorStop(0, '#ffb070'); gl.addColorStop(1, 'rgba(255,120,60,0)');
  ctx.fillStyle = gl; ctx.beginPath(); ctx.arc(0, len * 0.2, len * 0.9, 0, TAU); ctx.fill(); ctx.restore();
}

function booster(ctx, o, t) {
  const { xray = 0, fill = 1, legs = 0, fins = 0 } = o;
  // 着陆腿
  if (legs > 0) [-1, 1].forEach(d => { line(ctx, [[d * 14, -46], [d * (15 + 40 * legs), 6 * legs]], { lw: 5, stroke: '#2b2b33', jitter: 0 }); line(ctx, [[d * 14, -20], [d * (15 + 30 * legs), 4 * legs]], { lw: 2.5, stroke: '#2b2b33', jitter: 0 }); });
  // 发动机喷管
  [-9, 0, 9].forEach(x => shape(ctx, [[x - 4, 0], [x + 4, 0], [x + 6, 9], [x - 6, 9]], { fill: '#4a4a55', lw: 1.5, jitter: 0 }));
  ctx.save(); ctx.globalAlpha *= lerp(1, 0.25, xray);
  rrect(ctx, -15, -300, 30, 300, { r: 3, fill: '#f3f1ec', lw: 2, jitter: 0.3, seed: 500 });
  ctx.restore();
  rrect(ctx, -15, -22, 30, 22, { r: 2, fill: '#34343d', lw: 2, jitter: 0 });
  if (legs <= 0) [-1, 1].forEach(d => rrect(ctx, d > 0 ? 13 : -17, -58, 4, 40, { r: 1, fill: '#2b2b33', lw: 0, jitter: 0 }));
  // 栅格舵
  [-1, 1].forEach(d => rrect(ctx, d > 0 ? 15 : -15 - 12 * (0.3 + fins * 0.7), -292, 12 * (0.3 + fins * 0.7), 10, { r: 1, fill: '#8a8a95', lw: 1.4, jitter: 0 }));
  if (xray > 0) {
    ctx.save(); ctx.globalAlpha *= xray;
    // 液氧箱
    rrect(ctx, -12, -290, 24, 140, { r: 8, fill: 'rgba(20,30,60,0.35)', stroke: '#dfe8ff', lw: 1.4, jitter: 0 });
    const lh = 136 * fill;
    rrect(ctx, -10, -152 - lh, 20, lh, { r: 6, fill: '#4aa8ff', lw: 0, jitter: 0 });
    // 煤油箱
    rrect(ctx, -12, -140, 24, 112, { r: 8, fill: 'rgba(20,30,60,0.35)', stroke: '#dfe8ff', lw: 1.4, jitter: 0 });
    const fh = 108 * clamp(fill * 1.1);
    rrect(ctx, -10, -30 - fh, 20, fh, { r: 6, fill: '#f0a13a', lw: 0, jitter: 0 });
    line(ctx, [[0, -152], [0, -20]], { stroke: '#8fd0ff', lw: 3, jitter: 0 });
    // 气泡
    const r = rng(9);
    for (let i = 0; i < 18; i++) { const bx = (r() - 0.5) * 16, sp = 20 + r() * 30, ph = r() * 140; const by = -152 - ((t * sp + ph) % Math.max(1, lh)); ctx.fillStyle = 'rgba(255,255,255,0.7)'; ctx.beginPath(); ctx.arc(bx, by, 1 + r() * 1.5, 0, TAU); ctx.fill(); }
    ctx.restore();
  }
}
function upper(ctx, o, t) {
  const { fairing = 0, mvac = false } = o;
  if (mvac) shape(ctx, [[-6, -300], [6, -300], [13, -268], [-13, -268]], { fill: '#55555f', lw: 1.6, jitter: 0 });
  else rrect(ctx, -15, -330, 30, 30, { r: 1, fill: '#2c2c33', lw: 2, jitter: 0 });
  rrect(ctx, -15, -420, 30, 90, { r: 2, fill: '#f3f1ec', lw: 2, jitter: 0.3, seed: 501 });
  if (fairing <= 0) {
    shape(ctx, [[-19, -420], [19, -420], [19, -450], [12, -485], [0, -505], [-12, -485], [-19, -450]], { fill: '#f7f5f0', lw: 2, jitter: 0.3, seed: 502 });
  } else {
    [-1, 1].forEach(d => {
      ctx.save(); ctx.translate(d * 19 + d * fairing * 60, -420 + fairing * 30); ctx.rotate(d * fairing * 1.2); ctx.translate(-d * 19, 420);
      shape(ctx, [[0, -420], [d * 19, -420], [d * 19, -450], [d * 12, -485], [0, -505]], { fill: '#f7f5f0', lw: 2, jitter: 0 });
      ctx.restore();
    });
    rrect(ctx, -9, -445, 18, 22, { r: 3, fill: '#d9b24a', lw: 1.6, jitter: 0 }); // 卫星
  }
}
function drawRocket(ctx, o, t) {
  const { x, y, rot = 0, scale = 1, flame = 0, part = 'full', upperOffset = 0, boosterRot = 0 } = o;
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(scale, scale);
  if (part === 'full') {
    ctx.save(); ctx.translate(0, 8); flameShape(ctx, 150 * flame, 18, t); ctx.restore();
    booster(ctx, o, t); upper(ctx, o, t);
  } else if (part === 'sep') {
    ctx.save(); ctx.translate(0, -upperOffset);
    if (o.upperFlame) { ctx.save(); ctx.translate(0, -266); flameShape(ctx, 90 * o.upperFlame, 11, t, 3, ['#6fb7ff', '#cfe6ff', '#ffffff']); ctx.restore(); }
    upper(ctx, { ...o, mvac: true }, t); ctx.restore();
    ctx.save(); ctx.translate(0, upperOffset * 0.25 - 150); ctx.rotate(boosterRot); ctx.translate(0, 150);
    booster(ctx, { ...o, fins: 1 }, t);
    if (o.puffs) for (let i = 0; i < 3; i++) { const k = ((t * 2 + i / 3) % 1); puff(ctx, (i % 2 ? 1 : -1) * (20 + k * 30), -300 - k * 10, 6 + k * 10, { alpha: 1 - k, seed: i }); }
    ctx.restore();
  } else if (part === 'booster') {
    ctx.save(); ctx.translate(0, 8); flameShape(ctx, 90 * flame, 14, t); ctx.restore();
    booster(ctx, o, t);
  }
  ctx.restore();
}

// ---------- 场景块 ----------
function tower(ctx, x, y0, y1, arm = 1) {
  rrect(ctx, x, y1, 44, y0 - y1, { r: 1, fill: '#2a2540', lw: 1.6, stroke: '#171428', jitter: 0 });
  ctx.save(); ctx.strokeStyle = '#4a4468'; ctx.lineWidth = 1.4;
  for (let yy = y1; yy < y0; yy += 30) { ctx.beginPath(); ctx.moveTo(x, yy); ctx.lineTo(x + 44, yy + 30); ctx.moveTo(x + 44, yy); ctx.lineTo(x, yy + 30); ctx.moveTo(x, yy); ctx.lineTo(x + 44, yy); ctx.stroke(); }
  ctx.restore();
  if (arm > 0) rrect(ctx, x - 40 * arm, y1 + 40, 40 * arm, 8, { r: 1, fill: '#2a2540', lw: 1, jitter: 0 });
}

function duskSky(ctx, y0 = 0) {
  const g = ctx.createLinearGradient(0, y0 - 400, 0, y0 + 600);
  g.addColorStop(0, '#221d4f'); g.addColorStop(0.35, '#5a3f8f'); g.addColorStop(0.62, '#a7619b'); g.addColorStop(0.82, '#e88b86'); g.addColorStop(1, '#f5b77e');
  ctx.fillStyle = g; ctx.fillRect(-2000, y0 - 3000, 5000, 4000);
}

// 发射台黄昏世界（世界坐标，火箭底部在 (640,590)）
function drawPad(ctx, t, o = {}) {
  duskSky(ctx);
  starfield(ctx, { seed: 4, count: 90, h: 360, y: -40, x: -100, w: W + 200, alpha: 0.8 });
  ctx.fillStyle = '#3b3360';
  ctx.beginPath(); ctx.moveTo(-600, 600);
  for (let x = -600; x <= 1900; x += 40) ctx.lineTo(x, 560 - Math.abs(Math.sin(x * 0.004)) * 30 - Math.sin(x * 0.013) * 8);
  ctx.lineTo(1900, 700); ctx.lineTo(-600, 700); ctx.fill();
  ctx.fillStyle = '#1d1a31'; ctx.fillRect(-600, 590, 2500, 800);
  rrect(ctx, 600, 578, 150, 20, { r: 2, fill: '#2e2a45', lw: 1.5, stroke: '#171428', jitter: 0 });
  tower(ctx, 680, 590, 110, o.arm ?? 1);
}

function smoke(ctx, t, t0, baseX, baseY, n = 46) {
  const r = rng(21);
  for (let i = 0; i < n; i++) {
    const ts = t0 + i * 0.06, side = i % 2 ? 1 : -1, sp = 0.6 + r() * 0.8, rise = r(), sz = 0.7 + r() * 0.6;
    const age = t - ts; if (age < 0) continue;
    const k = 1 - Math.exp(-age * 1.2);
    const x = baseX + side * (30 + k * 360 * sp), y = baseY - 12 - k * 70 * rise;
    puff(ctx, x, y, (18 + k * 70) * sz, { fill: '#fbeae4', shade: '#d7a9b7', seed: i, alpha: clamp(1.4 - age * 0.12) });
  }
}

function earthCurve(ctx, t, cy = 1500, r = 1180, shift = 0) {
  ctx.save();
  ctx.shadowColor = '#7ab8ff'; ctx.shadowBlur = 40;
  ctx.fillStyle = '#2f6fd0'; ctx.beginPath(); ctx.arc(640, cy, r, 0, TAU); ctx.fill();
  ctx.restore();
  ctx.save(); ctx.beginPath(); ctx.arc(640, cy, r, 0, TAU); ctx.clip();
  const g = ctx.createLinearGradient(0, cy - r, 0, cy - r + 160); g.addColorStop(0, '#5aa6ff'); g.addColorStop(1, '#2a60c0');
  ctx.fillStyle = g; ctx.fillRect(0, cy - r, W, 200);
  const rr = rng(33);
  for (let i = 0; i < 9; i++) {
    const bx = ((rr() * 1800 - shift * 60) % 1800 + 1800) % 1800 - 260, by = cy - r + 20 + rr() * 90, bw = 60 + rr() * 140;
    shape(ctx, Array.from({ length: 10 }, (_, j) => { const a = (j / 10) * TAU; return [bx + Math.cos(a) * bw * (0.7 + hash(i, j) * 0.3), by + Math.sin(a) * 14 * (0.7 + hash(j, i) * 0.3)]; }), { fill: '#5fbf5a', stroke: '#2f6f3a', lw: 1.4, jitter: 0 });
  }
  ctx.restore();
  ctx.save(); ctx.strokeStyle = 'rgba(160,210,255,0.8)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(640, cy, r + 2, 0, TAU); ctx.stroke(); ctx.restore();
}

function spaceBg(ctx, k = 1) {
  const g = ctx.createLinearGradient(0, 0, 0, H);
  g.addColorStop(0, '#0b0a1f'); g.addColorStop(1, lerp(0, 1, k) > 0.5 ? '#1b1842' : '#2b2260');
  ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  starfield(ctx, { seed: 8, count: 160, alpha: 0.9 });
}

// 地球仪：经纬度多边形 + 正交投影
const CONTINENTS = [
  [[-165, 65], [-140, 70], [-95, 72], [-75, 62], [-60, 50], [-80, 30], [-97, 20], [-105, 22], [-118, 33], [-125, 48], [-150, 58]],
  [[-80, 10], [-60, 8], [-35, -6], [-40, -22], [-55, -35], [-70, -52], [-75, -40], [-72, -18], [-80, -3]],
  [[-17, 15], [-5, 35], [10, 37], [32, 31], [43, 12], [51, 11], [40, -15], [32, -28], [20, -35], [12, -17], [8, 4], [-8, 5]],
  [[-10, 36], [-9, 43], [0, 50], [10, 55], [25, 70], [40, 65], [30, 45], [15, 40]],
  [[40, 65], [70, 75], [110, 75], [140, 70], [170, 65], [140, 50], [122, 30], [108, 20], [100, 10], [80, 8], [70, 22], [55, 25], [35, 35], [30, 45]],
  [[114, -22], [130, -12], [142, -11], [153, -27], [145, -38], [132, -32], [115, -34]],
];
function globe(ctx, cx, cy, R, lon0, t) {
  const tilt = 0.35;
  const proj = (lon, lat) => {
    const la = lat * Math.PI / 180, lo = (lon - lon0) * Math.PI / 180;
    let x = Math.cos(la) * Math.sin(lo), y = -Math.sin(la), z = Math.cos(la) * Math.cos(lo);
    const y2 = y * Math.cos(tilt) - z * Math.sin(tilt), z2 = y * Math.sin(tilt) + z * Math.cos(tilt);
    return [x, y2, z2];
  };
  ctx.save(); ctx.shadowColor = '#8f7bff'; ctx.shadowBlur = 50; ctx.fillStyle = '#2f6fd0';
  ctx.beginPath(); ctx.arc(cx, cy, R, 0, TAU); ctx.fill(); ctx.restore();
  ctx.save(); ctx.beginPath(); ctx.arc(cx, cy, R, 0, TAU); ctx.clip();
  CONTINENTS.forEach((poly, ci) => {
    const dense = [];
    poly.forEach((a, i) => { const b = poly[(i + 1) % poly.length]; for (let k = 0; k < 6; k++) dense.push([lerp(a[0], b[0], k / 6), lerp(a[1], b[1], k / 6)]); });
    const pts = dense.map(([lo, la]) => proj(lo, la));
    if (pts.every(q => q[2] < 0)) return;
    const s = pts.map(([x, y, z]) => { if (z < 0) { const m = Math.hypot(x, y) || 1; x /= m; y /= m; } return [cx + x * R, cy + y * R]; });
    shape(ctx, s, { fill: '#62c05c', stroke: '#2b6a36', lw: 1.6, jitter: 0.4, seed: 700 + ci });
  });
  // 云旋
  [[-30, 15], [150, -20], [60, 40], [-120, -25]].forEach(([lo, la], i) => {
    const [x, y, z] = proj(lo, la); if (z < 0.1) return;
    ctx.save(); ctx.globalAlpha = z * 0.85; ctx.strokeStyle = '#fff'; ctx.lineWidth = 2.5; ctx.beginPath();
    for (let a = 0; a < 12; a += 0.2) { const rr = 2 + a * 2.2; ctx.lineTo(cx + x * R + Math.cos(a + t) * rr * (0.4 + z * 0.6), cy + y * R + Math.sin(a + t) * rr * 0.7); }
    ctx.stroke(); ctx.restore();
  });
  const nt = ctx.createLinearGradient(cx - R, 0, cx + R, 0);
  nt.addColorStop(0, 'rgba(8,8,40,0.72)'); nt.addColorStop(0.38, 'rgba(8,8,40,0.55)'); nt.addColorStop(0.46, 'rgba(8,8,40,0)');
  ctx.fillStyle = nt; ctx.fillRect(cx - R, cy - R, R * 2, R * 2);
  ctx.restore();
  ctx.save(); ctx.strokeStyle = 'rgba(170,150,255,0.8)'; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(cx, cy, R + 2, 0, TAU); ctx.stroke(); ctx.restore();
}

function engineSchematic(ctx, t, k) {
  if (k <= 0) return;
  ctx.save(); ctx.globalAlpha = k;
  ctx.fillStyle = 'rgba(16,14,40,0.82)'; ctx.fillRect(0, 0, W, H);
  // 顶部橙色半圆（放大镜的来源）
  ctx.fillStyle = '#f4a340'; ctx.beginPath(); ctx.ellipse(640, 0, 300, 120, 0, 0, Math.PI); ctx.fill();
  const flow = -t * 60;
  const pipe = (pts, col) => { line(ctx, pts, { stroke: col, lw: 10, jitter: 0 }); ctx.save(); ctx.setLineDash([10, 14]); ctx.lineDashOffset = flow; line(ctx, pts, { stroke: 'rgba(255,255,255,0.7)', lw: 3, jitter: 0 }); ctx.restore(); };
  pipe([[500, 60], [500, 260], [560, 300]], '#4aa8ff');
  pipe([[780, 60], [780, 260], [720, 300]], '#f0a13a');
  pipe([[560, 300], [620, 380]], '#4aa8ff');
  pipe([[720, 300], [660, 380]], '#f0a13a');
  const pump = (x, y, col, lab) => {
    circle(ctx, x, y, 40, { fill: col, lw: 3 });
    ctx.save(); ctx.translate(x, y); ctx.rotate(t * 8);
    for (let i = 0; i < 6; i++) { ctx.rotate(TAU / 6); line(ctx, [[0, 0], [30, 8]], { lw: 3, stroke: '#fff', jitter: 0 }); }
    ctx.restore();
    return lab;
  };
  pump(560, 300, '#2f7fd8'); pump(720, 300, '#d9822b');
  circle(ctx, 640, 250, 30, { fill: '#b9b0d8', lw: 3 });
  ctx.save(); ctx.translate(640, 250); ctx.rotate(-t * 10); for (let i = 0; i < 8; i++) { ctx.rotate(TAU / 8); line(ctx, [[6, 0], [24, 0]], { lw: 3, jitter: 0 }); } ctx.restore();
  line(ctx, [[600, 300], [680, 300]], { lw: 5, jitter: 0, stroke: '#ddd' });
  // 燃烧室 + 喷管
  shape(ctx, [[610, 380], [670, 380], [672, 450], [700, 560], [580, 560], [608, 450]], { fill: '#5b5a66', lw: 3 });
  const fk = p(t, 17.2, 17.7, ease.out);
  ctx.save(); ctx.translate(640, 560); flameShape(ctx, 150 * fk, 56, t); ctx.restore();
  const lab = (s, a, b, t0) => callout(ctx, { text: s, anchor: a, at: b, t, t0, color: LABEL, size: 28 });
  lab('oxidizer pump', [520, 300], [360, 300], 15.8);
  lab('fuel pump', [760, 300], [900, 300], 16.1);
  lab('turbine', [640, 222], [640 - 150, 170], 16.4);
  lab('combustion chamber', [690, 430], [880, 450], 16.8);
  lab('thrust!', [640, 660], [800, 660], 17.6);
  ctx.restore();
}

// ---------- 主绘制 ----------
export default {
  name: 'rocket', duration: 42, fps: 30, width: W, height: H,
  draw(ctx, t) {
    const rocketBase = [640, 590];

    // 发射台世界：用于 B~F
    const padScene = (camOpts, o = {}) => camera(ctx, camOpts, () => {
      drawPad(ctx, t, { arm: 1 - p(t, 19.0, 19.6) });
      const rise = t > 19.8 ? 70 * Math.pow(t - 19.8, 2.2) : 0;
      if (t > 18.9) smoke(ctx, t, 18.9, 640, 590);
      drawRocket(ctx, {
        x: rocketBase[0], y: rocketBase[1] - rise, scale: 0.95,
        xray: p(t, 10.2, 10.8) * (1 - p(t, 18.2, 18.7)), fill: p(t, 10.8, 12.8),
        flame: p(t, 18.8, 19.3, ease.out) * (0.9 + 0.1 * Math.sin(t * 40)),
      }, t);
      if (t > 18.9) smoke(ctx, t, 19.4, 640, 596, 20);
      // X 光标注（世界坐标）
      if (t > 11 && t < 15.2) {
        ctx.save(); ctx.globalAlpha = 1 - p(t, 14.6, 15.1);
        callout(ctx, { text: 'liquid oxygen', anchor: [650, 590 - 210 * 0.95], at: [720, 590 - 250 * 0.95], t, t0: 11.4, color: LABEL, size: 18 });
        callout(ctx, { text: 'kerosene (RP-1)', anchor: [650, 590 - 90 * 0.95], at: [720, 590 - 130 * 0.95], t, t0: 12.2, color: LABEL, size: 18 });
        callout(ctx, { text: 'loading propellant...', anchor: [652, 590 - 40], at: [720, 590 - 20], t, t0: 13.0, color: '#ffd9a8', size: 16 });
        ctx.restore();
      }
      return rise;
    });

    // ===== A：纸面开场 =====
    const paperWorld = (irisOpen) => {
      paper(ctx, PAPER);
      line(ctx, [[0, 520], [W, 520]], { lw: 1.4, jitter: 0.6 });
      // 铅笔草图
      const sk = p(t, 2.6, 4.2, ease.inOut);
      const rx = 860, by = 520, s = 0.62;
      const outline = [[rx - 15 * s, by], [rx - 15 * s, by - 420 * s], [rx - 19 * s, by - 420 * s], [rx - 19 * s, by - 450 * s], [rx, by - 505 * s], [rx + 19 * s, by - 450 * s], [rx + 19 * s, by - 420 * s], [rx + 15 * s, by - 420 * s], [rx + 15 * s, by], [rx - 15 * s, by]];
      drawOn(ctx, outline, sk, { stroke: '#8a8580', lw: 1.6 });
      drawOn(ctx, [[rx + 40, by], [rx + 40, by - 300 * s * 1.5]], p(t, 3.3, 4.2), { stroke: '#8a8580', lw: 1.4 });
      drawOn(ctx, [[rx + 66, by], [rx + 66, by - 300 * s * 1.5]], p(t, 3.5, 4.3), { stroke: '#8a8580', lw: 1.4 });
      const wx = kf(t, [[0, -140], [2.2, 540, ease.out]]);
      const walking = t < 2.2;
      const hop = t > 4.3 && t < 4.8 ? Math.sin(p(t, 4.3, 4.8, ease.linear) * Math.PI) * 30 : 0;
      drawTuanzi(ctx, {
        x: wx, y: 520, scale: 0.85, walk: walking ? t * 13 : null, blink: autoBlink(t), hop,
        look: t > 2.4 ? [1, -0.4] : [0.3, 0], mood: t > 4.3 ? 'wow' : 'normal', squash: hop > 0 ? -0.2 : 0,
        armR: t > 4.3 ? { angle: -0.7 } : undefined, armL: t > 4.3 ? { angle: -2.4 } : undefined,
      });
    };

    if (t < 7.2) paperWorld();

    // ===== B：传送门展开 =====
    if (t > 4.8 && t < 7.2) {
      const r = t < 6.2 ? 180 * p(t, 4.8, 5.5, ease.backOut) : lerp(180, 1500, p(t, 6.2, 7.1, ease.in));
      const e = p(t, 6.2, 7.1, ease.in);
      const zoom = lerp(0.5, 1, e), sx = 860, sy = 330;
      iris(ctx, lerp(sx, 640, e), lerp(sy, 360, e), r, () => padScene({ x: 640 - (lerp(sx, 640, e) - 640) / zoom, y: 380 - (lerp(sy, 360, e) - 360) / zoom, zoom }), { width: 7 });
    }

    // ===== C~F：发射台 =====
    if (t >= 7.1 && t < 22.6) {
      const push = kf(t, [[7.1, 1], [10.0, 1.12], [10.8, 2.3, ease.inOut], [14.6, 2.5], [15.3, 4.2, ease.inOut], [18.4, 4.4], [18.9, 1, ease.inOut]]);
      const cy = kf(t, [[7.1, 380], [10.0, 380], [10.8, 590 - 170, ease.inOut], [14.6, 590 - 160], [15.3, 580, ease.inOut], [18.4, 580], [18.9, 380, ease.inOut]]);
      const rise = t > 19.8 ? 70 * Math.pow(t - 19.8, 2.2) : 0;
      const follow = t > 20.6 ? Math.min(cy, 380 - (rise - 70 * Math.pow(0.8, 2.2))) : cy;
      padScene({ x: 640, y: follow, zoom: push, shake: t > 18.9 && t < 21.5 ? 5 * (1 - p(t, 20.5, 21.5)) : 0 });
      engineSchematic(ctx, t, p(t, 15.2, 15.6) * (1 - p(t, 18.2, 18.6)));
    }

    // ===== G~H：太空爬升 + 分离 =====
    if (t >= 22.3 && t < 30.8) {
      spaceBg(ctx);
      earthCurve(ctx, t, lerp(1500, 1700, p(t, 22.3, 30.8, ease.linear)), 1180, t);
      // 速度线
      ctx.save(); ctx.strokeStyle = 'rgba(200,210,255,0.35)'; ctx.lineWidth = 1.5;
      for (let i = 0; i < 28; i++) { const x = (hash(i, 1) + 1) / 2 * W, sp = 600 + (hash(i, 2) + 1) * 400, y = ((t * sp + i * 97) % (H + 200)) - 100; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x - 18, y + 60); ctx.stroke(); }
      ctx.restore();
      const rot = kf(t, [[22.3, 0.1], [26.5, 0.75]]);
      const sep = t > 27.4;
      const dir = [Math.sin(rot), -Math.cos(rot)];
      const cx = 600, cyy = 430;
      if (!sep) {
        drawRocket(ctx, { x: cx, y: cyy + 150, rot, scale: 0.62, flame: 1 - p(t, 26.9, 27.1), fins: 0 }, t);
      } else {
        const d = 40 * Math.pow(t - 27.4, 1.6) * 3;
        drawRocket(ctx, {
          x: cx - dir[0] * d * 0.15, y: cyy + 150 - dir[1] * d * 0.15, rot, scale: 0.62, part: 'sep', upperOffset: d,
          upperFlame: p(t, 27.8, 28.0), fairing: p(t, 28.2, 29.2, ease.out), boosterRot: p(t, 28.4, 30.2, ease.inOut) * Math.PI, puffs: t > 28.4 && t < 30.2,
        }, t);
      }
      const L = (s, a, b, t0, t1) => { ctx.save(); ctx.globalAlpha = 1 - p(t, t1, t1 + 0.3); callout(ctx, { text: s, anchor: a, at: b, t, t0, color: LABEL, size: 26 }); ctx.restore(); };
      L('gravity turn', [640, 300], [800, 250], 23.6, 26.4);
      L('MECO — main engine cut off', [560, 520], [360, 600], 26.95, 28.2);
      L('stage separation', [620, 360], [820, 400], 27.5, 29.0);
      L('fairing sep', [760, 230], [940, 200], 28.3, 30.4);
      L('booster flip', [560, 400], [330, 330], 28.8, 30.4);
    }

    // ===== I：海上着陆 =====
    if (t >= 30.5 && t < 36.0) {
      ctx.save(); ctx.globalAlpha = p(t, 30.5, 30.9);
      const g = ctx.createLinearGradient(0, 0, 0, 500); g.addColorStop(0, '#7a5ab3'); g.addColorStop(0.5, '#e38a93'); g.addColorStop(1, '#f7c27e');
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, 500);
      starfield(ctx, { seed: 12, count: 30, h: 180, alpha: 0.6 });
      circle(ctx, 930, 505, 70, { fill: '#ffd98f', lw: 0 });
      const og = ctx.createLinearGradient(0, 500, 0, H); og.addColorStop(0, '#3a66b8'); og.addColorStop(1, '#1b2b66');
      ctx.fillStyle = og; ctx.fillRect(0, 500, W, H - 500);
      ctx.fillStyle = 'rgba(255,217,143,0.5)'; for (let i = 0; i < 8; i++) ctx.fillRect(930 - 60 + hash(i, 3) * 30, 515 + i * 14, 120 - i * 10, 3);
      ctx.strokeStyle = 'rgba(200,220,255,0.5)'; ctx.lineWidth = 1.6;
      for (let i = 0; i < 18; i++) { const x = ((hash(i, 1) + 1) / 2 * W + t * 20) % W, y = 530 + (hash(i, 2) + 1) / 2 * 180; ctx.beginPath(); ctx.moveTo(x, y); ctx.quadraticCurveTo(x + 10, y - 5, x + 20, y); ctx.stroke(); }
      // 回收船
      rrect(ctx, 480, 572, 320, 22, { r: 3, fill: '#5d626e', lw: 2, stroke: '#2a2d36', jitter: 0 });
      rrect(ctx, 500, 566, 280, 8, { r: 1, fill: '#8a8f9a', lw: 1.4, stroke: '#2a2d36', jitter: 0 });
      circle(ctx, 640, 570, 26, { fill: null, stroke: '#f2c14e', lw: 2, jitter: 0 });
      const by = kf(t, [[30.6, -180], [33.8, 566, ease.out]]);
      const landed = t > 33.8;
      drawRocket(ctx, { x: 640, y: by, scale: 0.55, part: 'booster', fins: 1, legs: p(t, 32.9, 33.5, ease.backOut), flame: landed ? 0 : 0.9 + 0.1 * Math.sin(t * 40) }, t);
      if (landed) for (let i = 0; i < 8; i++) { const k = p(t, 33.8, 35.2, ease.out); puff(ctx, 640 + (i % 2 ? 1 : -1) * (20 + k * (60 + i * 18)), 560 - k * 10, 10 + k * 22, { fill: '#fbeae4', shade: '#c9a3b4', seed: i + 40, alpha: 1 - k * 0.7 }); }
      callout(ctx, { text: 'landing on a ship at sea', anchor: [690, 560], at: [820, 460], t, t0: 34.1, color: '#fff', size: 26 });
      ctx.restore();
    }

    // ===== J：地球轨道 =====
    const orbitScene = () => {
      spaceBg(ctx);
      const zoom = lerp(0.9, 1.15, p(t, 35.8, 40, ease.inOut));
      camera(ctx, { zoom }, () => {
        const th = t * 0.9, rx = 300, ry = 78, tilt = -0.22, ocx = 640, ocy = 370;
        const pos = a => { const x = Math.cos(a) * rx, y = Math.sin(a) * ry; return [ocx + x * Math.cos(tilt) - y * Math.sin(tilt), ocy + x * Math.sin(tilt) + y * Math.cos(tilt)]; };
        const orbit = (front) => { ctx.save(); ctx.setLineDash([4, 8]); ctx.strokeStyle = 'rgba(255,255,255,0.55)'; ctx.lineWidth = 2; ctx.beginPath(); for (let a = front ? 0 : Math.PI; a <= (front ? Math.PI : TAU) + 0.01; a += 0.05) ctx.lineTo(...pos(a)); ctx.stroke(); ctx.restore(); };
        const sat = () => { const [x, y] = pos(th); ctx.save(); ctx.translate(x, y); ctx.rotate(th + Math.PI / 2 + tilt); rrect(ctx, -8, -20, 16, 40, { r: 3, fill: '#f3f1ec', lw: 2, jitter: 0 }); rrect(ctx, -30, -4, 18, 8, { r: 1, fill: '#4a78c8', lw: 1.4, jitter: 0 }); rrect(ctx, 12, -4, 18, 8, { r: 1, fill: '#4a78c8', lw: 1.4, jitter: 0 }); ctx.restore(); };
        const front = Math.sin(th) > 0;
        orbit(false); if (!front) sat();
        globe(ctx, ocx, ocy, 180, t * 18, t);
        orbit(true); if (front) sat();
      });
      callout(ctx, { text: 'payload: in orbit ✓', anchor: [930, 330], at: [1030, 250], t, t0: 36.6, color: '#fff', size: 26 });
    };
    if (t >= 35.6 && t < 42) {
      const k = p(t, 35.6, 36.1);
      if (t < 39.5) { ctx.save(); ctx.globalAlpha = k; orbitScene(); ctx.restore(); }
      else {
        // ===== K：遮罩收回纸面 =====
        paper(ctx, PAPER);
        line(ctx, [[0, 520], [W, 520]], { lw: 1.4, jitter: 0.6 });
        const hop = t > 40.5 ? Math.abs(Math.sin((t - 40.5) * 5)) * 26 * (1 - p(t, 41.2, 42)) : 0;
        drawTuanzi(ctx, { x: 640, y: 520, scale: 0.95, mood: 'happy', hop, squash: hop > 1 ? -0.15 : 0.05, armL: { angle: -2.5, wave: 9 }, armR: { angle: -0.6, wave: 9 } });
        if (t > 40.5) for (let i = 0; i < 5; i++) sparkle(ctx, 640 + Math.cos(i * 1.26 + t * 0.6) * 130, 360 + Math.sin(i * 1.26 + t * 0.6) * 60, 6 + 3 * Math.sin(t * 5 + i), '#f2c14e');
        const r = lerp(1500, 0, p(t, 39.5, 40.5, ease.in));
        iris(ctx, 640, 330, r, orbitScene, { width: 7, colors: ['#9ad7b5', '#6cbf5a', '#9ad7b5'] });
      }
    }
    grain(ctx, 0.07);
  },
};
