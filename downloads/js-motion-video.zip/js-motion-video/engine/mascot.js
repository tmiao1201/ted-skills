// 原创吉祥物「团子」：薄荷绿麻薯 + 头顶小芽。局部坐标原点在两脚之间的地面。
import { INK, ellipse, circle, line, shape, hash, clamp, lerp, TAU, time } from './core.js';

export const TUANZI = { body: '#9ad7b5', bodyDark: '#77bf9a', blush: '#f5a3a3', sprout: '#6cbf5a' };

// 自动眨眼：返回 0..1（1 = 闭眼）
export function autoBlink(t, seed = 1) {
  const period = 2.6 + (hash(seed, 3) + 1) * 0.8, ph = (t + seed * 0.37) % period;
  return ph < 0.14 ? Math.sin((ph / 0.14) * Math.PI) : 0;
}

/*
 s = {
   x, y, scale=1, flip=false, alpha=1,
   squash: -1..1（正值压扁，负值拉长）,
   look: [dx, dy] 眼珠偏移 -1..1,
   blink: 0..1, mood: 'normal'|'happy'|'surprised'|'focus'|'wow',
   walk: 走路相位（弧度，持续增长即迈步）, hop: 身体离地高度,
   armL / armR: { angle } 以弧度表示的手臂方向，或 { to:[wx,wy] } 伸长手臂到世界坐标,
   holding: (ctx, handX, handY) => void  右手里画的东西（局部坐标）,
   sunglasses: 0..1, sprout: 小芽摆动幅度倍数
 }
*/
export function drawTuanzi(ctx, s) {
  const t = time();
  const { x, y, scale = 1, flip = false, alpha = 1, squash = 0, look = [0, 0], blink = 0, mood = 'normal', walk = null, hop = 0 } = s;
  const c = { ...TUANZI, ...(s.colors || {}) };
  ctx.save();
  ctx.globalAlpha *= alpha;
  ctx.translate(x, y);
  ctx.scale(scale * (flip ? -1 : 1), scale);
  const toLocal = ([wx, wy]) => [((wx - x) / scale) * (flip ? -1 : 1), (wy - y) / scale];

  const sx = 1 + squash * 0.18, sy = 1 - squash * 0.18;
  const bob = walk !== null ? Math.abs(Math.sin(walk)) * 5 : 0;
  const lift = hop + bob;
  const bw = 132 * sx, bh = 104 * sy, bcx = 0, bcy = -18 - bh / 2 - lift;

  // 影子
  ctx.save(); ctx.globalAlpha *= 0.18 * clamp(1 - hop / 200, 0.3, 1); ctx.fillStyle = '#3b2f2a';
  ctx.beginPath(); ctx.ellipse(0, 0, 58 * sx, 8, 0, 0, TAU); ctx.fill(); ctx.restore();

  // 脚
  const footLift = i => (walk !== null ? Math.max(0, Math.sin(walk + i * Math.PI)) * 10 : 0);
  [-1, 1].forEach((d, i) => ellipse(ctx, d * 30 * sx, -9 - footLift(i) - hop, 16, 10, { fill: c.bodyDark, lw: 2.6, seed: 40 + i }));

  // 手臂（先画在身体后面的一侧）
  const shoulder = d => [d * (bw / 2 - 8), bcy + 10];
  const drawArm = (d, arm) => {
    const [sx0, sy0] = shoulder(d);
    let hx, hy, ctrl;
    if (arm && arm.to) {
      [hx, hy] = toLocal(arm.to);
      const mx = (sx0 + hx) / 2, my = (sy0 + hy) / 2, dx = hx - sx0, dy = hy - sy0, len = Math.hypot(dx, dy) || 1;
      const bend = (arm.bend ?? 0.12) * len * d;
      ctrl = [mx - (dy / len) * bend, my + (dx / len) * bend];
    } else {
      const ang = arm?.angle ?? (d > 0 ? 0.9 : Math.PI - 0.9);
      const wave = arm?.wave ? Math.sin(t * arm.wave) * 0.35 : 0;
      const len = arm?.len ?? 34;
      hx = sx0 + Math.cos(ang + wave) * len; hy = sy0 + Math.sin(ang + wave) * len;
      ctrl = [(sx0 + hx) / 2, (sy0 + hy) / 2];
    }
    const pts = [[sx0, sy0], ctrl, [hx, hy]];
    ctx.save(); ctx.lineCap = 'round';
    line(ctx, pts, { stroke: INK, lw: 14, jitter: 0.3, seed: 60 + d });
    line(ctx, pts, { stroke: c.body, lw: 9, jitter: 0.3, seed: 60 + d });
    ctx.restore();
    circle(ctx, hx, hy, 9, { fill: c.body, lw: 2.6, seed: 70 + d });
    return [hx, hy];
  };
  const handR = drawArm(1, s.armR);
  drawArm(-1, s.armL);

  // 身体：圆润麻薯
  const bodyPts = [];
  for (let i = 0; i < 40; i++) {
    const a = (i / 40) * TAU, ca = Math.cos(a), sa = Math.sin(a);
    const e = 2.6; // 超椭圆指数，越大越方
    const rx = Math.sign(ca) * Math.pow(Math.abs(ca), 2 / e) * bw / 2;
    const ry = Math.sign(sa) * Math.pow(Math.abs(sa), 2 / e) * bh / 2 * (sa > 0 ? 1 : 1.04);
    bodyPts.push([bcx + rx, bcy + ry]);
  }
  shape(ctx, bodyPts, { fill: c.body, lw: 3, jitter: 0.8, seed: 5 });
  // 高光
  ctx.save(); ctx.globalAlpha *= 0.45; ctx.fillStyle = '#ffffff';
  ctx.beginPath(); ctx.ellipse(bcx - bw * 0.26, bcy - bh * 0.24, 14, 7, -0.5, 0, TAU); ctx.fill(); ctx.restore();

  // 小芽
  const sway = Math.sin(t * 3.2) * 0.18 * (s.sprout ?? 1) - squash * 0.3;
  ctx.save(); ctx.translate(bcx, bcy - bh / 2 + 2); ctx.rotate(sway);
  line(ctx, [[0, 0], [2, -12], [0, -24]], { stroke: INK, lw: 3, jitter: 0.3, seed: 80 });
  shape(ctx, [[0, -22], [-10, -34], [-24, -32], [-14, -22]], { fill: c.sprout, lw: 2.4, seed: 81 });
  shape(ctx, [[0, -22], [9, -36], [24, -36], [15, -23]], { fill: c.sprout, lw: 2.4, seed: 82 });
  ctx.restore();

  // 脸
  const ex = 24, ey = bcy - 4, lx = look[0] * 5, ly = look[1] * 4;
  ctx.save(); ctx.fillStyle = INK; ctx.strokeStyle = INK; ctx.lineCap = 'round'; ctx.lineWidth = 3.4;
  if (mood === 'happy') {
    [-1, 1].forEach(d => { ctx.beginPath(); ctx.arc(d * ex + lx, ey + 4 + ly, 8, Math.PI * 1.1, Math.PI * 1.9); ctx.stroke(); });
  } else if (s.sunglasses > 0) {
    // 墨镜遮住眼睛，下面单独画
  } else {
    const r = mood === 'surprised' || mood === 'wow' ? 7.5 : 6;
    const open = 1 - clamp(blink);
    [-1, 1].forEach(d => {
      const cx = d * ex + lx, cy = ey + ly;
      if (open < 0.15) { ctx.beginPath(); ctx.moveTo(cx - 6, cy); ctx.lineTo(cx + 6, cy); ctx.stroke(); return; }
      ctx.beginPath(); ctx.ellipse(cx, cy, r * 0.85, r * 1.2 * open, 0, 0, TAU); ctx.fill();
      ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(cx - 1.8, cy - 3 * open, 2, 0, TAU); ctx.fill(); ctx.fillStyle = INK;
      if (mood === 'focus') { ctx.beginPath(); ctx.moveTo(cx - 8 * d, cy - 12); ctx.lineTo(cx + 6 * d, cy - 9); ctx.stroke(); }
    });
  }
  // 腮红
  ctx.globalAlpha *= 0.55; ctx.fillStyle = c.blush;
  [-1, 1].forEach(d => { ctx.beginPath(); ctx.ellipse(d * (ex + 18), ey + 14, 10, 6, 0, 0, TAU); ctx.fill(); });
  ctx.globalAlpha /= 0.55;
  // 嘴
  ctx.lineWidth = 3; ctx.beginPath();
  if (mood === 'surprised' || mood === 'wow') { ctx.ellipse(lx, ey + 18, 5, mood === 'wow' ? 7 : 5, 0, 0, TAU); ctx.fill(); }
  else if (mood === 'happy') { ctx.arc(lx, ey + 12, 9, 0.15 * Math.PI, 0.85 * Math.PI); ctx.stroke(); }
  else { ctx.arc(lx, ey + 12, 5, 0.2 * Math.PI, 0.8 * Math.PI); ctx.stroke(); }
  ctx.restore();

  if (s.sunglasses > 0) {
    const k = clamp(s.sunglasses), drop = (1 - k) * -40;
    ctx.save(); ctx.globalAlpha *= k;
    [-1, 1].forEach(d => shape(ctx, [[d * 8, ey - 9 + drop], [d * 38, ey - 11 + drop], [d * 36, ey + 7 + drop], [d * 10, ey + 8 + drop]], { fill: '#1c1a1f', lw: 2, seed: 90 + d }));
    line(ctx, [[-8, ey - 6 + drop], [8, ey - 6 + drop]], { lw: 3, jitter: 0 });
    ctx.fillStyle = 'rgba(255,255,255,0.55)'; ctx.fillRect(-32, ey - 7 + drop, 8, 3); ctx.fillRect(16, ey - 7 + drop, 8, 3);
    ctx.restore();
  }

  if (s.holding) s.holding(ctx, handR[0], handR[1]);
  ctx.restore();
  return { hand: [x + handR[0] * scale * (flip ? -1 : 1), y + handR[1] * scale] };
}
