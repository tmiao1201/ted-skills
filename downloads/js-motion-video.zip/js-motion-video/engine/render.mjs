#!/usr/bin/env node
// 逐帧渲染：node engine/render.mjs scenes/xxx.js out/xxx.mp4 [--from 0] [--to 10] [--audio bgm.mp3] [--stills 1,5,9] [--serve]
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const ENGINE = path.dirname(fileURLToPath(import.meta.url));
const args = process.argv.slice(2);
const opt = (k, d) => { const i = args.indexOf('--' + k); return i >= 0 ? args[i + 1] : d; };
const flag = k => args.includes('--' + k);
const [sceneArg, outArg] = args.filter((a, i) => !a.startsWith('--') && !args[i - 1]?.startsWith('--'));
if (!sceneArg) { console.log('用法: node engine/render.mjs <scene.js> [out.mp4] [--from s] [--to s] [--audio f] [--stills t1,t2] [--serve]'); process.exit(1); }

const ROOT = process.cwd();
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.mjs': 'text/javascript', '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml', '.json': 'application/json' };
const server = http.createServer((req, res) => {
  let u = decodeURIComponent(new URL(req.url, 'http://x').pathname);
  const file = u.startsWith('/engine/') ? path.join(ENGINE, u.slice(8)) : path.join(ROOT, u);
  fs.readFile(file, (err, buf) => {
    if (err) { res.writeHead(404); return res.end('404 ' + u); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-store' });
    res.end(buf);
  });
});
await new Promise(r => server.listen(+opt('port', 0), r));
const port = server.address().port;
const sceneUrl = '/' + path.relative(ROOT, path.resolve(sceneArg)).split(path.sep).join('/');
const url = `http://localhost:${port}/engine/player.html?scene=${encodeURIComponent(sceneUrl)}`;

if (flag('serve')) { console.log('预览地址:', url); await new Promise(() => {}); }

const { chromium } = await import('playwright');
async function launch() {
  try { return await chromium.launch(); } catch {}
  try { return await chromium.launch({ channel: 'chrome' }); } catch {}
  const os = await import('node:os');
  const cacheDir = path.join(os.homedir(), 'Library/Caches/ms-playwright');
  const found = fs.existsSync(cacheDir) ? fs.readdirSync(cacheDir).filter(d => /^chromium-\d+$/.test(d)).sort().reverse() : [];
  for (const d of found) {
    for (const rel of ['chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing', 'chrome-mac/Chromium.app/Contents/MacOS/Chromium', 'chrome-linux/chrome']) {
      const exe = path.join(cacheDir, d, rel);
      if (fs.existsSync(exe)) try { return await chromium.launch({ executablePath: exe }); } catch {}
    }
  }
  throw new Error('找不到可用的 Chromium，请运行: npx playwright install chromium');
}
const browser = await launch();
const page = await browser.newPage({ viewport: { width: 1400, height: 900 } });
page.on('pageerror', e => console.error('[页面错误]', e.message));
page.on('console', m => m.type() === 'error' && console.error('[console]', m.text()));
await page.goto(url + '&render=1');
await page.waitForFunction(() => window.__ready, null, { timeout: 60000 });
await page.evaluate(() => window.__ready);
const meta = await page.evaluate(() => window.__scene);

const grab = async t => {
  const b64 = await page.evaluate(t => { window.__renderFrame(t); return document.getElementById('c').toDataURL('image/jpeg', 0.95).split(',')[1]; }, t);
  return Buffer.from(b64, 'base64');
};

const stills = opt('stills');
if (stills) {
  const dir = outArg || 'out/stills'; fs.mkdirSync(dir, { recursive: true });
  for (const s of stills.split(',')) { const f = path.join(dir, `${path.basename(sceneArg, '.js')}_${(+s).toFixed(2)}.jpg`); fs.writeFileSync(f, await grab(+s)); console.log(f); }
  await browser.close(); server.close(); process.exit(0);
}

const fps = meta.fps, from = +opt('from', 0), to = +opt('to', meta.duration);
const total = Math.round((to - from) * fps);
const out = outArg || `out/${path.basename(sceneArg, '.js')}.mp4`;
fs.mkdirSync(path.dirname(out), { recursive: true });
const audio = opt('audio');
const ff = spawn('ffmpeg', ['-y', '-loglevel', 'error', '-f', 'image2pipe', '-framerate', String(fps), '-c:v', 'mjpeg', '-i', '-',
  ...(audio ? ['-ss', String(from), '-i', audio, '-shortest', '-c:a', 'aac', '-b:a', '192k'] : []),
  '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-crf', '18', '-preset', 'medium', '-movflags', '+faststart', out], { stdio: ['pipe', 'inherit', 'inherit'] });

const t0 = Date.now();
for (let i = 0; i < total; i++) {
  const buf = await grab(from + i / fps);
  if (!ff.stdin.write(buf)) await new Promise(r => ff.stdin.once('drain', r));
  if (i % fps === 0) process.stdout.write(`\r渲染 ${i}/${total} 帧 (${((Date.now() - t0) / 1000).toFixed(0)}s)`);
}
ff.stdin.end();
await new Promise(r => ff.on('close', r));
await browser.close(); server.close();
console.log(`\n完成 → ${out}  (${total} 帧, ${((Date.now() - t0) / 1000).toFixed(1)}s)`);
