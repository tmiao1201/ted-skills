// 手绘风 Canvas 动画引擎核心：时间/缓动/关键帧、手绘图元、纸张质感、镜头、转场、粒子
export const W = 1280, H = 720;
export const INK = '#3b2f2a';
export const FONT_CN = '"ZCOOL KuaiLe", "Kaiti SC", "STKaiti", "PingFang SC", sans-serif';
export const FONT_EN = '"Caveat", "ZCOOL KuaiLe", cursive';

// ---------- 数学与时间 ----------
export const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
export const lerp = (a, b, k) => a + (b - a) * k;
export const TAU = Math.PI * 2;

export const ease = {
  linear: k => k,
  in: k => k * k * k,
  out: k => 1 - Math.pow(1 - k, 3),
  inOut: k => (k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2),
  expoOut: k => (k === 1 ? 1 : 1 - Math.pow(2, -10 * k)),
  expoInOut: k => (k === 0 || k === 1 ? k : k < 0.5 ? Math.pow(2, 20 * k - 10) / 2 : (2 - Math.pow(2, -20 * k + 10)) / 2),
  backOut: k => { const c = 1.9; return 1 + (c + 1) * Math.pow(k - 1, 3) + c * Math.pow(k - 1, 2); },
  backIn: k => { const c = 1.7; return (c + 1) * k * k * k - c * k * k; },
  elasticOut: k => (k === 0 || k === 1 ? k : Math.pow(2, -10 * k) * Math.sin((k * 10 - 0.75) * (TAU / 3)) + 1),
  bounceOut: k => {
    const n = 7.5625, d = 2.75;
    if (k < 1 / d) return n * k * k;
    if (k < 2 / d) return n * (k -= 1.5 / d) * k + 0.75;
    if (k < 2.5 / d) return n * (k -= 2.25 / d) * k + 0.9375;
    return n * (k -= 2.625 / d) * k + 0.984375;
  },
};

// t 在 [a,b] 区间内的缓动进度 0..1
export const p = (t, a, b, e = ease.inOut) => e(clamp((t - a) / (b - a)));

// 关键帧：kf(t, [[0, 0], [1, 100, ease.out], [2, [1,2]]])，值可为数字或数字数组
export function kf(t, keys) {
  if (t <= keys[0][0]) return keys[0][1];
  for (let i = 1; i < keys.length; i++) {
    const [t1, v1, e = ease.inOut] = keys[i];
    if (t <= t1) {
      const [t0, v0] = keys[i - 1];
      const k = e((t - t0) / (t1 - t0));
      return Array.isArray(v0) ? v0.map((v, j) => lerp(v, v1[j], k)) : lerp(v0, v1, k);
    }
  }
  return keys[keys.length - 1][1];
}

// 确定性哈希噪声 -1..1（保证逐帧渲染可复现）
export function hash(a, b = 0) {
  let h = Math.imul(a | 0, 374761393) + Math.imul(b | 0, 668265263);
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  h ^= h >>> 16;
  return (h >>> 0) / 4294967295 * 2 - 1;
}
export function rng(seed) {
  let s = seed >>> 0;
  return () => { s = (s + 0x6d2b79f5) | 0; let r = Math.imul(s ^ (s >>> 15), 1 | s); r = (r + Math.imul(r ^ (r >>> 7), 61 | r)) ^ r; return ((r ^ (r >>> 14)) >>> 0) / 4294967296; };
}

// 手绘"沸腾"：线条抖动每秒刷新 BOIL_FPS 次，像逐格动画
export const BOIL_FPS = 8;
let boil = 0, now = 0;
export function setTime(t) { now = t; boil = Math.floor(t * BOIL_FPS); }
export const time = () => now;

// ---------- 手绘图元 ----------
function roundRectPts(x, y, w, h, r, step = 16) {
  r = Math.min(r, w / 2, h / 2);
  const pts = [];
  const edge = (x0, y0, x1, y1) => {
    const n = Math.max(1, Math.round(Math.hypot(x1 - x0, y1 - y0) / step));
    for (let i = 0; i < n; i++) pts.push([lerp(x0, x1, i / n), lerp(y0, y1, i / n)]);
  };
  const arc = (cx, cy, a0) => {
    const n = Math.max(2, Math.round(r / 4));
    for (let i = 0; i < n; i++) { const a = a0 + (i / n) * Math.PI / 2; pts.push([cx + Math.cos(a) * r, cy + Math.sin(a) * r]); }
  };
  edge(x + r, y, x + w - r, y); arc(x + w - r, y + r, -Math.PI / 2);
  edge(x + w, y + r, x + w, y + h - r); arc(x + w - r, y + h - r, 0);
  edge(x + w - r, y + h, x + r, y + h); arc(x + r, y + h - r, Math.PI / 2);
  edge(x, y + h - r, x, y + r); arc(x + r, y + r, Math.PI);
  return pts;
}
function ellipsePts(cx, cy, rx, ry, n) {
  n = n || Math.max(16, Math.round((rx + ry) / 3));
  return Array.from({ length: n }, (_, i) => { const a = (i / n) * TAU; return [cx + Math.cos(a) * rx, cy + Math.sin(a) * ry]; });
}
function jitter(pts, amp, seed) {
  if (!amp) return pts;
  return pts.map(([x, y], i) => [x + hash(seed * 131 + i, boil) * amp, y + hash(seed * 97 + i + 7, boil) * amp]);
}
function tracePath(ctx, pts, closed) {
  ctx.beginPath();
  if (pts.length < 3) { ctx.moveTo(...pts[0]); pts.slice(1).forEach(q => ctx.lineTo(...q)); if (closed) ctx.closePath(); return; }
  if (!closed) {
    ctx.moveTo(...pts[0]);
    for (let i = 1; i < pts.length - 1; i++) { const m = [(pts[i][0] + pts[i + 1][0]) / 2, (pts[i][1] + pts[i + 1][1]) / 2]; ctx.quadraticCurveTo(pts[i][0], pts[i][1], m[0], m[1]); }
    ctx.lineTo(...pts[pts.length - 1]);
    return;
  }
  const n = pts.length, mid = i => [(pts[i % n][0] + pts[(i + 1) % n][0]) / 2, (pts[i % n][1] + pts[(i + 1) % n][1]) / 2];
  ctx.moveTo(...mid(0));
  for (let i = 1; i <= n; i++) { const m = mid(i); ctx.quadraticCurveTo(pts[i % n][0], pts[i % n][1], m[0], m[1]); }
  ctx.closePath();
}

// o: { fill, stroke=INK, lw=2.5, jitter=0.7, seed, shadow:true|{x,y,blur,color}, alpha, closed=true, dash }
export function shape(ctx, pts, o = {}) {
  const { fill, stroke = INK, lw = 2.5, closed = true, alpha = 1, dash } = o;
  const js = jitter(pts, o.jitter ?? 0.7, o.seed ?? 1);
  ctx.save();
  ctx.globalAlpha *= alpha;
  ctx.lineJoin = 'round'; ctx.lineCap = 'round';
  tracePath(ctx, js, closed);
  if (fill) {
    if (o.shadow) {
      const s = o.shadow === true ? {} : o.shadow;
      ctx.shadowColor = s.color ?? 'rgba(60,40,30,0.16)'; ctx.shadowBlur = s.blur ?? 14; ctx.shadowOffsetY = s.y ?? 6; ctx.shadowOffsetX = s.x ?? 0;
    }
    ctx.fillStyle = fill; ctx.fill();
    ctx.shadowColor = 'transparent';
  }
  if (stroke && lw > 0) { if (dash) ctx.setLineDash(dash); ctx.strokeStyle = stroke; ctx.lineWidth = lw; ctx.stroke(); }
  ctx.restore();
}
export const rrect = (ctx, x, y, w, h, o = {}) => shape(ctx, roundRectPts(x, y, w, h, o.r ?? 12), o);
export const ellipse = (ctx, cx, cy, rx, ry, o = {}) => shape(ctx, ellipsePts(cx, cy, rx, ry), o);
export const circle = (ctx, cx, cy, r, o = {}) => ellipse(ctx, cx, cy, r, r, o);
export const line = (ctx, pts, o = {}) => shape(ctx, pts, { closed: false, fill: null, ...o });

// 描边逐步画出（铅笔草图 / 标注线）
export function drawOn(ctx, pts, k, o = {}) {
  if (k <= 0) return;
  const lens = [0];
  for (let i = 1; i < pts.length; i++) lens.push(lens[i - 1] + Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]));
  const target = lens[lens.length - 1] * clamp(k), out = [pts[0]];
  for (let i = 1; i < pts.length; i++) {
    if (lens[i] <= target) { out.push(pts[i]); continue; }
    const f = (target - lens[i - 1]) / (lens[i] - lens[i - 1]);
    out.push([lerp(pts[i - 1][0], pts[i][0], f), lerp(pts[i - 1][1], pts[i][1], f)]);
    break;
  }
  if (out.length >= 2) line(ctx, out, { jitter: 0.4, ...o });
}

export function text(ctx, s, x, y, o = {}) {
  const { size = 28, color = INK, font = FONT_CN, align = 'left', baseline = 'middle', weight = '', alpha = 1, rot = 0, stroke } = o;
  ctx.save();
  ctx.globalAlpha *= alpha;
  ctx.translate(x, y); if (rot) ctx.rotate(rot);
  ctx.font = `${weight} ${size}px ${font}`;
  ctx.textAlign = align; ctx.textBaseline = baseline;
  if (stroke) { ctx.lineWidth = stroke.lw ?? 5; ctx.strokeStyle = stroke.color ?? '#fff'; ctx.lineJoin = 'round'; ctx.strokeText(s, 0, 0); }
  ctx.fillStyle = color; ctx.fillText(s, 0, 0);
  ctx.restore();
  return ctx.measureText ? measure(ctx, s, size, font, weight) : 0;
}
export function measure(ctx, s, size = 28, font = FONT_CN, weight = '') {
  ctx.save(); ctx.font = `${weight} ${size}px ${font}`; const w = ctx.measureText(s).width; ctx.restore(); return w;
}

// 打字机：按字数显示
export const typed = (s, t, t0, cps = 14) => Array.from(s).slice(0, Math.max(0, Math.floor((t - t0) * cps))).join('');

// ---------- 纸张与颗粒 ----------
const cache = {};
function paperTex(base) {
  if (cache[base]) return cache[base];
  const c = document.createElement('canvas'); c.width = W; c.height = H;
  const g = c.getContext('2d'), r = rng(7);
  g.fillStyle = base; g.fillRect(0, 0, W, H);
  for (let i = 0; i < 40; i++) {
    const x = r() * W, y = r() * H, rad = 80 + r() * 260;
    const gr = g.createRadialGradient(x, y, 0, x, y, rad);
    gr.addColorStop(0, `rgba(${r() > 0.5 ? '255,255,255' : '120,100,80'},0.05)`); gr.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = gr; g.fillRect(0, 0, W, H);
  }
  for (let i = 0; i < 2600; i++) { g.fillStyle = `rgba(70,55,40,${0.05 + r() * 0.18})`; g.fillRect(r() * W, r() * H, r() * 1.6 + 0.4, r() * 1.6 + 0.4); }
  return (cache[base] = c);
}
export const paper = (ctx, base = '#f3eee4') => ctx.drawImage(paperTex(base), 0, 0);

function grainTex() {
  if (cache.grain) return cache.grain;
  const c = document.createElement('canvas'); c.width = 512; c.height = 512;
  const g = c.getContext('2d'), img = g.createImageData(512, 512), r = rng(3);
  for (let i = 0; i < img.data.length; i += 4) { const v = 128 + (r() - 0.5) * 90; img.data[i] = img.data[i + 1] = img.data[i + 2] = v; img.data[i + 3] = 255; }
  g.putImageData(img, 0, 0);
  return (cache.grain = c);
}
// 全屏胶片颗粒，放在每帧最后
export function grain(ctx, amount = 0.06) {
  const tex = grainTex(), ox = Math.abs(hash(boil, 1)) * 512, oy = Math.abs(hash(boil, 2)) * 512;
  ctx.save(); ctx.globalAlpha = amount; ctx.globalCompositeOperation = 'overlay';
  for (let x = -ox; x < W; x += 512) for (let y = -oy; y < H; y += 512) ctx.drawImage(tex, x, y);
  ctx.restore();
}

// ---------- 镜头与转场 ----------
// 以世界坐标 (x,y) 为画面中心，缩放 zoom，旋转 rot，可叠加 shake
export function camera(ctx, { x = W / 2, y = H / 2, zoom = 1, rot = 0, shake = 0 } = {}, fn) {
  ctx.save();
  const sx = shake * hash(Math.floor(now * 30), 11), sy = shake * hash(Math.floor(now * 30), 12);
  ctx.translate(W / 2 + sx, H / 2 + sy); ctx.scale(zoom, zoom); ctx.rotate(rot); ctx.translate(-x, -y);
  fn();
  ctx.restore();
}
// 以某点为中心缩放局部元素（弹出动画）
export function pop(ctx, cx, cy, s, fn, alpha = 1) {
  if (s <= 0.001 || alpha <= 0) return;
  ctx.save(); ctx.globalAlpha *= alpha; ctx.translate(cx, cy); ctx.scale(s, s); ctx.translate(-cx, -cy); fn(); ctx.restore();
}
// 圆形遮罩（iris）：在圆内绘制 inside，可带彩色光环
export function iris(ctx, cx, cy, r, inside, ring) {
  if (r <= 0) return;
  ctx.save(); ctx.beginPath(); ctx.arc(cx, cy, r, 0, TAU); ctx.clip(); inside(); ctx.restore();
  if (ring) {
    ctx.save();
    const g = ctx.createLinearGradient(cx - r, cy - r, cx + r, cy + r);
    (ring.colors ?? ['#7b6cf6', '#c86dd7', '#6fb7ff']).forEach((c, i, a) => g.addColorStop(i / (a.length - 1), c));
    ctx.strokeStyle = g; ctx.lineWidth = ring.width ?? 6; ctx.beginPath(); ctx.arc(cx, cy, r, 0, TAU); ctx.stroke();
    ctx.restore();
  }
}

// ---------- 装饰与粒子 ----------
export function sparkle(ctx, x, y, r, color = '#fff', rot = 0) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.fillStyle = color; ctx.beginPath();
  for (let i = 0; i < 8; i++) { const a = (i / 8) * TAU, rr = i % 2 ? r * 0.28 : r; ctx.lineTo(Math.cos(a) * rr, Math.sin(a) * rr); }
  ctx.closePath(); ctx.fill(); ctx.restore();
}
export function starfield(ctx, { seed = 1, count = 120, w = W, h = H, x = 0, y = 0, alpha = 1, color = '#fff', size = 1 } = {}) {
  const r = rng(seed);
  ctx.save();
  for (let i = 0; i < count; i++) {
    const sx = x + r() * w, sy = y + r() * h, s = (0.6 + r() * 1.6) * size, ph = r() * TAU, sp = 1 + r() * 3;
    const tw = 0.45 + 0.55 * Math.sin(now * sp + ph);
    ctx.globalAlpha = alpha * tw;
    if (s > 1.9) sparkle(ctx, sx, sy, s * 2.2, color); else { ctx.fillStyle = color; ctx.fillRect(sx, sy, s, s); }
  }
  ctx.restore();
}
// 一团烟/云：多个圆叠加，带底部阴影
export function puff(ctx, x, y, r, { fill = '#fbf1ea', shade = '#e7c9bf', seed = 1, alpha = 1, outline = null } = {}) {
  if (r <= 0) return;
  const rr = rng(seed), lobes = Array.from({ length: 6 }, (_, i) => { const a = (i / 6) * TAU + rr(); return [x + Math.cos(a) * r * 0.55, y + Math.sin(a) * r * 0.35, r * (0.5 + rr() * 0.3)]; });
  lobes.push([x, y, r * 0.7]);
  ctx.save(); ctx.globalAlpha *= alpha;
  if (outline) { ctx.fillStyle = outline; lobes.forEach(([a, b, c]) => { ctx.beginPath(); ctx.arc(a, b, c + 2.5, 0, TAU); ctx.fill(); }); }
  ctx.fillStyle = shade; lobes.forEach(([a, b, c]) => { ctx.beginPath(); ctx.arc(a, b + c * 0.15, c, 0, TAU); ctx.fill(); });
  ctx.fillStyle = fill; lobes.forEach(([a, b, c]) => { ctx.beginPath(); ctx.arc(a - c * 0.08, b - c * 0.1, c * 0.88, 0, TAU); ctx.fill(); });
  ctx.restore();
}

// 标注：从 anchor 画线到 at，然后手写体打出文字
export function callout(ctx, { text: s, anchor, at, t, t0, color = '#fff', size = 26, font = FONT_EN, align }) {
  const k = p(t, t0, t0 + 0.45, ease.out);
  if (k <= 0) return;
  drawOn(ctx, [anchor, at], k, { stroke: color, lw: 1.6, jitter: 0 });
  const al = align ?? (at[0] < anchor[0] ? 'right' : 'left');
  text(ctx, typed(s, t, t0 + 0.35, 22), at[0] + (al === 'right' ? -8 : 8), at[1] - 2, { size, color, font, align: al });
}

// 下落/抛物线：从 a 到 b，arc 为弧高
export function arcPath(a, b, k, h = 120) { return [lerp(a[0], b[0], k), lerp(a[1], b[1], k) - Math.sin(k * Math.PI) * h]; }
