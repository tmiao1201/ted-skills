# 引擎 API 速查（engine/core.js + engine/mascot.js）

画布固定 1280×720（`W`/`H`），场景导出 `{ name, duration, fps, width, height, draw(ctx, t) }`。
`draw` 必须是时间 `t` 的纯函数：随机数一律用 `hash()`/`rng(seed)`，禁止 `Math.random()`，否则逐帧渲染会闪烁。

## 时间
| 函数 | 说明 |
|---|---|
| `p(t, a, b, e=ease.inOut)` | t 在 [a,b] 内的缓动进度 0..1，最常用 |
| `kf(t, [[t0,v0],[t1,v1,ease],...])` | 关键帧插值，值可以是数字或数组 `[x,y]` |
| `ease.{linear,in,out,inOut,expoOut,expoInOut,backOut,backIn,elasticOut,bounceOut}` | 缓动函数 |
| `typed(str, t, t0, cps)` | 打字机效果，返回当前应显示的子串 |
| `arcPath(a, b, k, h)` | 从 a 到 b 的抛物线，k=0..1，h 为弧高 |
| `lerp / clamp / hash(a,b) / rng(seed)` | 工具函数 |

## 手绘图元（公共参数 o）
`o = { fill, stroke=INK, lw=2.5, jitter=0.7, seed, shadow, alpha, dash, closed }`
- 同一个物体固定一个 `seed`，抖动形态才会连贯。
- `rrect(ctx,x,y,w,h,{r,...o})` 圆角矩形 · `circle(ctx,cx,cy,r,o)` · `ellipse(ctx,cx,cy,rx,ry,o)`
- `shape(ctx, pts, o)` 任意闭合多边形（自动做圆滑处理）· `line(ctx, pts, o)` 折线
- `drawOn(ctx, pts, k, o)` 按进度 k 逐步画出线条（草图、标注线）
- `text(ctx, s, x, y, {size,color,font,align,baseline,alpha,rot,stroke})`；`measure(ctx,s,size,font)` 测量文字宽度

## 质感
- `paper(ctx, base)` 纸张背景 · `grain(ctx, amount)` 胶片颗粒，放在最后一步

## 镜头与转场
- `camera(ctx, {x, y, zoom, rot, shake}, fn)`：把世界坐标 (x,y) 放在画面中心
- `pop(ctx, cx, cy, scale, fn, alpha)`：以某点为中心缩放一组元素（弹出、强调）
- `iris(ctx, cx, cy, r, insideFn, {width, colors})`：圆形遮罩，圆内画另一个世界

## 装饰与粒子
- `sparkle(ctx,x,y,r,color)` 四角星 · `starfield(ctx,{seed,count,x,y,w,h,alpha})` 闪烁星空
- `puff(ctx,x,y,r,{fill,shade,seed,alpha})` 一团烟或云（发射烟雾 = 许多 puff 按生成时间外扩）
- `callout(ctx,{text,anchor,at,t,t0,color,size})` 标注：先画引线，再打字

## 团子 drawTuanzi(ctx, s)
原点在两脚之间的地面。返回 `{ hand }`，即右手的世界坐标。
```
{ x, y, scale, flip, alpha,
  squash,            // 正值压扁，负值拉长
  look: [dx, dy],    // 眼珠方向，-1..1
  blink,             // 配合 autoBlink(t, seed)
  mood,              // 'normal' | 'happy' | 'surprised' | 'wow' | 'focus'
  walk,              // 走路相位；传 t*13 就会迈步，传 null 表示站立
  hop,               // 离地高度
  armL, armR,        // { angle, wave, len } 或 { to:[wx,wy], bend } 伸长手臂
  sunglasses,        // 0..1，墨镜落下
  sprout,            // 小芽摆动幅度
  colors }           // 覆盖 TUANZI 配色，可换皮
```

## 渲染命令
```
node engine/render.mjs scenes/x.js --serve [--port 5173]     # 浏览器实时预览（空格播放）
node engine/render.mjs scenes/x.js out/stills --stills 1,4.5,9   # 导出指定时刻的静帧
node engine/render.mjs scenes/x.js out/x.mp4 [--from 3 --to 8]   # 导出 MP4（可只导出一段）
node engine/render.mjs scenes/x.js out/x.mp4 --audio bgm.mp3     # 混入背景音乐
```
速度参考：M 系列 Mac 上 1280×720@30fps，约 1 秒渲染 1–1.5 秒视频。
