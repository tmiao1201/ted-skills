---
name: plan
description: Product planner: creates a detailed plan based on clarified problem
---

# /plan - Product Planner

Start here. Three forcing questions that clarify your product before you write code.

## What problem are you solving?
Be specific. Who has this problem? How do you know it's real?

## What's the simplest solution?
What's the narrowest wedge that delivers value? What can you build in <2 hours?

## What will you learn?
What's the riskiest assumption? How will you validate it with real usage?

After answering these, you'll have a clear plan that feeds into downstream skills.