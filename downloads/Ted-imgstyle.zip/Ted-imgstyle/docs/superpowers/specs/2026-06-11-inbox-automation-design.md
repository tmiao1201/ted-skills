# Ted-imgstyle 入库自动化 loop — 设计文档

日期：2026-06-11
状态：已与用户确认设计，待出实现计划

## 目标

把「inbox 新图 → 解读 → 分类 → 归档 → 回灌风格模板」从手动触发变成每日自动运行的 loop，
用户只负责 review 模板修改。

## 三个核心决策（已确认）

1. **信任边界：归档自动，模板留审。**
   自动化可以解读、分类、把图移入 `reference/<风格>/`（可逆操作）；
   但 `styles/*.md` 是核心资产，自动化只产出 proposal 草稿，合入必须有人在场。
2. **触发方式：launchd 每日定时 headless 运行。**
   不依赖用户开 Claude Code；笔记本睡眠错过后唤醒补跑；inbox 空时秒退零 token。
3. **Review 方式：会话内审核。**
   SessionStart hook 提醒待审数量，用户说「审模板」逐条看 diff 后合入。

## 目录与文件

```
~/cc/Ted-imgstyle/
  automation/
    run-inbox.sh        # launchd 调用的入口脚本
    inbox-prompt.md     # 喂给 headless claude 的固定 prompt
    logs/               # 每次运行的日志（git 忽略）
  proposals/            # 模板回灌草稿，待审
    done/               # 审核完成后归档
  state.md              # loop memory：日期/图片/归档位置/proposal/状态
  docs/superpowers/specs/   # 设计文档
```

新增系统文件：

- `~/Library/LaunchAgents/com.tedmiao.ted-imgstyle-inbox.plist` —
  `StartCalendarInterval` 每天 09:00
- 升级 `~/.claude/hooks/ted-imgstyle-inbox-check.sh`（见下）

## 组件

### run-inbox.sh（loop 躯干）

1. 扫 `inbox/` 下图片文件（png/jpg/jpeg/webp/gif，排除 `.obsidian/`），无图则 `exit 0`
2. 锁文件防并发（已有锁且进程存活则退出）
3. `cd ~/cc/Ted-imgstyle && claude -p "$(cat automation/inbox-prompt.md)"`，
   工具白名单限定：Read / Write / Edit / Glob / Grep / `Bash(mv:*)`，不开全局 skip-permissions
4. 运行输出写 `automation/logs/YYYY-MM-DD.log`
5. 结束后 `git add -A && git commit`（消息含当日入库数量）

### inbox-prompt.md（loop 脑子）

执行 Ted-imgstyle skill 的入库流程，附加硬约束：

- **禁止修改 `styles/*.md`**；回灌内容写成 `proposals/YYYY-MM-DD-<风格>.md`，
  内容为对应风格模板的增量修改建议（引用原文 + 建议新增/修改段落）
- 分类置信度低的图**留在 inbox 不动**，在当日 proposal 中标注「需人工分类」及原因
- 每张图的处理结果追加到 `state.md`：日期、文件名、判定风格、归档路径、proposal 文件、状态
- 永不触碰 `inbox/.obsidian/`

### SessionStart hook（提醒层）

两段式提醒：

1. `proposals/` 根目录有待审文件 → 「有 N 个模板 proposal 待审，说『审模板』开始」
2. `inbox/` 仍有图（定时未跑成 / 标记需人工分类）→ 保留现有「入库」提醒作为兜底

### 审核流程（会话内，maker/checker 分离）

用户说「审模板」→ 逐条展示 proposal 与现有 `styles/*.md` 的对比 →
用户确认后合入 → proposal 移入 `proposals/done/`。
`styles/` 只在有人在场的会话中被修改。

## 错误处理

- claude 运行失败/超时：图留在 inbox，日志留存，次日定时重试 + SessionStart 提醒兜底
- 分类不确定：不归档、不猜，留给人
- 并发：锁文件
- 回滚：git 历史（本设计包含 `git init` + `.gitignore`：`.DS_Store`、`inbox/.obsidian/`、`automation/logs/`）

## Token 成本

每天最多一次运行；每张图约一次 vision 解读 + proposal 写作；inbox 空时 shell 直接退出，零成本。

## 验收标准

1. 用 inbox 现有 3 张图真实跑一轮 `run-inbox.sh`：
   图归档到正确的 `reference/<风格>/`、proposal 生成、`styles/` 一字未动、`state.md` 有记录、git 有 commit
2. `launchctl kickstart` 验证 launchd 调度可用
3. 新开 Claude Code 会话：hook 正确提示待审数量，「审模板」流程走通一条
