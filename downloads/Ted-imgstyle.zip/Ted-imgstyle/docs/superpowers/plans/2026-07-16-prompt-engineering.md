# Ted-imgstyle Prompt 工程层实现计划

> **面向 AI 代理的工作者：** 必需子技能：使用 superpowers:subagent-driven-development（推荐）或 superpowers:executing-plans 逐任务实现此计划。步骤使用复选框（`- [ ]`）语法来跟踪进度。

**目标：** 在保持 A–M 视觉风格 DNA 不变的基础上，增加统一、可验证的 Prompt 工程层。

**架构：** `SKILL.md` 保持为入口和工作流；新建的公共参考文件承载跨风格 Prompt 输出契约；12 个 `styles/*.md` 只保存各自的工程控制差异。先用 B/H/M 场景建立基线，再用同一场景验证改造后的输出。

**技术栈：** Markdown、`rg`、`wc`、Codex 子智能体评估、`apply_patch`。

**版本控制说明：** `/Users/tedmiao/cc/Ted-imgstyle` 当前不是 Git 仓库；本计划不创建提交、不初始化仓库。

---

## 文件结构

- 创建：`reference/gpt-image-prompt-engineering.md` — 跨 A–M 的 Prompt 输出契约、控制块、文本/参考图/系列协议与 QA。
- 修改：`SKILL.md` — 主流程指向公共规范，定义最终交付的五段式结构，补充入库溯源原则。
- 修改：`styles/A-handdrawn-sketch.md` — 手绘素描的工程控制。
- 修改：`styles/B-dark-blueprint.md` — 工程蓝图的工程控制。
- 修改：`styles/C-blue-ballpoint.md` — 单色钢笔的工程控制。
- 修改：`styles/D-marker-whiteboard.md` — 中文白板的工程控制。
- 修改：`styles/E-mascot-comic.md` — 吉祥物漫画的工程控制。
- 修改：`styles/F-xiaohongshu-collage.md` — 拼贴信息图的工程控制。
- 修改：`styles/G-editorial-bw.md` — 编辑信息图的工程控制。
- 修改：`styles/H-flat-vector.md` — 流程图的工程控制。
- 修改：`styles/J-asian-handnote.md` — 亚洲手账的工程控制。
- 修改：`styles/K-serif-blueprint.md` — 工程档案的工程控制。
- 修改：`styles/L-dark-serif-hero.md` — 发布 Hero 的工程控制。
- 修改：`styles/M-evidence-dossier-collage.md` — 证据档案拼贴的工程控制。
- 创建：`docs/superpowers/plans/2026-07-16-prompt-engineering.md` — 本实施计划。

### 任务 1：建立三组生图 Prompt 的基线评估

**文件：**
- 读取：`SKILL.md`
- 读取：`styles/B-dark-blueprint.md`
- 读取：`styles/H-flat-vector.md`
- 读取：`styles/M-evidence-dossier-collage.md`
- 不写入工作区；评估结果留在会话记录中。

- [ ] **步骤 1：准备三个固定评估输入**

```text
B：绘制一个 Agent 故障恢复架构图：4 层模块、一个失败回环、主色橙和辅色青。
H：绘制一个多工具内容生产流程图：6 个节点、1 个判断菱形、yes/no 分支、1 条循环、底部图例。
M：绘制一个研究证据链：左侧 3 个来源、中间 4 步核验、右侧档案柜，蓝/橙/红三类颜色职责明确。
```

- [ ] **步骤 2：在不加载新公共规范的独立智能体中运行三组输入**

每个智能体只读取当前 `SKILL.md` 和对应风格模板，然后生成一组生图交付。记录是否缺失：`Creative brief`、`Text manifest`、`Control block`、数量约束、流程关系、禁止项。

- [ ] **步骤 3：确认基线按预期失败**

预期：至少一个场景没有将元素数量/连线关系单列为可核验控制项，且至少一个场景没有完整的五段式交付。若所有场景已经满足，修改评估输入，使其需要参考图优先级或成套图锁定后再运行。

### 任务 2：创建公共 Prompt 工程规范

**文件：**
- 创建：`reference/gpt-image-prompt-engineering.md`

- [ ] **步骤 1：写入文档的顶层导航与适用范围**

```markdown
# GPT Image Prompt 工程规范

适用于用户已选定 A–M 风格、需要为 nanobanana 或 GPT Image 2 生成单图、信息图、参考图编辑或成套分镜时。

不用于：风格判定、未经核验的事实性榜单，或将外部作品逐像素复刻。
```

- [ ] **步骤 2：实现五段式输出契约**

```markdown
## 输出契约

始终输出：Creative brief、English prompt、Text manifest。
在有固定数量、连接关系、保真要求或禁止项时，输出 Control block。
在两张及以上且需要统一视觉时，输出 Series lock。
```

其中 English prompt 的固定顺序必须逐字写为：`Style anchor → Goal → Canvas → Layout → Main elements → Visual treatment → Constraints → Negative constraints`。

- [ ] **步骤 3：实现控制块、文字预算和参考图协议**

```markdown
## Control block

- Exact count：只锁定可核验的节点、卡片、人物或物件数量。
- Relationship：逐条写明 A → B、分支条件和回环方向。
- Preservation：引用图仅可指定身份、产品、构图或风格中的一个主角色；第二角色必须写优先级。
- Exclusions：列出额外面板、伪文字、水印、未授权 logo 或不需要角色等禁止项。
```

补齐以下两条硬规则：事实性文字只接受用户提供或已核验的信息；每个文字区只承担标题、标签、说明或来源中的一种角色。

- [ ] **步骤 4：实现系列锁定与 QA 清单**

```markdown
## Series lock

锁定：风格锚点、比例、色板、字体气质、线条/材质与固定 IP/产品保真要求。
可变：主题、主体、流程节点、局部图标、标题和 Text manifest。
```

QA 清单必须检查：风格来源、画布、读图顺序、文字逐字性、数字/关系、禁止项、参考图角色、事实来源、系列锁定是否按条件触发。

- [ ] **步骤 5：静态验证公共规范**

运行：

```bash
rg -n '^## (输出契约|Control block|参考图协议|Series lock|QA)' reference/gpt-image-prompt-engineering.md
```

预期：列出五个对应章节；文件中不出现 `YouMind`、自动抓取或具体模型排行榜。

### 任务 3：让主 Skill 使用公共规范与输出契约

**文件：**
- 修改：`SKILL.md`
- 读取：`reference/gpt-image-prompt-engineering.md`

- [ ] **步骤 1：在目录结构中加入 `reference/`**

```markdown
├── reference/          # 跨风格的 Prompt 工程规范，按需读取
│   └── gpt-image-prompt-engineering.md
```

- [ ] **步骤 2：扩充流程二第 3 步的交付字段**

将原来的三项交付替换为以下结构：

```markdown
- **Creative brief**：核心目标、画布比例与读图顺序。
- **English prompt**：遵循 `reference/gpt-image-prompt-engineering.md` 的固定顺序。
- **Text manifest**：图中文字逐字列出，注明位置与层级。
- **Control block**：仅在数量、关系、保真或禁止项重要时输出。
- **Series lock**：仅在两张及以上且需要统一视觉时输出。
```

- [ ] **步骤 3：增加按需读取与入库溯源规则**

在生图流程开始前加入：选定风格后读取公共规范；若无固定元素数量、参考图或系列一致性要求，不生成冗余的 Control block / Series lock。

在入库流程的第 5 步后加入：用户提供外部灵感来源时，记录平台、作者、原链接、许可/未知和本次吸收的可复用要素；不得推断许可或复制外部图像。

- [ ] **步骤 4：静态验证入口链接与术语一致性**

运行：

```bash
rg -n 'gpt-image-prompt-engineering|Creative brief|Text manifest|Control block|Series lock|许可/未知' SKILL.md
```

预期：五段输出和溯源规则各有一处清晰入口。

### 任务 4：为 B、H、K、M 写入高结构密度工程控制

**文件：**
- 修改：`styles/B-dark-blueprint.md`
- 修改：`styles/H-flat-vector.md`
- 修改：`styles/K-serif-blueprint.md`
- 修改：`styles/M-evidence-dossier-collage.md`

- [ ] **步骤 1：在每个文件的“注意 / 负面”之前增加 `## 工程控制`**

使用以下精确内容方向：

```markdown
### B
- 阅读方向：上→下分层或中心→四周放射，二选一。
- 文本预算：标题 ≤ 8 个英文词；模块标签 1–3 个词；中文只保留必要术语。
- 锁定：黑底、橙主青辅、mono 字、虚实箭头语法。
- Control block 必写：层数、模块数、失败回环、图例是否存在。

### H
- 阅读方向：左→右或上→下，必须在 brief 中说明。
- 文本预算：节点名 ≤ 6 个字或 3 个英文词；每个边最多一个条件。
- 锁定：圆角矩形、菱形判断、扁平蓝绿、无手绘抖动。
- Control block 必写：节点数、判断数、分支、循环、图例。

### K
- 留白：主画布至少保留一个完整空白区，不以装饰补满。
- 锁定：米白、单一蓝细线、衬线标题、档案页眉/页脚。
- 禁止：高饱和卡片阵列、粗重多色箭头、密集正文。

### M
- 固定阅读方向：左来源 → 中核验 → 右知识资产。
- 文本预算：每张来源卡 3–5 个短字段；红章仅 1–2 个。
- 锁定：蓝=来源、橙=主流程、红=风险/验证、黑墨=系统主体。
- Control block 必写：来源数、核验步数、柜体抽屉数和发布出口数。
```

- [ ] **步骤 2：确认工程控制不替代原有视觉特征或变体**

运行：

```bash
for f in styles/B-dark-blueprint.md styles/H-flat-vector.md styles/K-serif-blueprint.md styles/M-evidence-dossier-collage.md; do rg -n '^## (视觉特征|English Prompt 模板|工程控制|注意 / 负面)' "$f"; done
```

预期：四个文件仍保留原有章节，且每个文件恰有一个 `工程控制`。

### 任务 5：为其余八种风格写入简短工程控制

**文件：**
- 修改：`styles/A-handdrawn-sketch.md`
- 修改：`styles/C-blue-ballpoint.md`
- 修改：`styles/D-marker-whiteboard.md`
- 修改：`styles/E-mascot-comic.md`
- 修改：`styles/F-xiaohongshu-collage.md`
- 修改：`styles/G-editorial-bw.md`
- 修改：`styles/J-asian-handnote.md`
- 修改：`styles/L-dark-serif-hero.md`

- [ ] **步骤 1：为每个文件插入 3–4 条工程控制**

必须满足下面的风格差异，且每段不超过 8 行：

| 风格 | 工程控制重点 |
|---|---|
| A | 横向读图、橙色仅作高亮、每区一句短结论、禁止规整 UI 卡片 |
| C | 单一隐喻、单色蓝、标题与 2–4 个标签、禁止多面板信息墙 |
| D | 网格卡片数量、每卡短术语、中文手写可读性、禁止超长段落 |
| E | 固定角色卡、分镜数、每格一句情绪/行动、禁止角色漂移 |
| F | 标题/副标题/卡片层级、竖图安全边距、emoji 限量、禁止证据档案感 |
| G | 报刊栏数、大数字和图注职责、留白、禁止高饱和社媒贴纸 |
| J | 竖向 Q&A/清单结构、每段短手写句、荧光高亮限量、禁止正文墙 |
| L | 16:9 Hero、标题/产品/统计三层、橙强调唯一、禁止多卡片拼贴 |

- [ ] **步骤 2：批量验证工程控制覆盖**

运行：

```bash
rg -l '^## 工程控制' styles/*.md | wc -l
```

预期：输出 `12`。

- [ ] **步骤 3：检查风格文件没有被公共规范重复淹没**

运行：

```bash
for f in styles/*.md; do wc -l "$f"; done
```

预期：每个风格文件只增加简短控制段；不复制公共规范的五段式全文。

### 任务 6：运行改造后的三组应用验证

**文件：**
- 读取：`SKILL.md`
- 读取：`reference/gpt-image-prompt-engineering.md`
- 读取：`styles/B-dark-blueprint.md`
- 读取：`styles/H-flat-vector.md`
- 读取：`styles/M-evidence-dossier-collage.md`
- 不写入工作区；结果留在会话记录中。

- [ ] **步骤 1：用任务 1 的同一 B/H/M 输入，在三个独立智能体中重新生成交付**

每个智能体必须读取新的公共规范、主 Skill 和对应风格模板。

- [ ] **步骤 2：按固定断言逐项核验**

```text
B：有 Creative brief、English prompt、Text manifest、Control block；Control block 中有 4 层、失败回环、橙主青辅和禁止额外面板。
H：有五段交付；Control block 中有 6 节点、1 菱形、yes/no、1 循环、图例；箭头关系没有遗漏。
M：有五段交付；Control block 中有 3 来源、4 核验步骤、档案柜；文字清单没有捏造来源或无法阅读的长段落。
```

- [ ] **步骤 3：复核条件输出没有被滥用**

用一个单张、无固定数量、无参考图的 A 风格输入再测一次。预期：只输出 Creative brief、English prompt、Text manifest，不输出空的 Control block 或 Series lock。

### 任务 7：最终静态检查与规格对照

**文件：**
- 读取：`docs/superpowers/specs/2026-07-16-prompt-engineering-design.md`
- 读取：`SKILL.md`
- 读取：`reference/gpt-image-prompt-engineering.md`
- 读取：`styles/*.md`

- [ ] **步骤 1：运行文件与术语检查**

运行：

```bash
test -f reference/gpt-image-prompt-engineering.md
rg -n 'gpt-image-prompt-engineering|Creative brief|Text manifest|Control block|Series lock' SKILL.md
test "$(rg -l '^## 工程控制' styles/*.md | wc -l | tr -d ' ')" = '12'
```

预期：三个命令均退出 0。

- [ ] **步骤 2：运行范围保护检查**

运行：

```bash
rg -n 'YouMind|自动抓取|12,895|12,895 条' SKILL.md reference styles || true
```

预期：没有输出，证明没有将外部仓库变成运行依赖或硬编码资料库。

- [ ] **步骤 3：逐项对照设计规格验收清单**

逐项确认规格中的 5 项验收条件均有对应证据：主 Skill 入口、公共规范章节、12 个控制段、B/H/M 应用验证、无新增依赖/风格/原图改动。
