# D · 彩色马克笔·中文白板信息图（Colored Marker Whiteboard）

> 一句话：白底上用彩色马克笔画的"中文术语卡片墙"，N 个概念整齐并列成网格，每个配小图标 + 手写体，sketchnote 风。

## 视觉特征

- **背景**：纯白 / 极浅底。
- **配色**：多彩但柔和的马克笔色（彩虹色系但低饱和、不刺眼），每个卡片/概念用不同色区分；黑色手写线。
- **线条**：手绘 sketchnote 线 + 手绘圆角卡片框 / 虚线分隔。
- **字体**：标题手写粗体（中英混排），编号常用彩色圆圈①②③；正文小号手写中文。
- **构图**：**规整网格**——一张图并列 5/12/20 个概念，每格 = 编号 + 标题 + 小图标 + 一句中文解释。顶部一个手绘大标题横幅。
- **图标**：彩色简笔涂鸦图标，每概念一个，活泼。
- **气质**：中文知识科普、"一张图看懂 N 个术语"、信息密度高但因网格而清爽。

## 适合内容
中文术语表 / 概念合集（"AI 入门 20 个核心概念""大模型常见术语一览"），多个并列知识点，需要中文友好 + 信息全 + 不显乱。

## English Prompt 模板

```
A colorful hand-drawn sketchnote infographic on a white background, marker-pen style.
A neat grid of {{N}} concept cards, each card = a colored number circle + a bold
hand-written title + a small doodle icon + one short explanatory line. Soft rainbow
marker palette (low-saturation), black hand-drawn outlines, rounded card borders /
dashed separators. A big hand-drawn title banner at the top.

Cards content: {{逐格内容，例：①Context Window ②Tokenization ③RAG ... each with its
icon and one-line explanation}}.

Style keywords: sketchnote, marker infographic, white background, grid of cards,
colorful doodle icons, hand-written, friendly, educational, high but tidy density.

Aspect ratio: {{16:9 横图（多列网格）/ 3:4 竖图}}.
```

## 图中文字（单独逐字给模型）
- 大标题横幅：`{{标题，如 "AI 入门 20 个核心概念"}}` + 副标题 `{{一张图看懂大模型常见术语}}`
- 每格：编号 `①…` + 术语 `{{中文/英文术语}}` + 一句解释 `{{≤15字}}`
- **中文是这个风格的主场**，可放心用中文手写体；但因卡片多、字多，务必每格解释精简，标题给全列表让模型逐格渲染。

## 变体
- **彩色满格版**（IMG_5752 / IMG_5798）：每格底色不同，活泼饱满。
- **铅笔+橙点缀版**（IMG_5753 AI Agent 速览）：偏黑白铅笔素描 + 橙色强调，更冷静；介于本类与 A 类之间，按"中文网格信息图"归此类。

## 注意 / 负面
- 与 A 区别：A 是米黄纸 + 单一橙强调、英文为主、信息少；D 是白底 + 多彩、中文为主、网格密集。
- 与 F 区别：F 是小红书高饱和拼贴 + emoji + 强对比；D 更"白板手写"、克制、教学感。
- 网格要对齐工整，别堆叠；文字虽多但每格短。

## 样例图（reference/D-marker-whiteboard/）
- `IMG_5798.JPG` — AI 入门 20 个核心概念（4×5 彩色网格）
- `IMG_5752.PNG` — AI 词汇一览表（密集彩色网格）
- `IMG_5753 2.JPG` — AI Agent 概念速览（铅笔+橙点缀变体，Model+Scaffold+Harness）
