# A · 米黄纸·手绘素描风（Hand-drawn Sketch on Cream Paper）

> 一句话：像在米黄色草稿纸上用铅笔 + 马克笔随手画的解读图，亲切、不正式、信息清楚。Ted 库里最大的一类。

## 视觉特征

- **背景**：米黄/奶白色纸质底（cream / off-white paper texture），偶有横线笔记本纸纹。
- **线条**：黑色手绘线，粗细不匀、带轻微抖动（hand-drawn, slightly wobbly ink lines），图标是简笔涂鸦风。
- **质感**：铅笔排线阴影（pencil hatching / cross-hatching），物体有手绘投影。
- **配色**：以黑白为主 + **暖橙色作为唯一强调色**（标题下划线、箭头、高亮）。少量柔和粉/绿/蓝点缀（马克笔淡彩）。
- **字体**：标题常是粗手写体或粗无衬线（marker / bold sans）；正文小号手写感字体。关键词用橙色波浪/直线**手绘下划线**强调。
- **构图**：常见"左大标题 + 右图解"、"横向流程箭头串联 N 个步骤"、"中心放射"。箭头是手绘箭头。
- **图标**：极简涂鸦图标（文件夹、终端窗、大脑、灯泡、齿轮、地球），统一黑线 + 偶尔单色填充。
- **气质**：knowledge worker 友好、英文为主（也可中文）、像聪明人的随手白板讲解。

## 适合内容
流程讲解（A→B→C）、概念入门、工具科普、"我是怎么搭建 X 的"、前后对比表。信息量中等、希望显得亲切不端着时首选。

## English Prompt 模板

```
A hand-drawn sketch-style infographic on a cream / off-white paper background with
subtle paper texture. Black hand-drawn ink lines with a slightly wobbly, doodled feel,
pencil hatching for light shading. Single warm-orange accent color used only for
title underlines, arrows and highlights. Clean generous white space.

Layout: {{布局，例：a big bold hand-written title on the left, and on the right a
horizontal flow of 3–6 simple doodle icons connected by hand-drawn arrows}}.

Main elements: {{要画的主体/隐喻/图标，例：a folder labeled "vault", a chat window,
a brain made of connected nodes}}.

Style keywords: hand-drawn, sketchnote, doodle icons, marker title, orange highlight
underline, cream paper, friendly, lots of whitespace, flat 2D, no photorealism.

Aspect ratio: {{16:9 横图 / 1:1 方图}}.
```

## 图中文字（单独逐字给模型）
- 标题：`{{标题文字}}`（粗手写体，放左上 / 顶部居中，下方加橙色手绘下划线）
- 标签：`{{标签1}}` `{{标签2}}` …（手写小字，放在对应图标下方）
- 该风格英文标题效果最稳；中文标题也可，但用手写体且尽量短。

## 变体
- **记事本纸变体**：换成淡蓝横线笔记本纸背景（如"Install Node.js 三步"那张），步骤用彩色圆角框分区（蓝/橙/绿）。
- **中文+品牌色变体**：米黄底黑色手绘 + 单一品牌色马克笔（如 Codex GOAL 那张用蓝色），适合中文标题党选题。
- **技术教学组图变体**：AI/agent 类教学逐字稿拆成成组分镜时用。**英文锁术语 + 中文短标签**混排（标题/术语用英文最稳：`Progressive Disclosure`、`EDD`、`description`；叙述性标签用中文压到一行）。统一 16:9 成组。常用可复用版式：①封面=居中大标题+橙下划线+单一主视觉隐喻+3 个橙色小标签；②三件套=左大图标 + 右三张并列 doodle 卡片；③分层金字塔/漏斗（配侧向橙箭头标"逐层加载"）；④双路径对比（虚线分隔左右面板 + 底部橙色横幅放进阶 tip）；⑤三栏"坑→解法"对照（每栏顶 pothole 图标 + 橙箭头向下指 checkmark，文字务必压短，挤就拆成单图）；⑥飞轮循环箭头 + 两气泡 callout + 底部清单。信息最密的对照栏若拥挤，改 1:1 方图或拆单图重生。

- **写实炭笔肖像变体**（GBrain 那张）：米黄底 + 手绘涂鸦保持，但人物换成**写实炭笔/铅笔素描肖像**（charcoal portrait）+ 手写签名，配红/绿双色强调和圆形图标，适合"问题 → 解决方案 + 人物背书"叙事。注意这是唯一允许出现写实质感的地方（仅限肖像）。

- **超宽循环教学版**（LOOPS 那张）：纯白 / 淡奶白纸底，21:9 左右的超宽横幅。中心放一个超大手写核心词，周围用 6–10 个黑线圆角小卡组成闭环，卡内只放一个涂鸦图标和 1–2 个英文短词；用暖橙色细箭头串起完整循环。左右可各放一张“旧方式 / 循环方式”对照卡，顶部排少量品牌 logo，底部用一句手写结论收束。整体比常规 A 更稀疏，只保留黑线、白纸和橙色下划线，适合 agent loop、工作流闭环、迭代方法论。

## 工程控制
- 默认按横向 16:9 从左到右读图；已选记事本纸、写实炭笔肖像或超宽循环教学变体时，以该变体的主导构图为准。
- 默认仅以暖橙作高亮；中文品牌色、写实炭笔肖像和记事本纸变体按既有变体允许的色彩例外执行。
- Text manifest 中每个分区只放一句短结论；固定步骤、循环节点或对照关系时，在 Control block 写明数量与关系。
- 默认在 English prompt 的 Negative constraints 写 `do not include regular UI cards`；只有用户明确要求逐项核验该排除项时，才在 Control block 重复列出。技术教学组图与超宽循环变体仅可使用既有的 doodle 卡片构图。

## 注意 / 负面
- 不要写实照片质感、不要 3D、不要渐变光影；保持"草稿纸涂鸦"廉价亲切感（写实肖像变体例外，仅人物用炭笔素描）。
- 强调色克制——**只用一种**暖橙（或单一品牌色），多了就乱。
- 文字别太密；密集信息改用 D（彩色白板）或 F（小红书）。

## 样例图（reference/A-handdrawn-sketch/）
- `HI4Z7y_WMAAWY-g.jpeg` — Obsidian Vault → Claude → Thinking Model（三段式 + 橙箭头）
- `HJKP9sEX0AA_gun.jpeg` — How I Set Up Claude Code as Investment Analyst（横向 7 步流程）
- `HJMKIrhX0AAYMXd.jpeg` — How to Make Money With Claude（左标题 + 右放射图标）
- `HJOQrQSa4AALvQ7.jpeg` — Claude Code 101（左标题 + 右涂鸦元素 + 徽章）
- `HJORYbEbsAAMi-Z.jpeg` — Before/After 时间对比（红/绿手绘条形）
- `HJOSfZjaUAAF8v-.jpeg` — Install Node.js 三步（记事本纸变体）
- `HJPdN7yWAAAC1yk.jpeg` — Obsidian INPUTS → Full System（四段式）
- `HJQ6D0YbUAAeZdc.jpeg` — Claude + YouTube = $（白底极简公式式）
- `HJQilhTakAk062V.jpeg` — Codex GOAL 来了（中文 + 蓝色品牌色变体）
- `HHuHt7dbUAA0FwH.jpeg` — 「ゼロから始める .claude構築」（日文标题 + 橙色像素 IP 抱 .claude/ 盒子，封面式 A）
- `HJaHDDGWoAAP4w9.jpeg` — THE OLD WAY → THE AGENT WAY（黑线描机器人 + 橙色 ×8/85% 喷溅强调，横向流程）
- `HJbAkEQbEAAVEzT.jpeg` — RAG 32x Memory Efficient（火柴人 + 手绘 vector 方块 + 红色强调，前后对比）
- `HJf4w7eboAAHYWO.jpeg` — GBrain: THE PROBLEM/THE SOLUTION（米黄底 + 名人写实炭笔肖像 + 红绿强调，写实肖像变体）
- `HJ2T-PaaUAA2t96.jpeg` — Codex 更新汇总 2026.06（中文标题 + 英文副标 + 橙强调；**顶部 5 个统计卡 + 下方三栏分区**仪表盘式版式：01 角色插件 / 02 Sites / 03 Annotations，每栏内嵌涂鸦图标小卡，底部橙色关键词条）
- `HLQR6x3WgAAoX0v.jpeg` — Everything you need to know: LOOPS（超宽循环教学版：中心大词 + 8 个闭环节点卡 + 左右对照卡 + 橙色箭头与下划线）
