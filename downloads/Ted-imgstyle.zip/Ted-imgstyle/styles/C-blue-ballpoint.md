# C · 单色蓝·钢笔手绘风（Blue Ballpoint Sketch）

> 一句话：全图只用一种蓝色圆珠笔/钢笔在白纸上速写，靠排线明暗，做一个干净的单一隐喻图。

## 视觉特征

- **背景**：纯白 / 极浅白纸。
- **配色**：**单色蓝**（ballpoint blue / ink blue，#2f4fd0 类）一种颜色到底，靠线条疏密表现明暗，无第二色。
- **线条**：钢笔/圆珠笔排线（cross-hatching）塑造体积，手绘感强但比 A 更"工整专注"。
- **构图**：通常一个**核心大隐喻**占满画面（冰山、金字塔、树、河流），周围标注分层文字标签。
- **图标**：蓝色线描小图标贴在标签前。
- **气质**：专注、单点说透一个概念、克制优雅，像高质量手账速写。

## 适合内容
单一强隐喻的概念图——"冰山：看得见的 5% vs 看不见的 95%"、分层金字塔、成长树。一张图讲透一个比喻时首选。

## English Prompt 模板

```
A monochrome blue ballpoint-pen sketch on white paper. Entire illustration drawn in a
single ink-blue color (#2f4fd0), shading done purely with hand-drawn cross-hatching,
no other colors. Clean, focused, hand-drawn but tidy.

Central metaphor: {{核心隐喻，例：a large iceberg, tip above the waterline labeled
"the visible 5%", huge mass below labeled "95% invisible"}}.

Around it: {{标注，例：a vertical list of labeled line-icon items along the underwater
part}}.

Style keywords: monochrome blue, ballpoint pen, cross-hatching, white paper, single
big metaphor, hand-drawn, minimal, elegant.

Aspect ratio: {{3:4 竖图（隐喻多为竖向）}}.
```

## 图中文字（单独逐字给模型）
- 标题：`{{标题}}`（手写蓝字，常带一个手绘箭头指向主体）
- 分层标签：`{{标签 + 小字说明}}`（沿隐喻主体排列）
- 水印：`{{brand}}`（左下角蓝色小 logo）
- 中英皆可，蓝色手写体；标签短。

## 变体
- 目前库里仅 1 张（冰山）。若后续出现金字塔/树等其它单一隐喻的蓝色速写，同归此类并在此补充。

## 工程控制
- Creative brief 只确定一个核心隐喻，所有标签均依附该主体，不扩展为多面板叙事。
- 全图只能使用单色蓝墨；不得加入第二强调色、彩色填充或暗底。
- Text manifest 只列一个标题与 2–4 个短标签；固定标签数或标签与主体的位置关系时，在 Control block 写明。
- 默认在 English prompt 的 Negative constraints 写 `do not include a multi-panel information wall`；只有用户明确要求逐项核验该排除项时，才在 Control block 重复列出。

## 注意 / 负面
- 严格单色——出现第二种强调色就不是这个风格了。
- 不要彩色、不要暗底、不要写实；保持"一支蓝笔画完"。

## 样例图（reference/C-blue-ballpoint/）
- `HJQdctWWwAE54za.jpeg` — "AI today" 冰山图（水面上 the chatbot，水下 12 项工程能力）
