# B · 暗黑终端·工程蓝图风（Dark Technical Blueprint）

> 一句话：纯黑底 + 橙/青描边 + 等宽字体的硬核技术图，像把系统架构印在终端/电路板上。极客感、信息密度高。

## 视觉特征

- **背景**：纯黑 / 接近纯黑（#0a0a0a–#111），偶尔深炭灰分区块。
- **配色**：黑底 + **暖橙（#E8743B 类，Claude 橙）作主强调** + 青绿/蓝点缀；正文浅灰/米白等宽字。
- **线条**：细的彩色描边框（thin glowing outlined boxes），实线/虚线箭头表流向，常带 LEGEND 图例。
- **字体**：等宽 monospace（terminal 感）；标题大写无衬线粗体。
- **构图**：分层结构（Layer 0/1/2…）、文件树、命令中心放射、模块方框 + 连线。强烈的"系统图/架构图"骨架。
- **图标**：线性单色图标（终端、齿轮、数据库、文件、机器人），描边风格统一。
- **气质**：工程、硬核、可信赖、SaaS landing 配图感，常带站点水印（如 singlebrain.com）。

## 适合内容
系统架构、Agent 编排、多模块关系、技术分层、"开发套件/操作系统"式的硬核盘点。需要显得专业极客时用。

## English Prompt 模板

```
A dark technical blueprint infographic on a near-black background (#0d0d0d).
Thin outlined boxes with glowing edges, monospace terminal-style typography.
Warm orange (#E8743B) as the primary accent, with teal/cyan secondary accents,
light-grey body text. Dashed and solid arrows showing flow between modules,
a small legend in a corner.

Layout: {{布局，例：horizontal/vertical layered architecture, "Layer 0..3" on the
left edge, module boxes connected by labeled arrows; or a central "command center"
box radiating to specialist boxes}}.

Main elements: {{模块/图标，例：boxes labeled PRIMARY AGENT / SUPPORT AGENT / SHARED
MEMORY, line icons of terminal, gears, database, robot}}.

Style keywords: dark mode, blueprint, terminal aesthetic, monospace, outlined boxes,
orange + cyan on black, technical diagram, high information density, flat.

Aspect ratio: {{3:4 竖图 / 16:9 横图}}.
```

## 图中文字（单独逐字给模型）
- 标题：`{{大写标题}}`（顶部，大号 mono 粗体，橙色或白色）
- 模块标签：`{{模块名}}` + 下方小字 mono 说明
- 图例/水印：`{{LEGEND 条目}}` `{{site.com}}`（右下角小字）
- 英文 mono 效果最佳；中文可做但建议关键术语保留英文。

## 变体
- **文件树版**（Agent Dev Kit 那张）：左侧画 `folder/` 树状结构，右侧对应彩色说明卡，底部一行流程链。
- **命令中心版**（Hermes 那张）：中心一个大框，向四周 specialist 框放射，分区块用不同暗色底。
- **浅色蓝图变体**（HOW TO MASTER 那张）：底色翻成米黄 + 工程网格（cream blueprint grid），保留终端窗口 mockup、等宽字、像素吉祥物和蓝图虚线连接线，强调色仍是橙。是"暗黑硬核 → 浅色明亮极客"的折中，适合既要工程感又不想全黑的封面。
- **点阵标题版**（HOW TO FIX AI SLOP 那张）：黑底终端窗口里用**点阵/像素字（dot-matrix LED）**做大标题，背景铺淡红代码雨，流程框 GENERATE→SCORE→GATE→SHIP，失败回环用红色弧线箭头。

## 工程控制

- **Creative brief**：标准 B 图解只能在两种主阅读方向中二选一：分层版为上→下，命令中心版为中心→四周放射；不得混用两种主路径。文件树版是明确的特殊变体，按左→右的文件树→explanation cards 阅读，不计入两种标准方向。
- **Text manifest**：标题不超过 8 个英文词；模块标签为 1–3 个词；每个模块说明最多一行，且不超过 8 个英文词或 12 个汉字；中文只保留必要术语，不放长句或段落。
- 主版锁定纯黑/近黑背景、暖橙为主与青/青绿为辅的色板、monospace 字体，以及实线/虚线箭头的流程语义。**浅色蓝图变体**锁定米黄工程网格、终端窗口/等宽字/蓝图虚线的终端骨架，以及橙色强调；不得按主版要求改成黑底。
- **Control block**：按所选模式完整声明结构计数、failure loop 状态与 legend 状态。分层版必须使用 `exactly [N] layers` 和 `exactly [N] modules`；命令中心放射版必须使用 `exactly [N] specialist modules` 与 `do not include layers`；**文件树**版必须使用 `exactly [N] top-level branches` 与 `exactly [N] explanation cards`，并明确 `do not include layers or specialist modules`。三种模式都必须明确 failure loop 与 legend 是存在（写清起止模块或位置）还是排除（`do not include a failure loop` / `do not include a legend`）。
- **点阵标题版**：锁定黑底终端窗口、点阵 LED 标题、淡红代码雨和红色 failure loop；橙/青不再是此变体的强制主辅色。Creative brief 声明上→下的 `GENERATE → SCORE → GATE → SHIP` 阅读方向，以及失败从 `GATE` 回到 `GENERATE`。Control block 必须使用 `exactly 4 workflow stages`，明确该 failure loop，并明确 legend 是存在还是 `do not include a legend`。

## 注意 / 负面
- 主版用纯黑暗底；浅色蓝图变体（见上）可用米黄网格底，但仍须保留终端窗口 / 等宽字 / 蓝图虚线的硬核骨架。不要手绘涂鸦感、不要水彩；要锐利、规整、digital。
- 强调色仍要克制（橙为主，青为辅），避免彩虹色。
- 中文长句在 mono + 暗底下易糊，文字精简。

## 样例图（reference/B-dark-blueprint/）
- `HJMhXUhWsAMQ-fh.jpeg` — THE DUAL-AGENT OPERATING SYSTEM（分层 0–3 + 自愈循环 + 底部对比）
- `HJQWMBFaoAEipW5.jpeg` — HERMES AGENT AS AN ORCHESTRATOR（命令中心放射 + 分区块）
- `HJTz2RTbMAA0f5e.jpeg` — The Agent Development Kit（五层文件树 + 右侧说明卡）
- `HJk0pzlaYAEJkzi.jpeg` — HOW TO FIX AI SLOP（终端窗口 + 点阵/像素标题字 + 红色 fail loop，eval-loop 流程）
- `HJaQIPUXIAMxF31.jpeg` — HOW TO MASTER Claude Code（浅色变体：米黄网格底 + 终端窗口 + 像素章鱼 + 蓝图虚线）
