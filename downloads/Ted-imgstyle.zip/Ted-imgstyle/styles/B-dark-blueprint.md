# B · 暗黑终端·工程蓝图风（Dark Technical Blueprint）

> 一句话：纯黑底 + 橙/青描边 + 等宽字体的硬核技术图，像把系统架构印在终端/电路板上。极客感、信息密度高。

## 视觉特征

- **背景**：纯黑 / 接近纯黑（#0a0a0a–#111），偶尔深炭灰分区块。
- **配色**：黑底 + **暖橙（#E8743B 类，Claude 橙）作主强调** + 青绿/蓝点缀；正文浅灰/米白等宽字。
- **线条**：细的彩色描边框（thin glowing outlined boxes），实线/虚线箭头表流向，常带 LEGEND 图例。
- **字体**：等宽 monospace（terminal 感）；标题大写无衬线粗体。
- **构图**：分层结构（Layer 0/1/2…）、文件树、命令中心放射、模块方框 + 连线。强烈的"系统图/架构图"骨架。
- **图标**：线性单色图标（终端、齿轮、数据库、文件、机器人），描边风格统一。
- **气质**：工程、硬核、可信赖、SaaS landing 配图感，常带站点水印（如 singlebrain.com）。

## 适合内容
系统架构、Agent 编排、多模块关系、技术分层、"开发套件/操作系统"式的硬核盘点。需要显得专业极客时用。

## English Prompt 模板

```
A dark technical blueprint infographic on a near-black background (#0d0d0d).
Thin outlined boxes with glowing edges, monospace terminal-style typography.
Warm orange (#E8743B) as the primary accent, with teal/cyan secondary accents,
light-grey body text. Dashed and solid arrows showing flow between modules,
a small legend in a corner.

Layout: {{布局，例：horizontal/vertical layered architecture, "Layer 0..3" on the
left edge, module boxes connected by labeled arrows; or a central "command center"
box radiating to specialist boxes}}.

Main elements: {{模块/图标，例：boxes labeled PRIMARY AGENT / SUPPORT AGENT / SHARED
MEMORY, line icons of terminal, gears, database, robot}}.

Style keywords: dark mode, blueprint, terminal aesthetic, monospace, outlined boxes,
orange + cyan on black, technical diagram, high information density, flat.

Aspect ratio: {{3:4 竖图 / 16:9 横图}}.
```

## 图中文字（单独逐字给模型）
- 标题：`{{大写标题}}`（顶部，大号 mono 粗体，橙色或白色）
- 模块标签：`{{模块名}}` + 下方小字 mono 说明
- 图例/水印：`{{LEGEND 条目}}` `{{site.com}}`（右下角小字）
- 英文 mono 效果最佳；中文可做但建议关键术语保留英文。

## 变体
- **文件树版**（Agent Dev Kit 那张）：左侧画 `folder/` 树状结构，右侧对应彩色说明卡，底部一行流程链。
- **命令中心版**（Hermes 那张）：中心一个大框，向四周 specialist 框放射，分区块用不同暗色底。

## 注意 / 负面
- 不要亮底、不要手绘涂鸦感、不要水彩；要锐利、规整、digital。
- 强调色仍要克制（橙为主，青为辅），避免彩虹色。
- 中文长句在 mono + 暗底下易糊，文字精简。

## 样例图（reference/B-dark-blueprint/）
- `HJMhXUhWsAMQ-fh.jpeg` — THE DUAL-AGENT OPERATING SYSTEM（分层 0–3 + 自愈循环 + 底部对比）
- `HJQWMBFaoAEipW5.jpeg` — HERMES AGENT AS AN ORCHESTRATOR（命令中心放射 + 分区块）
- `HJTz2RTbMAA0f5e.jpeg` — The Agent Development Kit（五层文件树 + 右侧说明卡）
