# N · 东方史卷·古典纸艺拼贴（Oriental Historical Paper Collage）

> 一句话：把历史人物、宫殿、水墨山河和题签做成一幅撕边宣纸拼贴，像一张可展开的东方史卷封面。

## 视觉特征

- **背景**：旧宣纸、米黄色纤维纸与暗红织物叠层，保留撕边、折痕、胶带与轻微投影。
- **配色**：赭红、宫墙朱、旧金、墨黑、宣纸米白；山水使用低饱和青灰，红色只负责标题、封条与日轮。
- **线条与质感**：工笔人物和服饰纹样结合水墨山河；人物、宫殿、云纹以白色撕纸轮廓剪贴，形成舞台式纵深。
- **字体**：中文大标题采用书法黑体或碑帖感字形；Latin 产品名可用旧式衬线体，以朱红突出。
- **构图**：典型 16:9 横图，左侧历史场景占约 58%，右侧留一张完整题签纸承载标题；中景建筑与远山形成由近到远的层次。
- **视觉母题**：帝王/文士/将领群像、宫殿、塔、远山、红日、祥云、团扇、印章、红色纸胶带与撕纸边。
- **文字纪律**：只保留一条主标题和最多一条副题；右下可有一枚装饰性印章，但不得伪造真实机构印鉴。

## 适合内容

中国史、东亚史、古典文学、传统文化、朝代兴衰、历史人物关系、东方主题产品封面与文化栏目头图。

## English Prompt 模板

```text
An oriental historical paper-collage cover on aged xuan paper, combining refined
gongbi-style historical figures with ink-wash mountains, palace architecture, clouds
and a muted red sun. Layer the figures and buildings as carefully cut paper pieces
with visible torn white edges, subtle shadows, creases and red paper tape. Use a
restrained palette of parchment cream, cinnabar red, antique gold, ink black and
blue-grey landscape tones. Rich textile and robe patterns, but no glossy 3D rendering.

Wide split composition: the left 58% contains {{历史人物与场景}} arranged in foreground,
middle-ground architecture and distant ink mountains; the right 42% is a large intact
cream title sheet with a thin red border, generous blank space and one decorative seal.
Place the exact title {{标题}} on the right sheet, with {{Latin 关键词}} in a classic red
serif when needed. Editorial historical montage, tactile paper fibers, museum-poster
craftsmanship, cinematic depth, flat layered collage.

Aspect ratio: 16:9 landscape.
```

## 图中文字

- 主标题：`{{8–18 个汉字}}`，最多分三行。
- Latin 关键词：`{{产品名 / 英文短词}}`，朱红衬线体。
- 印章：只用装饰性短词，如 `史卷`、`长安`；不得使用真实机构名称。

## 变体

- **朝代封面版**：人物群像 + 都城建筑 + 朝代题签，适合历史主题首图。
- **人物传记版**：单一主人物放大，身后用三层纸片交代时代、地点和关键关系。
- **古典文本版**：人物减少，以书页、诗句题签和山水意象为主，留白更多。

## 工程控制

- Creative brief 固定“左侧叙事场景 → 右侧题签标题”的阅读顺序。
- Control block 锁定 `exactly 1 main historical figure group`、`exactly 1 title sheet`、`exactly 1 decorative seal`；主标题必须完整出现在题签纸内。
- 不得混入现代 emoji、霓虹色、圆角 SaaS 卡片或写实摄影背景；不得复制真实名画的独特构图。

## 样例图（reference/N-oriental-history-paper-collage/）

- `HNFRIiNbQAE0hS3.jpeg` — 唐朝纸片分层动画封面（工笔人物群像 + 长安建筑 + 水墨山河 + 右侧题签纸 + 朱红胶带）
