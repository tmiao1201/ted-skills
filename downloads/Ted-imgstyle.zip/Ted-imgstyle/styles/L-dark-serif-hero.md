# L · 深色奢华·衬线发布 Hero（Dark Luxe Serif Hero）

> 一句话：深棕黑底 + 优雅白衬线大标题（橙色斜体强调词）+ 悬浮的产品 mockup 透视展示，像高端 SaaS landing 首屏 / 发布宣言封面，奢华、克制、有质感。

## 视觉特征

- **背景**：深棕黑 / 暖近黑（warm espresso near-black，#1a1410 类），偶带极淡暗角或哑光质感，绝不纯白。
- **配色**：暗底 + **米白/象牙白衬线文字** + **暖橙作唯一强调**（斜体词、下划线、圆形 badge），整体暖调奢华，低饱和、不撞色。
- **标题**：**优雅衬线大标题（editorial serif）**，常用斜体 + 橙色给关键词做强调（如 *agent*、*Creator's*），手绘橙色下划线点缀某个词。
- **产品展示**：多块**产品 UI mockup（手机/平板/dashboard 截图）以 3D 透视 / 轴测悬浮**排布，带柔和投影，像 deck 里的"设备阵列"。
- **点缀**：圆形发光 badge（如 `OPEN SOURCE`）、底部一排**大数字统计 + 小标签**（如 `71 Design Systems` / `19 Skills` / `0 Lock-in`）。
- **档案排版**：顶/底通栏小字页眉页脚——刊名 / `MANIFESTO` / `COVER · 01 / 08` / 版本年份，宽字距大写，瑞士感。
- **气质**：高端发布会 / 产品宣言 / 作品集首图，奢华、自信、安静有力，比 K（浅色技术手册）更"营销 hero"、更暗更贵。

## 适合内容
产品发布 hero、开源项目/作品集首屏、"宣言式"封面、个人旗舰作品主视觉、需要高级奢华感而非热闹的营销主图。

## English Prompt 模板

```
A dark, luxurious product-launch hero infographic on a warm near-black / dark espresso
background. An elegant editorial serif headline in ivory/off-white, with a key word in
orange italic and a hand-drawn orange underline accent. Include product UI mockups
(phone / tablet / dashboard screenshots) floating in 3D perspective / axonometric
arrangement, a small glowing circular badge, and a bottom row of large statistics with
small labels only when the user has supplied or verified the relevant product or
statistical information; otherwise omit them. Thin spaced-out uppercase running
header/footer (publication name, "MANIFESTO", "COVER · 01 / 08", year/version).
Warm luxe palette: near-black + ivory serif text + single orange accent, low saturation.

Layout: {{布局，例：a big serif manifesto headline on the left; when supported by
provided or verified information, a floating product array on the right and a statistics
row along the bottom}}.

Style keywords: dark luxe, editorial serif headline, orange italic accent, optional
floating device mockups, 3D perspective, optional glowing badge, optional big stat
numbers, manifesto, archive header/footer, premium SaaS landing hero, low saturation,
sophisticated.

Aspect ratio: {{16:9 横图（首屏 hero）}}.
```

## 图中文字（单独逐字给模型）
- 大标题：`{{标题}}`（衬线，关键词橙色斜体 + 橙手绘下划线）+ 副标题 `{{一两句说明}}`
- 页眉/页脚：`{{刊名 / MANIFESTO / COVER · 01 / 08 / 年份·版本}}`（小号大写宽字距）
- 产品 mockup：仅在用户提供或已核验产品信息时列出其中逐字文字；否则省略。
- badge：仅在用户提供或已核验的产品/统计信息支持时列出逐字内容；否则省略。
- 统计行：仅在用户提供或已核验统计信息时列出 `{{71}} {{Design Systems}}` `{{19}} {{Skills}}` …；否则省略。
- 英文衬线 hero 效果最佳；中文衬线大标题也可，但产品 mockup 里的截图文字尽量精简。

## 变体
- 暂时仅一张（open.design 那张）。后续若收到同类"深色奢华 hero / 发布宣言"再细分变体。

## 工程控制
- Creative brief 固定为 16:9 Hero，并按标题→产品展示（若有）→统计行（若有）建立三层读图。
- 暖橙只承担一个标题关键词、下划线或 badge 的强调职责，不扩展为第二套强调色。
- 产品 UI mockups、badge 与底部统计行仅在用户提供或已核验相关产品/统计信息时包含；否则省略。存在固定数量时，Control block 锁定数量；固定产品按参考图协议以产品为主角色，并写 preservation。
- 默认在 English prompt 的 Negative constraints 写 `do not include a multi-card collage`；只有用户明确要求逐项核验该排除项时，才在 Control block 重复列出；不含固定数量、关系、保真或禁止项时不得输出空块。

## 注意 / 负面
- 与 K 区别：K 是浅米白底 + 蓝色细线等距图 + 技术手册感；L 是深色暖底 + 橙强调 + 产品 mockup 透视 + 营销 hero 感。
- 与 G 区别：G 黑白报刊严肃；L 暖暗奢华、强调产品展示与发布气质。
- 与 B 区别：B 是黑底等宽极客终端蓝图；L 是暖暗 + 优雅衬线 + 奢华营销，完全不同气质。
- 不要做成热闹拼贴；留白、克制、单一橙强调是高级感来源；产品 mockup 透视和柔和阴影别做廉价。

## 样例图（reference/L-dark-serif-hero/）
- `HJX0-qhaEAAInKx.jpeg` — open.design「Design with the agent already on your laptop」（深棕底 + 白衬线 + 橙斜体 + 悬浮设备 mockup + 底部 71/19/06/0 统计）
