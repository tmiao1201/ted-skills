# K · 淡雅衬线·工程档案风（Elegant Serif Technical Archive）

> 一句话：浅米白底 + 优雅衬线/几何大标题 + 蓝色细线框等距示意图 + 大量留白 + 档案式页眉页脚，像一份排版考究的技术手册或设计宣言，克制、高级、digital。

## 视觉特征

- **背景**：浅米白 / 纯白（warm off-white / paper white），极简，大量留白是命门。
- **配色**：低饱和——米白底 + 黑/深灰正文 + **单一冷色（蓝）作线框与强调**，可加极少量淡金/橙点缀。整体安静、不撞色。
- **标题**：**衬线大标题（elegant serif，杂志/书籍感）** 或几何无衬线/点阵粗体，字号拉大、字距讲究；关键词可用蓝/橙单色或下划线强调。
- **线框**：**蓝色细线（thin blue strokes）** 画等距/轴测示意图（isometric line diagrams）、线框图标、流程节点；描边纤细均匀，无填充或极淡填充。
- **档案排版**：瑞士国际主义栅格 + **档案式页眉页脚**——文档类型 / 版本号 / 日期 / 章节号（如 `01 / 08`、`COVER`、`AI AGENT ARCHITECTURE`、`v1.0`），小号大写字母拉开字距。
- **气质**：technical manual / design manifesto / 工程档案，安静、考究、留白多、可信赖；比 G（黑白报刊）更"产品/设计感"、更冷静淡雅。

## 适合内容
架构总览、技术手册/原理讲解、产品宣言或 landing hero、需要"高级克制 + 工程档案感"而非热闹的选题；尤其适合中文衬线大标题 + 淡蓝线框的"雅致工程"调性。

## English Prompt 模板

```
An elegant, minimal technical-archive infographic on a warm off-white / paper-white
background with generous white space. Refined large {{serif / geometric}} headline with
careful letter-spacing; a key word emphasized in blue or orange. Thin blue line strokes
draw isometric / axonometric line diagrams and wireframe icons with no fill. Swiss grid
layout with an archive-style running header & footer — document type, version, date and
section numbers (e.g. "01 / 08", "AI AGENT ARCHITECTURE", "v1.0") in small spaced-out
uppercase. Low-saturation palette: off-white + black/grey text + a single blue accent,
optional faint gold/orange touch. Quiet, sophisticated, digital, lots of breathing room.

Layout: {{布局，例：a large serif title block on the left, a fine blue isometric diagram
on the right; or a centered title with thin-line nodes connected below}}.

Main elements: {{要画的主体，例：thin blue isometric diagrams of a touchscreen / a floppy
disk; wireframe boxes labeled Claude Code / Codex / 飞书 CLI connected by fine arrows}}.

Style keywords: editorial serif headline, thin blue line art, isometric wireframe,
technical manual, design manifesto, Swiss grid, archive header/footer, off-white,
minimal, generous whitespace, low saturation, elegant, digital.

Aspect ratio: {{16:9 横图（封面/宣言） / 3:4（手册页）}}.
```

## 图中文字（单独逐字给模型）
- 页眉/页脚：`{{文档类型 / 章节号 01-08 / 版本 v1.0 / 日期}}`（小号大写，宽字距，放四角或顶/底通栏）
- 大标题：`{{标题}}`（衬线或几何粗体，中英皆可；中文衬线大标题是该风格的高级感来源）+ 关键词蓝/橙强调
- 节点/图注：`{{节点名}}` + 细线说明（小号无衬线）
- 中英混排清晰；标题求"雅"用衬线，技术节点用细线无衬线小字。

## 变体
- **淡雅工程架构版**（飞书 CLI 那张）：米白底 + 中文衬线大标题 + 蓝色细线框节点（Claude Code / Codex / 飞书 CLI）+ 淡金描边卡 + 四角档案页眉，气质雅致克制。
- **技术手册书页版**（MAKING SOFTWARE 那张）：纯白书页 + 蓝色点阵/几何标题 + 衬线正文分栏 + 蓝色等距线框示意图（触摸屏电极、软盘），侧边竖排章节标签，像真正的技术书内页。
- **发光等距 3D 宣言版**（pi-docs-playbook 那张）：浅白底 + **超粗黑体无衬线中文大标题**（左侧，关键词蓝色下划线）+ 右侧**带氛围发光的等距 3D 场景**——罗盘 + `DOCUMENTATION BASE` 圆盘基座 + 漂浮的 .md 文档节点 + 远端 3D 建筑群（Agent 应用），用**青色 + 橙色双色发光流动光带**连接两侧（青=精准阅读、橙=高效构建）。比纯细线版多一层景深、光点粒子和发光质感，更像 hero / 宣言封面而非手册内页。左下角四个能力图标 + 中文短标签（读得准/用得对/构得稳/演进快）。Style keywords 追加：`glowing isometric 3D scene, ambient light particles, cyan & orange flowing light ribbons, depth of field, compass + disc-base metaphor, hero manifesto`。

## 注意 / 负面
- 与 G 区别：G 是黑白报刊/咨询报告、衬线 + 大数据字、偏严肃新闻感；K 更淡雅、靠蓝色细线等距图 + 大留白 + 档案页眉，偏"设计/产品手册"。
- 与 H 区别：H 是扁平彩色矢量流程图、品牌色块填充；K 是细线无填充 + 单一蓝 + 衬线标题 + 留白，冷静得多。
- 留白是灵魂——别塞满；线要细、要均匀；强调色只用一种蓝（必要时一点金/橙）。
- 深色奢华衬线 hero（如 open.design 那种深棕底 + 产品 mockup）气质不同，暂不归此类。

## 样例图（reference/K-serif-blueprint/）
- `HJY9HrSbYAEZHeH.jpeg` — 中文「Claude Code + Codex + 飞书 CLI」（淡雅工程架构版：衬线大标题 + 蓝线框节点 + 档案页眉）
- `截屏2026-05-30 19.26.54.png` — MAKING SOFTWARE（技术手册书页版：蓝点阵标题 + 衬线正文 + 蓝等距线框）
