# K · 淡雅衬线·工程档案风（Elegant Serif Technical Archive）

> 一句话：浅米白底 + 优雅衬线/几何大标题 + 蓝色细线框等距示意图 + 大量留白 + 档案式页眉页脚，像一份排版考究的技术手册或设计宣言，克制、高级、digital。

## 视觉特征

- **背景**：浅米白 / 纯白（warm off-white / paper white），极简，大量留白是命门。
- **配色**：低饱和——米白底 + 黑/深灰正文 + **单一冷色（蓝）作线框与强调**，可加极少量淡金/橙点缀。整体安静、不撞色。
- **标题**：**衬线大标题（elegant serif，杂志/书籍感）** 或几何无衬线/点阵粗体，字号拉大、字距讲究；关键词可用蓝/橙单色或下划线强调。
- **线框**：**蓝色细线（thin blue strokes）** 画等距/轴测示意图（isometric line diagrams）、线框图标、流程节点；描边纤细均匀，无填充或极淡填充。
- **档案排版**：瑞士国际主义栅格 + **档案式页眉页脚**——文档类型 / 版本号 / 日期 / 章节号（如 `01 / 08`、`COVER`、`AI AGENT ARCHITECTURE`、`v1.0`），小号大写字母拉开字距。
- **气质**：technical manual / design manifesto / 工程档案，安静、考究、留白多、可信赖；比 G（黑白报刊）更"产品/设计感"、更冷静淡雅。

## 适合内容
架构总览、技术手册/原理讲解、产品宣言或 landing hero、需要"高级克制 + 工程档案感"而非热闹的选题；尤其适合中文衬线大标题 + 淡蓝线框的"雅致工程"调性。

## English Prompt 模板

```
An elegant, minimal technical-archive infographic on a warm off-white / paper-white
background with generous white space. Refined large {{serif / geometric}} headline with
careful letter-spacing; a key word emphasized in blue or orange. Thin blue line strokes
draw isometric / axonometric line diagrams and wireframe icons with no fill. Swiss grid
layout with an archive-style running header & footer — document type, version, date and
section numbers (e.g. "01 / 08", "AI AGENT ARCHITECTURE", "v1.0") in small spaced-out
uppercase. Low-saturation palette: off-white + black/grey text + a single blue accent,
optional faint gold/orange touch. Quiet, sophisticated, digital, lots of breathing room.

Layout: {{布局，例：a large serif title block on the left, a fine blue isometric diagram
on the right; or a centered title with thin-line nodes connected below}}.

Main elements: {{要画的主体，例：thin blue isometric diagrams of a touchscreen / a floppy
disk; wireframe boxes labeled Claude Code / Codex / 飞书 CLI connected by fine arrows}}.

Style keywords: editorial serif headline, thin blue line art, isometric wireframe,
technical manual, design manifesto, Swiss grid, archive header/footer, off-white,
minimal, generous whitespace, low saturation, elegant, digital.

Aspect ratio: {{16:9 横图（封面/宣言） / 3:4（手册页）}}.

Negative constraints (default): do not include high-saturation card arrays, heavy
multicolor arrows, or dense body text.
```

## 图中文字（单独逐字给模型）
- 页眉/页脚：`{{文档类型 / 章节号 01-08 / 版本 v1.0 / 日期}}`（小号大写，宽字距，放四角或顶/底通栏）
- 大标题：`{{标题}}`（衬线或几何粗体，中英皆可；中文衬线大标题是该风格的高级感来源）+ 关键词蓝/橙强调
- 节点/图注：`{{节点名}}` + 细线说明（小号无衬线）
- 中英混排清晰；标题求"雅"用衬线，技术节点用细线无衬线小字。

## 变体
- **淡雅工程架构版**（飞书 CLI 那张）：米白底 + 中文衬线大标题 + 蓝色细线框节点（Claude Code / Codex / 飞书 CLI）+ 淡金描边卡 + 四角档案页眉，气质雅致克制。
- **技术手册书页版**（MAKING SOFTWARE 那张）：纯白书页 + 蓝色点阵/几何标题 + 衬线正文分栏 + 蓝色等距线框示意图（触摸屏电极、软盘），侧边竖排章节标签，像真正的技术书内页。
- **编辑循环教程封面版**（loops 那张）：16:9 暖白细网格，左侧用超大黑色衬线标题与斜体关键词，右侧用黑色虚线圆环、圆角节点和一个悬浮纸卡讲循环；只保留一枚珊瑚橙判断节点，像一本克制的产品教程封面。
- **发光等距 3D 宣言版**（pi-docs-playbook 那张）：浅白底 + **超粗黑体无衬线中文大标题**（左侧，关键词蓝色下划线）+ 右侧**带氛围发光的等距 3D 场景**——罗盘 + `DOCUMENTATION BASE` 圆盘基座 + 漂浮的 .md 文档节点 + 远端 3D 建筑群（Agent 应用），用**青色 + 橙色双色发光流动光带**连接两侧（青=精准阅读、橙=高效构建）。比纯细线版多一层景深、光点粒子和发光质感，更像 hero / 宣言封面而非手册内页。左下角四个能力图标 + 中文短标签（读得准/用得对/构得稳/演进快）。Style keywords 追加：`glowing isometric 3D scene, ambient light particles, cyan & orange flowing light ribbons, depth of field, compass + disc-base metaphor, hero manifesto`。

## 工程控制

- **Creative brief**：先声明“档案/手册默认变体”或“发光等距3D宣言变体”，并在指定位置保留约 20–30% 画布的完整、连续空白区，不放标题、正文、节点、线框或装饰。
- 档案/手册默认变体锁定米白/暖白背景、单一蓝色细线、衬线标题和档案式页眉页脚；Text manifest 将页眉、标题、节点标签与图注分别列区，不以密集正文替代图示。
- 编辑循环教程封面版锁定左右 46/54 分栏、黑色虚线循环和单一珊瑚橙判断节点；允许不用蓝色，但禁止再加入第二强调色。
- 发光等距3D宣言变体锁定浅白基底、粗黑无衬线标题、青橙双色发光光带和等距 3D 场景；其 Text manifest 仍须保留标题、能力标签与图注的分区职责。
- 默认变体的线框节点保持细、少、均匀，避免填满画布。
- **Control block**：必须输出，至少列出 `preserve blank zone`、其位置与约 20–30% 面积；并列出固定页眉/页脚或 `exactly [N] wireframe nodes`（如有）。仅当用户明确要求逐项核验时，才重复 `do not include high-saturation card arrays, heavy multicolor arrows, or dense body text`。发光等距3D宣言变体另列出保真的青橙光带与 3D 场景。

## 注意 / 负面
- 与 G 区别：G 是黑白报刊/咨询报告、衬线 + 大数据字、偏严肃新闻感；K 更淡雅、靠蓝色细线等距图 + 大留白 + 档案页眉，偏"设计/产品手册"。
- 与 H 区别：H 是扁平彩色矢量流程图、品牌色块填充；K 是细线无填充 + 单一蓝 + 衬线标题 + 留白，冷静得多。
- 留白是灵魂——别塞满；线要细、要均匀；**档案/手册默认变体**的强调色只用一种蓝（必要时一点金/橙）。发光等距3D宣言变体例外，允许青橙双色光带；但仍须遵守工程控制中约 20–30% 的连续留白约束。
- 深色奢华衬线 hero（如 open.design 那种深棕底 + 产品 mockup）气质不同，暂不归此类。

## 样例图（reference/K-serif-blueprint/）
- `HJY9HrSbYAEZHeH.jpeg` — 中文「Claude Code + Codex + 飞书 CLI」（淡雅工程架构版：衬线大标题 + 蓝线框节点 + 档案页眉）
- `截屏2026-05-30 19.26.54.png` — MAKING SOFTWARE（技术手册书页版：蓝点阵标题 + 衬线正文 + 蓝等距线框）
- `HJzlX4hacAEVt-K.jpeg` — pi-docs-playbook「让你的 agent 从 pi 上长出来」（发光等距 3D 宣言版：粗黑无衬线大标题 + 罗盘/基座圆盘 + 青橙双色发光光带 + 3D 文档/建筑群）
- `HMokF6Ra8AAN5s1.jpeg` — Getting started with loops（编辑循环教程封面版：左侧大衬线标题 + 右侧虚线循环 + 暖白细网格 + 珊瑚橙判断节点）
