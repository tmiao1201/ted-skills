# M · 证据档案·纸张拼贴（Evidence Dossier Paper Collage）

> 一句话：把来源文件、证据卡、核验流程和知识资产做成一张“调查档案桌”——真实纸张拼贴负责证据感，黑墨手绘柜体负责系统感。

## 视觉特征

- **背景**：纯白 / 暖白大画布，留白充足；局部铺旧米黄纸、撕边便签和薄纸阴影，不做满版复古纹理。
- **配色**：纸张米黄 + 黑色墨线为主；**钴蓝**用于来源卡、虚线溯源关系和元数据；**暖橙**用于主流程箭头；**印章红**只用于“已验证 / 已确认”等状态。四色职责固定，不随意混用。
- **线条与质感**：真实扫描文档、PDF、CSV、网页摘录等半写实纸张碎片，与黑色钢笔 / 铅笔手绘结构图并置。纸张有撕裂毛边、胶带、回形针、折痕和轻微投影；系统主体保持 hand-drawn ink illustration，不做 3D 渲染。
- **字体**：中文手写标题与批注 + 小号打字机 / 无衬线元数据。流程节点用工整手写体，证据卡用蓝色钢笔小字，疑问与风险批注用红笔。
- **构图**：典型 16:9 横图，按“左 → 中 → 右”讲完整证据链：左侧散落原始资料，中间是来源卡与纵向核验步骤，右侧是大型档案柜 / 抽屉 / 资料库隐喻；最右再伸出发布渠道或应用结果。底部可放横向版本记录纸条。
- **视觉母题**：撕纸、透明胶带、回形针、PDF/Word/CSV 小图标、蓝色 provenance card、虚线引用关系、红色圆章、勾选清单、版本表、标签抽屉、档案柜。
- **文字与署名**：中文为主，信息密度中高。文字分三层：大标题 / 模块名、证据卡短字段、红笔风险批注。来源字段尽量固定为“来源 / 类型 / 页码或 URL / 摘录 / 文档 ID”；署名只放底部角落。

## 适合内容

RAG 与知识库、企业资料治理、事实核验、研究证据链、审计底稿、版本追踪、内容生产流水线、数据血缘、从原始资料到可发布资产的全过程。

## English Prompt 模板

```text
An evidence-dossier paper-collage infographic on a clean warm-white canvas, combining
realistic torn document scraps with a precise hand-drawn black-ink systems diagram.
Use aged cream paper, masking tape, paper clips, folded edges and subtle paper shadows
for the source materials. Use cobalt-blue provenance cards and dotted traceability
lines, warm-orange arrows for the main verified workflow, and restrained red rubber
stamps only for validation states. No glossy 3D, no colorful social-media cards.

Wide left-to-right composition: on the left, {{原始资料，如 PDF, Word, CSV, FAQ and
web excerpts}} scattered as taped paper evidence with a few red handwritten questions;
in the middle, a column of blue source cards connected to {{3–5 个核验步骤}} with orange
arrows; on the right, a large hand-drawn archival cabinet labeled {{知识资产名称}}, with
drawers for {{正文 / 元数据 / 摘要 / 图片}} and visible source-traceability labels. Extend
one or two arrows to {{发布渠道 / 下游应用}}. Add a narrow torn-paper version-history
strip along the bottom.

Style keywords: evidence dossier, archival collage, torn paper, taped documents,
provenance cards, traceability, hand-drawn filing cabinet, black ink sketch, cobalt
blue metadata, orange workflow arrows, red verification stamp, editorial whitespace,
Chinese knowledge-management infographic, flat 2D, no photorealistic scene.

Aspect ratio: 16:9 landscape.
```

## 图中文字（单独逐字给模型）

- 左侧来源区：`{{企业资料 / 原始证据}}`；每张纸只放一个来源类型和一个短疑问。
- 蓝色证据卡：`来源：{{...}}` `类型：{{...}}` `页码/URL：{{...}}` `摘录：{{...}}` `DOC-{{编号}}`。
- 核验步骤：`来源解析` → `事实回填` → `人工确认` → `修订记录`。
- 右侧柜体：`{{知识草稿 / 证据库}}`；抽屉标签控制在 2–5 个字。
- 红章：`已验证` 或 `已确认`，整张图只出现 1–2 次。
- 底部版本条：`版本` `日期` `变更摘要` `来源覆盖` `确认人`。

## 变体

- **知识库版**：右侧主体是档案柜，突出正文、元数据、摘要、图片四类抽屉和“可追踪来源”。
- **审计底稿版**：右侧改为装订底稿册；左侧来源换成合同、发票、银行流水；红章改为“已复核”。
- **研究证据链版**：中间由来源卡连接到论点卡，使用“支持 / 反证 / 待核验”三类标签；仍保持蓝、橙、红职责不变。
- **数据血缘版**：纸张资料减少，蓝色 provenance card 增多；右侧柜体换成数据表抽屉，强调字段级来源与版本。

## 工程控制

- **Creative brief**：固定读图顺序为左侧来源 → 中部核验 → 右侧知识资产；如有发布出口，只能从右侧知识资产继续向外延伸。
- **Text manifest**：每张来源卡严格保留 3–5 个短字段；红章全图只出现 1–2 个。验证章和每个事实字段必须遵守公共规范的“来源/状态”映射：逐项标注 `来源=用户提供/已核验材料标识` 与 `状态=已核验/待补充`。没有映射时，只能使用“待补充”或“待核验”，不得使用验证章或伪造事实字段。
- 锁定蓝=来源、橙=主流程、红=风险/验证、黑墨=系统主体；不得交换颜色职责或用其他颜色替代状态含义。
- **Control block**：必须列出 `exactly [N] evidence records`、`exactly [N] verification steps`、`exactly [N] knowledge-asset sections` 与 `exactly [N] publication exits`，并写明来源卡→核验步骤→知识资产的连接关系。知识资产区按变体具体命名为 cabinet drawers、workpaper sections 或 claim cards；发布出口可为 `exactly 0 publication exits`，此时明确 `do not include publication exits`。

## 注意 / 负面

- 不要归成 F：禁止高饱和撞色、emoji、圆角社媒卡和种草感。
- 不要归成 A 的普通手绘版：M 必须同时出现“真实纸张证据”和“手绘系统主体”，并突出可追溯性。
- 不要让所有元素都变成照片；写实只用于纸张与文档碎片，柜体、流程、图标保持黑墨手绘。
- 每张证据卡只保留 3–5 行短字段；文字过密时拆图，不生成无法阅读的伪文档。
- 红色只用于风险批注和验证章，橙色只用于主流程，蓝色只用于来源与引用。

## 样例图（reference/M-evidence-dossier-collage/）

- `HLu7n5TboAEy2kx.jpeg` — 企业资料 → 来源证据卡 → 核验流程 → 知识草稿柜 → SEO / 多站分发（撕纸文档 + 蓝色溯源 + 红章 + 黑墨档案柜）
