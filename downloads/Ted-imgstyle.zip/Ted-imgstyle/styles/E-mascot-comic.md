# E · 可爱吉祥物·分格漫画风（Cute Mascot Comic）

> 一句话：圆润可爱的拟人吉祥物 + 柔和水彩 + 漫画分格，把抽象功能讲成有情绪的小故事。Ted 最初说的"漫画类"就是这一类。

## 视觉特征

- **角色**：圆润、大眼、Q 版拟人吉祥物（库里是一只红色小龙虾，戴耳机/打电话），表情丰富、有情绪（睡觉、眨眼、卖萌）。
- **画风**：柔和水彩 / 蜡笔质感（soft watercolor, colored-pencil texture），线条温柔不锐利。
- **配色**：低饱和马卡龙色——奶油黄、藕粉、薰衣草紫、淡蓝，整体暖糯治愈。
- **背景**：温馨生活场景（卧室、床、台灯、夜空星星月亮），细节丰富有故事感。
- **分格**：常见双格 / 四格漫画（前后对比、时间推进），格子有圆角描边；或单幅大场景。
- **文字**：圆润手写体标题（中英混排），对话用**手绘对话气泡**，底部常有一条说明性 caption 条。
- **装饰**：星星、爱心、小闪光点等可爱碎元素点缀边角。
- **气质**：治愈、萌、有人格化叙事，把"枯燥的技术功能"变成"小生物的日常"。

## 适合内容
拟人化讲功能（"心跳/定时/webhook 三件套"这种）、情绪化或故事化的解读、对比"之前 vs 之后"、需要亲和力和记忆点的传播图。

## English Prompt 模板

```
A cute children's-book style comic illustration, soft watercolor and colored-pencil
texture, gentle rounded linework. A round chubby adorable mascot character
({{角色，例：a little red lobster with big shiny eyes, wearing headphones}}),
very expressive and emotional. Warm cozy {{场景，例：bedroom at night with a glowing
lamp, starry sky through the window}}. Soft macaron palette: cream, dusty pink,
lavender, pale blue. Decorated with tiny stars, hearts and sparkles in the corners.

Layout: {{单幅大场景 / a 2-panel comic / a 4-panel comic}} with rounded panel borders.
Panel(s) show: {{每格画面，例：panel 1 the mascot sleeping with Zzz; panel 2 the mascot
waking up winking}}.

Style keywords: kawaii mascot, picture-book illustration, soft watercolor, cozy,
healing, pastel, hand-drawn speech bubble, rounded panels.

Aspect ratio: {{1:1 方图 / 16:9 横图}}.
```

## 图中文字（单独逐字给模型）
- 标题：`{{标题}}`（圆润手写体，顶部，常配编号圆圈，如"⑤ Heartbeat 心跳"）
- 对话气泡：`{{气泡台词}}`（手绘云朵气泡里）
- 底部 caption 条：`{{一句说明}}`（圆角框 + 虚线边）
- 中文渲染没问题，但保持短句、口语化、卖萌语气。

## 变体
- **单幅场景版**（storyboard-04 那张）：不分格，一整幅生活大场景，角色 + 道具讲一个状态；顶部一条标题 caption。
- **分格连续版**（card-05 那张）：双/四格，强调前后/时间变化，每格一个小情节。

## 注意 / 负面
- 不要写实、不要锐利硬边、不要高饱和荧光色；要软、糯、暖。
- 角色要**保持一致**：跨多张图时把吉祥物的固定特征（红色小龙虾、大眼、耳机）写死在 prompt 开头，避免每张长得不一样。
- 文字别多，靠画面情绪传达；信息密集的内容不适合这个风格。

## 样例图（reference/E-mascot-comic/）
- `card-05.PNG` — ⑤ Heartbeat 心跳（双格：睡觉的龙虾 → 闹钟响后眨眼"有事吗？没事继续睡"）
- `storyboard-04.PNG` — 龙虾打电话夜间汇报（单幅大场景：人在睡、龙虾值班，"凌晨3点自动汇报中"）
