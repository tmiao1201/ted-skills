# F · 小红书·高饱和拼贴信息图（Xiaohongshu Collage Infographic）

> 一句话：高饱和配色 + emoji + 圆角卡片堆叠 + 强对比中文标题的"种草感"干货长图，一眼抓人、信息塞得满。

## 视觉特征

- **背景**：彩色/渐变底或浅色底 + 大量彩色色块分区。
- **配色**：**高饱和**对比色（亮蓝、亮黄、亮粉、亮绿），强调色撞色用，醒目。
- **卡片**：圆角卡片层层堆叠/分栏，编号徽章（①②③或 01 02 03），重点词加底色高亮块。
- **字体**：粗黑标题（中文为主，常带描边/阴影/撞色），emoji 大量混排当图标用。
- **构图**：竖向长图为主，分 N 个板块自上而下；顶部大标题 + 副标题 + 角标（如 "v1.0""X 关注清单"），底部常有"怎么用这张图"行动指引。
- **图标**：emoji + 彩色扁平图标 + 品牌 logo 混用。
- **气质**：社媒种草、干货清单、热闹、信息量大、转发友好；有时配一个 AI 吉祥物角色。

## 适合内容
干货清单（"必关注名单""N 个工具""投资逻辑图解"）、对比测评、榜单、需要在社媒一眼抓眼球并塞满信息的选题。

## English Prompt 模板

```
A vibrant Xiaohongshu-style (RED app) infographic poster, high-saturation contrasting
colors, rounded cards stacked in sections, lots of emoji used as inline icons.
Bold Chinese title with outline/shadow at the top, a subtitle and a small corner badge.
Numbered section badges (①②③ or 01/02/03), key phrases highlighted with colored
background blocks. Energetic, eye-catching, content-dense, social-media share-friendly.

Sections (top to bottom): {{逐板块内容，例：① official accounts ② products ③ research
... each a colored card with a few bullet items}}.

Optional: {{a cute AI mascot character in a corner}}.

Style keywords: xiaohongshu / RED style, high saturation, colorful cards, emoji icons,
bold Chinese title, badges, highlight blocks, vertical long poster, content-rich.

Aspect ratio: {{3:4 或更长的竖图}}.
```

## 图中文字（单独逐字给模型）
- 大标题：`{{标题}}`（粗黑撞色，可带描边）+ 副标题 `{{副标题}}` + 角标 `{{v1.0 / 来源}}`
- 各板块：编号 + 板块名 `{{板块标题}}` + 条目 `{{条目文字}}`
- 底部：`{{怎么用这张图：1… 2… 3…}}`
- 中文主场，但板块多、字密 → 标题给全，每条精简；必要时拆成多张避免糊字。

## 变体
- **名单/榜单版**（必关注名单、ETF）：分类卡 + 每类列 3–N 个条目 + logo。
- **逻辑图解版**（Serenity 投资逻辑）：分步骤板块 + 表格/对比 + 重点高亮，更"逻辑流"。
- **教程长图版**（MCP 入门教程）：超长竖图，分章节，混代码块/命令行卡片，信息极密。

## 工程控制
- Creative brief 固定标题→副标题/角标→内容卡的层级；固定卡片数时在 Control block 写数量与自上而下的关系。
- 竖图的标题、角标和底部行动指引均留出安全边距；Text manifest 中 emoji 只作区块标记，每张内容卡最多一个。
- 名单/榜单、逻辑图解和教程长图分别沿用既有分类卡、逻辑流或章节/命令行卡片例外，不将它们混为同一版式。
- 在 Control block 写 `do not include evidence-dossier styling, verification stamps, or document IDs`。

## 注意 / 负面
- 与 D 区别：D 是白底克制手写网格、教学感；F 是高饱和撞色、emoji、种草社媒感。
- 高饱和但别脏；撞色要有主次。
- 这是最容易"字糊"的风格（字最多）——优先拆图、每板块精简。

## 样例图（reference/F-xiaohongshu-collage/）
- `HJa0eJ0asAApb43.jpeg` — Claude/Anthropic 必关注名单 v1.0（8 分类卡 + 吉祥物 + 底部指引）
- `HJSmmPza0AAAelL.jpeg` — Serenity 的 AI 投资逻辑图解（分步骤逻辑流）
- `HJQb25XX0AAwfoV.jpeg` — ETF building future of AI Space & robotics（分类榜单 + logo）
- `HJTwUB0bgAEEUNn.jpeg` — MCP 小白完整入门教程（超长教程竖图变体）
- `HJdDWIyXkAAykz3.jpeg` — Manus / Butterfly Effect 必关注名单（与 Claude 名单同模板：分类卡 + 真人头像 + 吉祥物 + 底部系列回顾）
