# J · 亚洲手账·马克笔解读图（Asian Handnote / Marker Study Notes）

> 一句话：像在米黄笔记本上用马克笔做的中/日文学习手账——手写体 + 真人头像贴纸 + 荧光高亮圈 + 小吉祥物 + Q&A 流程，亲切、热闹、像学霸的彩色笔记。

## 视觉特征

- **背景**：米黄 / 米白纸质底（cream notebook paper），可带极淡网格或横线。
- **配色**：暖色系为主——米黄底 + 黑色手写 + **橙/黄荧光高亮**为核心强调，蓝色手绘线框分区，少量红/绿点缀。比 A 更"彩"、比 F 更"柔"。
- **线条**：手绘抖动感线条，但更"笔记"而非"涂鸦"——圆角手绘方框、波浪下划线、箭头串联；蓝色细马克笔描边框分区块。
- **手写体**：标题和正文大量使用**手写体（中文/日文）**，关键词套**荧光高亮块或圆圈**，像用荧光笔划重点。
- **贴纸元素**：真人**头像贴纸**（圆形/方形剪贴，画人物时用半写实卡通）、星星★、emoji、小标签（如"手绘数据信息图""X/Twitter 关注清单"角标）。
- **吉祥物**：常有一个小机器人/AI 角色在角落引导。
- **构图**：竖向长图为主，自上而下分区块；常见 **Q&A 结构**（❓问题 → 💡解法 → ✅结论）、问题清单、前后对比、底部一句话总结。
- **气质**：东亚社媒学习笔记（小红书/X 中日博主），亲切、用功、信息塞得满但靠手写+高亮组织得有条理。

## 适合内容
中/日文的"硬核话题平民化讲解"、Q&A 式答疑（"为什么 X 会 Y？"）、新闻解读、个人学习笔记式科普、需要亲切又有信息量、带人物/观点背书的选题。

## English Prompt 模板

```
A hand-written study-notes infographic (Asian "shou-zhang" / study journal style) on a
cream notebook-paper background. Heavy use of hand-written {{Chinese / Japanese}} text,
key phrases highlighted with orange/yellow marker highlights and hand-drawn circles.
Blue hand-drawn rounded boxes divide the page into sections. Cut-out style avatar
stickers of {{people}}, small stars, emoji and a little AI-robot mascot in a corner.
Warm palette: cream + black handwriting + orange/yellow highlighter + light blue line
boxes, occasional red/green dots.

Layout (top to bottom): {{逐区块，例：a big hand-written title with a highlighted
keyword; ❓ a question box; 💡 a solution box with a small diagram; ✅ a bottom takeaway}}.

Style keywords: handwritten study notes, marker highlighter, cream notebook paper,
avatar stickers, cute mascot, Q&A blocks, Chinese/Japanese handwriting, friendly,
content-rich but organized, vertical long poster.

Aspect ratio: {{3:4 或更长竖图}}.
```

## 图中文字（单独逐字给模型）
- 大标题：`{{标题}}`（手写体，关键词套荧光高亮块/圆圈）+ 角标 `{{手绘数据信息图 / 来源}}`
- 区块：`❓{{问题}}` `💡{{解法}}` `✅{{结论}}`，重点词单独高亮
- 头像贴纸旁标 `{{人名 / 身份}}`
- 中/日文主场，手写体短句最稳；信息多时务必靠高亮和分区组织，单块文字压短，挤就拆图。

## 变体
- **日文新闻解读版**（135兆円那张）：米黄底 + 日文手写 + 真人头像贴纸（CEO/创始人）+ 橙色高亮圈 + 手绘上升曲线/对比表 + emoji，适合"某公司/事件"深度解读。
- **中文 Q&A 答疑版**（token 那张）：竖图，❓提问 → 问题拆解 → 用 Agent Skill 解法 → 代码/流程小图 → 底部一句话总结，蓝色手绘框分层，"手绘数据信息图"角标。
- **课程/清单提炼版**（吴恩达「AI Prompting for Everyone」那张）：竖图，顶部大手写课程标题 + 右上角名人手绘笑脸头像贴纸（如 Andrew Ng）+ 副标点明"N 节看完，提炼最值得抄的 X 条"。主体是**编号 ①–⑥ 的横向分区块**，每块=左侧手写要点（关键数字/术语套橙红高亮）+ 右侧一排黑线描涂鸦小图标（金字塔/对话框/天平等）做图解。多色克制点缀（橙红主强调，蓝绿做图标分类），底部一句话总结 + 课程链接角标。适合"长内容提炼成 N 条干货清单"的科普选题。术语锁英文（`deep research`、`Let's think step by step`），叙述用中文手写压短。

## 工程控制
- Creative brief 按变体分支：新闻解读为标题→身份头像→重点/曲线或对比→结论，Q&A 为问题→拆解→解法→总结，课程清单为编号分区；按实际选定结构计数区块，固定时在 Control block 锁定数量与自上而下关系。
- Text manifest 中每个区块只放短手写句；真人头像固定时，参考图以身份为主角色，并在 Control block 用 preservation 锁定识别特征。
- 每个区块最多一个荧光高亮重点，避免多色标记抢走阅读顺序。
- 在 Control block 写 `do not include a wall of body text`。

## 注意 / 负面
- 与 A 区别：A 是英文为主的 Excalidraw 涂鸦、强调色只用一种橙；J 是中/日文手写学习笔记、多用荧光高亮 + 头像贴纸 + 更暖更彩。
- 与 F 区别：F 是高饱和撞色 emoji 拼贴卡片（数字海报感）；J 是米黄纸 + 手写 + 荧光笔（手账/笔记感），更柔更"用功"。
- 与 D 区别：D 是白底网格术语卡、克制；J 是米黄底 + 流程/Q&A + 头像贴纸，更叙事。
- 手写中/日文字密易糊，靠高亮和分区救场，宁可拆图。

## 样例图（reference/J-asian-handnote/）
- `HJcGsZaaYAA9S9D.jpeg` — 日文「135兆円のAI企業、2026年上場観測」（真人头像贴纸 + 橙高亮 + 手绘曲线/对比表，新闻解读版）
- `HJiA-s_W0AIj-fL.jpeg` — 中文「把数据库接入 AI Agent 后为什么 token 消耗还很大」（Q&A 答疑版 + 蓝手绘框 + 吉祥物）
- `HHThyp4boAANF3s.jpeg` — 中文「吴恩达 2026 新课《AI Prompting for Everyone》21 节提炼 6 条」（课程/清单提炼版：编号 ①–⑥ 横向分区 + Andrew Ng 笑脸头像贴纸 + 橙红高亮 + 黑线描涂鸦图标）
