# O · 毛毡刺绣·立体手账（Felt Embroidery Infographic）

> 一句话：用毛毡贴布、缝线和软糯立体字，把教程与清单做成一张可以摸到的手作知识海报。

## 视觉特征

- **背景**：奶油色毛毡或亚麻布，带均匀纤维、轻微压痕和手工针脚。
- **配色**：鼠尾草绿、雾霾蓝、珊瑚橙、芥末黄和奶油白，整体低饱和、温暖。
- **线条与质感**：多层 felt appliqué、刺绣边线、锁边针、纽扣、软垫填充与自然投影；所有图标和卡片都像手工剪裁后缝在布面上。
- **字体**：主标题是厚实毛毡剪字，正文是清晰刺绣体或深色布贴字；文字必须短，避免模拟细小印刷字。
- **构图**：3:4 竖向知识海报，中心一块大标题布贴，四周环绕手机、分镜板、笔记本、图标、清单和成长箭头。
- **视觉母题**：布艺手机、六格分镜板、场记板、灯泡、版权盾牌、线圈本、铅笔、柱状图、叶片、星星和虚线缝线路径。
- **文字纪律**：标题 4–10 个字；每个布贴卡片只放 1 个短标签，长解释留给图外排版。

## 适合内容

教程清单、课程总结、亲子科普、创作者方法论、温暖型知识长图、成长复盘、生活方式主题。

## English Prompt 模板

```text
A handcrafted felt-applique and embroidery infographic poster on warm cream textile.
Every element is made from layered felt, stitched fabric patches and padded cut-out
letters, with visible blanket stitches, soft fibers, tiny seams and gentle physical
shadows. Use a muted cozy palette of sage green, dusty blue, coral orange, mustard
yellow and ivory. Tactile handmade craft, soft dimensionality, no plastic, no glossy 3D.

Vertical composition: a large central stitched title patch reading {{标题}}, surrounded
by exactly {{N}} themed felt objects and cards: {{手机 / 分镜板 / 场记板 / 清单 / 图标}}.
Connect selected objects with embroidered dashed paths. Put one small checklist near the
bottom and one upward felt arrow or chart as the closing visual. Keep labels short and
legible; preserve generous spacing between patches.

Aspect ratio: 3:4 portrait.
```

## 图中文字

- 主标题：`{{4–10 个汉字}}`，厚毛毡剪字，居中。
- 副标题：`{{一句短句}}`，刺绣布条。
- 卡片标签：每张只放 `{{2–6 个汉字}}`。
- 底部行动句：`{{8–14 个汉字}}`，单独放在浅色布贴内。

## 变体

- **教程清单版**：中心标题 + 四周工具卡 + 底部清单，信息完整但不拥挤。
- **六格分镜版**：顶部放 2×3 毛毡分镜板，每格一个图标或角色动作。
- **成长复盘版**：用缝线路径串联起点、方法、成果和下一步，底部以软布柱状图收束。

## 工程控制

- Creative brief 先固定中心标题布贴、外围卡片数量和自上而下的阅读顺序。
- Control block 必须写 `exactly [N] felt cards/objects`、`exactly [N] checklist items` 和各自位置；主标题不得被图标遮挡。
- 禁止光滑塑料、金属质感、霓虹色、照片拼贴和密集细字；真实感来自纤维、针脚和层叠，不来自写实场景。

## 样例图（reference/O-felt-embroidery-infographic/）

- `HNKB0AKbkAAzOUL.jpeg` — AI 视频干货清单（中心毛毡剪字 + 手机/六格板/场记板 + 版权盾牌 + 清单与成长图）
