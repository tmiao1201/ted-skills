# G · 杂志·黑白编辑信息图（Editorial B&W Infographic）

> 一句话：像高端杂志/咨询报告的版面——黑白为主、严谨网格排版、少量品牌色点缀，显得专业、深度、权威。

## 视觉特征

- **背景**：白 / 浅灰，部分区块用黑底反白做重点。
- **配色**：**黑白灰为主调** + 极少量单一品牌色点缀（橙/金）。克制、高级。
- **排版**：杂志栅格（columns / sections），有页眉页脚、栏目名（FIELD REPORT / CORE PRINCIPLES）、编号小节（01 02 03）、数据大字突出（如 "0.1%" "83%"）。
- **字体**：衬线大标题（editorial serif，有 Vogue/报刊感）+ 无衬线正文，对比强。
- **构图**：信息分区块清晰，重点用黑底卡反白；可含地图、路线、流程，但比 A 正式得多。
- **图标**：精炼线性图标，统一细描边。
- **气质**：严肃、权威、深度、可信，适合"官方/工程团队"出品感。

## 适合内容
深度盘点、官方/团队报告式内容、安全/原理/方法论总结、需要"权威严谨"调性而非"亲切涂鸦"的选题。

## English Prompt 模板

```
A sophisticated editorial black-and-white infographic, like a premium magazine or
consulting report spread. Mostly black/white/grey with a single restrained accent
color ({{橙 or 金}}) used sparingly. Magazine grid layout with running header/footer,
named sections (e.g. "FIELD REPORT", "CORE PRINCIPLES"), numbered subsections 01/02/03,
and a few large bold data figures highlighted ({{例：0.1%, 83%}}). Elegant serif
headlines paired with clean sans-serif body. Some sections use black cards with
reversed white text for emphasis. Refined thin-line icons.

Content blocks: {{逐区块，例：4 core principles as numbered black cards; 3 risk types
as columns; case studies at the bottom}}.

Style keywords: editorial, magazine layout, black and white, serif headline, numbered
sections, data highlights, professional, authoritative, restrained accent.

Aspect ratio: {{3:4 竖图 / 16:9 横图}}.
```

## 图中文字（单独逐字给模型）
- 页眉/栏目：`{{HEADER / 栏目名}}`（小号大写无衬线）
- 大标题：`{{标题}}`（衬线粗体，中英皆可）
- 小节：`01 {{小节名}}` + 说明；数据大字 `{{0.1%}}` 单独突出
- 中英都行；要"报刊感"建议标题用衬线、术语可中英混排。

## 变体
- **路线/地图版**（GitHub 入门指南）：左侧大标题 + 蜿蜒路线图串起节点，右侧分编号小节，整体黑白 + 极少强调。
- **field report 版**（Agent 安全实战）：完整报告版式，页眉页脚 + CORE PRINCIPLES 黑卡 + 数据大字 + 底部 case study，橙色点缀。
- **瑞士网格版**（workflow 那张）：白底 + 极简栅格 + 单一品牌色（蓝），等宽小字页眉页脚 + 大留白，4 格分镜式排版，比报刊版更"国际主义 / digital"。
- **单色框线版**（Personal CFO 那张）：单一砖红 / 赭色（terracotta）描边表格 + 等宽标题，STEP 流程条 + 分栏框线，复古技术文档 / 打字机气质。
- **黑红密集版**（LLM API、10 Principles 那两张）：黑白 + 红色双强调，手绘感细线性图标，编号宫格 / 分层注释，信息密度拉满的科普长图。

## 注意 / 负面
- 与 A 区别：A 手绘涂鸦亲切；G 是规整杂志排版、严肃权威，几乎不手绘。
- 强调色极度克制——黑白是主角。
- 排版要"对齐、留白、有层级"，避免花哨。

## 样例图（reference/G-editorial-bw/）
- `HI2KOUsa4AAWGmg.jpeg` — GitHub 小白完全入门指南（路线图版，黑白）
- `HJSb8abaoAA_Sfe.jpeg` — Agent 安全实战 field report（报告版式 + 橙点缀 + 数据大字）
- `HJbA0zoacAA3pLv.jpeg` — 10 Principles to Build Scalable AI Agents（黑+红，10 宫格编号卡 + 手绘线性图标 + 底部 tech stack）
- `HJdAH_nasAAhq0l.jpeg` — workflow 模式来了（中文，白底瑞士网格 4 格 + 蓝色强调标题 + 等宽页眉页脚 + 终端截图）
- `HJdNdq6bEAALnt-.jpeg` — What Happens When You Call Any LLM API（黑+红超密 editorial，分层编号 + 大量小字技术注释）
- `HJDOHfUbMAAIC65.jpeg` — Claude as Your Personal CFO（砖红单色框线表格 + 等宽标题 + STEP 分栏）
