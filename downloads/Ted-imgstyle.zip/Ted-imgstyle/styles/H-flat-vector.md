# H · 干净矢量·流程图风（Clean Flat Vector Diagram）

> 一句话：扁平矢量、规整的流程/架构图，圆角方框 + 清晰箭头 + 品牌色块分区，digital、整洁、专业但不冷硬。

## 视觉特征

- **背景**：纯白 / 淡色分区底（如左白右浅绿对比两栏）。
- **配色**：干净的品牌色块（蓝、绿为主），低噪、扁平、无手绘抖动。
- **线条**：规整矢量描边，圆角方框 / 菱形判断节点，实线箭头 + 虚线循环箭头，标准流程图语汇。
- **字体**：清爽无衬线（中英混排都清晰），节点内居中标注。
- **构图**：标准 flowchart / 架构图——节点 + 连线 + 判断分支 + 循环；可左右分栏做"A 的局限 vs B 的优势"对比。底部常有图例（Node / Edge / State 释义）。
- **图标**：扁平彩色图标点缀节点（大脑、工具、数据库、机器臂）。
- **气质**：清晰、专业、技术文档/教学 PPT 感，比 B（暗黑）更明亮易读、比 A（手绘）更正式精确。

## 适合内容
流程图、状态机、架构对比、"线性 vs 图状""旧方案 vs 新方案"、需要精确表达节点/分支/循环关系的技术内容。

## English Prompt 模板

```
A clean flat vector flowchart / architecture diagram. Crisp rounded rectangle nodes,
diamond decision nodes, solid arrows and dashed loop arrows (standard flowchart
grammar). Flat brand colors (blue and green), low-noise, no hand-drawn wobble, clear
sans-serif labels centered in nodes. Small flat icons accenting nodes (brain, tools,
database, robot arm). Optional two-column comparison ({{左：A 的局限 / 右：B 的优势}})
on a split white / pale-green background. A small legend at the bottom explaining
Node / Edge / State.

Diagram content: {{流程内容，例：Start/Think node → conditional diamond → Tools node
(parallel) → Quality Check → End, with a conditional loop back}}.

Style keywords: flat vector, flowchart, architecture diagram, rounded boxes, decision
diamonds, clean arrows, blue + green, sans-serif, professional, bright, precise.

Aspect ratio: {{16:9 横图}}.
```

## 图中文字（单独逐字给模型）
- 标题：`{{标题，中英混排}}`（顶部，无衬线粗体）
- 节点标签：`{{节点名}}` + 括注说明（如 "A (Start/Think) — LLM"）
- 边标签：`{{条件文字，如 [Needs Tool?] yes / no}}`
- 图例：`{{Node 节点 / Edge 边 / State 状态}}`
- 中英混排清晰，是这个风格的强项；流程逻辑务必在 prompt 里讲清节点连接关系。

## 变体
- **对比双栏版**（LangChain vs LangGraph）：左窄栏画"局限版"、右宽栏画"完整流程"，背景分色。
- **手绘混合版**（Codex GOAL 偏此类但带手绘）：若节点是手绘风 + 品牌色，介于 A 与 H 之间，按主导风格归类。

## 注意 / 负面
- 与 B 区别：B 暗黑 mono 极客；H 明亮矢量、易读、教学感。
- 与 A 区别：A 手绘抖动亲切；H 规整精确无抖动。
- 流程关系要在 prompt 里写明确（谁连谁、哪是循环、哪是分支），否则模型乱连线。

## 样例图（reference/H-flat-vector/）
- `HJTe54MaUAACiz8.jpeg` — LangChain 线性链 vs LangGraph 图状编排（对比双栏 + 底部图例）
