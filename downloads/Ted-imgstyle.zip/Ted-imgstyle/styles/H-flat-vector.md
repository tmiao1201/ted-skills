# H · 干净矢量·流程图风（Clean Flat Vector Diagram）

> 一句话：扁平矢量、规整的流程/架构图，圆角方框 + 清晰箭头 + 品牌色块分区，digital、整洁、专业但不冷硬。

## 视觉特征

- **背景**：纯白 / 淡色分区底（如左白右浅绿对比两栏）。
- **配色**：干净的品牌色块（蓝、绿为主），低噪、扁平、无手绘抖动。
- **线条**：规整矢量描边，圆角方框 / 菱形判断节点，实线箭头 + 虚线循环箭头，标准流程图语汇。
- **字体**：清爽无衬线（中英混排都清晰），节点内居中标注。
- **构图**：标准 flowchart / 架构图——节点 + 连线 + 判断分支 + 循环；可左右分栏做"A 的局限 vs B 的优势"对比。底部常有图例（Node / Edge / State 释义）。
- **图标**：扁平彩色图标点缀节点（大脑、工具、数据库、机器臂）。
- **气质**：清晰、专业、技术文档/教学 PPT 感，比 B（暗黑）更明亮易读、比 A（手绘）更正式精确。

## 适合内容
流程图、状态机、架构对比、"线性 vs 图状""旧方案 vs 新方案"、需要精确表达节点/分支/循环关系的技术内容。

## English Prompt 模板

```
A clean flat vector flowchart / architecture diagram. Crisp rounded rectangle nodes,
diamond decision nodes, solid arrows and dashed loop arrows (standard flowchart
grammar). Flat brand colors (blue and green), low-noise, no hand-drawn wobble, clear
sans-serif labels centered in nodes. Small flat icons accenting nodes (brain, tools,
database, robot arm). Optional two-column comparison ({{左：A 的局限 / 右：B 的优势}})
on a split white / pale-green background. A small legend at the bottom explaining
Node / Edge / State.

Diagram content: {{流程内容，例：Start/Think node → conditional diamond → Tools node
(parallel) → Quality Check → End, with a conditional loop back}}.

Style keywords: flat vector, flowchart, architecture diagram, rounded boxes, decision
diamonds, clean arrows, blue + green, sans-serif, professional, bright, precise.

Aspect ratio: {{16:9 横图}}.
```

## 图中文字（单独逐字给模型）
- 标题：`{{标题，中英混排}}`（顶部，无衬线粗体）
- 节点标签：`{{节点名}}` + 括注说明（如 "A (Start/Think) — LLM"）
- 边标签：`{{条件文字，如 [Needs Tool?] yes / no}}`
- 图例：`{{Node 节点 / Edge 边 / State 状态}}`
- 中英混排清晰，是这个风格的强项；流程逻辑务必在 prompt 里讲清节点连接关系。

## 变体
- **对比双栏版**（LangChain vs LangGraph）：左窄栏画"局限版"、右宽栏画"完整流程"，背景分色。
- **手绘混合版**（Codex GOAL 偏此类但带手绘）：若节点是手绘风 + 品牌色，介于 A 与 H 之间，按主导风格归类。
- **深色变体**（走错方向 那张）：背景翻深色（near-black / 深灰），扁平矢量**人物插画** + 绿/橙强调 + 流程 / 架构长图。介于 H 与 B 之间，但保留矢量插画与圆润图标（不是终端 mono），按"有矢量插画 + 品牌色"归 H 而非 B。
- **发布信息图版**（Opus 4.8 那张）：顶部产品名 + 卖点卡 + benchmark 表格 + "What's new / Where available" 分区，扁平 + 单品牌色，官方 release 配图风。
- **密集技术卡片长图版**（LLM 底层原理那张）：白底竖向长图，顶部用超大黑体标题 + 一行端到端流程带 + 右侧引用卡；主体采用 3×3 等宽圆角卡片矩阵，每卡固定为“彩色编号 + 中英术语标题 + 两三行解释 + 极简公式/小流程图 + 淡色 Tiny explainer 底栏”。配色不是大色块，而是蓝、青、紫、橙、红等低饱和描边按章节编码；底部再放 2–3 张总结卡和深色结论条。适合把复杂系统拆成 7–10 个连续模块，信息密度高但依靠严格网格、统一卡片骨架和大量白底维持秩序。

## 工程控制

- **标准 flowchart / architecture 变体**：**Creative brief** 选择左→右或上→下，并用一句 brief 说明起点、判断/分支与终点的阅读路径。**Text manifest** 中每个节点名不超过 6 个汉字或 3 个英文词；每条边最多携带一个条件。
- 仅标准 flowchart / architecture 变体锁定圆角矩形节点、菱形判断节点、扁平蓝绿配色和规整矢量描边；禁止手绘抖动、随意弯曲的线条或非流程图语法。
- 标准 flowchart / architecture 变体的 **Control block** 必须列出 `exactly [N] nodes`、`exactly [N] decision nodes`、所有分支及其去向、所有循环及其回接关系、图例是否存在；不需要的分支、循环或图例必须明确排除。
- **发布信息图**与密集卡片矩阵变体：Creative brief 必须说明色板与节点语法相对标准流程图的例外；不强制菱形判断、蓝绿配色、分支或循环。Control block 只为实际出现的卡片、表格和关系输出准确数量、位置或连接，且不输出虚构的流程图元素。
- **深色变体**：锁定深灰/近黑背景、绿橙强调、圆润矢量人物插画和非 terminal mono 的字体气质。Control block 只按实际出现的流程/架构元素输出可检验数量、方位或连接关系，不强制标准 flowchart 的菱形、蓝绿或循环语法。
- **手绘混合版**：只有当手绘是主导风格时才允许手绘节点；否则仍按规整矢量处理。不强制蓝绿配色或标准菱形，Control block 按实际可数节点与关系输出数量、位置或连接，不虚构判断、分支或循环。

## 注意 / 负面
- 与 B 区别：B 暗黑 mono 极客；H 明亮矢量、易读、教学感。
- 与 A 区别：A 手绘抖动亲切；H 规整精确无抖动。
- 流程关系要在 prompt 里写明确（谁连谁、哪是循环、哪是分支），否则模型乱连线。

## 样例图（reference/H-flat-vector/）
- `HJTe54MaUAACiz8.jpeg` — LangChain 线性链 vs LangGraph 图状编排（对比双栏 + 底部图例）
- `HIOLDxAXMAEMtbX.jpeg` — How to Build an Obsidian Vault That Grows（六边形 vault + 扁平图标卡 + 紫/橙/绿 INPUT→OUTPUT 流）
- `HJapzxQaYAAhuTD.jpeg` — Skills.md Your AI's Operating System（三栏卡片 + 品牌色 + 表格，扁平 vector）
- `HJbQdO2agAA73gY.jpeg` — Claude Opus 4.8 Build more, Ship faster（扁平卡片 + benchmark 表 + 橙品牌色，发布信息图版）
- `HJeAeeia0AAfCQu.jpeg` — 中文「工程化工作流」（扁平矢量 + 蓝绿卡片 + 真人矢量插画，旧用法 → 新用法）
- `HJF5GxmagAASc5r.jpeg` — CI/CD 全流程（8 阶段编号卡 + 品牌 logo + 底部工具表 / 架构，超完整 flowchart）
- `HJT6MHObkAAB60c.jpeg` — 中文「走错方向了」（深色变体：深底 + 扁平矢量人物插画 + 绿/橙强调 + 记忆层架构长图）
- `HLKdyasXMAAHezS.jpeg` — LLM 底层到底在干什么（密集技术卡片长图版：顶部总流程 + 3×3 模块矩阵 + 公式/小图 + Tiny explainer + 底部总结）
