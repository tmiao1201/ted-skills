# 城市手卡分镜词指南（trip-cards · 产物③）

调用 `Ted-imgstyle` skill 的"生图"流程，为每座城市出一张统一风格的旅游手卡。本文件给：①分镜套路 ②默认 J 手账锚句模板 ③图中文字纪律 ④成套不跑风的做法 ⑤各目的地配色表（HTML 卡也用它）。

---

## ① 分镜套路（每城一张，3:4 竖图）
先把分镜列给用户过目，再出提示词。每张：
- **hero**：该城最标志的 1 个景点（占主视觉）
- **2–3 个小景点**（蓝框涂鸦 + 手写标签）
- **2 个特色美食**（食物涂鸦 + 标签）
- **1 条行程标签**（🚄/✈️ + 起讫 + 时刻，或天数 Dx）
- **角标**：`{{目的地}}手账·序号`

## ② 选风格
默认 **J 亚洲手账**（米黄笔记本纸 + 手写中文 + 荧光高亮 + 涂鸦 + 贴纸，最贴"旅游手账"、中文标签好看）。
备选：**F 小红书**（高饱和撞色 emoji 拼贴，种草感）/ **A 米黄手绘**（黑线涂鸦明信片，文字最少最稳）。让用户选一种，**5 张统一**。

## ③ J 手账·风格锚句（5 张一字不动）
```
A hand-written travel study-journal ("手账"/shou-zhang) infographic on warm cream
notebook paper with faint grid lines. Hand-written Chinese text, key words highlighted
with orange-and-yellow marker highlighter and hand-drawn circles. Light-blue hand-drawn
rounded boxes divide the page into sections. Cute doodle line-illustrations of landmarks
and food, a few cut-out stickers (stars, washi-tape strips) and a tiny mascot in a corner.
Warm palette: cream paper + black handwriting + orange/yellow highlighter + light-blue
boxes. Cozy hand-made travel-notebook feel, content-rich but organized. Vertical 3:4 poster.
```
> 换非暖色目的地时，把锚句里的 "warm cream / orange highlighter" 按 ⑤ 配色表替换主强调色（如江南→青绿高亮、海岛→湖蓝高亮），其余不动。

**逐城主体（接锚句后）：**
```
City: {{城市英文}}. Hero illustration: {{hero 景点英文描述}}. Smaller doodles in blue
boxes: {{小景点1}}, {{小景点2}}. Food row at the bottom: {{美食1}} and {{美食2}} with
steam doodles. A little {{🚄/✈️}} icon near a transport tag.
```

## ④ 图中文字（单独逐字给模型，务必精简）
- 顶部大标题 `{{城市}}`（首字套高亮圈）
- 右上贴纸 `{{Dx / 日期}}`
- 蓝框 `{{景点1}}` `{{景点2}}` `{{景点3}}`
- 美食 `{{美食1}}` `{{美食2}}`
- 底部 `{{🚄/✈️ 起讫 时刻}}`
- 角标 `{{目的地}}手账·{{序号}}`
> 中文渲染易糊：每块压短；糊就减字（先保城市名+景点名）或重生挑好的。

## ⑤ 成套不跑风
1. **先生第 1 张**当样板，满意后把它**作为风格参考图**一起喂，再生其余 N 张。
2. 锁死：锚句 + 配色 + 质感词不动，**只换主体描述和图中文字**。
3. 全部 3:4 竖图 → 手机相册成套、可发小红书九宫格。

## ⑥ 精确数据归 HTML，不进生图
车次/时刻/座位等精确信息**只**放产物①②的 HTML 卡；手卡图里只放精简标签（"🚄 沪→洛 06:48"），因为 AI 渲染密集中文/数字易糊。

---

## 各目的地配色表（HTML `:root` 变量 + 生图高亮色统一用）

| 目的地主题 | 背景/纸 | 主强调 | 次/金 | 适用 |
|---|---|---|---|---|
| 沙漠·丝路（默认） | `#F4ECDD` | `#BF5E2E` 赭橙 | `#B5903F` 沙金 | 西北/河西走廊/敦煌 |
| 江南·古镇 | `#F2F4EE` | `#3E7D6E` 青瓷绿 | `#9AAE7B` 竹青 | 江浙/徽州/水乡 |
| 海岛·滨海 | `#EEF5F6` | `#2E7DA1` 湖蓝 | `#E0A24E` 沙金 | 海南/厦门/海岛 |
| 雪国·北境 | `#EEF1F5` | `#3D5A80` 雪蓝 | `#98A8BC` 雾灰 | 东北/雪乡/高纬 |
| 都市·现代 | `#F1F1F3` | `#34405A` 石墨蓝 | `#C0894B` 暖铜 | 大都市/夜景游 |
| 山林·秋色 | `#F5EFE6` | `#B05A2A` 枫橙 | `#7E8B4E` 苔绿 | 川西/秋叶/红叶 |

> 锁屏卡（产物②）用对应主题的**深色版**：背景取主强调色的极深褐/墨调，文字用纸色+金，保持与行程卡同源。
