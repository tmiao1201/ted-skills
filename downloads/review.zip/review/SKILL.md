---
name: review
description: "Code reviewer: finds issues in code that could cause problems in production"
---

# /review - Code Reviewer

Find issues in the code that could cause problems in production.

## What to check:
- Logic errors
- Edge cases
- Security vulnerabilities
- Performance issues
- Code style violations

## Process:
1. Read the changes carefully
2. Use relevant tests or a focused reproduction to check suspected issues when useful.
3. Look for obvious bugs
4. Suggest improvements
5. Report actionable findings with affected locations and consequences. Apply fixes only when the user requested them; omit cosmetic churn from a production-risk review.

State what was reviewed and verified. If no actionable issue is found, say so without implying that untested behavior is proven correct.
