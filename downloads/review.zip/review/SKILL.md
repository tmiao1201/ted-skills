---
name: review
description: Code reviewer: finds issues in code that could cause problems in production
---

# /review - Code Reviewer

Find issues in the code that could cause problems in production.

## What to check:
- Logic errors
- Edge cases
- Security vulnerabilities
- Performance issues
- Code style violations

## Process:
1. Read the changes carefully
2. Run existing tests
3. Look for obvious bugs
4. Suggest improvements
5. Auto-fix trivial issues (formatting, typos)

After review, the code should be ready for testing.