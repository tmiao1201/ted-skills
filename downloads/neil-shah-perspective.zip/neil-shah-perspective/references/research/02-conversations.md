# 02 · Neil Shah 的长对话与即兴思考

> 调研维度：播客、长视频访谈、TV 直播评论、panel 发言、AMA。重点抓"被追问时的回答方式"和"即兴类比"。
> 调研时间：2026-05-24。
> 信息源黑名单遵循：未使用知乎、微信公众号、百度百科。

## 总体观察

Neil Shah 的"长对话"主要分两类：
1. **TV / 财经媒体即时评论**（CNBC、CNBC-TV18、Bloomberg TV、Reuters TV、Forbes India、ET Now）——通常 3-8 分钟，回答 1-3 个具体问题，节奏快、数据密、有 1-2 个金句。
2. **行业论坛 panel / keynote**（MWC、SEMICON India、IoT World Asia、5G Asia、Display Supply Chain Conference、Tech Show India）——15-45 分钟，框架性更强，他更愿意露出方法论。

他**很少**出现在长形式深度对话（>1 小时单人访谈）类节目里——这是分析师人物相比 CEO/创业者的典型差异。最接近"长访谈"的样本是 Onalytica blog（2017 文字访谈）、HERE 平台访谈（书面）、TomTom Newsroom 访谈（书面）、Forbes India "The Daily Tech Conversation" 播客（2024 关于 Apple 印度制造）。

---

## 一、已确认的播客 / 视频访谈

### 1. Forbes India - The Daily Tech Conversation（2024）
- 标题："Neil Shah, at Counterpoint Research, on Apple's manufacturing strategy and growing volumes in India"
- 平台：Spotify
- 来源：[Spotify episode link](https://open.spotify.com/episode/5utV6rI8Vlu22gaghATW8G) / [Creators page](https://creators.spotify.com/pod/profile/forbes-india---the-daily-tech-conversation1/episodes/Neil-Shah--at-Counterpoint-Research--on-Apples-manufacturing-strategy-and-growing-volumes-in-India-e1h1e8a)
- 议题：Apple India 制造、Foxconn vs Tata 分工、PLI 政策影响、印度 vs 越南、出口逻辑。

### 2. CNBC "Why Apple Is Betting Big On Making iPhones In India"（2023-2024）
- 平台：CNBC，Counterpoint 转发
- 来源：[Counterpoint Insight](https://www.counterpointresearch.com/insight/cnbc-ft-neil-shah-why-apple-is-betting-big-on-making-iphones-in-india)
- 议题：Apple 印度门店、Cook 访印、制造扩产逻辑。

### 3. CNBC "India's chip sector is taking 'baby steps'"（2025-09-03）
- 平台：CNBC International Video
- 来源：[CNBC video 2025-09](https://www.cnbc.com/video/2025/09/03/indias-chip-sector-is-taking-baby-steps-counterpoint-research.html)
- 议题：印度半导体进展、SEMICON India 2025 解读。
- Neil 的金句框架："baby steps"——刻意压低预期，反对印度半导体"超英赶美"的宏大叙事。

### 4. CNBC "Analyst discusses India's bid to become a global chipmaking hub"（2022-09-28）
- 来源：[CNBC video 2022-09](https://www.cnbc.com/video/2022/09/28/analyst-discusses-indias-bid-to-become-a-global-chipmaking-hub.html)
- 议题：印度芯片野心、Vedanta-Foxconn JV（后来失败）。

### 5. CNBC-TV18 Twitter Spaces "The 5G Opportunity"（2023-02-23）
- 平台：Twitter Spaces 现场，5pm IST
- 来源：[Counterpoint Insights](https://www.counterpointresearch.com/insights/meet-counterpoint-twitter-spaces-5g-opportunity-driving-next-wave-digital-transformation-consumers-enterprises/)
- 议题：5G 的 consumer + enterprise 双引擎。

### 6. HAS 2024 - Huawei Analyst Summit "Analyst Perspectives"（2024）
- 平台：Huawei Tech Talks
- 来源：[Huawei page](https://www.huawei.com/en/huaweitech/techtalks/has24-counterpoint-neil)
- 议题：AI deployment in telecoms。
- 注：完整文字稿未抓取到（页面只剩 metadata）。

### 7. HERE Interview - Location Platforms（2024-2025）
- 平台：HERE Technologies blog + Facebook video
- 来源：[HERE blog](https://www.here.com/learn/blog/evaluating-location-platforms-an-interview-with-neli-shah-of-counterpoint-research) / [Facebook video](https://www.facebook.com/here/videos/we-sat-down-with-neil-shah-counterpoint-research-to-discuss-how-ai-and-ground-tr/1990737435178076/)
- 议题：地图 + 位置智能、AI + ground truth。

### 8. TomTom Newsroom Q&A - Automotive Tech（2024-2025）
- 来源：[TomTom newsroom](https://www.tomtom.com/newsroom/explainers-and-insights/counterpoint-research-interview-neil-shah/)
- 议题：IVI 演进、software-defined vehicle、voice/copilot。

### 9. The Rise of AI Agentic Commerce Ft. Neil Shah（2025-10）
- 平台：Counterpoint Research
- 来源：[Counterpoint Insight](https://counterpointresearch.com/en/insights/the-rise-of-ai-agentic-commerce-ft-neil-shah)
- 议题：agentic commerce、AI 智能体购物。

### 10. Podcast #76: GenAI – The Next Big Thing in Smartphones（Counterpoint 内部播客）
- 来源：[Counterpoint Podcast 76](https://counterpointresearch.com/en/insights/podcast-76-genai-next-big-thing-smartphones)
- 议题：GenAI 手机定义、采用节奏。

### 11. 5G Monetization Forum（2022, virtual）+ MWC 系列（年度）
- 来源：[Counterpoint 5G Monetization 2022](https://www.counterpointresearch.com/5g-monetization-forum-2022/)
- 议题：5G 的 B2B 商业化路径。

### 12. BT Tech Today Congress ft. Neil Shah
- 来源：[Counterpoint Insight](https://www.counterpointresearch.com/insights/bt-tech-today-congress-ft-neil-shah/)
- 议题：印度通信产业。

### 13. Inaugural Business of Semiconductor Summit ft. Neil Shah
- 来源：[Counterpoint Insight](https://www.counterpointresearch.com/insights/the-inaugural-business-of-semiconductor-summit-ft-neil-shah/)
- 议题：半导体商业生态。

### 14. SEMICON India 2025（speaker）
- 来源：[SEMICON India profile](https://www.semiconindia.org/node/7136)
- 议题：印度半导体生态。

### 15. MWC Shanghai（年度 speaker）
- 来源：[MWC Shanghai profile](https://www.mwcshanghai.com/agenda/speakers/15375-neil-shah)

---

## 二、被追问时的回答方式（Pattern）

从访谈实录里能看到的几个典型 pattern：

### Pattern A：先给数据，再给类比，最后给行动建议
- 例如 HERE 访谈谈定位平台：先说 "Most of the location mapping players are moving from mapping and data platforms to an overall location intelligence approach"（趋势判断）→ 再给类比 "A transportation company likely already has a map that gives them a route between two points. But, when you add a strong location intelligence layer to that map, now you have a service that provides road conditions, traffic ahead..."（具体场景）→ 最后给评价 "if you look at HERE, it's completely independent because of its business model – which is rooted in licensing."（位置定位）

### Pattern B：用"smartphone 演化史"做万能类比
- TomTom 访谈："There are a lot of parallels between vehicle tech and smartphones, and how these have evolved."
- "We have gone from basic phones, to feature phones, to smartphones with bigger displays" → 用来解释车机 IVI 的演进路径。
- 几乎所有跨行业话题（车、IoT、PC、wearable）他都会回到手机这条参照线。

### Pattern C：拒绝单极叙事，主动加 "but, however, marathon"
- Apple India 制造："It will not be a sprint to build like-for-like supplier ecosystem as it enjoyed in China, but a marathon and a step by step process."
- India semi 半导体："baby steps"——明确告诉媒体不要过度兴奋。
- 这是分析师的职业本能：避免被引用成"语不惊人死不休"，宁可降一档预期。

### Pattern D：碰到敏感客户（如 Apple、Samsung），用第三人称 + "ecosystem"语言
- 他几乎从不直接评价 Apple 决策的对错，而是说 "Apple is looking to build...", "Apple is positioned to..."。
- 当被问"谁是赢家"，他常给一个组合（"Apple and Samsung are best positioned"）而非单一选择。

### Pattern E：被追问预测时，给"if-then"条件预测而非绝对预测
- "In an ideal scenario, India should aim for at least 35 per cent... This is possible if we build enough capacity and support the component ecosystem."（条件式）
- "The PLI support should continue... to keep India cost competitive until it reaches a good threshold."（前置条件 + 阈值）

---

## 三、即兴类比与隐喻

| 类比 | 用在哪里 | 揭示 |
|------|---------|------|
| Marathon, not a sprint | Apple India 供应链建设 | 长期主义节奏感 |
| Baby steps | 印度半导体进展 | 反通胀预期 |
| Smartphone evolution as template | 解释车机/IoT/wearable | "我的核心数据集" |
| "Smarter brains and larger memory buffers" | 解释 GenAI 手机硬件升级 | 拟人化技术叙事 |
| "Maximum share of a user's lives will rule" | 解释 brand equity 终局 | 平台霸权视角 |
| "Volume to value" | 解释行业从拼出货转向拼营收 | 招牌口号 |
| "Channel-specific brand" | 解释 Xiaomi/Realme 战略 | 印度市场专属语 |
| Layer cake（Maps → Location intelligence layer） | 解释平台叠加结构 | B2B 平台思维 |

---

## 四、改变立场的瞬间（observable）

公开素材中很难看到 Neil 大幅修正自己的立场（部分原因是 Counterpoint 报告更新频繁，旧观点不会被孤立保存）。但能观察到几处节奏调整：

1. **2022 → 2023 印度半导体**：从早期对 Vedanta-Foxconn JV 的相对乐观，转向 2025 "baby steps" 的克制。失败的 JV 让他更谨慎。
2. **2023 5G hype → 2025 5G enterprise reality**：早期强调消费者 5G，后期更聚焦企业级（5G 在 IoT、FWA、私有网络）。
3. **2024 AI 手机定义**：从早期模糊的"AI 智能手机"概念，逐步收紧到 "GenAI-capable"（明确 7B+ 本地参数 + agentic 能力）。
4. **2025-2026 全球出货量预测**：在 RAM 价格暴涨后从 +X% 转向 -2.1%，背书 MS Hwang/Yang Wang 的下修。

---

## 五、拒绝回答 / 沉默的话题

- **直接点评客户公司的产品缺陷**：他不会公开说"iPhone 17 Pro 设计失败"或"Samsung One UI 太烂"。
- **政治立场（莫迪政府、中美贸易）**：他评政策走向，但不评政治人物。
- **股票推荐**：分析师身份决定他不给 buy/sell rating（这是 sell-side equity research 的工作）。
- **同行公开开撕**：他不会公开反驳 IDC、Canalys、Gartner 的具体数字，即使 Counterpoint 的数字差异显著（"All over the map" 是外部评论而非他自己评论）。
- **Counterpoint 内部商业**：估值、客户名单、收入构成，从不公开。

---

## 六、信息不足或薄弱维度

- **长形式深度对话（>1 小时）**：基本不存在。最长的可访问内容是 Forbes India 30 分钟级别。
- **现场直播金句**：CNBC / Bloomberg 短评的完整文字稿大多没有公开存档，只能通过媒体引用拼凑。
- **会议 keynote 录像**：MWC / SEMICON 的现场视频通常不公开或埋在 organizer 付费会员区。

