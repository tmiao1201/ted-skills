# 04 · 他者视角与外部评价

> 调研维度：媒体引用频率、同行（IDC/Canalys/Gartner/CCS Insight/TechInsights）对比、被反驳/挑战的案例、外部对 Counterpoint 整体声誉的评价。
> 调研时间：2026-05-24。
> 信息源黑名单遵循：未使用知乎、微信公众号、百度百科。

## 总体观察

Neil Shah 是亚洲科技媒体最常引用的 smartphone / semiconductor 分析师之一，但他个人**没有像 Ben Thompson、Patrick Boyle、Benedict Evans 那样的"独立媒体声誉"**——他的影响力 99% 通过 Counterpoint Research 品牌发声。

外部对他和 Counterpoint 的评价分三类：

1. **媒体方的"引用便利性"评价**：高——他回复快、给具体数字、英语流畅、愿意上 TV。
2. **同行（其他咨询机构）的隐性竞争**：Counterpoint vs IDC / Canalys / Gartner 经常给出**互不相同的数字**，外界对此有"all over the map"的批评（不直接点 Neil 个人）。
3. **客户方（OEM / 政策方）的声誉**：他长期出现在 Huawei Analyst Summit、MediaTek Summit、Apple 印度发布事件，说明在客户侧有可信度。

---

## 一、媒体引用频率（定性）

被引用最频繁的几家：

| 媒体 | 引用主题 | 频次定性 |
|------|---------|---------|
| **CNBC / CNBC International** | Apple India、印度半导体、smartphone shipments | 极高（年均 10+ 次） |
| **CNBC-TV18 / ET Now（印度）** | 印度市场季度回顾、5G、PLI | 极高（季度常驻嘉宾） |
| **Bloomberg / Bloomberg TV** | Apple、Samsung、中国手机品牌 | 高 |
| **Reuters** | smartphone shipments、Apple India、Foxconn 扩产 | 高 |
| **Financial Times** | China smartphone、Huawei、AI 手机 | 中 |
| **The Information** | Apple supply chain、亚洲科技产业 | 中 |
| **Wall Street Journal** | Apple, China, India | 中 |
| **TechCrunch** | startup 趋势、AI 手机 | 中 |
| **Forbes India / 印度本地媒体（Mint、ET、Business Standard、Outlook Business）** | 印度智能手机、电子制造 | 极高 |
| **Mobile World Live / GSMA Intelligence** | 5G、MWC、telecom | 高 |
| **IANS / PTI**（印度通讯社） | 政策与产业 | 高 |
| **Patently Apple** | Apple 印度、Foxconn | 中 |
| **My Mobile India / Fonearena / Gizbot / Outlook Business** | 印度本地市场 | 极高 |

### 引用议题的分布

按议题热度（粗略排序）：
1. Apple 印度制造、iPhone 印度销售（最常被引用）
2. India smartphone quarterly tracker
3. GenAI / AI 智能手机
4. 印度半导体（SEMICON India、PLI）
5. 中国手机品牌（Huawei 回归、Xiaomi、OPPO/Vivo 全球化）
6. 5G monetization
7. 高端化（premiumization）全球趋势
8. Memory / RAM 价格冲击（2025-2026 新议题）

注意他**很少被引用的主题**：消费者心理 / UX / 产品设计美学、电池/续航深技术、操作系统（iOS/Android）哲学层面、个人开发者经济。

---

## 二、与同行（其他咨询机构）的视角对比

| 机构 | 强项 | vs Counterpoint / Neil 的差异 |
|------|------|------------------------------|
| **IDC** | 全球出货量 sell-in 数据、企业 IT 市场 | IDC 偏 sell-in，Counterpoint 偏 sell-through + retail demand。两家手机出货量数字常差 5-15% |
| **Canalys** | 全球 channel-based 数据、SMB 市场 | Canalys 同样偏 sell-in，但欧洲覆盖更细 |
| **Gartner** | 企业级 IT、Magic Quadrant、CIO 视角 | Gartner 在 device 市场份额不如 IDC/Canalys；其分析师更倾向战略框架，少给具体数字 |
| **CCS Insight** | 欧洲市场、telecom 业务 | 欧洲深度更强 |
| **TechInsights**（原 Strategy Analytics 大部分人员） | smartphone 拆机、teardown、半导体 BOM | Counterpoint 不做 teardown，TechInsights 做 |
| **Omdia** | 显示器、半导体 | 显示器领域比 Counterpoint 强 |
| **GfK / Circana** | 零售 POS 数据、欧美 | 渠道数据补充 |
| **Niko Partners** | 亚洲游戏 | 不同领域 |

**Neil 的差异化**：
- 全球 + 印度交叉视角（很少有分析师同时覆盖好这两个）
- "shipment + ASP + revenue + profit share" 四维框架是 Counterpoint 招牌（IDC/Canalys 偏 unit shipments）
- 半导体 + 设备 + 网络的"全栈视角"（不只看一层）
- 印度本地访问能力（Mumbai 常驻、印地语 + 英语，能接触本地 OEM 和政府）

---

## 三、被挑战 / 反驳的案例

公开素材里直接反驳 Neil 个人的案例很少（分析师之间通常通过"己方数据"间接反驳，而非点名）。但可以观察到一些信号：

### 1. Counterpoint 数字 vs IDC / Canalys 数字的差异（媒体侧的反映）
- Patently Apple 2024 评论："A Major Clash between analytical reports from Canalys & Gartner regarding Q3-24 PC shipments causes confusion in the market." 来源：[Patently Apple](https://www.patentlyapple.com/2024/10/a-major-clash-between-analytical-reports-from-canalys-gartner-regarding-q3-24-pc-shipments-causes-confusion-in-the-market.html)
- WalasTech 评论："reports from IDC and Counterpoint have been published with statistics that are all over the map, showing that these firms sometimes produce conflicting market data and interpretations."
- Starsight 把 Gartner、IDC、Forrester 列为 "FIGs"（biggest analyst firms），暗示 Counterpoint 在第二梯队。
- **影响**：媒体读者对 Counterpoint 数字的"权威性"评分中等偏上，但低于 Gartner 的品牌力。

### 2. 印度半导体的乐观 vs 现实
- 2022 Neil 对 Vedanta-Foxconn 印度半导体 JV 偏乐观（CNBC 视频）→ 该 JV 2023 失败。
- 2025 他主动用 "baby steps" 修正预期，是一次隐性的"打脸自己"。

### 3. AI 手机定义之争
- 2024 Apple Intelligence 发布后，市场有声音质疑"AI 手机"定义过松（任何带 NPU 的手机都被算）。Counterpoint 后来收紧到 "GenAI-capable"（明确硬件 + 模型尺寸阈值），是对市场质疑的回应。

### 4. "Apple 在中国份额会回升"vs "永久衰退" 的预测
- 2023-2024 关于 Apple 在中国 vs Huawei 复兴的预测，市场分歧大。Neil 的立场：Apple 在中国会承压但 ecosystem 强，难被完全替代；Huawei 回归主要影响中端。事后看，这个判断方向上对，但具体节奏（季度涨跌）经常修正。

---

## 四、外部对 Counterpoint 整体声誉的评价

正面：
- "fast-growing industry research firm"（多家媒体描述）
- "sought-after frequently-quoted Industry Analyst"（[Counterpoint 自己 page](https://counterpointresearch.com/en/opinion-leader/10)，但被广泛复制）
- **印度市场权威**：印度本地媒体（ET、Mint、Business Standard）几乎把 Counterpoint 当作 default source。
- **韩国市场权威**：Tom Kang 在韩国是 default source。

中性/负面：
- 体量小于 Gartner、IDC（员工数和收入差一个数量级）。
- 在欧洲市场覆盖度不如 CCS Insight、Canalys。
- 在企业 IT / 云计算赛道弱（vs Gartner / Forrester / IDC）。
- 数字偶尔与同行差异大，被部分读者诟病。

---

## 五、Neil 在 LinkedIn / X 上被反驳的案例

公开可见的"被反驳"少见。但有几个观察：
- 他偶尔会和媒体记者 / 同行（如 @karn_chauhan, @Tarunpathak）公开讨论数据细节。
- 他对评论区争议较少回应（更倾向用下一份 report 回应）。
- 印度 X 社区对他的认可度很高，几乎不存在系统性反 Counterpoint 的圈子。

---

## 六、被同事称呼的关系网络

Counterpoint 内部最常一起出现的人：
- **Tom Kang**（Co-founder, Seoul-based，韩国市场、Samsung）
- **Peter Richardson**（Co-founder, UK-based，欧洲、tablet）
- **Tarun Pathak**（Research Director, Gurugram-based，印度市场招牌）
- **Jeff Fieldhack**（Research Director, US-based，北美、运营商）
- **Karn Chauhan**（Senior Analyst, 印度市场细分）
- **MS Hwang, Yang Wang**（Korea/China analysts，2026 RAM 价格分析署名）
- **Jene Park**（Korea, foundry / semiconductor）

Counterpoint 2013 年成立，由 Strategy Analytics 老同事 + 客户关系网组成。

---

## 七、信息不足或薄弱维度

- **结构性反对意见**：缺少 academic / independent commentator 对 Neil 的系统批评。
- **粉丝群体画像**：X follower 数量级未确认，LinkedIn 万人级，但具体互动深度未量化。
- **被引用频次的精确统计**：定性高，定量需要 Muck Rack 等付费数据库。
- **同行的私下评价**：闭门信息无法获取。

