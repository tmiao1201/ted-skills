# 06 · Neil Shah 时间线

> 调研维度：从教育背景到 2026 最新动态。重点防过时——突出 2024-2026 动态。
> 调研时间：2026-05-24。
> 信息源黑名单遵循：未使用知乎、微信公众号、百度百科。

## 一、教育背景

| 时间 | 节点 | 来源 |
|------|------|------|
| 早期 | Electronics Engineer 本科（印度，具体院校未公开确认）"I grew up tinkering with electronics and went on to become an Electronics Engineer" | [Onalytica 访谈](https://onalytica.com/blog/posts/an-interview-with-neil-shah/) |
| ~2006-2007 | **University of Maryland**（USA）攻读 Telecommunications + Business Management，"multiple advanced degrees in telecommunications and business management from the University of Maryland" | LinkedIn / Counterpoint bio |
| 早期工作期间 | 在 Maryland 期间担任 **Information Systems Analyst at the University of Maryland** | LinkedIn 等多源 |
| 近年 | **Executive Program in General Management, MIT Sloan School of Management** | LinkedIn / Counterpoint bio |

---

## 二、职业时间线

| 时间 | 节点 | 关键动作 |
|------|------|---------|
| 早期 | **Philips Electronics**（印度）多个岗位，做 product management / market assessment / go-to-market strategy | 转 telecom 行业前的产品端基础 |
| 2008-2009 | 开始 **personal blogging & tweeting**（telecom、wireless networks、handset OEMs），通过公开内容建立行业声誉 | 这是他转型分析师的关键起点 |
| 2009-2013 | **Strategy Analytics（Boston area）**，从 Research Analyst 升至 Senior Analyst of Global Wireless Practice；专注 wireless networks、mobile devices、NFC、WiFi、location-based services | 4 年扩展行业网络 |
| 2012-2013 | 因家庭原因回印度（Mumbai），"bumped into his ex-SA colleague and ex-client to form Counterpoint Research" | 与 Tom Kang（Seoul）、Peter Richardson（UK）联合创立 |
| 2013 | **Counterpoint Research 正式创立**（Hong Kong HQ、Mumbai 实地办公） | Co-Founder、Partner、VP of Research |
| 2013-2020 | Counterpoint 建立 India、China、Korea、UK、US 多地分析师网络；开始季度发布 Global Smartphone Tracker、Premium Smartphone Tracker | 分析框架成型 |
| 2017 | Onalytica 长篇访谈发表，明确表达 "loyal brand equity at scale" 主张 | [Onalytica](https://onalytica.com/blog/posts/an-interview-with-neil-shah/) |
| 2017 (Q4) | Reliance Jio 上线一年后，他发布印度 4G LTE 渗透 X 帖（135M subs / 10GB / 626 mins VoLTE / 14 hrs video） | [X 2017-11](https://x.com/neiltwitz/status/935502564862263297) |
| 2019 | 5G Asia + IoT World Asia, Singapore keynote | [Post Event Coverage](https://www.counterpointresearch.com/post-event-coverage-5g-asia-iot-world-asia-2019/) |
| 2022 | MediaTek Summit, CNBC India 半导体 hub 评论, 5G Monetization Forum | [X 2022](https://x.com/neiltwitz/status/1590752724274262016) |
| 2022-09 | 发表招牌 X 图："The ONLY chart you need to see how competitive is the smartphone market"——Apple vs rest, volume to value captured | [X 2022-09](https://twitter.com/neiltwitz/status/1575136781082599424/photo/1) |
| 2023 | **Counterpoint 收购 DSCC（Display Supply Chain Consultants）**，加强显示器和半导体覆盖；2023-02-23 CNBC-TV18 Twitter Spaces "The 5G Opportunity" 主持 | [Counterpoint Insights](https://www.counterpointresearch.com/insights/meet-counterpoint-twitter-spaces-5g-opportunity-driving-next-wave-digital-transformation-consumers-enterprises/) |
| 2023-04 | Apple 印度首店开业（Mumbai BKC + Delhi Saket），Neil 在 CNBC 大量评论 Apple 印度战略 | [CNBC 2023-04](https://www.cnbc.com/2023/04/18/apple-opens-first-store-in-india-in-iphone-sales-manufacturing-push.html) |
| 2024 | HAS 2024 - Huawei Analyst Summit speaker（"AI deployment in telecoms"）；多次 MWC / SEMICON India panel | [Huawei page](https://www.huawei.com/en/huaweitech/techtalks/has24-counterpoint-neil) |
| 2024 | Forbes India - The Daily Tech Conversation 播客嘉宾（Apple 印度制造） | [Spotify](https://open.spotify.com/episode/5utV6rI8Vlu22gaghATW8G) |
| 2024-2025 | 担任 **IC 50 Committee vice-chairman**（半导体行业组织） | [Counterpoint Insight](https://www.counterpointresearch.com/insights/neil-shah-joins-vice-chairman-ic-50-committee/) |
| 2025-01 | CES 2025 现场，分析 AI PC、AI 智能手机、wearables 趋势 | [LinkedIn](https://www.linkedin.com/posts/meetneilshah_counterpoint-research-analysing-ces-2025-activity-7287499467732176896-vkJg) |
| 2025-09 | **SEMICON India 2025**——发"baby steps"叙事，X 庆祝 5 fabs + 63 designs + 28 chips；CNBC video "India's chip sector is taking 'baby steps'" | [X 2025-09](https://x.com/neiltwitz/status/1962741439546487259) / [CNBC 2025-09](https://www.cnbc.com/video/2025/09/03/indias-chip-sector-is-taking-baby-steps-counterpoint-research.html) |
| 2025-10 | 发布 "The Rise of AI Agentic Commerce Ft. Neil Shah" | [Counterpoint Insight 2025-10](https://counterpointresearch.com/en/insights/the-rise-of-ai-agentic-commerce-ft-neil-shah) |
| 2025-10 | Tata Electronics 收购中国 iPhone 供应商 Justech 印度业务（~$100M），Neil 多次评论供应链整合 | [CNBC 2025-10](https://www.cnbc.com/2025/10/14/tata-electronics-buys-chinese-iphone-supplier-justech-india-unit.html) |
| 2026-01 | **CES 2026**——评 Motorola Signature 进入 premium，强调 ASP $400 wholesale 突破 | [LinkedIn 2026-01](https://www.linkedin.com/posts/meetneilshah_lenovotechworld-ces2026-activity-7424446520067985409-m0qo) |
| 2026-02 | 印度智能手机出口达 USD 30B（成为印度第一大出口品类），Neil 接受 IANS 等多家媒体采访 | [Business Standard 2026-02](https://www.business-standard.com/industry/agriculture/smartphone-india-top-export-category-with-total-overseas-shipment-worth-usd-30-bn-vaishnaw-126022500679_1.html) |
| 2026-Q1 | Counterpoint 印度 Q1 报告（Tarun Pathak 主笔，Neil 背书）："India smartphone market sees weakest quarter in six years"——Q1 同比 -3%，Nothing 同比 +47% 领涨 | [Counterpoint Q1 2026](https://counterpointresearch.com/en/insights/india-smartphone-market-q1-2026) / [Fonearena](https://www.fonearena.com/blog/480372/india-smartphone-market-q1-2026-counterpoint.html) |
| 2026 持续 | RAM/NAND 价格暴涨叙事主导——Counterpoint 预测全球 2026 出货 -2.1%，ASP +6.9%，Apple shipments -2.2% | [My Mobile India 2026](https://www.mymobileindia.com/counterpoint-research-warns-of-smartphone-market-decline-in-2026-as-ram-shortage-pushes-prices-higher-iphone-sales-predicted-to-fall/) |

---

## 三、关键里程碑（思维转折）

1. **2008-2009 从工程师/产品经理转分析师**：通过公开 blogging 在 Twitter 建立行业身份。这是他"公开表达即工作"心智模式的起点。
2. **2013 创立 Counterpoint**：从大机构（Strategy Analytics）独立出来，建立"亚洲深度 + 全球覆盖"差异化。这奠定他"印度视角 + 全球框架"双重身份。
3. **2017 Reliance Jio 入场**：彻底改变印度 telecom + smartphone 市场，给他"数据 → 趋势 → 长线"分析方法提供经典案例。
4. **2022-2023 Vedanta-Foxconn JV 解体**：从印度半导体乐观叙事中学到教训，2025 主动用 "baby steps" 重新校准。
5. **2024 Apple Intelligence + GenAI 手机定义之争**：触发 Counterpoint 收紧 "GenAI-capable" 定义，是分析框架的一次升级。
6. **2025-2026 RAM 危机**：让他的"premiumization + ASP"框架获得意外加强（不是消费者主动 premium，是 RAM 涨价被动 premium）。这是当前正在演化的一次叙事更新。

---

## 四、最近 12 个月动态（防过时，2025-05 → 2026-05）

1. **2025-09 SEMICON India 2025**：5 fabs 在建、63 taped-out designs、28 fabricated chips；正式确立 "baby steps" 叙事。
2. **2025-10 AI Agentic Commerce**：Counterpoint 把"AI agent shopping"列为 2026 主线，Neil 是公开 face。
3. **2025-10 Tata-Justech 收购**：印度供应链整合标志事件。
4. **2025-Q4 Apple 印度销售突破历史新高**，iPhone 16 series 全球同步在印度本地制造。
5. **2026-01 CES 2026**：Motorola 高端化、Lenovo Tech World，强化 premiumization 主线。
6. **2026-02 印度手机出口 USD 30B**：成为印度第一大出口品类，Neil 大量上 IANS / Mint / BS。
7. **2026-Q1 印度市场 -3% YoY**：六年来最弱单季，Nothing 同比 +47% 领涨。
8. **2026 全球预测下修**：RAM 涨价驱动全球出货 -2.1%、ASP +6.9%、Apple shipments -2.2%。
9. **持续**：在 X (@neiltwitz)、LinkedIn (@meetneilshah) 上保持每周多次更新；Counterpoint 报告频率维持季度。

---

## 五、家庭与个人生活（公开可知）

- 常驻 **Mumbai, India**。
- 因家庭原因从美国 Boston 回印度（2012-2013）。
- 配偶、子女等个人信息未公开（尊重边界）。
- 公开身份限于 professional analyst + entrepreneur mentor + investor。

---

## 六、影响他的关键事件（外部宏观）

1. **2007 iPhone 发布**——重塑他研究的核心 category。
2. **2010-2013 印度 telecom 自由化 + smartphone 起飞**——给印度市场地位铺路。
3. **2016 Reliance Jio 入场**——让他的印度数据 + 趋势框架开始全球扩散。
4. **2018-2020 美中科技战 / Huawei 禁令**——把 geopolitics 永久嵌入他的分析框架。
5. **2020 COVID + 半导体短缺**——把供应链从"幕后"推到"主线"。
6. **2022-2024 Apple 印度制造提速**——他职业生涯的一次最大叙事红利。
7. **2024-2025 GenAI 爆发**——给他的 AI 手机框架提供新支撑。

---

## 七、关键合作者与同事网络（按时间出现）

| 同事 | 角色 | 与 Neil 的关系 |
|------|------|-------------|
| **Tom Kang**（Seoul） | Counterpoint Co-founder | 联合创始人，Korea / Samsung 专家 |
| **Peter Richardson**（UK） | Counterpoint Co-founder | 联合创始人，Europe / tablet / PC 专家 |
| **Tarun Pathak**（Gurugram） | Research Director | 印度市场招牌主笔，Neil 公开背书 |
| **Jeff Fieldhack**（US） | Research Director | 北美 / 运营商，MediaTek Summit 常一起出现 |
| **Karn Chauhan** | Senior Analyst | 印度市场细分 |
| **MS Hwang, Yang Wang** | Korea/China analysts | 2026 RAM 价格分析署名 |
| **Jene Park** | Korea analyst | foundry / 半导体 |
| **Prachir Singh** | India analyst | 印度市场 Q1 2026 报告 co-author |

---

## 八、思维方式演化的内在节奏

回顾 18+ 年的公开痕迹，Neil 的分析框架呈现出几个清晰的"层级累积"：

1. **2008-2013 早期：focus on devices**
   - 关心手机本身（NFC、WiFi、operating systems）
   - 单设备 vendor 视角

2. **2013-2017 Counterpoint 早期：focus on shipments + brand share**
   - 出货量、地区、品牌 win/loss
   - 引入 ASP 维度

3. **2017-2020 Jio + premiumization 主导：focus on ASP + value share**
   - "Volume to value" 招牌叙事成型
   - 引入 revenue + profit share 四维

4. **2020-2024 supply chain + geopolitics**
   - PLI、tariff、出口管制成为分析变量
   - Apple India 叙事大爆发

5. **2024-2026 AI + memory 双驱动**
   - GenAI-capable 定义、agentic AI、AI Tax
   - Memory（DRAM/NAND）成为 ASP 的"被动驱动力"

每一层都没有抛弃前一层——这是分析师式的"累积学习"，不像企业家那样会主动割舍旧叙事。

---

## 九、信息不足或薄弱维度

- 早年印度本科院校具体名称未在公开素材中确认。
- Counterpoint 收入、估值、客户名单等商业信息未公开。
- 个人投资 portfolio 未公开。
- 个人生活细节（家庭、爱好、宗教、政治倾向）保持私密。
- 1990 年代-2000 年代早期的具体年份（出生年、本科年份）公开信息缺失。
- 与 Tom Kang、Peter Richardson 的具体相识时间和共事年限只有粗略 "ex-SA colleague and ex-client" 描述。

