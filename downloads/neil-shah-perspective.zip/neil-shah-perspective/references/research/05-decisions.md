# 05 · 公开市场预测与"决策"轨迹

> 对分析师而言，"决策"= 公开发布的市场判断、forecast、call。本文档跟踪 Neil Shah（与 Counterpoint 团队）的关键 call，标注命中/落空/不确定。
> 调研时间：2026-05-24。
> 信息源黑名单遵循：未使用知乎、微信公众号、百度百科。

## 总体观察

分析师的"声誉账户"由命中的 forecast 累积，由落空的 forecast 透支。Neil 的公开 call 大致可分为五大类：

1. **印度市场出货量/份额预测**（最稳定，多次命中）
2. **Apple 印度战略与制造扩产预测**（方向准确，节奏略乐观）
3. **5G 渗透节奏**（早期被市场认为过于乐观，2022-2023 修正后趋准）
4. **AI 手机渗透节奏**（2024-2026 节奏与现实接近）
5. **印度半导体**（早期偏乐观，2025 主动修正为 "baby steps"）

下面每个 call 都标注证据 URL、时间、命中度判断（仅基于公开信息，不构成完整 forecast 评估）。

---

## Call 1：Apple 印度市场销量 + 制造份额

### 公开 call（2023-2024）
- "Last year, Apple clocked almost 10 million iPhone sales in India, its highest ever in the country."（关于 FY2024）
- "In an ideal scenario, India should aim for at least 35 per cent contribution (one in three) of global iPhone production by the end of next year 2027. This is possible if we build enough capacity and support the component ecosystem."
- 来源：[India Entrepreneur 2025](https://india.entrepreneur.com/growth-strategies/india-should-aim-for-35-of-iphone-manufacturing-share-by/503359) / [Greater Kashmir / IANS](https://www.greaterkashmir.com/latest-news/apple-set-to-build-on-solid-growth-momentum-in-india-with-iphone-16-series/)

### 现状（2026 May）
- Apple 印度销量过 10 million 单位：已基本兑现。
- iPhone 印度制造份额：2025 年约 25%（Counterpoint 自家数据），向 35% 推进，但 RAM 涨价 + 2026 整体出货下滑可能延缓节奏。
- Tata 收购 Justech 印度业务等供应链整合事件持续兑现 Apple "marathon" 叙事。

### 评估
- 方向：✅ 命中
- 节奏：⚠ 略乐观（35% 到 2027 可能延后到 2028-2029）
- 信度：高

---

## Call 2：印度 2025 年智能手机市场——volume 平 + value 增 8%

### 公开 call
- "India's smartphone market grew a modest 1% YoY in volume, and a stronger 8% YoY in value in 2025, underscoring sustained premiumization."
- 来源：[Counterpoint via X](https://x.com/CounterPointTR/status/2019463809568751888)

### 评估
- ✅ 实际数据兑现（Counterpoint 自家发布）
- 框架价值：用 volume vs value 的并列展示，强化了 premiumization 主线。

---

## Call 3：印度 2026 年市场——压力延续、Q2 双位数下滑

### 公开 call（2026-04 之后）
- Counterpoint（Tarun Pathak 主笔，Neil 背书）：India 2026 全年可能 single-digit volume decline，Q2 2026 可能 double-digit decline。
- ASP 将进一步上行；mid-高端段受冲击有限，低端段（<INR 15,000）承压。
- 来源：[Counterpoint India Q1 2026](https://counterpointresearch.com/en/insights/india-smartphone-market-q1-2026) / [Fonearena coverage](https://www.fonearena.com/blog/480372/india-smartphone-market-q1-2026-counterpoint.html)

### 评估
- 仍在进行中（截至 2026-05），无法盖棺。
- 方向：⚠ 待验证

---

## Call 4：全球 GenAI 智能手机渗透节奏

### 公开 call
- 2024 年起预测：2025 全球 GenAI 手机出货超 4 亿台，占总市场约 1/3。
- 到 2026 Q1 数据：54% 智能手机出货被 Counterpoint 归类为 "GenAI-capable"（vs 2023 年的 11%）。
- 2026-2027 节奏：中国厂商（Xiaomi/OPPO/Vivo/Honor）会把 GenAI 推到 mid-range。
- 来源：[Mobile World Live](https://www.mobileworldlive.com/devices/genai-smartphone-shipments-set-to-surge-in-2025/)

### 评估
- 方向：✅ 命中（Apple Intelligence、Galaxy AI、HyperOS 2 + AI 等大量落地）
- 节奏：✅ 大致同步
- 注意：Counterpoint 自己定义了 GenAI-capable 的口径，所以"命中"部分依赖口径自洽性。

---

## Call 5：Apple 在中国市场的位置

### 公开 call（多次）
- 长期立场：Apple 在中国会因 Huawei 复兴承压，但 ecosystem + premium lock-in 难被完全替代；Apple 与 Samsung 在高端段长期是双寡头。
- "The gap continues to widen between @Apple and the rest of the industry going from volume to value captured!"（2022 X 帖）

### 评估
- 方向：✅ 命中（Apple 在中国份额承压但仍盈利第一）
- 季度节奏：⚠ 经常被修正（China 销售季度波动剧烈）

---

## Call 6：5G 真正商业化在企业端，不在消费者端

### 公开 call
- 2022-2023 反复强调："5G monetization" 关键在 B2B（IoT、FWA、private network、industrial）。
- 消费者端 5G 不构成手机销售单独驱动力。
- 来源：[5G Monetization Forum 2022](https://www.counterpointresearch.com/5g-monetization-forum-2022/) / [CNBC-TV18 Twitter Spaces 2023](https://www.counterpointresearch.com/insights/meet-counterpoint-twitter-spaces-5g-opportunity-driving-next-wave-digital-transformation-consumers-enterprises/)

### 评估
- 方向：✅ 命中（消费者侧 5G 增长平淡，FWA / 工业 5G 增长显著）
- 不过 5G 整体 hype 未达 2020 年最初的"超级周期"预测，这部分是 Neil 自己 2023 年开始修正。

---

## Call 7：印度半导体——从乐观到 "baby steps"

### 早期 call（2022）
- Neil 在 CNBC 评论印度芯片野心，对 Vedanta-Foxconn JV 偏温和乐观。
- 来源：[CNBC video 2022-09-28](https://www.cnbc.com/video/2022/09/28/analyst-discusses-indias-bid-to-become-a-global-chipmaking-hub.html)

### 后续修正（2024-2025）
- Vedanta-Foxconn JV 2023 解体。
- 2025-09 CNBC video："India's chip sector is taking 'baby steps'"。
- 来源：[CNBC video 2025-09](https://www.cnbc.com/video/2025/09/03/indias-chip-sector-is-taking-baby-steps-counterpoint-research.html)
- 同时在 X 公开庆祝 SEMICON India 进度：5 个 fab 在建 + 63 taped-out designs + 28 fabricated chips + 1 in pilot。
  - 来源：[X 2025-09](https://x.com/neiltwitz/status/1962741439546487259)

### 评估
- 方向：✅ 大方向上印度半导体确实在起步，但节奏远低于 2022 年的部分乐观叙事。
- 自我修正：Neil 主动调整叙事，没有掩饰。这是分析师"诚实账户"的加分项。

---

## Call 8：Memory 价格驱动 2026 全球出货下滑

### 公开 call（2026 Q1-Q2）
- Counterpoint 团队（MS Hwang、Yang Wang 主笔；Neil 背书）：2026 全球 smartphone shipments 预计同比 -2.1%，ASP 升 6.9%，Apple shipments -2.2%。
- "Apple and Samsung are best positioned to weather the next few quarters."
- 来源：[My Mobile India 2026](https://www.mymobileindia.com/counterpoint-research-warns-of-smartphone-market-decline-in-2026-as-ram-shortage-pushes-prices-higher-iphone-sales-predicted-to-fall/)

### 评估
- 进行中，无法盖棺。
- 方向：与市场共识一致（RAM 涨价是真实供给冲击）。

---

## Call 9：Brand equity at scale 集中化

### 公开 call（2017 Onalytica 访谈）
- "Very few brands have successfully achieved that – Apple, Tesla, Starbucks, Amazon, Coke."
- "The future is the company that has the maximum share of a user's lives... will rule."

### 评估
- 方向：✅ 长期看 Apple、Amazon、（部分）Tesla 持续兑现 brand equity at scale 的飞轮；Tesla 的争议性增加，但 2026 仍在全球品牌价值 top 列表。
- 这是一个"软 call"——不可证伪到具体数字，但叙事方向有效。

---

## Call 10：Xiaomi 中国/全球策略——"channel-specific brand" 风险与机会

### 公开 call
- "Profitability is the biggest challenge as their scale declines because the segments they have been targeting (affordable entry-to-mid-tier) has been shrinking."
- 强调 Xiaomi 需要往 premium 走（也确实在做：Mi 11 Ultra → 13/14/15 系列高端化）。

### 评估
- 方向：✅ 命中（Xiaomi 持续推 ultra/foldable，但全球 profit share 仍远低于 Apple/Samsung）

---

## 总结：Neil 的"命中模式"特征

1. **方向准、节奏偶尔过早**：他 calls 趋势方向准确率高，但时间表（"by 2027" 等）偏激进。
2. **结构性框架命中率高**：premiumization、volume-to-value、ecosystem 这类**叙事框架**比单点数字更稳定地兑现。
3. **诚实修正**：在印度半导体这类"早期乐观"上主动修正，没有掩饰。
4. **避免极端 call**：他不做 "Apple 五年内被颠覆" 或 "Samsung 必倒"这种极端预测，所以也不会有 spectacular fails。
5. **依赖 Counterpoint 集体智慧**：很多印度市场具体数字 call 实际是 Tarun Pathak / Karn Chauhan 主笔，Neil 是 face of forecast 但不是唯一 author。

---

## 不构成"决策"但值得记录的公开行动

1. **2008-2009 起开始系统 blogging & tweeting telecom**——奠定从 OEM → analyst 转型基础。
2. **2012-2013 离开 Strategy Analytics、回印度、与 Tom Kang / Peter Richardson 联合创立 Counterpoint**——核心职业决策。
3. **2023 Counterpoint 收购 DSCC (Display Supply Chain Consultants)**——把显示器、半导体补全。
4. **持续担任 SEMICON India 的 vice-chairman 角色（IC 50 Committee）**——参与印度半导体产业政策。
5. **持续在 MIT Sloan 等学术圈 keep alumni link**——保持智识网络的国际化。

---

## 信息不足或薄弱维度

- **付费 client 报告里的精确 call**：无法访问。
- **闭门预测会上的内部分歧**：无法访问。
- **个人投资 / advisor 角色**：他自称 "Entrepreneur Mentor & Investor"，但具体投资标的、conflict-of-interest 信息未公开。
- **某些 forecast 被市场遗忘**：分析师定期更新会覆盖旧 call，缺少 longitudinal 追踪。

