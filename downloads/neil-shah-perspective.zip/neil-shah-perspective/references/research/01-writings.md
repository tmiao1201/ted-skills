# 01 · Neil Shah 的著作与系统性长文

> 调研维度：Counterpoint Research 署名/合著 blog、insights、media columns、白皮书、自创术语。
> 调研时间：2026-05-24。
> 信息源黑名单遵循：未使用知乎、微信公众号、百度百科。

## 总体观察

Neil Shah 不是传统意义上的"作者"——他没有出版过书籍或学术论文。他的"长文"主要分布在：

1. **Counterpoint Research 官网 Insights/Reports**——大量署名 "Neil Shah" 或 "Team Counterpoint" 的市场快报、季度展望、行业评论；他特别频繁出现在 Premium Smartphone、AI Smartphone、Apple、India、Semiconductor、5G、IoT、Automotive、Location Platforms 几个 vertical 中。
2. **LinkedIn long-form posts**——在 @meetneilshah 账号上发布，常以 #premiumization #genai #5g #aipc #semiconductors 等 hashtag 串联，单篇约 200-800 字。
3. **第三方平台 op-ed 和访谈实录**——TomTom Newsroom、HERE Technologies Blog、Huawei "Analyst Perspectives"、Onalytica blog、Forbes India Tech Conversations 播客文字稿。
4. **会议 keynote 和 panel 发言整理**——MWC Barcelona / MWC Shanghai、IoT World Asia、SEMICON India、5G Asia、5G Monetization Forum、Mobile World Live 主旨预演。

分析师作为"作者"的特殊性：他的核心 IP 在 Counterpoint 付费报告里（不公开），公开素材是这些报告的"摘要 + 媒体话术"。所以下面提到的论点都是**他愿意公开的版本**，更激进/更具体的客户报告无法公开获得。

---

## 一、反复出现 ≥3 次的核心论点（这些是真信念）

### 论点 1：Premiumization 是 2020 年代手机产业的主线，超过 unit shipment 增长

- **2024 年度全球高端手机份额报告**：高端手机（>$600 wholesale）份额在 2024 年首次升至 25%，Apple 在该段占 67% sales share，Samsung 18%。来源：[Counterpoint Global Premium Smartphone Share 2024](https://counterpointresearch.com/en/insights/post-insight-research-notes-blogs-global-premium-smartphone-share-climbs-to-25-in-2024-as-premiumization-continues)
- **Q4 2025 全球 ASP**：全球智能手机 ASP 首次突破 $400 批发价，Neil 在 LinkedIn 直接评论："Premiumization is happening as consumers go for more premium smartphones. This is evident as the global smartphone ASP climbed to $400 wholesale in Q4'25 as per Counterpoint Research." 来源：[LinkedIn post 2026-01](https://www.linkedin.com/posts/meetneilshah_lenovotechworld-ces2026-activity-7424446520067985409-m0qo)
- **印度市场 2025 年**："India's smartphone market grew a modest 1% YoY in volume, and a stronger 8% YoY in value in 2025, underscoring sustained premiumization."（Counterpoint 官方 X 帖，Neil 转发） 来源：[Counterpoint X 2026-02](https://x.com/CounterPointTR/status/2019463809568751888)
- **Q3 2024 印度数据**：smartphone shipments grew 3% YoY，但 value 增长 12%，"value share growth outpacing unit shipment growth"。
- **跨域出现**：他在 Apple/Samsung/Motorola/Vivo/Oppo/Honor 几乎所有品牌的分析里都用 premiumization 框架；他评 Motorola 进入高端时也以此为切口（[LinkedIn 2026-01 CES post](https://www.linkedin.com/posts/meetneilshah_lenovotechworld-ces2026-activity-7424446520067985409-m0qo)）。
- **可信度**：一手（本人原话+本人公司报告），高。

### 论点 2：Shipment + ASP + Revenue + Profit Share 是分析手机市场的"四维框架"

- 这是 Counterpoint 的招牌方法论——不要只看出货量，要同时跟踪平均售价、营收（shipment × ASP）和利润份额。
- **代表性 X 帖（2022-09-28）**："The ONLY chart you need to see how competitive is the smartphone market. The gap continues to widen between @Apple and the rest of the industry going from volume to value captured!" 来源：[Neil Shah X](https://twitter.com/neiltwitz/status/1575136781082599424/photo/1)
- 在 Counterpoint Insights 系列里，"Global Smartphone Revenue tracker" 和 "Smartphone Profit Share tracker" 是反复发布的命名产品。
- **跨域出现**：他用同样的四维框架分析 PC（laptop ASP）、TWS、Smartwatch、Tablet 多个品类。
- **可信度**：一手，高。

### 论点 3：印度市场是接下来 10 年最重要的增量市场，但要看 ASP 而非 unit

- "Last year, Apple clocked almost 10 million iPhone sales in India, its highest ever in the country."（[Greater Kashmir / IANS quote](https://www.greaterkashmir.com/latest-news/apple-set-to-build-on-solid-growth-momentum-in-india-with-iphone-16-series/)）
- "In an ideal scenario, India should aim for at least 35 per cent contribution (one in three) of global iPhone production by the end of next year 2027. This is possible if we build enough capacity and support the component ecosystem."（[India Entrepreneur quote 2025](https://india.entrepreneur.com/growth-strategies/india-should-aim-for-35-of-iphone-manufacturing-share-by/503359)）
- "India's smartphone market grew a modest 1% YoY in volume, and a stronger 8% YoY in value in 2025"——他刻意把 volume 和 value 并列展示。
- **跨域出现**：印度智能手机消费 + 印度制造（PLI 政策）+ 印度半导体 fab。
- **可信度**：一手，高（来自他自己的 IANS / Forbes India 采访）。

### 论点 4：GenAI / Agentic AI 是下一波手机/PC 升级的主要驱动力，但需要 SoC + memory 同步升级

- **Counterpoint 预测 2025 年 GenAI 手机出货超 4 亿台，占全球 1/3**；2026 Q1 GenAI-capable 手机占比 54%（vs 2023 年的 11%）。来源：[Mobile World Live, Counterpoint forecast](https://www.mobileworldlive.com/devices/genai-smartphone-shipments-set-to-surge-in-2025/)
- 他 2025 年起反复强调："To run GenAI and agentic applications on-device, phones need significantly smarter brains (SoCs) and much larger memory buffers."
- **2025-2027 节奏判断**：高端先行（Apple/Samsung/Pixel），2026-2027 年由 Xiaomi/OPPO/Vivo/Honor 把 GenAI 推到中端。
- 2025 年 10 月与 Counterpoint 合作发布《The Rise of AI Agentic Commerce Ft. Neil Shah》，明确把 agentic AI 列为 2026 大趋势。来源：[Counterpoint 2025-10](https://counterpointresearch.com/en/insights/the-rise-of-ai-agentic-commerce-ft-neil-shah)
- **可信度**：一手，高。

### 论点 5：5G 是 device-network-ecosystem 三位一体的故事，不能只看终端

- 在 CNBC-TV18 Twitter Spaces "The 5G Opportunity Featuring Neil Shah"（2023-02-23），他主张 5G 真正的价值不在手机销售，而在 enterprise digital transformation + IoT 设备联网。来源：[Counterpoint Insight 2023](https://www.counterpointresearch.com/insights/meet-counterpoint-twitter-spaces-5g-opportunity-driving-next-wave-digital-transformation-consumers-enterprises/)
- 2017 年印度 Reliance Jio 入场后他的 X 帖："Some significant data consumption trend shifts with arrival of @reliancejio in just 12 months in India: 4G LTE subscriptions: 135 Million / Data Consumption: 10GB per month/user / VoLTE calls: 626 minutes per month/user / Video Consumption: 14 hrs per month/user." 来源：[Neil Shah X 2017](https://x.com/neiltwitz/status/935502564862263297)
- 反复在 5G Monetization Forum、MWC、IoT World Asia 等场合 keynote 同一主题。
- **可信度**：一手，高。

### 论点 6：Apple 在中国的护城河正被 vertical integration（自研芯片+操作系统+服务）持续加深，但供应链需要去单点

- 多次为 CNBC 评论："Apple is looking to build 'highly localized' partners to become 'truly diversified.' It will not be a sprint to build like-for-like supplier ecosystem as it enjoyed in China, but a marathon and a step by step process." 来源：[CNBC via India Entrepreneur](https://india.entrepreneur.com/growth-strategies/india-should-aim-for-35-of-iphone-manufacturing-share-by/503359)
- "The US tariffs accelerated the manufacturing of iPhones from India especially to USA vs China last year and the momentum continues as Apple looks to build an ecosystem around the manufacturing partners."
- 跨域：他同样用"marathon, step-by-step"叙事分析 Samsung 越南布局、Foxconn 印度 / 墨西哥扩张。
- **可信度**：一手，高。

### 论点 7：Brand equity at scale 是品牌的终极护城河；只有极少数品牌真做到了

- Onalytica 访谈原话："The biggest challenge a brand faces is to build a 'loyal brand equity' at scale. Very few brands have successfully achieved that – Apple, Tesla, Starbucks, Amazon, Coke." 来源：[Onalytica 2017](https://onalytica.com/blog/posts/an-interview-with-neil-shah/)
- "The future is the company that has the maximum share of a user's lives... will rule."
- 跨域：他评 Xiaomi 时强调"Profitability is the biggest challenge as their scale declines because the segments they have been targeting (affordable entry-to-mid-tier) has been shrinking."（说明品牌权益不止做品牌广告，而是和分价位结构、利润结构挂钩）
- **可信度**：一手，高。

### 论点 8：Geopolitics（关税、出口管制、PLI 补贴）是设备和半导体产业的"第二张地图"

- 关于 US tariffs → Apple 把 iPhone 制造移到印度：见论点 6 引用。
- 关于 India PLI（Production-Linked Incentive）："The PLI support should continue from production to exports as well, to keep India cost competitive until it reaches a good threshold."
- 关于印度半导体 fab："SEMICON India 2025 - Building the Next Semiconductor Powerhouse... Five new Semiconductor Fabs construction in progress, adding to the pioneer fab SCL ❤️‍🔥 63 taped-out designs | 28 fabricated chips ❤️‍🔥 One in Pilot."（[Neil Shah X 2025-09](https://x.com/neiltwitz/status/1962741439546487259)）
- 跨域：iPhone、半导体、5G 设备出口（中美博弈、印度 vs 越南竞争）。
- **可信度**：一手，高。

### 论点 9：Memory（DRAM/NAND）已成 2026 年手机定价的主导变量

- Counterpoint 2026 年预测："Global smartphone shipments are expected to decline 2.1% in 2026 as surging component costs..."、"average smartphone prices will climb 6.9% year-on-year in 2026"、"memory price inflation, which has increased nearly 4x over the past three quarters"。来源：[My Mobile India 2026](https://www.mymobileindia.com/counterpoint-research-warns-of-smartphone-market-decline-in-2026-as-ram-shortage-pushes-prices-higher-iphone-sales-predicted-to-fall/)
- "The market's mid- and high-end segments have seen 10%-15% price increases."
- "Apple and Samsung are best positioned to weather the next few quarters."
- 注：这条主要来自 Counterpoint 公司报告，引用人是 MS Hwang 和 Yang Wang，但 Neil 在 X / LinkedIn 多次转发并背书该判断，属于他参与的团队观点。
- **可信度**：一手（公司层面），中（Neil 个人原话有限）。

---

## 二、自创/反复使用的术语

| 术语 | 含义 | 出处示例 |
|------|------|---------|
| **Premiumization** | 消费者向更高价位段（>$400, >$600）迁移的趋势 | 出现在 30+ 报告标题 |
| **Volume to Value** | 行业从拼出货量转向拼营收/利润的范式切换 | "going from volume to value captured" |
| **Shipment-ASP-Revenue-Profit Share** | 四维分析框架 | 反复在 X / LinkedIn 引用 |
| **GenAI-capable** | 内置 7B+ 参数本地大模型、能跑 agentic 任务的手机 | Counterpoint 2025 起标准定义 |
| **AI Tax** | AI 手机硬件升级（SoC+RAM）转嫁给消费者的额外成本 | Outlook Business 2025 报道 |
| **Channel-specific brand** | 针对线上 vs 线下渠道差异化做品牌（如 Realme/iQOO） | 评论 Xiaomi 时使用 |
| **Loyal brand equity at scale** | 跨地域、跨周期都能复购的品牌资产 | Onalytica 访谈 |
| **Location intelligence layer** | 比"地图"高一层的实时上下文（路况、天气、路径优化） | HERE 访谈 |
| **Marathon, step-by-step** | 供应链去单点化的节奏比喻 | 反复用于评 Apple India / Foxconn |

---

## 三、推荐书单 / 影响来源（揭示智识谱系）

Onalytica 访谈直接提名："Satya Nadella, Steve Jobs, Bill Gates, Jim Whitehurst, Ben Horowitz" 是他的 professional influences。来源：[Onalytica](https://onalytica.com/blog/posts/an-interview-with-neil-shah/)

观察：
- **Satya Nadella**：transformation leadership（B2B + cloud + 文化重塑），符合 Neil 对企业转型的关注；
- **Steve Jobs**：产品 + 品牌，符合他对 brand equity at scale 的执念；
- **Bill Gates**：平台思维；
- **Jim Whitehurst（前 Red Hat CEO）**：开放生态系统；
- **Ben Horowitz**：硬核运营 + 创业实战。

智识谱系特征：他的偶像名单全是 **operator-CEO** + **B2B 平台型领导者**，没有学院派学者、没有未来主义大师（如 Ray Kurzweil 类）。这与他作为分析师的实务取向高度一致。

---

## 四、Counterpoint 公司层面的"标志性产品报告"（Neil 经常署名/合著）

公开可见的反复出现的报告族：

- **Global Smartphone Market Share: Quarterly**（Neil 经常引用）
- **India Smartphone Market Share: Quarterly**（Counterpoint 招牌）
- **Global Premium Smartphone Share**（年度旗舰）
- **Global Smartphone Revenue / Profit Share Tracker**
- **AI Smartphone / GenAI Tracker**（2024 起推出）
- **Counterpoint Macro Index**（季度宏观与科技产业链交叉报告）
- **Foundry Monthly Intelligence Report**（半导体代工）
- **Smartphone Pre-owned Market**（"From Saturation to Surge" 系列）

---

## 五、信息不足或薄弱维度

- **学术性长文**：未发现 peer-reviewed paper 或独立出版的书籍，分析师身份决定其不走学术路径。
- **长篇 essay（>3000 字）**：除偶尔 LinkedIn 长帖外，他不写 Stratechery / Ben Thompson 风格的长文。最长的公开内容是 Onalytica + HERE + TomTom 访谈实录。
- **与同事合著的署名情况**：Counterpoint Insights 通常署 "Team Counterpoint" 或主笔分析师；Neil 出现频率高但单署率低于 Tarun Pathak（印度市场）和 Tom Kang（韩国市场）。
- **付费 client 报告 vs 公开摘要的差异**：公开内容主要是结论 + 部分数据；详细 model、品牌级 P&L、地区交叉表只在 Counterpoint 订阅产品里。

