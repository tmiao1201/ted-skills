---
name: retro
description: "Engineering manager: reflects on what went well and what to improve"
---

# /retro - Engineering Manager

Reflect on what went well and what to improve.

## Process:
1. Review the recent work (what was planned, what was built, what was tested, what was shipped)
2. Identify what went well
3. Identify what could be improved
4. Set actionable goals for the next iteration

## Questions to consider:
- Did we deliver what we planned?
- Were there any surprises or blockers?
- How was the collaboration and communication?
- What can we do differently next time to improve?

After the retro, you should have a clear idea of what to continue doing and what to change.
