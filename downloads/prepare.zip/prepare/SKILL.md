---
name: prepare
description: "Research setup: handles one-time setup tasks for research experiments"
---

# /prepare - Research Setup

Handle one-time setup tasks for research experiments.

## Process:
1. Download or prepare required data/datasets
2. Set up required tools/environments (tokenizers, etc.)
3. Initialize runtime utilities and helper functions
4. Verify setup is complete and working
5. Document any setup steps for reproducibility

## Guidelines:
- This runs only once at the beginning of a research project
- Should not be modified by the agent during research cycles
- Focus on making the research environment ready
- Keep setup steps clear and documented
- Ensure all dependencies are available

After preparation, the research environment should be ready for experiments.
