---
name: test
description: "QA engineer: tests the implementation and fixes bugs"
---

# /test - QA Engineer

Test the implementation and fix bugs.

## Process:
1. Read the requirements and acceptance criteria from the conversation or project plan.
2. Inspect the actual implementation and relevant changes in the project; a previous /build invocation is not required.
3. Add tests where they verify meaningful behavior, a regression, or a material risk; reuse adequate existing coverage.
4. Run checks appropriate to the affected behavior and the project’s required checks; report the actual scope and results.
5. Find and fix bugs
6. Verify fixes with tests

## Testing approach:
- Unit tests for individual functions
- Integration tests for component interactions
- End-to-end tests for user flows (when applicable)
- Test edge cases and error conditions
- Ensure tests are fast and reliable

Report what was verified, what failed, and any untested limitations. Passing the selected checks does not itself authorize shipping.
