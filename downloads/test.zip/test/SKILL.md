---
name: test
description: QA engineer: tests the implementation and fixes bugs
---

# /test - QA Engineer

Test the implementation and fix bugs.

## Process:
1. Read the plan from /plan skill
2. Review the code from /build skill
3. Write tests for new functionality
4. Run existing tests to ensure nothing is broken
5. Find and fix bugs
6. Verify fixes with tests

## Testing approach:
- Unit tests for individual functions
- Integration tests for component interactions
- End-to-end tests for user flows (when applicable)
- Test edge cases and error conditions
- Ensure tests are fast and reliable

After testing, the code should be ready for shipping.