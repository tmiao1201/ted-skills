# 04 · 外部观察、批评与传记式分析

> 来源权重序：Tae Kim《The Nvidia Way》(2024.12) > Stephen Witt《The Thinking Machine》(2025) > Acquired Podcast Nvidia 三部曲 + Jensen 访谈 (2022-2024) > Ben Thompson Stratechery 多年战略分析 > Bloomberg / Fortune / The Information / The New Yorker 调查报道 > 同行公开评价 > 投资人口述。
>
> 严格区分 **【事实】**（多源可交叉验证）vs **【他人评价】**（观察者主观解读）。保留**故事不同版本**。批评章节力求完整，不洗白。
>
> 信息源黑名单：知乎、微信公众号、百度百科。所有引文出自英文一手或二手公开报道。时间截至 2026-05-24。

---

## 一、两本传记的定位差异（理解后续所有公共讨论的取景框）

| 维度 | **Tae Kim《The Nvidia Way》** (Norton, 2024-12) | **Stephen Witt《The Thinking Machine》** (PRH, 2025) |
| --- | --- | --- |
| 作者背景 | 前 Barron's 资深科技专栏作者，华裔 | The New Yorker 撰稿人，《How Music Got Free》作者 |
| 信息源 | **100+ 次访谈**，含 Jensen、两位联创、原 VC、早期前员工、现高管 | 不到 Kim 一半，但拿到 Jensen 多轮独家时间 + 关键反派访谈 |
| 视角 | "公司史 + 文化解剖"，主线是 Nvidia 如何运营 | "人物传记 + AI 时代纪事"，主线是 Jensen 这个人 |
| 写法 | 接近 HBR 案例集，含大量管理实践细节 | 接近 New Yorker 长稿，含心理画像与场景白描 |
| 对 Jensen 态度 | **明显偏正面**，被多个书评批为 "hagiographic" | **不完全奉承**（"not entirely admiring"），保留 Jensen 失控瞬间 |
| 奖项 | 入围 SABEW 2025 年度商业图书两类 | **获 FT/Schroders 2025 年度商业图书大奖**；The Economist 2025 年度好书 |
| 关键缺陷 | 1990s 占 50% 篇幅，过去十年 <25%；**完全跳过加密周期、ARM 收购失败**；对 AMD FSR 等竞品轻描淡写 | 硬件/CUDA 技术深度不足；后半段 AI 章节"赶进度"感 |

> 【评价】boilingsteam 书评："Kim 飞得离太阳太近——他写的是基于 Nvidia 高管友好访问通道的书，不是平衡视角解释 Nvidia 何以成功又何以失败的书。他对偶像 Jensen 的崇拜在每一页都流露出来。"

**结论**：看"Jensen 怎么管公司"读 Kim；看"Jensen 是怎样一个人"读 Witt。两本互补。

---

## 二、外部观察到的核心管理模式（事实）

### 2.1 组织结构
- 【事实】**60+ 名直接汇报**，财富 500 强常规 8-12。Kim 在书中确认。
- 【事实】**不开 1-on-1**，公开表态"高管不需要被哄、不需要职业指导"（CNBC 2023-11）。
- 【事实】**T5T（Top-5）邮件**：从初级工程师到高管定期发 5 条优先事项/挑战/观察的短邮件，跳过中层。Jensen 一天可读"上百封"。
- 【事实】**2026-02 政策更新**：Nvidia **限制了**员工直接给 Jensen 发邮件的权限（winbuzzer）。首次出现"扁平到不可持续"的官方信号。
- 【事实】**离职率 2.7%**，行业均值 17.7%（Fortune/Bloomberg）。

### 2.2 反馈与冲突方式
- 【事实】Jensen 自述："I'd rather torture you into greatness because I believe in you."（Patrick Collison 访谈，2024 重新流传）
- 【事实】60 Minutes（Bill Whitaker 2023）现场员工形容"demanding, perfectionist, not easy to work for"，Jensen 当面回应"perfectly"。
- 【事实】**公开斥责的标志性事件**（Witt 核心场景）：2008 年一颗有缺陷的 GPU 架构出问题，Jensen 在 Santa Clara 总部食堂当着 **100+ 名高管**的面，**连续超过一小时**斥责负责架构师。
- 【事实】Witt 另记录：一名前员工小错后被当众羞辱，Jensen **当场计算他整个职业生涯总薪酬**，要求"退回去"。
- 【事实】Bloomberg（2024-05，10 位前/现员工）：会议常以 yelling and fighting 贯穿，工作日延伸到凌晨 1-2 点。

### 2.3 工作强度
- 【事实】Jensen 自述从清晨醒来到睡前都在工作（Fortune 2025-07-21）。
- 【事实】员工吐槽："People hate when Jensen goes on vacation because he emails them more."（Kim 书中收录）

---

## 三、批评与争议（不洗白）

### 3.1 管理风格争议

| 角度 | 批评 | 来源 |
| --- | --- | --- |
| 公开羞辱 | "verbal abuse"；Witt 认为发火**几乎总在公开场合**，是有意为之的信号传递 | Witt |
| 私下脾气 | "在闭门时 Jensen 直接 EXPLODES，那个总是微笑的舞台 Jensen 完全不是同一个人" | Witt（Blacklynx Brief 转述） |
| 周围只剩唯命是从 | 高管"对 Jensen 冲他们吼的恐惧，超过了对消灭人类的恐惧" | Witt 原文挖苦 |
| 金手铐 | 2.7% 离职率被部分前员工解释为巨额股权让人走不了，不代表健康文化 | Bloomberg/Fortune 2024 |
| 接班人模糊 | 截至 2026 仍未公开继任计划；Jensen 几乎每日卖出 $14M 股票但拒谈接班 | Fortune 2024-08-22 |

### 3.2 CUDA 反垄断
- 【事实】2024 年 DOJ 升级对 Nvidia 反垄断调查并向第三方公司发出传票。
- 【事实】**焦点**：CUDA 只支持 Nvidia GPU，被指构成排他性互操作壁垒。
- 【事实】IDC 数据：2024 年云端 AI 加速器装机 **Nvidia 占 ~85%**。

### 3.3 2025-2026 AI 泡沫 / 估值争议
- 【事实】Michael Burry 2025-11 把 Nvidia 类比 1999 Cisco，称 AI 基建热是 "glorious folly"。
- 【事实】Burry 技术批评：Nvidia GPU **经济寿命只有 2.5-3.5 年**，远短于云厂商财报折旧的 4-6 年（因 Nvidia 每年发新芯片）——对 hyperscaler 资本支出建模有杀伤。
- 【事实】Burry 基金对 NVDA+PLTR 持 **$10 亿+ 名义看跌期权**。
- 【事实】Nvidia 内部备忘录（CNBC 2025-11-25）**点名回应 Burry**，反驳他对回购金额和 SBC 稀释的算法（"Burry 错把 RSU 税算进了回购"）。**万亿公司点名一个对冲基金经理**，本身就是异常事件。
- 【事实】2025 年董事 Mark Stevens 单笔减持 **$44M**，被市场解读为高位套现信号。

### 3.4 对中国市场的"两面性"（2025-2026 最尖锐争议）
- 【事实】2025-04 美国对 H20 加许可证要求，Nvidia 因不可销售库存计提 $45 亿。
- 【事实】Trump 后反转，允许 H20 销售，**换 15% 营收抽成**。
- 【事实】Jensen 公开口径反复，2026-05 承认中国市场 **"zero percent"** market share，已 "largely conceded to Huawei"。
- 【评价】Transformer News 长文 "The many contradictions of Jensen Huang" **逻辑自相矛盾**：
  - 一会儿说"中国公司买 Nvidia 因为我们芯片更好"
  - 一会儿又说"多亏华为，训练 Mythos 级模型的算力在中国 abundantly available，AI 发展 going just fine"
  - 不能同时为真：若华为真有竞争力，Nvidia 没多大市场被剥夺；若 Nvidia 真更好，卖给中国必然加速中国 AI。
- 【事实】Tom's Hardware：被记者直接逼问中国问题时，Jensen "nearly lost his composure"，原话："You're not talking to someone who woke up a loser."
- 【事实】Trump 访华团名单**没有 Jensen**（Tim Cook 和 Elon Musk 在），被解读为政治距离的信号。

### 3.5 过度承诺 AI 能力
- 【事实】"sovereign AI" 叙事（Jensen 自 2023 起反复推销）被指既是真实洞察也是销售话术：每个国家"需要"自己的 AI 基础设施 = 每个国家"需要"买 Nvidia 芯片。
- 【评价】Witt 书中明确：被问 AI 危害时，Jensen **不只是拒绝回答，而是当场暴怒**，对 Hinton 的态度是嘲讽——"很多研究员不理解他为什么这么说，可能是想给自己的工作引流"。Witt 形容这次暴怒 "uncontained and wildly inappropriate"。

### 3.6 接班人问题
- 【事实】公开材料中**无任何指定继任者**。
- 外部公推候选：
  - **Colette Kress**（CFO，2013 加入，已是亿万富翁）
  - **Jay Puri**（全球销售运营 EVP，20+ 年老臣，已是亿万富翁）
  - **Bill Dally**（Chief Scientist，原 Stanford CS 系主任，Jensen 在股价 $6 时挖来的）
  - **Bryan Catanzaro**（深度学习应用研究 VP，cuDNN 主要推手）
  - **Debora Shoquist**（Operations EVP）
- 【评价】Fortune 2024-08："technical and operational depth, but no anointed successor." 与 Apple Tim Cook 接班路径形成鲜明对比。

### 3.7 选择性叙事 / 被掩盖的失败
- 【事实】**加密周期**（2017-18、2021）GPU 因挖矿暴涨，收入和库存过山车，但 Kim 书几乎不提。
- 【事实】**ARM 收购失败**（$40B，2020 宣布、2022 撤回）：书中几乎不展开。
- 【事实】**Tegra 移动业务全面失败**：篇幅远低于 GPU 故事。
- 【事实】**自动驾驶进度低于承诺**：2015 起反复承诺，截至 2026 在 OEM 端仍非主导供应商。
- 【评价】多名书评认为缺失是**有意保护"Nvidia Way"叙事纯净度**。

---

## 四、与同行对比（外部视角）

| 维度 | Jensen Huang (Nvidia) | Lisa Su (AMD) | Pat Gelsinger (Intel, 离任) | Sam Altman (OpenAI) | Elon Musk (xAI/Tesla) |
| --- | --- | --- | --- | --- | --- |
| **个人 vs 团队叙事** | "Nvidia = Jensen 人格化身" | 刻意藏在团队后面 | 工程师式过度技术化沟通 | 政治家型，叙事不断变形 | 个人 IP > 公司 |
| **表达风格** | flamboyant、皮夹克、舞台化、即兴 | calm, calculated, consistent；"不需要做房间里最大声的人" | 直接攻击式，公开喊"Moore's Law 还活着" | 模糊化、外交辞令 | 极端、挑衅、Twitter-first |
| **对 Jensen 公开态度** | — | "家人，要肉烂在锅里"（确为母系一表亲） | "Jensen got lucky with AI"（GTC 2025 重复说过） | 公开感谢扩 AWS GPU 产能 | 公开称 Jensen 帮建 Colossus 速度"superhuman" |
| **员工评分** | Jensen 在 SF Bay CEO **Top 5%** | 内部评价同样高，但"安全感"成分大 | Pat 在 **Top 40%** | 2023-11 罢免/复职动荡 | Tesla/SpaceX/xAI 高离职率 |
| **失败处理** | "torture into greatness"，几乎不裁员；公开追责到具体个人 | 接手 AMD 后系统化清理产品线，不上升到人格 | Intel 大规模裁员；2024 被董事会解职 | Sam 自己被董事会解雇过一次 | 周期性大规模裁员 |
| **战略叙事** | "$0B markets"（提前进无人区） | "execution + roadmap discipline" | "IDM 2.0 + 重夺制造"（失败） | "AGI 安全"（被指叙事漂移） | "First Principles + 物理极限" |

### 关键观察
- **vs Lisa Su**：母系第一代表亲，没一起长大。"Huang is a market creator…Su rebuilt AMD by selling a narrative of present-day competence first." Jensen 自嘲："We're family… You got to keep it close to the family."
- **vs Gelsinger**（最公开敌意）：Computex 2024 当面点名 Jensen；GTC 2025 重复"got lucky"。Jensen 反击："如果 Intel 现在才开始，他们做出东西的时候我们已经到第七八代。"
- **vs Altman**（最微妙）：2016 Jensen **亲自**把 DGX-1 送到 OpenAI；2025-09 签意向投资最高 $100B；2026-02 主动澄清"对 OpenAI 不满"传闻是 "nonsense"。
- **vs Musk**（最复杂）：称 Musk 19 天部署 10 万 H100/H200 (Colossus) "superhuman"；同时 Musk 自建 Dojo + xAI 自研芯片对冲。

---

## 五、"公开 Jensen vs 私下 Jensen"反差（Witt 比 Kim 深的部分）

| 维度 | 舞台上的 Jensen | 私下的 Jensen |
| --- | --- | --- |
| 表情 | 微笑、自嘲、节目效果 | 易怒，被记者形容 "explode" 频率不低 |
| 沟通节奏 | 不用 teleprompter，叙事跳跃 inspirational | 短邮件密集轰炸，"上百封 a day" |
| 对失败的态度 | "embrace failure""intellectual honesty" | Witt："when an early bet went wrong, Huang has been quick to blame others" |
| 对自己话题 | GTC 上自如讲创业故事 | "He hates talking about himself and once responded to one of my questions by physically running away"（Witt） |
| 对 AI 风险 | "AI 是历史最大基础设施建设" | 被 Witt 追问时**当场暴怒**，扔出"你浪费了所有人的时间" |
| 对员工 | "we don't fire, we torture into greatness" | 2008 食堂事件 1 小时+ 当众斥责；公开计算前员工"应退还薪酬" |

> 【评价】Witt 精辟概括：他著名的暴脾气**与员工对他的温情记忆并存**——他记得员工孩子的名字，在家庭危机时给予真实支持。**这种双面性不是表演，是同一人的两个真实切面**。

---

## 六、同一故事的不同版本（暴露叙事建构痕迹）

### 6.1 Denny's 创业起源
| 版本 | 来源 | 重点 |
| --- | --- | --- |
| 浪漫版 | Nvidia 官方 / Sequoia 播客 | "Grand Slam 早餐 + 太多咖啡" |
| 苦情版 | Acquired Podcast | Jensen 曾在 Denny's 当 dishwasher 和 busboy，**选这里因为他知道安全又便宜** |
| 现实版 | Tae Kim《The Nvidia Way》 | Priem 和 Malachowsky 当时在 Sun，**Jensen 主动撺掇他们出来**；选 Denny's 因为是北加州**最受欢迎连锁之一** |

### 6.2 1996 生死劫
| 版本 | 重点 | 数字 |
| --- | --- | --- |
| Kim 版 | NV1 和 NV2 **两次连续失败**几乎杀死公司 | 现金 $3M，剩 9 个月 |
| 通用版 | NV1 失败 + Sega NV2 + Microsoft DirectX 标准化夹击 | 裁员从 100 → 40 |
| Sega 版（Tom Kalinske 自述） | Sega America CEO Tom Kalinske **额外给了 Jensen $5M 救命**，让 NV2 项目"体面下台" | $5M lifeline |

**外部观察差异**：Kim 强调"Jensen 自己的判断"，Acquired/Kalinske 视角强调"行业老兵的护盘"。**Jensen 公开叙事里基本不提 Kalinske 的救命**。

### 6.3 CUDA 起源
| 版本 | 重点 |
| --- | --- |
| Jensen 公开版 | "我们 2006 年看到了 general-purpose computing 的未来" |
| Kim 版 | 关键推手是 **Ian Buck**（Stanford 博士，被 Jensen 招来），先有学术界探索 |
| Witt 版 | 真正点燃是 **2012 AlexNet** 之后——之前十年 CUDA 都在被华尔街质疑"为什么烧这么多钱" |

### 6.4 AlexNet 时刻
- 【事实】Hinton 的 Toronto 组里 Alex Krizhevsky 用 **2 张 GeForce GTX 580** 训练神经网络，赢 2012 ImageNet。
- Jensen 版："我们 from the very beginning 就 enabled AI"。
- 冷版：**Nvidia 当时并不知道**这件事的战略意义，是被动受益者；Bryan Catanzaro 后来主动从 Jensen 那里争取来 cuDNN 项目，才把"被动受益"转成"主动布局"。Jensen 当场在白板写下 "**OIALO — Once In A Lifetime Opportunity**"。

---

## 七、Ben Thompson (Stratechery) 多年观察的演化

| 年份 | 核心判断 | 对应 Nvidia 阶段 |
| --- | --- | --- |
| 2017-2019 | CUDA 是"软件护城河"，但不确定能否撑起新业务 | crypto / ML 双注苦熬 |
| 2022 | "computing as a unit"的执行者；硬件 + 系统 + 软件捆绑 | ChatGPT 前夜 |
| 2024 ("Nvidia Waves and Moats") | 真正护城河是 **CUDA + 网络（Mellanox）+ NVLink + 系统级整合**，任何单一环节都不构成护城河 | 万亿市值后 |
| 2025 (chip controls 访谈) | Jensen 自承"CUDA 长期最大威胁是中国造一套替代" | H20 事件后 |
| 2026 (accelerated computing 访谈) | 战略叙事从"AI chip"切到"accelerated computing for everything"——避免被定义为"只是 AI" | 后 DeepSeek 时代去风险化 |

**Thompson 核心观点**：
- CUDA 模式 = **"give CUDA away for free and sell the chips that make it work"**（Jensen 原话被反复引用）。
- Thompson 不为 Jensen 辩护，**最早一批**指出：若训练市场转向推理为主，Nvidia 相对优势会缩小，因为推理对软件栈宽容度更高。

---

## 八、被反复观察但被低估的几个"模式"

1. **"信号通过公开惩罚传递"**：Jensen 几乎不私下批评，所有错误群体场合复盘。Witt 认为这不是失控，是有意的**信息广播机制**——一次公开 1 小时复盘 = 100 个人同时学习。
2. **"邮件 = 反层级雷达"**：T5T + 60 直接汇报，本质是**绕过中层过滤、直接读现场信号**。与他对"组织死于信息失真"的恐惧相关。
3. **"$0B markets 的真实风险"**：Jensen 公开讲 $0B 是品牌，但 Tegra、ARM 服务器、Omniverse 现金回报远低于公开期待。**不是每个 $0B 都会成长为 $1T**。
4. **"对失败者的二元态度"**：对**失败项目**极度宽容（intellectual honesty），对**失败的人**极度严厉（食堂当众斥责）。在 Jensen 哲学里不矛盾，但外部观察者经常混为一谈。
5. **"危机叙事永不下线"**：30 年来 Jensen 公开说"我们距离破产 30 天"，即使在万亿市值之后。**permanent paranoia** 是文化锚，但也被批为"故事化"。
6. **"政治不靠谱时立即变形"**：H20 / 15% 抽成 / Trump 访华团没他这些事件里，Jensen 表现出极强政治适应力——批评者称"两面派"，支持者称"务实"。与 Tim Cook 在 Trump 1.0 任期应对极相似。

---

## 九、最值得保留的外部金句（可作 reasoning 锚）

- 【Ian Cutress (More Than Moore)】"People see Nvidia as a personification of Jensen. And while Lisa is the savior of AMD, she's very clear that it's about everyone around her."
- 【Jodi Shelton (GSA) 论 Lisa Su】"She doesn't need to be the loudest person in the room."——**反向定义了 Jensen**。
- 【Witt】"He is surrounded by staff who are more afraid of Jensen yelling at them than they were of wiping out the human race."
- 【boilingsteam 论 Kim】"He flew too close to the sun. His fawning adoration for his idol Jensen Huang transpires on every single page."
- 【Transformer News】"Jensen 自相矛盾——要么华为芯片真竞争，要么 Nvidia 芯片真更好。两件事不能同时为真。"
- 【Burry 论 GPU 折旧】"Useful life is not 4-6 years claimed by hyperscalers, more like 2.5-3.5 years, because Nvidia releases new chips yearly."
- 【Gelsinger】"Jensen got lucky with AI." + "Unlike what Jensen would have you believe, Moore's Law is alive and well."
- 【Jensen 谈 Musk】"As far as I know, there's only one person in the world who could do that."
- 【Jensen 自评】"I'd rather torture you into greatness because I believe in you."
- 【Jensen 自评】"My ability to ensure pain and suffering… I consider them to be my superpowers."
- 【Jensen 自评】"Judge the rate of progress against the speed of light, not against what you did in the past or what the competition is doing."
- 【Jensen 自评】"Greatness comes from character, which can be refined. Character is not formed out of smart people, but from people who have suffered."
