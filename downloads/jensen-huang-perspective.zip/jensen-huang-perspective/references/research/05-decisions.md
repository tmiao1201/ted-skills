# 黄仁勋 重大决策与转折点

> 调研截至 2026-05-24。每个决策含：时间背景 / 决策内容 / 公开 vs 真实理由 / 反对声音 / 事后反思 / 言行一致性。
> 信息源黑名单：知乎、微信公众号、百度百科。

---

## 决策 1 — 1993 年 Denny's 创业：从 LSI Logic 跳出来

**时间与背景**：1993 年 1 月 25 日成立。三位创始人：Jensen Huang（30 岁，LSI Logic 显卡部门主管）、Chris Malachowsky（Sun 工程师）、Curtis Priem（Sun 图形架构师）。市场端 PC 3D 加速完全空白，2D VGA 由 S3/Trident/Cirrus 主导，3D 是 SGI 工作站的专利。

**决策内容**：辞职、自掏 4 万美元启动；随后 Don Valentine（Sequoia）+ Sutter Hill 各投 100 万，post-money $6M。公司名来自 "NV"（Next Version）+ 拉丁词 "invidia"（嫉妒）。

**公开理由 vs 真实理由**：公开是"PC 3D 浪潮 + 专用图形处理器"。真实（事后承认）：1) "I didn't really know how to start a company"——纯属冲动；2) 私人压力：黄太太 Lori 要求 Malachowsky 同时辞 Sun，两边老婆互相设条件；Priem 1992 年底先辞 Sun 打破僵局；黄 2 月 17 日（30 岁生日）离开 LSI。2024 Stanford + 2026 *How I Built This*：**"如果当时知道前面有多痛苦，绝对不会创业。"**

**反对声音**：LSI CEO Wilfred Corrigan 试图挽留失败后亲打电话给 Don Valentine："我送一个年轻人给你……" Valentine 听完 pitch 说"如果你赔光我的钱，我宰了你"。妻子 Lori 直接干预。

**事后反思**：把那家 Denny's 当"圣地"。*Acquired* 播客（2023.10）："正因为不知道难，才敢做。" → 给斯坦福学生的核心建议：naivety is a feature。

**言行一致性**：高。"成功来自痛苦"的叙事原点。唯一被质疑：把 Denny's 故事美化成"美国梦"，淡化家庭压力与运气成分。

---

## 决策 2 — 1995-1997 年 NV1/NV2 失败，转身 RIVA 128（**Near-Death #1**）

**时间与背景**：1995 NV1 押注 Quadratic Texture Mapping + 集成音频/手柄端口，与 Microsoft DirectX 三角形纹理标准冲突。1996 世嘉追投 700 万让做 Dreamcast 用的 NV2，仍走 QTM。NV1 卖 25 万片，绝大多数被 Diamond Multimedia 退回。员工从 100 砍到 30，账上只够发 **30 天**工资。

**决策内容**：黄飞东京见世嘉 CEO 入交昭一郎（Shoichiro Irimajiri），告知三件事：1) "Our technology doesn't work"；2) "We shouldn't finish your contract"；3) **"请把最后 $5M 付清，否则我们立刻 vaporize."** 入交几天后回答 **"We'll do it."** 黄随即砍 QTM，全公司转 Direct3D，1997.4 推 **RIVA 128**——以 2x 竞品性能爆卖 100 万片，公司起死回生。

**公开 vs 真实**：公开是"拥抱行业标准"。真实是没钱了别无选择。黄在 2023 *Acquired* 和 2024 Stanford："the humility to confront failure and ask for help" 是他最重要一课。

**反对声音**：内部工程师抵触推翻 QTM；投资人一度准备清算；多家媒体把 NVIDIA 列入"行将就木"名单。

**事后反思**：提炼出著名的 **"我们离破产永远只有 30 天"** —— 30 年来每月例会开场白。在 2023 Caltech 和 2024 Stanford 演讲中归为"3 次 near-death"的第一次。

**言行一致性**：极高。塑造了 NVIDIA 30 年的 paranoia culture（"a company that should not exist"）。

---

## 决策 3 — 1999 年发布 GeForce 256 并发明 "GPU" 一词

**时间与背景**：1999 年 8 月。NVIDIA 已凭 RIVA 128/TNT/TNT2 站稳，但市场视显卡为"商品零件"。业内已有"GPU"概念（3Dlabs 1997 Glint Gamma 用过 Geometry Processor Unit），但未流行。

**决策内容**：把 GeForce 256 包装为 "the world's first GPU"，重新定义为：单芯片集成 transform、lighting、triangle setup/clipping 与 rendering，每秒至少 1000 万多边形。NVIDIA 历史上第一次有意识的**类目创造**。

**公开 vs 真实**：公开是技术整合 T&L 到芯片。真实是黄想从"显卡供应商"跳出来变成"处理器公司"——这给 CUDA、AI 时代埋下"NVIDIA 不是图形公司是计算公司"的种子。

**事后反思**：2023 GeForce 3 25 周年纪念上黄明确说 **"GeForce led to CUDA. CUDA led to AI. AI led to today."** 这是黄少数被低估的决策。

**言行一致性**：高。"造词/造类目"成为后续 playbook：CUDA、Tegra、DGX、Omniverse、AI Factory、Physical AI、Sovereign AI。

---

## 决策 4 — 2006 年 CUDA 发布：被华尔街惩罚 10 年（**Near-Death #2**）

**时间与背景**：2006.11 随 GeForce 8800 GTX 发布 CUDA。NVIDIA 估值 ~$12B。CUDA 让所有 GPU 硬塞通用计算电路——die size 几乎翻倍，短期零客户付费。

**决策内容**：全产品线（不仅高端）支持 CUDA。大规模投入软件（cuDNN、CUFFT、CUBLAS……上千工程师）。在 Stanford/UIUC/Berkeley 推 CUDA 课程，自掏腰包发 GPU 给研究者。2007-2017 R&D 占营收常年 25-30%（2014 营收 $4.13B 花 $1.34B 做 R&D）。

**公开 vs 真实**：公开是"GPU 天然并行处理器，可做科学/金融/医疗"。真实（事后承认）：他**不知道** killer app 是 AI，只是确信"加速计算"是后摩尔定律必经之路。2023 *Acquired*："I didn't see AI coming."

**反对声音**：股价从 $12B 跌到 $2-3B 区间；多年被视为"过度投资 R&D 的低毛利硬件公司"。媒体（*Barron's*、*Seeking Alpha*）2008-2013 多次质疑 CUDA 是"耗钱填不满的坑"。戴尔/惠普起初拒绝为 CUDA 加价。

**事后反思**：**"Without CUDA, there would be no AI."** 归为"第二次 near-death"——不是技术失败，是市场长期不认可的精神折磨。Stanford 2024："Endure the pain needed to realize your dream."

**言行一致性**：极高。反讽点：他说"我不做长期规划"但 CUDA 是 10+ 年长期赌注——自洽解释：**不规划"路线"，但坚定"方向"**。

---

## 决策 5 — 2008-2009 年 Bumpgate + 金融危机

**时间与背景**：2008.7 NVIDIA 披露 2006-2008 出货的部分笔记本 GPU/MCP 有凸点焊料缺陷，受热反复膨胀开裂。第一批承认，计提 **$1.96 亿**保修拨备。同期金融危机，股价从 2007 高点跌 ~85%。

**决策内容**：主动披露 + 计提（而非否认）。后续 OEM 赔偿 + 集体诉讼总成本超 $4.5 亿。组织重组+裁员，但**坚持不砍 CUDA/R&D 预算**。决定逐步退出主板芯片组业务避免 Intel 总线授权官司。

**事后反思**：黄本人**几乎不主动提**——他的"3 次 near-death"叙事里没有 Bumpgate。这是他叙事里有意"删除"的章节。客观上：教训让 NVIDIA 此后对供应链、封装合作方（台积电/SK 海力士/Foxconn）极度重视——2024 HBM 短缺、CoWoS 产能争夺都能看到这块肌肉记忆。

**言行一致性**：中等。表面强调"负责任的工程文化"，但选择性叙事暴露他对形象管理非常在意。

---

## 决策 6 — 2009 年挖角 Bill Dally 任首席科学家

**时间与背景**：2003 黄亲赴 Stanford 拜访 Bill Dally（并行计算权威，Stanford 计算机系前主任），先做兼职顾问。2009（CUDA 推出 3 年 + 金融危机 + Bumpgate 同期），说服 Dally 全职加入任首席科学家。

**决策内容**：用全职 offer + Stanford 终身教席等价待遇拉人。Dally 主导 Fermi (2010) → Kepler → Maxwell → Pascal → Volta (2017) 一系列以并行计算/张量运算为核心的架构演进。

**公开 vs 真实**：公开是"建世界级研究院"。真实是黄已在赌通用并行计算会赢，需 Stanford 级权威坐实——同时提升 NVIDIA 学术圈软实力。

**事后反思**：2025 黄与 Dally 共同获伊丽莎白女王工程奖。被外界严重低估的一步——没 Dally，AlexNet 时代到来时 NVIDIA 不会有 cuDNN / Tensor Core 这套基础设施。

**言行一致性**：高。"招比自己强的人"的教科书案例。

---

## 决策 7 — 2012 年 AlexNet 时刻：把 AI 当 "Big Bang"

**时间与背景**：2012.9 Hinton/Krizhevsky/Sutskever 用两块 GTX 580（2GB 消费卡）训 AlexNet，ImageNet Top-5 错误率从 26.2% 砸到 15.3%。Hinton 团队曾找 NVIDIA 销售要 GPU 赞助被礼貌拒绝；事后黄听说后亲自补送。

**决策内容**：2013 起把"深度学习"列为公司级战略：cuDNN (2014)、TITAN 支持双精度、与学界合作发 DGX 早期原型、Tesla 加强 FP16/FP32。2015 起 P100 (Pascal) 专为深度学习设计，张量核心规划进 Volta。把这次称为 **"the Big Bang of AI"**。

**公开 vs 真实**：公开是识别深度学习为范式变化。真实是 AlexNet 结果让他**惊到睡不着觉**——"模型每多一倍数据+算力性能继续提升"意味着 GPU 永远卖不完。2024 SIEPR："That was the moment I realized this was going to be infinite."

**事后反思**：把 2012 定义为 NVIDIA 历史上最重要的一年之一（与 1993、2006、2022 并列）。与 Sutskever 在 2023 GTC 对谈："你给我看的那张训练损失曲线，是我职业生涯里最美的图。"

**言行一致性**：极高。"the more you buy, the more you save" 口号的逻辑根基就是 AlexNet 揭示的 scaling law。

---

## 决策 8 — 2014-2015 年退出智能手机：关闭 Icera

**时间与背景**：2011 NVIDIA 约 $367M 收购英国 Icera，整合 LTE 调制解调器到 Tegra SoC 挑战 Qualcomm。2013-2014 Tegra 4i 反响平平，无法说服中国 OEM 放弃 Qualcomm。

**决策内容**：2014 GTC：黄 Q&A 公开宣布不再追求"主流智能手机应用处理器"。2015.5 正式关 Icera，计提 ~$125M 一次性费用，140 人裁撤。Tegra 转向：汽车（Drive）、游戏（Nintendo Switch 用 Tegra X1）、机器人（Jetson）。

**公开 vs 真实**：公开是"聚焦能做差异化的视觉计算"。真实（事后承认）：手机市场是规模/价格游戏，Qualcomm Modem IP 护城河太深。*Acquired*："I learned that we should never try to take on someone in their core business unless we have a 10x advantage."

**事后反思**：这次"主动撤退"成为 NVIDIA **"不与客户竞争"** 原则的雏形——后来汽车不做整车、LLM 不做大模型应用都源于此。黄把这件事归为"第三次 near-death"——不是濒死，而是**主动放弃看似性感的赛道**的精神痛苦。

**言行一致性**：高。"have the strength to make sacrifices for what matters" 的教科书案例。

---

## 决策 9 — 2016 年亲送 DGX-1 给 OpenAI

**时间与背景**：2016.8。OpenAI 成立约 9 个月（2015.12 由 Musk/Altman/Brockman 创立的非营利）。DGX-1 是 NVIDIA 第一台"AI 超算"：8x P100 + NVLink，~$129K，原计划自用。

**决策内容**：黄亲飞旧金山到 OpenAI 办公室，**手抬**着 DGX-1 进门交给 Musk + Brockman 团队。机箱上手写签名：**"To Elon and the OpenAI Team! To the future of computing and humanity. I present you the world's first DGX-1!"**

**公开 vs 真实**：公开是"支持 AI 民主化"。真实是 OpenAI 是当时最聚集顶级 AI 研究者的地方。送一台机器，等于在硅谷 AI 圈打下"NVIDIA 是 AI 时代英特尔"的钉子。回报率：无价。

**事后反思**：此后形成"亲送首台"传统：DGX H100/H200/B200/Blackwell 首台都由他本人送给 OpenAI/xAI/Anthropic/Meta，并签名留念。把销售做成使命叙事的标志性 personal brand 动作。

**言行一致性**：极高。唯一争议：2024 Musk 与 OpenAI 翻脸后黄左右逢源——既继续支持 OpenAI、又给 xAI 优先供货（25 万 H100 的 Memphis Colossus）。

---

## 决策 10 — 2019 年 $6.9B 收购 Mellanox

**时间与背景**：2019.3。NVIDIA 数据中心营收快速增长，但黄意识到训练超大模型时**GPU 间互联带宽**会成瓶颈，光 NVLink 不够，需 InfiniBand 级整柜互联。Mellanox 是 InfiniBand/高速以太网龙头，Intel/Xilinx/Microsoft 都在竞购。

**决策内容**：$125/股全现金，总价 **$6.9B**，击败 Intel（据报 Intel 出价更高，但 Mellanox 董事会更信任 NVIDIA 整合愿景）。2020.4 完成交割（中国 SAMR 是最后批准方）。形成 **GPU + DPU (BlueField) + NVLink + InfiniBand** 的整柜级架构，直接催生 DGX SuperPOD → GB200 NVL72 → Rubin NVL144 这条产品线。

**公开 vs 真实**：公开是 "Moore's Law 已死，需全栈"。真实是黄看到 **"AI 模型规模 = 网络带宽需求"** 的指数关系。没有 Mellanox，NVL72 rack-scale 架构搭不起来。黄最被低估的战略动作之一。

**事后反思**：2024 GTC："Mellanox is one of the best acquisitions in the history of technology." Mellanox 创始团队被视为"皇冠资产"，DPU 路线被赋予与 GPU 同等优先级。

**言行一致性**：极高。"a chip is no longer the unit of compute—the data center is" 的物质支撑。

---

## 决策 11 — 2020-2022 年 ARM 收购失败

**时间与背景**：2020.9 NVIDIA 宣布以股票+现金 **$40B** 从软银收购 ARM。当时 ARM IP 几乎用于所有手机、苹果 M 系列、数据中心 Graviton。

**决策内容**：公开承诺保留 ARM 中立 IP 授权商身份、保留剑桥总部、不限制对手获取 IP。黄个人飞英/韩/日/中/欧盟反复游说。

**公开 vs 真实**：公开是"加速 ARM 在数据中心/AI 时代部署，承诺中立"。真实是黄想把 ARM CPU 与 NVIDIA GPU 真正深度耦合。完全的 ARM IP 掌控会让 NVIDIA 在 CPU+GPU 一体化路线上比 Intel 快 5 年以上。

**反对声音**：几乎全行业反对：Microsoft/Qualcomm/Google/Amazon/Apple 都不希望关键 IP 落入单一对手。2021.12 FTC 起诉阻止；UK CMA/EU/中国 SAMR 也分别启动深审。2022.2 终止收购。NVIDIA 损失 $1.25B 定金，但保留 20 年 ARM 长期授权。

**事后反思**：黄公开承认 **"We gave it our best shot. But the headwinds were too strong."** **Plan B 极成功**：失败后自研 Grace ARM 服务器 CPU，与 Hopper 通过 NVLink-C2C 互联，2024 GB200 上市后被市场反向证明"自研比收购更干净"。

**言行一致性**：中等偏低。黄少数明显"野心暴露"的动作——长期叙事说"做平台、不挤压客户"，但 ARM 收购会让所有 ARM 客户睡不着觉。监管失败后他迅速调整 narrative。

---

## 决策 12 — 2022 年 11 月 ChatGPT 时刻："iPhone moment"

**时间与背景**：2022.11.30 OpenAI 发布 ChatGPT，5 天破百万用户。此前 1 年 NVIDIA 数据中心营收增速放缓（加密泡沫破裂 + 超大规模厂商削减资本开支）。

**决策内容**：2023.1 起，黄在所有公开场合反复把 ChatGPT 类比为 **"AI 的 iPhone 时刻"** —— 塞进每次 keynote/earnings call/媒体采访。同步 lock-in H100 (Hopper) 产能、台积电 CoWoS 封装、SK 海力士 HBM3，对所有大客户启动配额制。2023.3 GTC 是教科书级 narrative reset——从"GPU 公司"切换到"AI infrastructure 公司"。

**公开 vs 真实**：公开是"ChatGPT 让生成式 AI 主流化"。真实是黄知道这是等了 10 年的 "CUDA payoff moment"。2023 *Stratechery*："Everyone woke up the same week. We've been ready for this for 15 years."

**事后反思**：把 2022/11/30 列为他个人时间线上的关键日。**"We didn't predict ChatGPT. But we built the infrastructure that made it possible."** ——把运气包装为长期准备。

**言行一致性**：高。但事后叙述强化了"我们一直在准备 AI"的剧本，淡化了 2018-2021 数据中心增长很大程度来自加密矿工的事实。

---

## 决策 13 — 2023 年起的产品节奏：年度迭代 + 拒绝拆分

**时间与背景**：2023 至今市值从 $1T 到 $5T+。DOJ 反垄断调查启动（2024）；AMD MI300/华为昇腾/自研 ASIC（TPU、MTIA、Trainium）轮番冲击。

**决策内容**：2024 GTC 宣布架构迭代从"两年一代"改为**"一年一代"**：Hopper (2022) → Blackwell (2024) → Blackwell Ultra (2025 H2) → Vera Rubin (2026 H2) → Rubin Ultra → Feynman。整柜级（rack-scale）成新单位：GB200 NVL72 → GB300 NVL72 → VR200 NVL144。**拒绝拆分公司**：分析师建议拆数据中心/游戏/汽车/专业可视化，黄明确拒绝，强调 "one architecture, one stack"。

**公开 vs 真实**：公开是"AI 发展太快，年度迭代对客户负责"。真实是年度迭代是对竞争对手的**窒息战术**——AMD/Intel/ASIC 两年才出一代，NVIDIA 每年都让对手刚追上就被下一代甩开。黄用运营+资本能力压制对手的核心 playbook。

**事后反思**：2026.3 Lex Fridman #494 上把这条路线叫 **"extreme co-design"** —— GPU/CPU/网络/存储/电源/冷却/机柜/数据中心一起设计。**"The unit of compute is the data center, not the chip."**

**言行一致性**：高度一致：从 2019 收购 Mellanox 开始就在讲整机/整柜，2024 只是节奏加速。

---

## 决策 14 — 2024-2025 应对美国对华出口管制 + H20 专供

**时间与背景**：2022.10 BIS 首次管制，A100/H100 不能销华；NVIDIA 推 A800/H800。2023.10 升级，A800/H800 也禁；推更阉割的 **H20**（中国专供）。2025.4 H20 也纳入许可证管理，一次性计提 **$55 亿**。2025.7 Trump 政府反转，允许 H20 恢复对华出口。

**决策内容**：**不选择"完全退出中国"** ——关键决策。黄判断完全退出 = 把市场永久让给华为昇腾，最终昇腾反向冲击亚洲/非洲/拉美。持续在 H20/阉割版/中国专供 SKU 之间反复迭代。罕见地公开批评美国出口管制：**"Export control was a failure."**（2025 Computex）

**公开 vs 真实**：公开是"客户优先/全球化/AI 应惠及全人类"。真实是 2024 中国市场贡献 NVIDIA 全球营收 ~13%（~$170 亿），完全退出会让数据中心营收 -15%；同时让华为获得 2-3 年喘息窗口培育本土生态。

**反对声音**：美国国会两党压力：Warren/Hawley/Cotton 多次施压；2024 民主党版本要求"完全切断"。部分国安智库认为黄"为利润损害美国国家利益"。中国监管：2025.9 SAMR 反控 NVIDIA 在 Mellanox 收购上违反反垄断承诺，对等施压。

**事后反思**：**"China is 50% of the world's AI developers. Locking them out is a strategic mistake for America."** 2025-2026 多次赴北京/上海见 DeepSeek、阿里、字节、百度、腾讯；与雷军等中国企业家"破冰"，2026 初被报道推出"中国生态 2.0"。

**言行一致性**：中等偏高。长期叙事是 "global platform company"，对华策略基本一致。矛盾点：国会听证强调"国家安全优先"，但实际行动持续游说放宽。

---

## 决策 15 — 2025-2026 应对反垄断 / 客户集中 / 循环融资争议

**时间与背景**：2024.8 DOJ 启动反垄断调查（焦点：GPU 捆绑 CUDA / RunAI 收购可能"封死"对手）。2025.12 法国 AMF 提正式指控；中国 SAMR 2025.9 再次指控违反 Mellanox 收购承诺。2025.9 NVIDIA 宣布与 OpenAI 签 LOI **"up to $100B"** 投资 OpenAI 数据中心，被指"循环融资"——NVIDIA 投 OpenAI，OpenAI 拿钱买 NVIDIA GPU。2025.12 又传 NVIDIA 与 Groq（AI 推理芯片对手）$20B 投资合作。

**决策内容**：**拒绝主动让步**：不限制 CUDA 排他、不剥离 RunAI、不公开对手价格策略。**反控叙事**：强调"竞争激烈"（AMD MI300/Intel Gaudi/ASIC/华为昇腾/Cerebras/Groq 至少 7-8 个直接对手）。**OpenAI $100B**：2026.2 黄主动改口 **"That was an invitation to invest up to $100B, never a commitment."** 通过媒体软着陆。**客户集中度对冲**：通过 CoreWeave/Lambda/Nebius 等 neoclouds 分散依赖；投资 ARM 服务器（Grace）、Marvell（NVLink Fusion）、xAI、Stripe。

**公开 vs 真实**：公开是"开放生态、欢迎竞争、反对垄断指控"。真实是 NVIDIA 在 AI GPU 市场 90%+ 份额，CUDA 已是事实标准，让步任何一寸都可能引发雪崩。黄选择**公关+监管周旋+业务调整**三线作战，而非主动收缩。

**事后反思**：2026.2 Fortune："The $100B was never a commitment. Maybe a little exaggeration on our part."——少有的承认 narrative 失控。2026.3 TechCrunch："I really love working with Sam. The reports of us pulling back are nonsense."

**言行一致性**：偏低。这是黄叙事一致性最弱的一段：长期讲"我们是平台公司、不与客户竞争"，但 RunAI 收购+Groq 投资+OpenAI 入股，每一步都在边缘试探。

---

## 决策 16 — "不做什么"清单（被低估的反向决策）

| 不做 | 时点 | 公开理由 | 真实理由 |
|---|---|---|---|
| 整车（自动驾驶汽车） | 2016+ | "我们做平台，不做整车" | 整车是十年回收的低毛利赛道；与 OEM 客户竞争会断送 Drive 平台 |
| 大模型应用 / 直接对消费者 | 2023+ | "我们 enable AI，不与客户竞争" | 与 OpenAI/Anthropic/xAI 同时做朋友 = 卖更多 GPU |
| 消费电子整机（手机/平板/PC） | 2015 退出 Icera 后确立 | "我们不擅长 ID / 渠道 / 营销" | Apple/三星护城河深，毛利游戏玩不过 |
| 拆分公司 / 数据中心独立上市 | 2024-2026 反复拒绝 | "one architecture, one stack" | 拆分会破坏 CUDA 平台效应 + 黄个人对全局控制的需求 |
| 进入云服务（与 AWS/Azure/GCP 直接竞争） | 至今未做 | "我们是 enabler" | 真做会失去全部 hyperscaler 客户；DGX Cloud 是边缘试探，与三大云合作而非对抗 |
| 收购 OpenAI / Anthropic | 2023 后多次被建议 | 未公开回应 | 同上 + 反垄断 |

**言行一致性观察**：这条清单是黄整个决策体系最被低估的部分。所有 keynote 讲"做什么"，但真正塑造 NVIDIA 命运的是"**主动拒绝什么**"。与 Tim Cook 的"少做几件事但做好"哲学有家族相似。

---

## 元叙事：黄的"3 次 near-death"标准话术

| Near-Death | 时点 | 学到的"一句话" | 对应技能 |
|---|---|---|---|
| #1 Sega NV2 (1996) | 第一次差点死 | "Have the humility to confront failure and ask for help." | 谦卑+求助 |
| #2 CUDA 长期亏损 (2006-2016) | 市场不认可 | "Endure the pain needed to realize your dream." | 长期忍耐 |
| #3 Tegra/手机退出 (2014-2015) | 主动放弃看似性感的赛道 | "Make sacrifices for your life's work." | 战略放弃 |

**值得警惕**：
1. 这三幕剧明显是黄精心打磨的 "creator narrative"，多次访谈一字不差。
2. **没有提**的事件至少包括：Bumpgate (2008)、ARM 收购失败 (2022)、2018 加密泡沫破裂后的库存危机、2024 Blackwell 良率延迟。
3. 这种"选择性记忆"本身就是研究他决策方式的关键线索——他叙事工程的能力 ≈ 他工程能力。

---

## 决策模式总结（用于 jensen-huang-perspective skill 元规则）

从 16 个决策点提炼的**决策启发式**：

1. **30 天思维**：把决策窗口压缩到极限，永远以"还有 30 天"驱动 urgency——即使账上 800 亿。
2. **不分散战线**：进入市场前问"能不能 10x 优势"，否则就退出（Icera 教训）。
3. **造词/造类目**：每次重大转折都伴随"创造一个新名词"（GPU/CUDA/DGX/Omniverse/AI Factory/Physical AI/Sovereign AI）。
4. **长期主义但不做规划**：方向坚定（10 年加速计算），但拒绝多年路线图。
5. **亲手送货 = 销售即仪式**：对关键客户的关键产品亲自交付，把交易包装为使命叙事。
6. **拥抱而非对抗客户**：宁可让出 10% 利润，也不与客户竞争（不做云/整车/大模型应用）。
7. **不规避痛苦**：把 pain & suffering 作为公开叙事核心，反向变成招聘/品牌资产。
8. **叙事工程 = 产品工程**：精心打磨"3 次 near-death"，省略 Bumpgate/ARM 失败等不利章节。
9. **运营节奏作为竞争武器**：从两年一代加速到一年一代，用 NVIDIA 的资本能力窒息对手。
10. **危机时不砍 R&D**：2008 金融危机、2018 加密崩盘、2022 数据中心放缓——三次都坚持加大研发投入。
