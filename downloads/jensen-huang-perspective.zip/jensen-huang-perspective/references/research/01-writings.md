# 黄仁勋系统性长文与书面表达

> 调研日期：2026-05-24
> 信息源：WebSearch 拼装（沙箱限制 WebFetch），优先一手 URL，未抓取全文逐字稿
> 黑名单：知乎/微信公众号/百度百科 全部排除

---

## 1. 一手与准一手长文清单

### A. 演讲（一手，最高可信度）
| # | 文本 | 时间 | URL |
|---|------|------|-----|
| 1 | **NTU 国立台湾大学毕业演讲** "Run, Don't Walk" | 2023-05-27 | https://blogs.nvidia.com/blog/huang-ntu-commencement/ ；转录 https://interconnected.blog/jensen-huang-ntu-commencement-speech-2023/ |
| 2 | **Stanford GSB "View From The Top"** "Pain and Suffering" | 2024-03-13 | https://www.gsb.stanford.edu/insights/jensen-huang-how-use-first-principles-thinking-drive-decisions ；https://siepr.stanford.edu/news/nvidias-jensen-huang-incredible-future-ai |
| 3 | **Caltech 第 130 届毕业典礼演讲** | 2024-06-14 | https://blogs.nvidia.com/blog/jensen-huang-caltech-commencement-address/ ；https://commencement.caltech.edu/news/2024-commencement-speaker-jensen-huang |
| 4 | **GTC keynote 系列** | 年度 | https://www.nvidia.com/gtc/keynote/ |
| 5 | **季度 earnings call CEO 评论 (SEC 8-K)** | 季度 | 例 https://www.sec.gov/Archives/edgar/data/0001045810/000104581024000028/q4fy24pr.htm |

### B. 长篇专访
| # | 媒体 | 时间 | URL |
|---|------|------|-----|
| 6 | **Acquired Podcast** (Gilbert & Rosenthal) | 2023-10 | https://www.acquired.fm/episodes/jensen-huang |
| 7 | **Lex Fridman Podcast #494** | 2026-03 | https://lexfridman.com/jensen-huang-transcript/ |
| 8 | **Stratechery 系列**（5 篇）2022/2023/2025/2026 | 多 | https://stratechery.com/2026/an-interview-with-nvidia-ceo-jensen-huang-about-accelerated-computing/ ；https://stratechery.com/2025/an-interview-with-nvidia-ceo-jensen-huang-about-chip-controls-ai-factories-and-enterprise-pragmatism/ ；https://stratechery.com/2023/an-interview-with-nvidia-ceo-jensen-huang-about-ais-iphone-moment/ ；https://stratechery.com/2022/an-interview-with-nvidia-ceo-jensen-huang-about-building-the-omniverse-cloud/ ；https://stratechery.com/2022/an-interview-with-nvidia-ceo-jensen-huang-about-manufacturing-intelligence/ |
| 9 | **Stanford GSB View From The Top S7E5** First-Principles | 2024-04-25 | https://www.gsb.stanford.edu/events/view-top-jensen-huang |
| 10 | **Founders Podcast #403** "How Jensen Works" | 2024 | https://podcastnotes.org/founders-podcast/jensen-huang-founder-of-nvidia-founders-podcast-with-david-senra/ |
| 11 | **How I Built This** (Guy Raz) | 2024 | https://podcasts.apple.com/us/podcast/nvidia-jensen-huang-from-near-collapse-to-becoming/id1150510297?i=1000766861065 |
| 12 | **Fortune** 60 directs / no 1:1 长篇 | 2024-11-12 | https://fortune.com/2024/11/12/jensen-huang-nvidia-ceo-leadership-mpp/ |

### C. 准一手传记
| # | 文本 | 作者 | URL |
|---|------|------|-----|
| 13 | **The Nvidia Way** | Tae Kim (Barron's) | https://www.amazon.com/Nvidia-Way-Jensen-Huang-Making/dp/1324086718 |

### D. 中文白名单来源
| # | 文本 | URL |
|---|------|-----|
| 14 | 36氪 巴黎 GTC 两万字实录 | https://36kr.com/p/3333740366636545 |
| 15 | 36氪 "硅谷芯王" | https://www.36kr.com/p/3066980997149313 |
| 16 | 36氪 毕业季评论 | https://36kr.com/p/3804492994780674 |
| 17 | 晚点 LateTalk 89（注：嘉宾为 NVIDIA 中国区员工，非黄本人） | https://podcast.latepost.com/89 |

---

## 2. 自创术语与概念（粗体 + 引文）

**Pain and Suffering**（痛苦与磨难）
> "For all of you Stanford students, I wish upon you ample doses of pain and suffering... Greatness is not intelligence. Greatness comes from character. And character isn't formed out of smart people, it's formed out of people who suffered." — Stanford GSB 2024-03-13（一手）

**Low Expectations**（低期待）
> "One of my great advantages is that I have very low expectations. People with very high expectations have very low resilience—and unfortunately, resilience matters in success." — Stanford GSB 2024-03-13（一手）

**Run, Don't Walk**（要跑别走）
> "Whatever it is, run after it. Don't walk. Remember, either you are running for food; or you are running from becoming food. And often times, you can't tell which. Either way, run." — NTU 2023-05-27（一手）

**Zero-Billion-Dollar Markets**（零十亿美元市场）
> "With no more markets to turn to, we decided to build something where we are sure there are no customers. Because one of the things you can definitely guarantee is where there are no customers, there are also no competitors." — Caltech 2024-06-14（一手）

**Speed of Light**（光速管理）
> "The only constraint on their work should be the laws of physics, nothing else. That's the benchmark they judge themselves against." — 多处复述，源自 Tae Kim《The Nvidia Way》（二手综合）

**Intellectual Honesty**（智识诚实）
> "Without intellectual honesty, you can't have a culture that's willing to tolerate failure because people cling too much to an idea that likely will be bad or isn't working and they feel like their reputation is tied up in it."（一手）
> "We assess on a continuous basis whether something makes sense or not. And if it's the wrong decision, let's change our mind."（一手）

**Mission is the Boss**（使命是老板）
> Mission 本身定义任务分配，不是经理派活。"Pilot in Command (PIC)" 是 mission 的临时 CEO，直接 report 给 Jensen。（二手综合，源自 Tae Kim 与 Acquired）

**Pilot in Command (PIC)**（机长制）
> 航空术语借用，每个项目一位"机长"，对 mission 100% 负责，越过中间层直接向 CEO 汇报。（二手）

**T5T (Top 5 Things)**（T5T 邮件）
> "I'm looking to detect the weak signals. It's easy to pick up the strong signals, but I want to intercept them when they are weak." — Fortune 2024-12（一手引述）

**60 Direct Reports + No 1:1s**
> "I don't do 1-on-1s and almost everything that I say, I say to everybody at the same time. I love that everybody is working off the same song sheet. I love that there is no privileged access to information."（一手引述）

**Extreme Co-Design**（极致协同设计）
> "The problem no longer fits inside one computer to be accelerated by one GPU... you added 10,000 computers, but you would like it to go a million times faster." — Lex Fridman #494（一手）

**No Plan / Hopes and Dreams Planning**
> "We don't do a periodic planning system... there is no five-year plan, there is no one-year plan, there is no plan—there is just what we are doing."（一手）

**Ridiculously Difficult Problems**
> "Is this task ridiculously difficult? If it's not difficult enough, we should stay away from it. The reason is simple: if something is easy to do, there will be a lot of competitors." — Acquired（一手综合）

**Fail Fast / Fail Cheap**
> "If you fail often enough, you actually might become a failure, and that's different than being successful."（一手）

**Criticize in Public**（公开批评）
> 不是 1:1 私下反馈，是当众点评，"全公司从一个人的错误中学习"——与主流管理学相反（二手综合）

**CEO Math**（CEO 数学）
> 用整数/量级思考，拒绝"假装精确"。50 vs 60 directs 都答得出来，因为不重要。（源自 Tae Kim《The Nvidia Way》）

**Compute Equals Revenues**（算力即收入）
> "Computing demand is growing exponentially—the agentic AI inflection point has arrived." — NVIDIA Q4 FY26 earnings（一手）

**The Innovator's Dilemma as Personal Doctrine**
> 不只是"读过"，是当 NVIDIA 防御 playbook，据传请克里斯坦森做顾问。（二手，待 Tae Kim 原文核对）

---

## 3. 核心信念（≥3 次反复出现）

**A. 加速计算是必然趋势，不是产品**
> "A trillion dollars of installed global data center infrastructure will transition from general purpose to accelerated computing."
> 出现于：GTC 每年 keynote / Stratechery 4 次访谈 / 每季度 earnings call / Lex Fridman #494（一手 ≥10 次）

**B. 性格 > 智商；磨难 > 顺遂**
> 出现于：NTU 2023 / Stanford 2024-03 / Caltech 2024 / Fortune 2025-11 / Stratechery 多次（一手 ≥5 次）

**C. 第一性原理 + 持续重新评估**
> "Given the conditions today... how would I redo this? How would I reinvent this whole thing?"
> 出现于：Stanford GSB First-Principles 整集 / Acquired / Lex Fridman / Stratechery 2025（一手 ≥4 次）

**D. 组织应长成产品架构的样子**
> "Your organization should be the architecture of the machinery of building the product."
> 出现于：Acquired / Lex Fridman / Fortune / Stratechery 多次（一手 ≥4 次）

**E. 追逐"零亿美元市场"**
> 出现于：Caltech 2024（命名）/ Acquired 2023 / NTU 2023 / Stratechery 2022 Omniverse（一手 ≥4 次）

**F. 信息平权 = 速度**
> 出现于：Fortune 60 directs / Fortune T5T / Acquired / Tae Kim 传记（一手 ≥3 次）

---

## 4. 智识谱系

| 思想家 | 著作 | 在黄思维中的位置 |
|--------|------|-----------------|
| **Andy Grove** | *Only the Paranoid Survive* / *High Output Management* | 管理学圣经；原话 "I really enjoyed Andrew Grove's books. They're all really good." |
| **Clayton Christensen** | *The Innovator's Dilemma* | 战略防御 playbook，据传聘其做顾问 |
| **Ray Kurzweil** | AI / Singularity 系列 | AI 长期路径预言来源 |
| **Malcolm Gladwell** | *Outliers* | "成功 = 努力 + 时代背景" |
| **Neal Stephenson** | *Snow Crash* | Omniverse 概念原型 |
| **Tae Kim** | *The Nvidia Way* | 当事人间接背书的官方版传记 |

**观察**：智识谱系出奇地"窄"+"工程师味重"。Andy Grove + Christensen 几乎占管理思想的 80%。没有人文哲学、心理学、政治学。与他"我是工程师 CEO"的自我定位一致。

---

## 5. 矛盾点

**矛盾 1：「No long-term plan」vs「20 年坚持押 CUDA」**
口径与行为相反。CUDA 2006 押到 2022 ChatGPT 时刻，16 年才回报。他用"conviction + 持续重评估"调和，但张力客观存在。

**矛盾 2：「Mission is the boss / flat org」vs「60 directs 都向 Jensen 汇报」**
表面 flat，实质 hub-and-spoke。Jensen 是 single source of truth。HN 讨论已质疑：https://news.ycombinator.com/item?id=37486882

**矛盾 3：「Embrace failure」vs「Criticize in public」**
一边说要容忍失败、智识诚实；一边公开点名批评。Tae Kim 书中前员工形容文化既 "toxic" 又 "high performance"。

**矛盾 4：「Low expectations」vs「Speed of light」**
对自身境遇低期待提升韧性，对工作产出 speed of light 提升上限。需在使用时区分语境。

**矛盾 5：AI doomers**
公开 frustrated with doomers；但承认 AI 会"replace over a trillion dollars of traditional computers"。劳动力影响极少主动谈，被问时用 "AI won't replace you, but a person using AI will" 标准答案搪塞。

---

## 6. 缺口（下一轮研究方向）

1. **1993 "First Day at NVIDIA" 内部信原文**：本轮搜索未找到公开版本，建议从 Tae Kim《The Nvidia Way》第一章补足。
2. **晚点 LatePost 对黄本人的专访**：仅找到 NVIDIA 中国区员工对话，黄本人独立专访待确认。
3. **财新 / 极客公园**：本轮未返回符合标准结果，可能在付费墙后。
4. **Founder's Letter / 年度致股东信**：⚠️ **NVIDIA 不发独立年度信**——原任务设定的这一项不存在。功能等价物是"每季度 8-K + GTC keynote"。
5. **2007 清华演讲**：豆瓣有转载，但豆瓣不在白名单。
6. **Sega CEO 名字**（NTU 故事中）：应为中山隼雄 Hayao Nakayama，需用 Tae Kim 书核对。

---

## 7. 快速索引

| 问题类型 | 优先读 |
|---------|--------|
| 长期主义 vs 短期压力 | NTU 2023 + 信念 A/E |
| 战略决策 | Stanford First-Principles + Acquired |
| 组织设计 / 扁平化 | Fortune 60 directs + T5T + Lex Fridman |
| 面对失败 | NTU 三故事 + Stanford Pain & Suffering |
| 选项目 | Ridiculously Difficult + Zero-Billion-Dollar Markets |
| 沟通 / 反馈 | Criticize in Public + T5T |
| 行业判断 | Stratechery 2025/2026 + Lex Fridman #494 + Compute Equals Revenues |
