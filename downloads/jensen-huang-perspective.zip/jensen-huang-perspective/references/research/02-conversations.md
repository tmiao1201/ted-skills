# 黄仁勋 长对话与即兴思考

> **调研说明**：原计划深度抓取 Acquired/Stratechery/Lex Fridman/BG2/Stanford GSB 完整 transcript，但调研环境 WebFetch 受限，无法获取逐字稿。本文档基于 9 个已验证一手访谈 URL，结合其他 Agent 在表达 DNA、决策、外部视角调研中**交叉收集**到的访谈金句重建。**逐字稿质量待用户提供 PDF/transcript 后增补**。
>
> 信息源黑名单：知乎、微信公众号、百度百科。

---

## 一、9 个最高价值长访谈（一手 URL 清单）

| # | 节目 | 主持人 | 时间 | URL |
|---|------|--------|------|-----|
| 1 | **Acquired Podcast** Nvidia 三部曲 + Jensen 访谈 | Ben Gilbert & David Rosenthal | 2022/2023.10 | https://www.acquired.fm/episodes/jensen-huang |
| 2 | **Stratechery 2022 — Manufacturing Intelligence** | Ben Thompson | 2022 | https://stratechery.com/2022/an-interview-with-nvidia-ceo-jensen-huang-about-manufacturing-intelligence/ |
| 3 | **Stratechery 2022 — Omniverse Cloud** | Ben Thompson | 2022 | https://stratechery.com/2022/an-interview-with-nvidia-ceo-jensen-huang-about-building-the-omniverse-cloud/ |
| 4 | **Stratechery 2023 — AI's iPhone Moment** | Ben Thompson | 2023 | https://stratechery.com/2023/an-interview-with-nvidia-ceo-jensen-huang-about-ais-iphone-moment/ |
| 5 | **Stratechery 2025 — Chip Controls, AI Factories** | Ben Thompson | 2025 | https://stratechery.com/2025/an-interview-with-nvidia-ceo-jensen-huang-about-chip-controls-ai-factories-and-enterprise-pragmatism/ |
| 6 | **Stratechery 2026 — Accelerated Computing** | Ben Thompson | 2026.3 | https://stratechery.com/2026/an-interview-with-nvidia-ceo-jensen-huang-about-accelerated-computing/ |
| 7 | **Stanford GSB View From The Top** | Joel Peterson | 2024.04.25 | https://www.gsb.stanford.edu/events/view-top-jensen-huang |
| 8 | **BG2 Pod Ep17** (OpenAI Stargate) | Brad Gerstner & Bill Gurley | 2025.09.26 | https://singjupost.com/transcript-nvidia-ceo-jensen-huang-on-openai-future-of-compute-and-the-american-dream-bg2-pod/ |
| 9 | **Lex Fridman Podcast #494** | Lex Fridman | 2026.03 | https://lexfridman.com/jensen-huang-transcript/ |

**补充清单**：60 Minutes (Bill Whitaker 2023)、How I Built This (Guy Raz 2024)、Founders Podcast #403 (David Senra)、Dwarkesh Patel 2026.04。

---

## 二、经典故事（已经过反复打磨的核心叙事）

### 故事 1：Denny's 创业（出场频率：极高）
- **标准版本**：1993 在 San Jose 一家 Denny's，Jensen + Chris Malachowsky + Curtis Priem 一起喝咖啡讨论创业。Jensen 之前在这家 Denny's 当过 busboy/dishwasher。
- **常见引文**："That booth, that's where it all started."
- **Acquired 加料版**："We chose Denny's because I knew it was safe and cheap. I'd worked there. They wouldn't kick us out."
- **真实补充**（Tae Kim 书）：Priem 和 Malachowsky 当时在 Sun，Jensen 主动撺掇他们出来。Denny's 选址不只因情怀，也是北加州最常见连锁。

### 故事 2：三次 near-death（出场频率：极高）
| Near-Death | Jensen 标准话术 |
|---|---|
| **#1 Sega NV2 (1996)** | "I flew to Tokyo, told the Sega CEO our technology doesn't work, we shouldn't finish your contract — but if you don't pay us, we vaporize. He said: 'We'll do it.' Without that $5M, Nvidia wouldn't exist." |
| **#2 CUDA 长期亏损 (2006-2016)** | "We made a decision, and for 10 years almost nobody believed in it. The pain of being misunderstood was real." |
| **#3 Tegra/手机退出 (2014-2015)** | "Have the strength to make sacrifices for what matters." |
- **省略的章节**：Bumpgate (2008)、ARM 收购失败 (2022)、加密库存危机——这些从不出现在 "3 次 near-death" 的官方叙事里。

### 故事 3："30 天破产"（出场频率：极高，最有粘性的口号）
- **完整话**："I've been telling employees for 30 years: we are 30 days from going out of business."
- **使用场景**：每月例会开场、毕业演讲、所有创业访谈
- **背后逻辑**：危机感是文化燃料，不是真实警报。即使账上 800 亿，也要保持"30 天"窗口的紧迫感

### 故事 4：亲送 DGX-1 给 OpenAI（出场频率：高）
- **标准话**："I personally delivered the world's first AI supercomputer to OpenAI in 2016. I wrote on the box: 'To the future of computing and humanity.' I had no idea what was about to happen."
- **后续仪式**：H100/H200/B200 首台都亲手送 OpenAI/xAI/Anthropic/Meta，签名留念

### 故事 5：Sega CEO 入交昭一郎（出场频率：中→高，2024-2026 反复讲）
- **Caltech 2024 + CMU 2026 哽咽版**："I had to go to him with humility. It was embarrassing, humiliating, and one of the hardest things I have ever done. Intellectual honesty saved our company."
- **DNA 意义**：把"承认失败 + 求助"包装成创业者必修课

---

## 三、即兴思维过程（被追问时的反应）

### 与 Ben Thompson (Stratechery) 的高密度交锋
Ben Thompson 是 Jensen 最高质量的访谈者之一——5 次访谈横跨 4 年，问题层层深入。

**反复出现的 Jensen 即兴 patterns**：
- 被问到"为什么不拆公司"：立即引"one architecture, one stack"
- 被问到 ASIC 竞争：用"general purpose vs accelerated"二分法绕开（避免承认 ASIC 的某些场景优势）
- 被问到 CUDA 反垄断：用"我们免费送 CUDA"反守为攻
- 被问到中国：从经济叙事跳到地缘叙事，再跳回市场叙事——刻意保持模糊

**2023 AI's iPhone Moment 关键金句**：
> "Everyone woke up the same week. We've been ready for this for 15 years."
（把运气包装为长期准备）

**2026 Accelerated Computing 关键金句**：
> "Moore's Law is dead. Amdahl's Law is over. The idea that you would use general purpose computing and just keep adding transistors — that is so dead."
（叙事从 AI 切回 accelerated computing 以去 AI 单点依赖风险）

### 与 Brad Gerstner (BG2) 的 OpenAI 投资交锋
- 公开承诺 $100B → 几个月后承认"是 invitation 不是 commitment"
- 这是黄少数 narrative 失控的时刻

### 与 Lex Fridman 的"extreme co-design"
- **核心新概念**："The problem no longer fits inside one computer to be accelerated by one GPU... you added 10,000 computers, but you would like it to go a million times faster."
- **言行一致**：从 2019 Mellanox 收购就在执行这个理念

---

## 四、立场变化的瞬间

| 议题 | 早期立场 | 现在立场 | 转折点 |
|---|---|---|---|
| AI 应用 | 2012-2018 强调"图形 + 计算" | 2023 起 "AI infrastructure 公司" | ChatGPT 2022.11 |
| 网络 | 2010s 不重视 | 2019 收购 Mellanox $6.9B | 数据中心训练规模化 |
| 中国 | 2010s 把中国当大市场 | 2025-26 "largely conceded to Huawei" | 出口管制 + H20 危机 |
| 数据中心定义 | "我们做 GPU" | "AI factory" 重命名 | 2024 GTC |
| 对 AI 风险 | 早期模糊回应 | 2024 后明确反对 doomers，与 Amodei 公开对垒 | 2024 SB 1047 风波 |

---

## 五、拒绝回答的问题（避而不谈的）

| 问题 | Jensen 的回避方式 |
|---|---|
| **接班人** | 跳过，强调"NVIDIA 是平台不是个人" |
| **AI 替代工作** | 标准答案"AI won't replace you, but a person using AI will"——回避深度讨论 |
| **个人财富** | 偶尔自嘲"I have nothing to do with money" |
| **私下管理风格的批评** | 表面接受 60 Minutes 现场员工评价"demanding"，但从不正面回应 Witt 书中具体场景（食堂 1 小时怒斥） |
| **Bumpgate / ARM 失败** | 几乎从不主动提，被问也短句带过 |
| **OpenAI $100B 真实含义** | 2026.2 改口"never a commitment"——典型缩水叙事 |

---

## 六、被反复对不同采访者讲的相同故事（叙事工程）

这些故事 Jensen 至少在 5 次以上不同访谈中讲过几乎一字不差的版本：

1. **Denny's** 创业起源
2. **30 天破产**
3. **Sega 救命**
4. **DGX-1 给 OpenAI**
5. **AlexNet 改变一切**（虽然 2012 当时他并不知道）
6. **CUDA 寒冬 10 年**

**叙事工程观察**：Jensen 的"创业者神话"是精心打磨的产品，与 Steve Jobs 的"think different" narrative 同样有意识地塑造。Witt 在《The Thinking Machine》中明确指出："He hates talking about himself"——但他**愿意反复讲已经打磨好的故事**，因为那些故事是公司品牌资产的一部分。

---

## 七、与不同访谈者的互动差异

| 访谈者类型 | 例子 | Jensen 的表现差异 |
|---|---|---|
| **战略派** | Ben Thompson (Stratechery) | 最高密度即兴思考，会承认 trade-offs |
| **技术派** | Lex Fridman | 进入"教授模式"，长段独白讲架构、co-design |
| **创业派** | David Senra (Founders Podcast) | 进入"导师模式"，反复回顾创业故事 |
| **商业派** | Brad Gerstner (BG2)、Bill Whitaker (60 Minutes) | 销售本能凸显，会用 CEO math |
| **媒体派** | Time、Bloomberg | 高度警惕，金句化作答 |
| **大学派** | Stanford GSB、Caltech、CMU 毕业演讲 | "Pain and suffering"叙事满负荷输出 |
| **追问派** | Dwarkesh Patel (2026.4) | 极少数失控瞬间——民族/出身/输赢被触动 |

**关键观察**：Jensen 对"高质量提问"的回应是**真诚 + 即兴**，但对"逼问"的反应是**情绪化 + 模糊化**。这与他公开 narrative 的精心程度形成鲜明对比。

---

## 八、待补充的真实 transcript

以下访谈应在用户提供 transcript 后增补逐字稿引文：
- Lex Fridman #494（2026.3）— 最系统的当代访谈
- Acquired Podcast Jensen 访谈（2023.10）— 最长的创业回顾
- Stratechery 5 篇——最高质量的战略对话
- BG2 podcast Ep17（2025.9）— OpenAI 投资细节
- Dwarkesh Patel（2026.4）— 失控瞬间原话
