# 黄仁勋 完整时间线
**1963年2月17日 — 2026年5月**

> 时间锚点（factual backbone），供其他维度检索具体日期、年龄、因果链。
> 信息源黑名单：知乎、微信公众号、百度百科。
> 最后更新：2026-05-24

## 0. 全周期速览

| 阶段 | 时间 | 关键词 | 年龄 |
|---|---|---|---|
| 1. 台湾-泰国期 | 1963.02 – 1972 | 台南/台北出生、迁泰国曼谷 | 0–9 |
| 2. 美国童年 | 1973 – 1981 | Tacoma、肯塔基 Oneida、俄勒冈 | 9–17 |
| 3. 大学 | 1981 – 1984 | OSU EE、遇见 Lori | 17–21 |
| 4. 工程师 | 1984 – 1992 | AMD → LSI Logic、Stanford MS | 21–29 |
| 5. NVIDIA 创立 | 1993.04 | Denny's、Sequoia、$600 启动 | 30 |
| 6. 死亡边缘 | 1993 – 1999 | NV1/NV2 失败、Sega 救命、RIVA 128、IPO | 30–36 |
| 7. GPU 称王 | 1999 – 2006 | GeForce、3dfx、Xbox | 36–43 |
| 8. CUDA 寒冬 | 2006 – 2012 | CUDA、Bumpgate、Tegra | 43–49 |
| 9. AI 萌芽 | 2012 – 2017 | AlexNet、DGX-1、捐 OpenAI | 49–54 |
| 10. 数据中心爆发 | 2017 – 2022 | Mellanox、ARM 失败、加密泡沫 | 54–59 |
| 11. ChatGPT 时刻 | 2022.11 – 2024 | Hopper、Blackwell、$3T | 59–61 |
| 12. AI 工厂时代 | 2025 – 2026.05 | DeepSeek 冲击、$5T、Rubin、Physical AI | 62–63 |

---

## 1. 早期生平（1963-1981）

- **1963.02.17** 台北出生，台南长大（Wikipedia 主流版本，但有台南出生说法并存）
- **1968** 5 岁随父亲（化学工程师）炼油厂工作迁泰国曼谷，读 Ruamrudee International School
- **1973** 9 岁与哥哥送美国 Tacoma 叔叔家；叔叔阿姨误把肯塔基 **Oneida Baptist Institute** 当名校，实为收容问题少年的浸信会学校 —— **reform school 说法是真的**。Jensen 在那洗厕所、被打、被同学羞辱。
- **1975** 全家定居俄勒冈 Aloha
- **1978.01** 15 岁打入 US Open Table Tennis 青少年双打第三
- **1978-1983** 在 Denny's 打工（dishwasher → busboy → waiter）
- **1981** 跳级 16 岁从 Aloha High School 毕业

## 2. 大学与早期工程师（1981-1992）

- **1981-1984** 俄勒冈州立大学（OSU）电气工程本科
- **1983** Lab partner 项目里认识 Lori Mills（未来妻子），两人合作做工程问题
- **1984** OSU 毕业，进入 AMD 任芯片设计工程师
- **1985** 与 Lori 结婚，承诺 "30 岁前当 CEO"
- **1985-1992** 离开 AMD 加入 LSI Logic，逐步升任图形芯片业务部主管
- **1990** 长子 Spencer 出生
- **1991** 长女 Madison 出生
- **1992** Stanford 电气工程硕士毕业（在职读完）

## 3. NVIDIA 创立与死亡边缘（1993-1999）

- **1993.02.17** 30 岁生日，离开 LSI Logic
- **1993.04.05** NVIDIA 在 Denny's（San Jose, Berryessa Rd 店）成立。三人各出 $200，初始资本 $600
- **1993 夏** Wilfred Corrigan 引荐 Sequoia 的 Don Valentine。"If you lose my money, I'll kill you." Sequoia + Sutter Hill 投 $200 万
- **1995** NV1 发布，押 QTM 失败
- **1996** Sega NV2 合约几乎拖死公司；Jensen 飞东京见 Sega CEO 入交昭一郎，索 $5M 救命
- **1997.04** RIVA 128 发布，距发不出工资剩 1 个月
- **1997-1998** RIVA TNT/TNT2 巩固 PC 3D 显卡地位
- **1999.01.22** IPO，首发价 $12，市值 $6 亿
- **1999.08** GeForce 256 发布，发明 "GPU" 概念

## 4. GPU 称王（1999-2006）

- **2000** 收购 3dfx 资产，吞并最后一个 PC 3D 竞争对手
- **2001** GeForce 3 入选 Xbox（与微软合作）
- **2003** 黄飞 Stanford 拜访 Bill Dally 任兼职顾问
- **2003 末** Jensen 兑现承诺纹身——股价过 $100 美元后在肩膀纹 NVIDIA logo
- **2006.10** 收购 PortalPlayer
- **2006.11** **CUDA 1.0 发布**，开启 10 年华尔街惩罚期

## 5. CUDA 寒冬 + AI 萌芽（2006-2017）

- **2008.07** Bumpgate 披露，计提 $1.96 亿
- **2008.09** 金融危机，股价从 2007 高点跌 ~85%
- **2009** Bill Dally 全职加入任首席科学家
- **2010** Fermi 架构发布，专为通用计算
- **2011** 收购 Icera ($367M)，进军移动调制解调器
- **2012.09** **AlexNet 时刻**——两张 GTX 580 训出来的模型改变 NVIDIA 命运
- **2014** cuDNN 发布
- **2014-2015** 退出智能手机：宣布不再追求主流手机 SoC，2015.5 关 Icera
- **2015** Pascal 架构规划深度学习专用
- **2016.04** P100 (Pascal) 发布
- **2016.08** **亲手送首台 DGX-1 给 OpenAI**，机箱手写签名 "To Elon and the OpenAI Team!"
- **2017.05** Volta 架构发布，首引入 Tensor Core
- **2017** 推出 GPU Cloud 与 NGC 镜像库

## 6. 数据中心爆发（2017-2022）

- **2018** Turing 架构发布（RTX 系列）；加密矿工泡沫顶点
- **2019.03.11** 宣布 **$6.9B 收购 Mellanox**
- **2020.04.27** Mellanox 收购完成
- **2020.05** Ampere (A100) 发布
- **2020.09.13** 宣布 **$40B 收购 ARM**
- **2020-2021** 加密泡沫二次爆发，库存过山车
- **2021** Omniverse Enterprise 发布
- **2022.02.07** **ARM 收购正式终止**，损失 $1.25B 定金
- **2022.03** Hopper (H100) 发布
- **2022.10** 美国 BIS 首次对华芯片出口管制，A100/H100 不能销华
- **2022.11.30** **ChatGPT 发布**——Jensen 后来反复称为 "AI's iPhone moment"

## 7. AI 工厂时代（2023-2024）

- **2023.03 GTC** narrative reset：从 "GPU 公司" 切到 "AI infrastructure 公司"
- **2023.05.27** NTU 国立台湾大学毕业演讲 "Run, Don't Walk"
- **2023.05.30** 市值首破 $1T，进万亿俱乐部
- **2023.10** A800/H800 也被禁，推 H20 中国专供
- **2023.10-11** Acquired Podcast 长访谈
- **2024.02.21** 市值破 $2T
- **2024.03.13** Stanford GSB "Pain and Suffering" 演讲
- **2024.03.18 GTC** 发布 **Blackwell** (B200)，GB200 NVL72 整柜级
- **2024.06.06** 市值破 $3T
- **2024.06.14** Caltech 毕业演讲 "Zero-Billion-Dollar Markets"
- **2024.07** SIGGRAPH 提父母移民经历哽咽
- **2024.08** DOJ 启动反垄断调查
- **2024.10-11** Blackwell 良率延迟传闻
- **2024.11.12** Fortune 长文披露 60 直接汇报、不开 1:1、T5T 邮件机制
- **2024.12** Tae Kim《The Nvidia Way》出版

## 8. 最近 12 个月动态（2025.05-2026.05，重点防过时）

- **2025.01.27** **DeepSeek 冲击**：R1 发布引发"算力是否过剩"恐慌，NVDA 单日跌 16.9%，**蒸发 ~$600B**（史上单股单日最大损失）
- **2025.04** Stephen Witt《The Thinking Machine》出版，FT/Schroders 年度商业图书大奖
- **2025.04** 美国对 H20 加许可证要求，NVIDIA 计提 **$55 亿**
- **2025.05.19** Computex 2025（台北）：发布 NVLink Fusion；宣布台湾 10K 张 Blackwell 超算；感谢台湾时哽咽；批评出口管制 "Export control was a failure"
- **2025.06** VivaTech Paris："I pretty much disagree with almost everything Dario Amodei says"
- **2025.07.16** Trump 反转，允许 H20 恢复对华出口
- **2025.08.11** Trump 宣布 NVIDIA/AMD 对华芯片营收 **15% 上缴美国政府**
- **2025.08.28** Q2 财报披露 **Customer A+B 两家神秘客户占 39% 营收**（业界推测 Microsoft + Meta）
- **2025.09** NVIDIA 投资 OpenAI **LOI up to $100B**（换股+买芯片闭环）
- **2025.09** 中国 SAMR 反控 NVIDIA 在 Mellanox 收购上违反反垄断承诺
- **2025.09.26** BG2 podcast Ep17（与 Brad Gerstner/Bill Gurley）
- **2025.10.29** 市值突破 **$5T**（史上首家）
- **2025.11** Michael Burry 把 NVDA 类比 1999 Cisco，公布 $10B+ 看跌期权
- **2025.11.25** NVIDIA 内部备忘录罕见地点名回应 Burry
- **2025.12** 收购 Groq 资产 $20B（NVIDIA 史上最大并购）
- **2025.12** Joe Rogan 上访谈，谈 Oneida reform school 童年
- **2026.01.06** CES 2026 keynote：Rubin 量产、Alpamayo 自动驾驶 AI
- **2026.02** 主动澄清"对 OpenAI 不满"传闻是 nonsense；改口 "$100B 是 invitation 不是 commitment"
- **2026.02** Anthropic 用百万 Google TPU；OpenAI 借 TPU 砍 NVIDIA 报价 30%
- **2026.02** NVIDIA 政策更新：限制员工直接给 Jensen 发邮件（T5T 第一次降档）
- **2026.03** Lex Fridman Podcast #494，"extreme co-design"
- **2026.03.16 GTC 2026**：$1T 在手订单、Groq 3 LPU、Kyber 架构、Uber Drive AV
- **2026.04** Dwarkesh 采访：被追问中国时几近失控，"You're not talking to someone who woke up a loser"
- **2026.05** CMU 毕业演讲，再讲 Sega CEO 求救故事
- **2026.05** 承认中国市场 "zero percent" 份额，已 "largely conceded to Huawei"
- **2026.05.20** Q1 FY2027 财报：营收 **$81.6B**（+85% YoY），数据中心 92% 占比

---

## 思想转折点提炼（5 个最关键）

1. **NV2 死于单一客户依赖** → CUDA 全免费、广撒生态
2. **CUDA 寒冬扛过 10 年** → 完成"GPU 公司 → 加速计算平台公司"的自我重构
3. **AlexNet 2012** → AI 从 graphics 扩展变成核心使命
4. **DeepSeek 2025** → Jevons 反向叙事（reasoning model 让 token 量 100×）
5. **2025-26** → "AI factory"取代"GPU"成为公司主语

## 个人节点

- **1985** 与 Lori 结婚（OSU lab partner）
- **1990 Spencer 出生 / 1991 Madison 出生**
- **2003** 股价过 $100 时纹 NVIDIA logo 兑现承诺
- **皮夹克**："My wife and my daughter dress me" —— 没有戏剧化故事，妻女选定

## 不确定项 / 待核

- 出生地"台北 vs 台南"两说并存
- 子女出生月份（仅推算到年）
- "Customer A/B"具体身份（业界推测但未官宣）
- 1996 Sega 救命具体金额（$5M lifeline 来自 Tom Kalinske 自述，未官方确认）
