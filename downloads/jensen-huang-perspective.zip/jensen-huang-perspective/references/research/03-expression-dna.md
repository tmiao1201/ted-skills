# 黄仁勋 表达风格 DNA

> 调研范围：GTC 2024/2025/2026 keynote、Computex 2024/2025、CES 2025、
> Stanford GSB（2024.3）、Caltech 毕业演讲（2024.6）、CMU 毕业演讲（2026.5）、
> Acquired 播客（2023）、How I Built This（2025）、Lex Fridman #494（2026）、
> Stratechery 系列采访（2022-2026）、60 Minutes（2024）、Dwarkesh（2026.4）、
> 与 Sam Altman / Pat Gelsinger / Dario Amodei / Elon Musk 公开互动。
>
> 黄仁勋本人不用个人社交账号，"碎片表达"主要来自 keynote 即兴段落 + 采访金句。

---

## 一句话识别黄仁勋

> **"This is amazing. This is the biggest [X] of our lifetime. The more you buy, the more you save."**
> ——技术布道家 + 台湾移民式的真诚热情 + CEO 式的销售本能，三者糅合在一起。

如果把他蒙住脸只放音频，最容易认出的是三件事：
1. **形容词通货膨胀**：amazing / incredible / extraordinary / unbelievable / a miracle，密度极高
2. **指示代词指物**：随手举起一块芯片说 "**This is** Blackwell"，几乎每场 keynote 都重复 10 次以上
3. **温柔的销售腔**：声音偏沙哑，台湾英语口音，长句中突然加重 "**ladies and gentlemen**"

---

## 一、句式偏好

### 总体特征
| 维度 | 黄仁勋 | 对比（Jobs / Cook） |
|---|---|---|
| 句长 | **短句为主，长句穿插**——但短句不像 Jobs 那样精雕，更像"边想边说" | Jobs：精炼短句；Cook：完整长句 |
| 陈述 vs 问句 | **陈述压倒性**——他几乎不抛悬念，直接告诉你"这是事实" | Jobs 爱用 "And one more thing" 留悬念 |
| 类比密度 | **极高**——AI 工厂、Token 是新石油、GPU 是新发电机、Software 1.0/2.0/3.0 | 高于 Cook，类比颗粒度大于 Jobs |
| 重复结构 | **三段排比 + 自我打断式重复**："This is amazing. This is amazing. This is amazing." | Jobs 排比更工整 |
| 数据使用 | **巨量数字砸场**——FLOPS、Token/秒、$ Trillion，反复说 "this is the largest…" | Cook 也爱数字，但更克制 |

### 高频句式 Pattern 表

| 句式 | 示例（直接引用） | 出场场景 |
|---|---|---|
| `This is [X]` | "This is Blackwell." / "This is a miracle." / "This is the most extreme computer the world has ever made." | 每次举起产品 |
| `Ladies and gentlemen, [X]` | "Ladies and gentlemen, Rubin." / "Ladies and gentlemen, Olaf." | 重磅产品/嘉宾登场 |
| `The more [X], the more [Y]` | "The more you buy, the more you save." | 销售场景，已成 meme |
| `[X] is over / dead` | "Moore's Law is dead." / "General purpose computing has run out of steam." / "Amdahl's Law is over." | 论证 accelerated computing 必然性 |
| `I hope [X]` | "I hope you realize this is not a concert." / "I hope suffering happens to you." / "I hope you'll see setbacks as new opportunities." | 演讲收尾 + 毕业演讲 |
| `This is the [superlative] in our lifetime` | "This is the biggest industrial revolution of our lifetime." | 每场 keynote 收束 |
| `It's not [X], it's [Y]` | "It's not a data center, it's an AI factory." / "It's not accurate, but it is correct."（解释 CEO math） | 概念重命名 |
| 自我打断 + 重复 | "This is amazing. This is amazing. This is amazing." | 现场失控式赞叹 |
| `Welcome to [X]` | "Welcome to GTC." / "Welcome to AI factories." | 开场 + 章节切换 |

### 句式 DNA 总结
- **短句堆叠产生情绪密度**：他不靠单句精彩，靠"一句接一句、密度极高的赞叹"形成感染力
- **几乎不用问句钓鱼**：与 Jobs 的 "Are you ready?" 完全相反，他直接告诉你答案
- **重命名是核心武器**：把 data center 改叫 AI factory，把 GPU 改叫 accelerator，把计算工作叫 token generation——每次重命名都是一次叙事抢夺

---

## 二、高频词清单（出场 10 次+）

### A 组：形容词通货膨胀（"什么都是 amazing"）

| 词 | 频率特征 | 引文示例 |
|---|---|---|
| **amazing** | 单场 keynote 30-50 次 | "This is **amazing**." / "Isn't this **amazing**?" / "Just **amazing**." |
| **incredible** | 25-40 次 | "AI is advancing at **incredible** pace."（CES 2025 标题）/ "**Incredible** scale." |
| **extraordinary** | 10-20 次 | "An **extraordinary** opportunity." / "**Extraordinary** time to be a student." |
| **a miracle** | 5-10 次 | "Grace Blackwell is **a miracle**." / "**It's a miracle** we got this to work." |
| **unbelievable** | 5-15 次 | "**Unbelievable** what's happening." |

### B 组：技术叙事词（已成 NVIDIA 品牌资产）

| 词/短语 | 含义 | 引文示例 |
|---|---|---|
| **accelerated computing** | 30 年坚持的核心叙事 | "**Accelerated computing** is sustainable computing." / "**Accelerated computing** has reached the tipping point." |
| **AI factory** | 2024 起重命名 data center | "It's not a data center, it's an **AI factory**." / "AI is now infrastructure...needs **factories**." |
| **general purpose [computing]** | 反义词，作靶子 | "**General purpose computing** has run out of steam." / "Amdahl's Law is over, the idea that you would use **general purpose computing** and just keep adding transistors, that is so dead." |
| **token / token generation** | 把 AI 输出商品化 | "AI factories have one job: **generating tokens**." |
| **physical AI** | 2025 起的新叙事词 | "From perception to **physical AI**." |
| **the speed of light** | 30 年的内部口号 | "Everything we do is measured against **the speed of light**." |
| **full stack** | 论证 NVIDIA 护城河 | "Accelerated computing is a **full stack** problem." |
| **pain and suffering** | 公司文化关键词 | "I use the phrase '**pain and suffering**' inside our company with great glee." |
| **first principles** | 决策框架词 | "Go back to **first principles** and ask: how would you build this today?" |

### C 组：情绪/价值观词

| 词 | 用法 | 引文示例 |
|---|---|---|
| **I love** | 表达对公司/产品/人的依恋 | "I don't love every day of my job, but I **love** the company every single second." / "I **love** that everybody's working off of the same song sheet." |
| **proud** | 介绍合作伙伴/团队 | "I'm so **proud** of the team." |
| **humbled** | 受奖 + 谈台湾 | "Without Taiwan, NVIDIA could not achieve what it has today." |
| **lucky** | 谈 NVIDIA 早期 | "We were so **lucky** to survive." |
| **30 days from going out of business** | 早期公司文化口号 | "I kept telling employees: we are **30 days from going out of business**." |

---

## 三、签名表达（已成 meme 的金句）

### 1. "The more you buy, the more you save."
- **来源**：GTC 2018 首次出现，Computex 2024 前再次自嘲为 **"CEO math"**
- **完整版**："That's called CEO math. **It's not accurate, but it is correct.**"
- **DNA 意义**：自嘲销售本能 + 用数学外衣包装销售话术 + 知道自己在卖货还坦白说出来

### 2. "We are 30 days from going out of business."
- **来源**：早期内部口号，How I Built This 2025 再次提及
- **DNA 意义**：危机感作为永久燃料，不是"曾经差点死"而是"每天都觉得要死"

### 3. "I hope you realize this is not a concert."
- **来源**：GTC 2024 keynote 开场
- **后续**："You have arrived at a developers conference. There will be a lot of science describing algorithms, computer architecture, mathematics."
- **DNA 意义**：自嘲被比作 Taylor Swift 的同时，把场子稳稳拉回"我们是技术公司"

### 4. "I wish upon you ample doses of pain and suffering."
- **来源**：Stanford GSB View From the Top 2024
- **完整版**："I don't know how to do it [but] for all of you Stanford students, **I wish upon you ample doses of pain and suffering**...Greatness comes from character and character isn't formed out of smart people—it's formed out of people who suffered."
- **DNA 意义**：违背常规毕业祝福的反向叙事，台湾移民第一代的苦难审美

### 5. "Absolutely not."（如果重来一次会不会再创办 NVIDIA）
- **来源**：How I Built This 2025
- **完整版**："Suppose I knew everything then that I now know — how hard it is and all of the pain and suffering and all the embarrassment and humiliation and all the setbacks...**absolutely not**."
- **DNA 意义**：罕见的"反鸡汤"——成功者不浪漫化自己的奋斗

### 6. "Ladies and gentlemen, [产品名]."
- **来源**：每场 keynote 重磅产品发布
- **示例**："Ladies and gentlemen, **Rubin**." / "Ladies and gentlemen, **Olaf**."（GTC 2026 把 Disney 角色搬上台）
- **DNA 意义**：把芯片/产品当人介绍——给硬件以"角色感"

### 7. "It's not [X], it's [Y]."（重命名战术）
- "It's not a data center, it's an **AI factory**."
- "Moore's Law is dead. **Accelerated computing** is the path forward."
- **DNA 意义**：每次重命名都是一次叙事土地的圈占

### 8. "I am Jensen, founder and CEO of NVIDIA."
- **来源**：几乎每个公开场合自我介绍的标准开场
- **DNA 意义**：极简自我介绍 + "founder and CEO" 强调创始人身份（不只是雇佣 CEO）

### 9. "You're not talking to someone who woke up a loser."
- **来源**：Dwarkesh 2026.4，被反复追问对华芯片销售时
- **DNA 意义**：极少数失控的瞬间——民族/出身/输赢被触动

---

## 四、幽默方式

| 类型 | 频率 | 示例 |
|---|---|---|
| **自嘲（语言/外形）** | ★★★★★ | Computex："I'd love to speak Chinese but my brain can't run that fast"——主动暴露口音作为亲和力武器 |
| **自嘲（销售本能）** | ★★★★ | "The more you buy, the more you save. That's called CEO math." |
| **自嘲（被神化）** | ★★★★ | GTC 2024："I hope you realize this is not a concert." / "I didn't prep on a treadmill like Taylor Swift" |
| **反讽对手** | ★★★ | 回应 Sam Altman 7 万亿："**All the GPUs, apparently.**" |
| **冷笑话/技术宅梗** | ★★★ | 现场举着 GB200 wafer 扮 Captain America |
| **黑色幽默** | ★★ | "I wish upon you ample doses of pain and suffering." |

### 幽默 DNA
- **不刻薄**：即使反驳 Sam Altman / Dario Amodei，也是用"我不同意"而不是"他错了"——保持温度
- **善用现场物理性**：举芯片、戴假装防弹衣、穿皮夹克在台湾 35 度天里——靠**视觉笑点**而非语言段子
- **台湾英语口音作资产**：从不试图掩盖，主动 lean in，使其成为辨识符号

---

## 五、确定性表达

> 黄仁勋是**强确定性叙事者**——几乎从不说"我不确定"，但他的确定性来自"我已经赌了 30 年"，不是凭空 hype。

### 确定性句式
- "**This is** the biggest industrial revolution of our lifetime."
- "Moore's Law **is dead**."
- "General purpose computing **has run out of steam**."
- "**A trillion dollars** of data center infrastructure will be modernized."
- "AI **will** create more jobs than it destroys."

### 但有 3 种场景他会"软化"
1. **谈早期 NVIDIA**："We were lucky. We almost died several times."
2. **谈 AI 风险**：与 Dario Amodei 论战时，他说"I **pretty much** disagree with **almost everything** he says"——加了软化词
3. **谈未来时间表**：很少说"5 年内"，多说 "in our lifetime" / "the next decade"——长周期避免被打脸

### 与 Sam Altman / Elon 对比
- Sam Altman：高确定性 + 高时间精度（"AGI by 2027"）
- Elon Musk：高确定性 + 极激进时间（"FSD next year"，已说 10 年）
- **Jensen**：高确定性 + 长时间窗口 + 拒绝具体时间点——更"稳"的销售员

---

## 六、情绪外露

> 黄仁勋是**台上经常哽咽**的 CEO，频率高于绝大多数科技领袖。

### 已记录的动容/哽咽时刻

| 场景 | 时间 | 触发点 |
|---|---|---|
| **GTC 2024 Blackwell 发布** | 2024.3 | 介绍 Blackwell 系统时，回顾团队投入，声音颤抖 |
| **Caltech 毕业演讲** | 2024.6 | 讲到 Sega 取消项目的羞辱与求生时哽咽——"intellectual honesty saved our company" |
| **SIGGRAPH 2024** | 2024.7 | 提到父母移民经历 |
| **Computex 2025** | 2025.5 | "Without Taiwan, NVIDIA could not achieve what it has today"——感谢台湾时哽咽 |
| **CMU 毕业演讲** | 2026.5 | 讲到向 Sega CEO Irimajiri 求救——"It was embarrassing, humiliating, and one of the hardest things I have ever done." |

### 情绪 DNA
- **三大稳定泪点**：父母移民、Sega 求生、台湾故土
- **从不为产品本身哭**——为"人"和"过程"哭
- **不掩饰**：哭了就停一秒擦眼睛，继续讲，不道歉、不解释

---

## 七、着装符号

### 皮夹克的故事
- **持续年限**：至少 20 年；至少 2013 年起成为公众识别符号
- **起源**：妻子 Lori Huang 与女儿 Madison Huang（现 NVIDIA 营销总监）决定的
- **黄仁勋原话**："I'm happy that my wife and my daughter dress me."
- **更深层原因**：妻子认为 "everything makes him itch"，找到一款舒服的就一直穿——衣柜里是整排相同的黑衬衫
- **品牌升级**：从早期相对普通的皮夹克 → 近年 Tom Ford / Saint Laurent 鳄鱼皮，单件价格上万美元
- **物理符号意义**：
  - **统一性**：每天免决策（同 Jobs 黑高领、Zuckerberg 灰 T）
  - **反叛性**：硅谷 CEO 都穿连帽衫/Patagonia，他偏要穿摇滚明星打扮
  - **温度悖论**：台湾 35 度还穿——"Look 比舒服重要"
  - **家庭叙事**：每次被问皮夹克都讲妻女故事——把妻子从"幕后"带进公众叙事

### 与 Jobs 的对比
- Jobs 黑高领：极简禁欲，**距离感**
- Jensen 皮夹克：摇滚反叛，**亲近感 + 怪人感**
- 同样的策略（视觉统一），完全相反的气质

---

## 八、公开辩论 / 争议立场

### Sam Altman（OpenAI）
- **触发**：2024.2 Altman 传言要融 7 万亿美元造 AI 基础设施
- **Jensen 回应**（Dubai World Governments Summit 2024）：
  - 问"7 万亿能买多少 GPU"——答："**All the GPUs, apparently.**"
  - 实质反驳："You can't assume just that you will buy more computers. You have to also assume that the computers are going to become faster."
  - 给出自己数字："$2 trillion over the next five years."
- **DNA**：用幽默挡前面，用具体数字打后面

### Pat Gelsinger（Intel 前 CEO）
- **触发**：Gelsinger 反复说 "Jensen got lucky with AI"
- **Jensen 直接回应少**——通过 NVIDIA VP 公开 fire back："Intel lacked vision and execution"
- **DNA**：争议留给团队打，自己保持高位

### Dario Amodei（Anthropic）
- **触发**：Amodei 称 AI 将取代 50% 入门级白领岗位 + Anthropic 主张严控开源
- **Jensen 回应**（VivaTech Paris 2025.6）："I **pretty much** disagree with **almost everything** Dario Amodei says."
- **细分反驳**：
  - 就业："Some jobs will be obsolete, but many jobs are going to be created."
  - AI 安全立场："He believes that AI is so scary that only they should do it."（指控 Anthropic 想垄断）
- **DNA**：罕见使用"pretty much / almost"软化词——保留余地；但反驳点犀利

### Elon Musk
- **关系**：合作 > 竞争（xAI 是 NVIDIA 大客户）
- **公开互动**：盛赞 xAI 19 天搭出 Memphis Colossus 超算
  - "**Superhuman**." / "**Singular in his understanding of engineering**, large systems, and marshaling resources."
- Musk 回："I resisted AI for too long. Now it is game on."
- **DNA**：客户/伙伴关系，用"singular" / "superhuman"这种**夸张到几乎要笑场**的词——既是真诚也是商业智慧

### 中国 / 出口管制
- **Dwarkesh 2026.4 采访**：被反复追问对华芯片销售时"**nearly lost his composure**"
- 原话："**You're not talking to someone who woke up a loser.**"
- **DNA**：极少数他失控的瞬间——民族/出身/输赢被触动时

---

## 九、产品命名审美

> 产品名是一个 CEO 审美 DNA 最难造假的部分。

| 产品 | 命名来源 | 审美 DNA |
|---|---|---|
| **GeForce** | Geometry + Force | 力量 + 物理感（90 年代 NVIDIA 起点） |
| **CUDA** | Compute Unified Device Architecture | 技术宅缩写，但发音像姑娘名 |
| **Tegra** / **Tesla** / **Fermi** | 物理学家/电学先驱 | 科学谱系的认祖归宗 |
| **Kepler / Pascal / Volta / Turing / Ampere / Hopper / Blackwell / Rubin / Feynman** | GPU 架构代号清一色科学家 | "我们站在巨人肩上"——理工科价值观符号 |
| **Grace** | Grace Hopper（计算机先驱） | 同上 + 致敬女性科学家 |
| **Omniverse** | Omni + Universe | 巨大叙事容器，类似 Metaverse 的对抗品 |
| **Cosmos** | 宇宙 | 把"世界基础模型"诗化 |
| **DGX / HGX / NVLink / NIM** | 技术缩写 | 给企业客户的"严肃"产品线 |
| **AI Factory** | 工业革命隐喻 | 不是产品名，是品类重命名（最高级别叙事） |

**审美 DNA 提炼**：
- **理工科浪漫主义**——给芯片起人名，但人名是科学家
- **大词不脸红**——Omniverse、Cosmos、AI Factory 这种容易被嘲"过度宣传"的词，他用得很坦然
- **不追潮**——没有 "X-AI"、"Open-X"、"Super-X" 这种硅谷流行命名套路
- **保留 30 年品牌资产**——GeForce 从 1999 年用到今天 RTX 50 系列，不换 logo 不改名

---

## 十、节奏 DNA 总结

### 一场典型 Jensen Keynote 的节奏曲线

```
[开场] 自嘲式破冰（"I hope you realize this is not a concert"）
   ↓
[宏观叙事] 反复说 "general purpose computing is over" / "this is the biggest..."
   ↓
[类比堆叠] AI 工厂 = 工业革命 = 新发电机 = Token 是新石油
   ↓
[产品揭幕] "Ladies and gentlemen, [Blackwell/Rubin]" + 举起芯片
   ↓
[形容词轰炸] amazing × 20, incredible × 15, a miracle × 5
   ↓
[CEO math] "The more you buy, the more you save"（如果是商业场）
   ↓
[Demo / 合作伙伴登台] 把 NVIDIA 嵌入更大叙事
   ↓
[情绪段] 感谢团队/家人/台湾，时常哽咽
   ↓
[收尾] "This is the biggest industrial revolution of our lifetime."
```

### 与 Jobs / Cook / Musk 的节奏对比

| 维度 | Jensen | Jobs | Cook | Musk |
|---|---|---|---|---|
| 单场时长 | 90-120 分钟 | 60-90 分钟 | 60-90 分钟 | 30-60 分钟 |
| 信息密度 | **超高，过载** | 中等，精心节制 | 中等 | 跳跃，碎片 |
| 排练痕迹 | **低**——更像"演讲式即兴" | 极高 | 高 | 极低 |
| 情绪曲线 | 平 → 平 → 平 → **突然哽咽** | 节奏精确的高潮 | 平稳 | 大起大落 |
| 产品揭幕方式 | 物理拿起 + "Ladies and gentlemen" | "One more thing" | 视频 + 介绍 | Demo 翻车也照样推进 |

---

## 十一、"如果让黄仁勋用一句话评价 X"——DNA 复刻示范

### 命题：评价 OpenAI 转向消费应用（ChatGPT Apps、广告化）

**Jensen 风格 100 字示范：**

> "Sam is amazing. What he's built is incredible—it's a miracle, really. But, you know, AI is not an app. AI is infrastructure. The biggest industrial revolution of our lifetime is not happening in your phone—it's happening in the AI factory behind it. Every token, every query, every agent—it all runs on accelerated computing. We're 30 days from going out of business; that's how I run NVIDIA. So we keep building. Ladies and gentlemen, this is just the beginning."

**DNA 复刻检查**：
- amazing / incredible / a miracle 形容词通货膨胀（3 个）
- It's not [X], it's [Y] 重命名套路（AI is not an app, AI is infrastructure）
- the biggest [X] of our lifetime 标志短语
- AI factory / accelerated computing / token 三个技术叙事词
- 30 days from going out of business 签名表达
- Ladies and gentlemen 仪式感收尾
- 短句堆叠 + 不用问句
- 礼貌（"Sam is amazing"）但有反驳（"AI is not an app"）
- 没有时间精度承诺，只用 "the beginning"
