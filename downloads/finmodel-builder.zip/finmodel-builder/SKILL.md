---
name: finmodel-builder
description: |
  从元数据出发，手搓全公式、前后勾稽、数据与逻辑分离的财务模型 Excel package
  （三表/合并报表/UE/项目评估/多维看板，任何行业任何公司结构）。
  五层架构：行业知识层(数据源管道校准) → 行业配置 → Meta 宽表数据层 → 行业无关逻辑引擎 → 呈现层。
  行业参数禁止凭 AI 记忆硬编，走降级链（招股书→可比年报→…→诚实标低置信度）；配双算交叉验证。
  触发词：「手搓财务模型」「做一个三表模型」「集团合并报表模型」「全公式 Excel 模型」
  「财务模型 package」「FP&A 模型」「预算模型」「多维度下拉看板」「从元数据建财务模型」。
  适用：单主体或集团、虚构或真实公司、求职作品集或进公司后接真实数据源。
  不适用：只要静态数字表不要公式联动的（直接 openpyxl 填数）、超 10 年月度颗粒度巨模型。
---

# finmodel-builder — 从元数据出发的可勾稽财务模型引擎

核心信仰两条：
1. **行业不在代码里，在指标字典里**——换行业 = 换一份 Meta 数据，引擎零改动
2. **完成 = 有证据**——每格数字双算交叉验证，绝不说"应该可以了"

## 触发场景

- "帮我做一个 XX 公司的财务模型 / 三表 / 预算包 / FP&A 模型"
- "从零手搓一个集团财务分析 package"
- "做改假设能联动、前后勾稽的模型"
- 进公司后："把 ERP/BI 数据接进模型按期出三表"

## 五层架构（先给用户讲这张图再动手）

```
行业知识层  数据源管道            ← 参数的出处（招股书/年报/tsdata/研报），模型先验只配当冷启动默认值
     ↓ 校准
行业配置层  industry_config.py   ← 实例化参数（校准后的，每个数字挂来源）
     ↓ 初始化
数据层      Meta 宽表            ← 全模型唯一取数源（xlsx 里的 Meta sheet）
     ↓ SUMIFS / get()
逻辑引擎层  engine.py + gen_*.py ← 三表映射/勾稽/抵消，行业无关
     ↓
呈现层      Dashboard/UE/Checks  ← 维度看板/单位经济/自检面板
```

**关键承诺 1：引擎只认 Meta 接口。** 初始化用配置灌 Meta；进公司后用 ERP 导出灌 Meta（scenario=ACTUAL 按期间覆盖）——同一份引擎两段人生。roundtrip 测试证明：从 xlsx 读回 Meta → bind → 重算 → 与基线逐格一致。

**关键承诺 2：知识与逻辑分离。** 行业参数不许凭模型记忆硬编——先验不实时、冷门行业会空转、且不可审计。参数必须走数据源管道，source 列如实标注。

## Meta 宽表契约（数据层的字段设计）

列：`entity | segment | region | period | scenario | metric | value | source | note`

- **scenario**：ACTUAL（实际）/ BUDGET（预算）/ FORECAST——同一模型装多版本，进公司后实际+预测共存
- **source**：数据血缘（假设初始化 / ERP导出 / 手工 / 行业研究）——FP&A 审计感的来源
- **metric**：指标代码（snake_case），语义在指标字典里定义
- 期初数类 metric 全期同值（引擎只读第 0 期），保留全期行是为了 SUMIFS 不落空

## 执行流程

### Step 1a 收入模式诊断（逻辑判断，模型可胜任）
判断目标公司的收入是三种模式的哪种组合（可混合）：

| 模式 | 公式 | 典型 | 关键指标 |
|---|---|---|---|
| **量×价** volume_price | 收入=量×价 | MaaS token、SaaS 席位、零售客流、制造产能 | 量、单价、单位成本 |
| **客户×留存** cohort_retention | 收入=客户×ARPU×留存 | 订阅、C端付费、会员 | 客户数/MAU、转化率、ARPU、churn、CAC |
| **项目×合同** project_contract | 收入=项目×合同额+运维年金 | 私有化部署、工程总包、定制 | 项目数、合同额、交付成本率、运维费 |

成本侧配三种：成本率 / 单位成本 / 人天。结构参数（税率/账期/编制/融资/关联定价）所有行业通用。

### Step 1b 参数获取（事实问题，禁止先验编数）
走数据源降级链，每个参数必须挂来源：

```
招股书（单店/单位经济模型最细）
→ 可比上市公司年报（tsdata: pro.income() 拉利润表算毛利率/费用率区间）
→ 产业链相邻公司 → 行业协会/统计年鉴 → 研报
→ 【兜底】模型先验 + source 列如实标注"低置信度假设"
```

- 产物：**Calibration sheet**（参数 | 原假设(先验) | 真实区间 | 校准值 | 来源 | 偏差解释）
- 校准不是机械套区间：行业结构差异（如现制咖啡 vs 堂食餐饮）允许取区间外，但偏差解释必须写明
- 宁可数字标"猜的"，不冒充"查的"——与 Checks 红灯价值观同源
- 产出：`metric_dict.py`（指标字典）+ `industry_config.py`（校准后参数）+ Calibration 表

### Step 2 Meta 数据层
- `meta.py`：build_rows（配置→宽表）+ get(metric, 期, 主体, 地区) 统一取数接口
  + bind(rows) 切换数据源 + load_meta_from_xlsx（外部灌数入口）
- Excel `Meta` sheet：蓝字 value 列可改、autofilter、冻结——**用户日常唯一要碰的表**
- scenario 按期间打标（历史 ACTUAL / 预测 BUDGET）

### Step 3 逻辑引擎（影子层，行业无关）
- `engine.py` 纯 Python 算三表：`import meta as A`，只认 get 接口
- **倒挤现金法**：BS cash = 负债+权益−非现金资产（结构性平衡，免循环引用）；
  CF 间接法独立推导，断言 CF现金=BS现金——最深勾稽线
- 期初数同口径倒挤（期初现金 = 期初权益−期初非现金资产）
- 断言集全绿才准进下一步（BS平衡×主体、CF=BS、现金>0、形状 sanity）

### Step 4 Excel 生成（公式层）
- **Layout 坐标注册器**：L.reg(sheet, key, row, expected) 登记坐标↔语义↔影子期望值；
  生成器全走 L.ref() 拼引用，多 agent 并行不冲突
- 驱动行 = SUMIFS 从 Meta/Assumptions 视图取数（视图层也全部 SUMIFS 回 Meta——
  全模型任何数字都能溯源到 Meta!G 列）
- 集团层：关联交易双边挂账逐笔配平；**合并 COGS 保留服务方真实成本**（只抵内部定价差，
  内部利润随对方对外收入实现）；长投成本法差额进合并资本公积；非全资→少数股东拆分
- 每张 sheet 底部自带 `★ 差异行`（应全 0）——证据长在表里
- 选做剧情：IC_Recon 埋一笔 cut-off 在途 → 对账矩阵亮差异 → 调节表归零 → 合并挂"在途"

### Step 5 分析层（可 subagent 并行）
Dashboard 四下拉（维度适用性：IS 全维、BS/CF 仅主体×期间）/ UE（模式对应：量价→单token剪刀差、
留存→LTV/CAC、项目→单项目毛利）/ ProjectEval（NPV/IRR+敏感性）/ Checks 汇总面板。

### Step 6 三重验证（缺一不可）
- [ ] `engine.py` 断言全 PASS
- [ ] `recompute.py`：formulas 重算 → 逐格 vs 影子期望 → 0 不一致
- [ ] Checks 面板全 PASS + 总灯绿
- [ ] roundtrip：load_meta_from_xlsx → bind → 重算 → 与基线一致
- [ ] 人工：改 Meta!G 一个数 → 全模型联动、Checks 不亮红灯

## 分层 DAG（graph engineering）

```
M0 metric_dict+meta+engine → Gate1 影子断言绿
→ M1 契约(style/layout+Meta sheet) → M2 单体层(可并行) → Gate2 BS平
→ M3 关联+合并层 → Gate3 合并勾稽 → M4 分析层(N agent 并行) → M5 Checks → Gate4 端到端
```

## 已知陷阱（实战验证）

| 坑 | 解法 |
|---|---|
| formulas 引擎 `"<>"` 对数字列失效 | 数字维度"全部"用 `">0"`，文本列用 `"*"` |
| 宽表同时存合并行+单体行，`"*"` 双算 | 条件格 `IF(选="*","<>合并",选)` |
| 备注文本以 `=` 开头被当公式编译 | 备注列禁 `=` 开头 |
| 常量假设只写一列，后续列空 | 常量写满全列（Meta 里全期给行） |
| 滚动行公式引用"上一列同行"时行号未定 | 先 `row=r` 再拼 `{chr(66+i)}{row}` |
| IRR 对全正现金流无解 | `IFERROR(IRR(...),"—")` 注明以 NPV 排序 |
| 批次折旧存量资产的起折年 | 存量并入首年批（视为年初全新、当年起折），净值=累计原值−累计折旧 |
| 批次表"原值"与"当年现金流出"口径打架 | 首年批含期初存量，capex 行要减存量才是现金流（CF 引用的必须是净增口径） |
| CF 显示行 vs Δ科目符号 | `减：应收增加` 显示的是现金流影响（−ΔAR），expected 写正 Δ 会对不上 |
| 影子与 Excel 口径漂移 | 每处分歧当场对齐并写进 recompute 期望 |
| formulas 对 "M01" 这类文本 criteria 全匹配（COUNTIFS=行数） | period 维度加数字列 period_num，SUMIFS/COUNTIFS 一律用数字 criteria（零食量贩单店模型实战验证） |
| formulas 把 sheet 名大写化（sol key 是 PNL!B5，写入是 PnL!B5） | recompute 逐格比对统一 lower()，否则大量格假性 skipped、假绿 |

## Red Flags

- 引擎断言没全绿就写 Excel 层 → 停
- 生成器出现手写数字而非公式/SUMIFS → 破坏溯源链
- 数字绕过 Meta 直接进公式 → 破坏数据与逻辑分离
- 没跑三重验证就宣布完成 → 违反核心信仰 2

## 输出规范

- 一键重建 `build.py` → dist/*.xlsx；三重验证+roundtrip 全绿才交付
- README 明示：Meta 字段契约、指标字典、全部简化假设（模型诚实度）
- 演示动线：Meta 改一个数 → 全模型联动 → Checks 依然全绿
