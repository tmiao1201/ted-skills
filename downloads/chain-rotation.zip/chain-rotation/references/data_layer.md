# 数据层范式 — tsdata 行情财务 + report_rc 券商一致预期

> 换主题时**只需改 `COMPANIES` 清单**（环节/名称/代码/兑现节奏），其余直接复用。
> 实战脚本见 `~/cursor/ai_supplychain/chain_rotation.py`（行情财务）+ `chain_forecast.py`（一致预期）。
> 解释器必须用 `/usr/local/bin/python3`，且 `PYTHONPATH=/Users/tedmiao/cursor`。

## A. 行情 + 财务 + PE 历史分位

```python
import sys; sys.path.insert(0, "/Users/tedmiao/cursor")
import tsdata, pandas as pd

# 换主题：改这个清单即可。code 用 tushare 格式(.SH/.SZ)
COMPANIES = [("环节","名称","代码.SZ","兑现节奏标签"), ...]
codes = [c[2] for c in COMPANIES]

panel = tsdata.get_panel("20230101", "20260531")        # 近3年，用于PE分位
panel = panel[panel.ts_code.isin(codes)]
last = panel.trade_date.max()
fina = tsdata.get_fina(); fina = fina[fina.ts_code.isin(codes)]   # roe/netprofit_yoy/or_yoy + ann_date

def pe_percentile(code):                                 # 当前PE在近3年的百分位(剔除负PE!)
    s = panel[panel.ts_code == code][["trade_date","pe"]].dropna()
    s = s[s.pe > 0]
    if len(s) < 30: return None, None
    cur = s[s.trade_date == last].pe
    if len(cur) == 0: return None, None
    cur = cur.iloc[0]
    return round(cur,1), round((s.pe < cur).mean()*100)

# 每家取: 最新 close/pe/pb/total_mv(万元→/1e4=亿) + PE分位 + 最新报告期 or_yoy/netprofit_yoy/roe
# fina 取 sort_values('ann_date').iloc[-1] 为最新一期
```

关键字段（tsdata 口径）：
- `get_panel` = daily ⋈ daily_basic：`close / pe / pb / total_mv(万元) / circ_mv`
- `get_fina`：`or_yoy`(营收增速%) / `netprofit_yoy`(净利增速%) / `roe`(%) / `end_date`(报告期) / `ann_date`(公告日)
- 缓存只读不联网；旧了先 `python -m tsdata.update`

## B. 券商一致预期 → forward PE（report_rc）

```python
from tsdata.client import get_pro
pro = get_pro()
CUT = "20260129"   # 近120天研报(相对最新交易日倒推约4个月)

r = pro.report_rc(ts_code="300308.SZ")    # 单家所有券商研报预测
r = r[r.report_date >= CUT]
# r 列: org_name(券商)/quarter(如'2026Q4'=该年全年)/eps/np/pe/tp(目标价)/roe
def med_eps(r, quarter):
    s = r[r.quarter == quarter]["eps"].dropna()
    s = s[(s > -50) & (s < 500)]          # 过滤极端值
    return (round(float(s.median()),2), len(s)) if len(s) else (None, 0)

e26, n26 = med_eps(r, "2026Q4")           # FY2026 一致EPS中位数 + 覆盖券商数
e27, n27 = med_eps(r, "2027Q4")
fwd_pe_26 = round(close / e26, 1) if e26 and e26>0 else None   # forward PE
exp_growth = round((e27/e26 - 1)*100) if e26 and e27 else None # 预期增速26→27
# n(覆盖券商数) < 5 → forward PE 标"仅供参考"
```

**聚合要点**：按 `quarter` 取**中位数**（抗单家异常），记 `len` 作覆盖券商数。`quarter='YYYYQ4'` 代表该年全年预测。逐家循环调用 `report_rc`，加 `time.sleep(0.3)` 防限频。

## C. 输出 JSON 结构（供仪表盘 D 数组）

每家一条，客观字段全来自上面真实接口，定性字段(`st/x/dr/rk`)由 Agent 结合财报人工判断：
```json
{"seg":"环节","n":"名称","c":"代码","mv":总市值亿,"pp":PE分位,
 "or":营收YoY,"np":净利YoY,"roe":ROE,"pe":当前PE,
 "fp26":forwardPE26,"fp27":forwardPE27,"g":预期增速,"nr":覆盖券商数,
 "st":"阶段red/grn/cyan/amb/gray","x":兑现进度0-100,"dr":"驱动一句话","rk":"风险一句话"}
```

## D. 降级策略

- `report_rc` 不可用/积分不足 → 跳过 forward PE 列，只用 A 的实际财报增速 + 定性，**明确告诉用户拿不到一致预期**
- tsdata 缓存旧 → 先 `PYTHONPATH=/Users/tedmiao/cursor /usr/local/bin/python3 -m tsdata.update`
- 港股标的 tsdata 覆盖有限 → 港股财务可能缺，标注 N/A 不硬填
