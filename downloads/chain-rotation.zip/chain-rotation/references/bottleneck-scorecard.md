# 卡点综合打分表（融合版）— serenity 卡点维度 × tsdata 真实数据

> 来源：移植自 serenity-skill 的 `bottleneck-scorecard.json`，**关键改造**是把其中纯定性的
> `evidence_quality` / `valuation_disconnect` 两维接到 chain-rotation 的 tsdata 真数据，
> 而不是靠 LLM 印象打分。用于给跨标的一个可排序的"综合研究优先级分"。
> 何时用：用户要一个综合排序分，而非只要 Step 6 的象限分类时。象限是 2 维可视化，本表是多维排序，互补。

## 评分口径

- 8 个**加分维度**，每维 0–5（0=无，5=很强）。
- 8 个**惩罚项**，每维 0–5（数值越大扣得越多）。
- **总分 = Σ加分 − 0.5·Σ惩罚**（权重可按主题微调；惩罚半权，避免好环节被单一风险一票否决）。
- 排序用总分；但**总分只排"研究优先级"，不替代 Step 6 的兑现阶段判断**，两者并列看。

## 8 个加分维度

| 维度 | 含义 | 打分依据 | 数据来源 |
|---|---|---|---|
| `demand_inflection` | 需求拐点 | 终端出货/订单是否正在加速 | 定性 + 公开出货数据 |
| `architecture_coupling` | 架构耦合 | 该环节是否绕不开（BOM 占比高、物理约束硬） | 定性（Step 1 BOM 增量逻辑） |
| `chokepoint_severity` | **卡点强度** | 供应商少 / 良率难 / 重资产扩产 | 定性（**Step 2.5 层级排序结论**） |
| `supplier_concentration` | 供应商集中度 | 全球可供货家数越少越高 | 定性 + 产业链调研 |
| `expansion_difficulty` | 扩产难度 | 认证周期长 / 设备依赖 / 良率爬坡慢 | 定性 |
| `evidence_quality` | **证据质量** | **财报是否已兑现（营收/净利/ROE 真增长）+ 证据强度标签** | **tsdata `get_fina` 真数 + 证据阶梯** |
| `valuation_disconnect` | **估值背离** | **PE 历史分位低 / forward PE 相对增速便宜 = 高分；已透支 = 低分** | **tsdata PE分位 + report_rc forward PE** |
| `catalyst_timing` | 催化时点 | 3–12 个月内是否有量产/订单/财报催化 | 定性 + 公告跟踪 |

> 两条硬规则：
> - `evidence_quality` **不能靠"进了大客户供应链"这种说法给高分**——必须 tsdata 看到净利真的兑现（呼应 SKILL.md 反偷懒表"卡位≠赚钱"）。证据本身按 强/中/弱/需核实 标签，弱证据封顶 2 分。
> - `valuation_disconnect` 必须用真实 PE 分位/forward PE，**禁止"估一个差不多的"**；缓存旧时此维度按 `data_date` 标注且降可信度。

## 8 个惩罚项

| 惩罚 | 含义 | 依据 |
|---|---|---|
| `dilution_financing` | 摊薄/再融资 | 是否需融资才能兑现（呼应"承压·长跑"） |
| `governance` | 治理 | 商誉/关联交易/减持/审计问题 |
| `geopolitics` | 地缘 | 出口管制/客户脱钩敞口 |
| `liquidity` | 流动性 | 港股/小盘流动性差 |
| `hype_risk` | 炒作风险 | 股价主要由情绪/题材驱动（红旗） |
| `accounting_quality` | 会计质量 | 应收/存货增速 > 营收等红旗 |
| `cyclicality` | 周期性 | 上游材料价格战（沪硅型亏损） |
| `alternative_design_risk` | 替代设计 | 技术路线被替代风险（如硅基OLED vs Micro-LED） |

## 每条证据的记录格式（带强度标签）

```json
{"claim": "三季报归母净利+73.5%", "source": "688608 2025Q3 定期报告", "strength": "强"}
```
`strength` 取值：`强`（年报/季报/交易所公告/IR/订单/专利）/ `中`（权威媒体/券商研报）/ `弱`（KOL/传闻）/ `需核实`。

## 强制证伪条件（每个 top 标的 ≥3 条）

`what_could_weaken_view`：明确写"什么事实会推翻这个判断"。例：
1. 反射光波导量产再延期，年报仍停在"NPI/攻关"、无独立收入与毛利改善；
2. 竞品技术路线（如 Micro-LED）抢跑，挤压硅基 OLED 窗口；
3. 高估值已 price-in，forward PE 远高于预期增速。

## JSON 模板（在 data_layer.md 的 D 数组基础上扩展）

```json
{
  "ticker": "688608.SH", "company": "恒玄科技", "market": "A股",
  "data_date": "20260530",
  "factors": {"demand_inflection":4,"architecture_coupling":4,"chokepoint_severity":3,
              "supplier_concentration":3,"expansion_difficulty":3,"evidence_quality":5,
              "valuation_disconnect":2,"catalyst_timing":4},
  "penalties": {"dilution_financing":0,"governance":0,"geopolitics":1,"liquidity":0,
                "hype_risk":2,"accounting_quality":0,"cyclicality":1,"alternative_design_risk":2},
  "evidence": [{"claim":"营收+18.6% 归母+73.5%","source":"2025Q3 报告","strength":"强"}],
  "what_could_weaken_view": ["高通AR1持续占旗舰致份额下滑","展锐价格战压毛利","高PE透支增速"],
  "total_score": 0
}
```

> `total_score` 由 `Σfactors − 0.5·Σpenalties` 算出，落表前用脚本填，不手填。
