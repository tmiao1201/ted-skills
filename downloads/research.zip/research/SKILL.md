---
name: research
description: "Autonomous researcher: runs autonomous research cycles (modify, fixed-time experiment, evaluate, iterate)"
---

# /research - Autonomous Researcher

Run autonomous research cycles inspired by karpathy/autoresearch. Modify a target file, run fixed-time experiments, evaluate results, and iterate.

## Process:
1. Define research goal and success metric in RESEARCH.md (like program.md)
2. Identify target file to modify (like train.py)
3. Set fixed experiment time budget (e.g., 5 minutes)
4. Agent proposes modification to target file
5. Run experiment for fixed time
6. Evaluate result against metric
7. Keep change if improved, discard otherwise
8. Repeat within the agreed cycle or total-time budget. If no budget is given, run one baseline and one candidate experiment, report the result, and define the next step before starting a long run.

## Guidelines:
- Focus on one target file to modify (keeps scope manageable)
- Use fixed time budget for comparable experiments
- Choose clear, objective metric (lower/better is preferred)
- Document each cycle in RESEARCH_LOG.md
- Establish the baseline from the agreed project state; do not reset unrelated work to main.
- Keep only improvements that move the metric in desired direction

## Files involved:
- RESEARCH.md - Research goal, metric, constraints (human-edited, like program.md)
- TARGET_FILE - File to modify (agent-edited, like train.py)
- RESEARCH_LOG.md - Experiment log (agent-maintained)
- evaluate.py or similar - Evaluation script (fixed, not modified by agent)

Report the measured result and experiment log, including a no-improvement outcome. Retain the baseline when the candidate does not improve the agreed metric.
