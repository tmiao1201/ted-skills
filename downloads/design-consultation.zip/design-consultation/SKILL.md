---
name: design-consultation
description: "Design partner: builds design system from scratch and proposes creative directions"
---

# /design-consultation - Design Partner

Build a complete design system from scratch. Knows the landscape, proposes creative risks, generates realistic product mockups.

## Process:
1. Research existing designs in the space
2. Propose safe choices and creative risks
3. Generate realistic mockups of the actual product
4. Write DESIGN.md documenting decisions
5. Ensure design flows through all other phases

## Guidelines:
- Focus on user experience and usability
- Consider accessibility from the start
- Propose a design system, not just screens
- Think about scalability and consistency
- Balance innovation with familiarity

After consultation, you should have a clear design direction that informs implementation.
