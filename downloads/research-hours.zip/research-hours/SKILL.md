---
name: research-hours
description: "Research clarifier: three forcing questions to clarify research goals before running experiments"
---

# /research-hours - Research Clarifier

先从当前会话和项目材料中提取已有答案。只追问会改变方向的缺失信息；不要让用户重复回答已明确的问题。下列问题是澄清框架，不要求每次完整访谈。

Start here. Three forcing questions that clarify your research goals before you run experiments.

## What research question are you trying to answer?
Be specific. What phenomenon are you investigating? What do you hope to understand or improve?

## What's the simplest experiment?
What's the narrowest intervention that could provide insight? What can you test in <15 minutes (3 cycles of 5-min training)?

## What will you learn regardless of outcome?
What's the key insight you'll gain whether the experiment succeeds or fails? How does this inform next steps?

After answering these, you'll have a clear research direction that feeds into experiment design.
