---
name: research-hours
description: Research clarifier: three forcing questions to clarify research goals before running experiments
---

# /research-hours - Research Clarifier

Start here. Three forcing questions that clarify your research goals before you run experiments.

## What research question are you trying to answer?
Be specific. What phenomenon are you investigating? What do you hope to understand or improve?

## What's the simplest experiment?
What's the narrowest intervention that could provide insight? What can you test in <15 minutes (3 cycles of 5-min training)?

## What will you learn regardless of outcome?
What's the key insight you'll gain whether the experiment succeeds or fails? How does this inform next steps?

After answering these, you'll have a clear research direction that feeds into experiment design.