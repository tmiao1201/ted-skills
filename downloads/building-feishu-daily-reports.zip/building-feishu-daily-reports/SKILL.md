---
name: building-feishu-daily-reports
description: Use when 用户要搭建定期推送到飞书的数据日报/周报/月报系统（GMV、损益、运营指标），涉及 CSV/Excel/ODPS 数据源、漂亮 HTML 模板、playwright 截图、飞书机器人推送、GitHub Actions 定时调度的完整链路。包含飞书自建应用 vs 群机器人选型、chat_id 获取、中文字体、ECharts 渲染等关键坑。
---

# 搭建飞书数据日报系统

## 概述

数据日报推送（GMV、PnL、运营指标 → 飞书）是常见内部展示场景。本 skill 提供端到端脚手架方法论 —— **HTML 模板 + Python 数据管线 + 飞书推送 + GitHub Actions 调度**。

**参考实现：** `~/cc/daily-report` 是已经跑通的完整项目（25 个文件、~1500 行），可直接 `cp -r` 当新项目起点。

**核心选型：** HTML 模板 → playwright 截图 PNG → 飞书图片消息。HTML 审美天花板远高于纯文本/markdown 卡片，且改版方便。

## 何时使用

适合：
- 推送频率：每日/每周/每月业务指标摘要
- 推送渠道：飞书（私聊或群）
- 视觉要求高（杂志风、报刊风、报告风）
- 数据源在 CSV/Excel/MaxCompute(ODPS)/MySQL
- 需要自动化（GitHub Actions / 公司定时服务）

不适合：
- 一次性图表 → 直接 matplotlib 出图
- 仅文本通知 → 直接调 webhook 文本接口
- 推送渠道是钉钉/企微/邮件 → 复用整套架构，仅替换 push 适配层

## 整体架构

```
数据源 → 指标计算 → HTML 模板 → 截图 → 飞书 → 调度
(CSV/    (环比/同   (Jinja2 +   (play-   (自建    (GH Actions
 ODPS)    比/异动)    ECharts)    wright)   应用)    cron)
```

参考目录：

```
daily-report/
├── config/report.yaml          # 数据源 / 推送 / 输出 集中配置
├── src/
│   ├── connectors/{csv,odps}*  # 双数据源
│   ├── metrics/calculator.py   # 环比/同比/罗马期号/损益布局
│   ├── render/{html,image}*    # Jinja2 + playwright
│   ├── push/feishu.py          # 飞书自建应用（上传图片+发图片消息）
│   └── main.py                 # 编排入口
├── templates/magazine.html     # 单文件 HTML+CSS+ECharts 模板
├── scripts/get_chat_id.py      # 一次性脚本：列群拿 chat_id
└── .github/workflows/daily.yml # cron 触发
```

## 关键决策树

### 推送方案：单自建应用 vs 双机器人

| 方案 | 何时用 | 限制 |
|---|---|---|
| **单自建应用**（强烈推荐） | 总是 | 需要 chat_id |
| 自建应用 + 群 webhook | 几乎不需要 | 多建一个机器人；很多公司禁用群自定义机器人 |

**关键坑：** 群自定义机器人 webhook **不能上传图片**！要发图片必须先用自建应用上传拿 image_key。所以即使走双机器人方案也跑不掉自建应用 —— **直接用单自建应用方案最干净**。

### 飞书自建应用必做项（90% 的人卡这里）

1. 「**应用功能 → 机器人 → 启用**」（默认是关的，必做）
2. 申请权限：`im:message`（发消息）+ `im:resource`（发图片）+ `im:chat:readonly`（让 get_chat_id 列群）
3. 「应用发布 → 创建版本」并通过审核
4. 把机器人拉进目标群（群设置 → 群机器人 → 添加机器人 → 「**企业自建**」分类）
5. 跑 `python -m scripts.get_chat_id` 拿目标群 `chat_id`

### GitHub Actions 三个细节

- **中文字体**：`apt-get install -y fonts-noto-cjk` —— 不装中文显示方块
- **playwright**：`playwright install --with-deps chromium`
- **时区**：cron 用 UTC，工作日北京 09:00 = `"0 1 * * 1-5"`
- **secrets**：`FEISHU_APP_ID` / `FEISHU_APP_SECRET` / `FEISHU_CHAT_ID`

## 杂志风视觉设计原则

参考 FT / 经济学人 / Bloomberg：

- **配色**：米白 `#FAF7F2` + 墨黑 `#1A1A1A` + 强调红 `#A6192E` + 上涨绿 `#2E7D32` + 下跌红 `#C62828`
- **字体**：标题 Playfair Display + 思源宋体；正文思源黑体；数字 `font-feature-settings: "tnum"` 对齐
- **结构**（七段式）：报头 → 今日导读眉标 → 头版头条（巨数字 + 解读）→ 三栏（KPI / 趋势图 / 评论）→ 损益表 → 异动榜 → 编辑寄语 → 页脚
- **细节**：3px double 分隔线、栏间细规线、ECharts 去网格保留留白、首字母放大装饰

## 复用流程（5 分钟开新日报）

```bash
# 1. 复制模板项目
cp -r ~/cc/daily-report ~/cc/<新项目名>
cd ~/cc/<新项目名>
rm -rf .git output/* && git init -b main

# 2. 改 4 个地方
config/report.yaml          # 数据源切换 csv ↔ odps
data/sample_*.csv           # 替换为真实 demo 数据
src/main.py                 # build_lead_copy / build_commentary 文案
templates/magazine.html     # 配色、字体、版块（如改 LOGO/刊名）

# 3. 推 GitHub + 配 secrets + 跑
gh repo create <name> --private --source=. --remote=origin --push
gh secret set FEISHU_APP_ID --body 'cli_xxx'
gh secret set FEISHU_APP_SECRET --body 'xxx'
gh secret set FEISHU_CHAT_ID --body 'oc_xxx'
sed -i '' 's/enabled: false/enabled: true/' config/report.yaml
git commit -am "chore: enable feishu push" && git push
gh workflow run "Daily Business Report"
```

## 常见错误速查

| 报错 / 现象 | 原因 | 修复 |
|---|---|---|
| `Repository not found` | gh 登录账号 ≠ 你以为的用户名 | `gh auth status` 看实际账号 |
| 飞书 99991663 / 99991668 | App ID/Secret 错或机器人未启用 | 飞书后台「应用功能 → 机器人」确认启用 |
| 飞书 99991672 | 缺权限或没发布新版本 | 申请 `im:resource` + 重新发布版本 |
| 找不到「自定义机器人」 | 公司 IT 禁用了 | **直接用单自建应用方案**，不走 webhook |
| 中文显示方块 | Actions 没装中文字体 | `apt-get install -y fonts-noto-cjk` |
| ECharts 截图空白 | playwright 没等图表渲染 | `wait_for_load_state("networkidle")` + `wait_for_timeout(800)` |
| App Secret 不慎泄露 | 粘到聊天/git/日志 | 飞书后台「凭证 → 重置」+ `gh secret set FEISHU_APP_SECRET --body '<新值>'` |

## 安全红线

- **App Secret 永远不要粘到对话/聊天/git/日志**。一旦看见即视为泄露，立刻重置 + 更新所有使用方
- 飞书凭证统一用环境变量或 GitHub Secrets 注入，**不写进 yaml/代码**
- 仓库默认 **private**（含飞书凭证相关引用）
