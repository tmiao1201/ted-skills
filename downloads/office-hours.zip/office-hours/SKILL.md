---
name: office-hours
description: "Product clarifier: three forcing questions to clarify what problem you're solving before writing code"
---

# /office-hours - Product Clarifier

先从当前会话和项目材料中提取已有答案。只追问会改变方向的缺失信息；不要让用户重复回答已明确的问题。下列问题是澄清框架，不要求每次完整访谈。

Start here. Three forcing questions that clarify your product before you write code.

## What problem are you solving?
Be specific. Who has this problem? How do you know it's real?

## What's the simplest solution?
What's the narrowest wedge that delivers value? What can you build in <2 hours?

## What will you learn?
What's the riskiest assumption? How will you validate it with real usage?

After answering these, you'll have a clear plan that feeds into downstream skills.
