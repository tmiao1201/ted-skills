# Troubleshooting · GitHub Actions 定时任务调试速查

每条都来自实战。看到对应错误信息直接对照修。

## SSH / Deploy Key 类

| 错误信息 | 根因 | 修法 |
|---|---|---|
| `error in libcrypto` | secret 里 PEM 私钥格式损坏（GitHub UI 处理多行私钥不可靠） | 用 `base64 -i ~/.ssh/key | tr -d '\n'` 转 base64 单行重粘 |
| `Permission denied (publickey)` (push 时) | deploy key 没勾 "Allow write access" | public repo → Settings → Keys → 删旧 key → 重加并勾 Allow write access |
| `Permission denied (publickey)` (clone 时) | deploy key 公钥没加到目标 repo | 目标 repo → Settings → Deploy keys → New deploy key |
| `base64: invalid input` | secret 里不是有效 base64（可能粘了 PEM 或带空白字符） | 重新粘干净的 base64 |
| `Could not read from remote repository` | repo 不存在 / URL 拼错 | 检查 git@github.com:USER/REPO.git 中 USER 和 REPO 是否对，注意大小写 |

## Workflow 触发类

| 现象 | 根因 | 修法 |
|---|---|---|
| 改了 workflow 推上去，跑还是旧逻辑 | 用了 **Re-run failed jobs**（用旧 commit）而不是 **Run workflow** | 必须从 workflow 列表页点 **Run workflow** 蓝色下拉触发新 run |
| schedule 时间到了没触发 | GitHub schedule 高峰期延迟 5-15 分钟正常；连续 60 天无 commit 会暂停 | 等一下，或避开整点；定期 commit 防暂停 |
| `permission denied to github-actions[bot]` | workflow 没声明 `permissions: contents: write` | yaml 里加 `permissions:` 块 |

## Git Push 类

| 错误信息 | 根因 | 修法 |
|---|---|---|
| `failed to push some refs` + `non-fast-forward` | 远端有比本地新的 commit | 没人手动改的话，clone 一遍重来；或 git pull --rebase |
| `pre-receive hook declined` | push 到了 protected branch（如 main） | 通过 PR 推 / 临时关 protection / 推到非 protected branch |

## Python 运行类

| 错误信息 | 根因 | 修法 |
|---|---|---|
| `ModuleNotFoundError: cryptography` | requirements.txt 漏了 cryptography | 加进 requirements.txt |
| `FileNotFoundError: /Users/xxx/...` | 代码硬编码绝对路径，Linux runner 没有 | workflow 加 `sudo mkdir -p /Users/xxx && sudo ln -sf "$PWD" /Users/xxx/yyy` |
| `tushare/api 鉴权失败` | TS_TOKEN secret 没配 / 配错 / 代码没读 env | 检查 secret 名拼写 + 代码 `os.getenv('TS_TOKEN')` |
| `ImportError: 中文模块名` | Python 不支持直接 `import 中文名` | 用 `importlib.util.spec_from_file_location()` |
| `_ssl.SSLError` 拉外网 API | 偶发网络问题 | 加重试逻辑 / 接受偶发失败 |

## GitHub Pages 类

| 现象 | 根因 | 修法 |
|---|---|---|
| 推送成功但 URL 显示 404 | 首次部署需 1-2 分钟；或 Pages 没启用 | 等；或 Settings → Pages → Source 设成 main / |
| Pages 显示旧版 | CDN 缓存 | 强制刷新 (Cmd+Shift+R) / 等几分钟 |
| 文件 commit 了但 Pages 看不到 | 不在 Pages 监听的目录 | 检查 Settings → Pages 配的是 `/` 还是 `/docs` |

## 调试技巧

1. **先看哪一步红 X**：Actions 页 → 点失败 run → 点 job → 展开各 step
2. **加 echo 调试**：在 workflow 里加 `echo "DEBUG: $VAR"`（注意 secret 会被自动 mask）
3. **secret 长度自检**：`echo "len=${#MY_SECRET}"` 能判断 secret 是否为空
4. **本地复现**：把 workflow 命令直接在本地 bash 跑（除了用到 secrets 的部分）
5. **看官方日志**：失败 step 上面几行通常含 traceback / 详细错误
