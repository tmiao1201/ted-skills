"""
泰坦看板 · 客户端密码加密
================================================
把生成好的 self-contained HTML 加密成"密码保护版"：
- 浏览器打开 → 看到密码框 → 输密码 → JS 解密 → 显示完整看板
- 链接公开（GitHub Pages）也安全：没密码看不到任何数据

用法：
  python3 加密看板.py 泰坦看板_20260430.html ./publish/index.html [--password XXX]

加密方案：
  PBKDF2-HMAC-SHA256 (250000 轮) + AES-GCM-256
  浏览器端 Web Crypto API 解密（零外部依赖，所有现代浏览器原生支持）

依赖：
  pip install cryptography
"""
import argparse
import base64
import os
import sys
import secrets
import getpass
from pathlib import Path

try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    from cryptography.hazmat.primitives import hashes
except ImportError:
    print("❌ 缺少 cryptography 库")
    print("   请先运行: pip install cryptography")
    sys.exit(1)


PBKDF2_ITERATIONS = 250_000


def derive_key(password: str, salt: bytes) -> bytes:
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=PBKDF2_ITERATIONS,
    )
    return kdf.derive(password.encode('utf-8'))


def encrypt_html(plaintext: str, password: str) -> dict:
    salt = secrets.token_bytes(16)
    iv = secrets.token_bytes(12)
    key = derive_key(password, salt)
    aes = AESGCM(key)
    ct = aes.encrypt(iv, plaintext.encode('utf-8'), None)
    return {
        'salt': base64.b64encode(salt).decode(),
        'iv': base64.b64encode(iv).decode(),
        'ciphertext': base64.b64encode(ct).decode(),
        'iterations': PBKDF2_ITERATIONS,
    }


WRAPPER_TEMPLATE = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5">
<meta name="theme-color" content="#0a0e1a">
<meta name="robots" content="noindex, nofollow">
<title>泰坦计划</title>
<style>
* { box-sizing: border-box; margin: 0; padding: 0; }
body {
  font-family: -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif;
  background: #0a0e1a; color: #e6edf7;
  background-image: radial-gradient(circle at 20% 0%, rgba(124,92,255,.10), transparent 50%),
                    radial-gradient(circle at 80% 100%, rgba(0,212,255,.08), transparent 50%);
  min-height: 100vh;
  display: flex; align-items: center; justify-content: center;
  padding: 24px;
}
.lock-card {
  background: #141b2d; border: 1px solid #233055;
  border-radius: 16px; padding: 36px 32px; max-width: 380px; width: 100%;
  box-shadow: 0 16px 48px rgba(0,0,0,.5);
}
.lock-icon {
  font-size: 40px; text-align: center; margin-bottom: 18px;
  background: linear-gradient(90deg, #00d4ff, #7c5cff);
  -webkit-background-clip: text; -webkit-text-fill-color: transparent;
}
.lock-title {
  font-size: 22px; font-weight: 700; text-align: center;
  background: linear-gradient(90deg, #00d4ff, #7c5cff);
  -webkit-background-clip: text; -webkit-text-fill-color: transparent;
  letter-spacing: 2px; margin-bottom: 6px;
}
.lock-sub {
  text-align: center; color: #8a96b3; font-size: 13px;
  margin-bottom: 28px; letter-spacing: 0.5px;
}
.field { margin-bottom: 16px; }
input[type="password"] {
  width: 100%; padding: 14px 16px; border-radius: 10px;
  background: #1a2238; border: 1px solid #233055;
  color: #e6edf7; font-size: 16px; outline: none;
  transition: border-color .2s;
  -webkit-appearance: none;
}
input[type="password"]:focus { border-color: #00d4ff; }
button {
  width: 100%; padding: 14px; border-radius: 10px; border: 0;
  background: linear-gradient(90deg, #00d4ff, #7c5cff);
  color: #0a0e1a; font-size: 15px; font-weight: 600;
  cursor: pointer; letter-spacing: 1px;
  transition: transform .1s;
}
button:hover { transform: translateY(-1px); }
button:active { transform: translateY(0); }
button:disabled { opacity: 0.5; cursor: wait; }
.error {
  margin-top: 14px; padding: 10px 12px; border-radius: 6px;
  background: rgba(255,85,112,.10); border: 1px solid rgba(255,85,112,.3);
  color: #ff5570; font-size: 12px; display: none;
}
.error.show { display: block; }
.foot {
  margin-top: 24px; text-align: center; color: #5a6480;
  font-size: 11px; letter-spacing: 0.5px;
}
.spinner {
  display: inline-block; width: 14px; height: 14px;
  border: 2px solid rgba(10,14,26,.3); border-top-color: #0a0e1a;
  border-radius: 50%; vertical-align: middle; margin-right: 8px;
  animation: spin 0.6s linear infinite;
}
@keyframes spin { to { transform: rotate(360deg); } }
</style>
</head>
<body>
<div class="lock-card">
  <div class="lock-icon">🔒</div>
  <div class="lock-title">TITAN PLAN</div>
  <div class="lock-sub">私享看板 · 请输入密码</div>
  <form id="login-form" onsubmit="event.preventDefault(); decrypt();">
    <div class="field">
      <input type="password" id="pwd" autofocus autocomplete="current-password"
             placeholder="密码" />
    </div>
    <button type="submit" id="submit-btn">解锁</button>
    <div class="error" id="err"></div>
  </form>
  <div class="foot">PBKDF2 + AES-GCM-256 · 客户端解密</div>
</div>
<script>
const PAYLOAD = __PAYLOAD__;

function b64ToBytes(s) {
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

async function decrypt() {
  const btn = document.getElementById('submit-btn');
  const err = document.getElementById('err');
  const pwd = document.getElementById('pwd').value;
  if (!pwd) return;

  btn.disabled = true;
  btn.innerHTML = '<span class="spinner"></span>解密中...';
  err.classList.remove('show');

  try {
    const enc = new TextEncoder();
    const keyMaterial = await crypto.subtle.importKey(
      'raw', enc.encode(pwd), 'PBKDF2', false, ['deriveKey']);
    const key = await crypto.subtle.deriveKey(
      { name: 'PBKDF2', salt: b64ToBytes(PAYLOAD.salt),
        iterations: PAYLOAD.iterations, hash: 'SHA-256' },
      keyMaterial,
      { name: 'AES-GCM', length: 256 },
      false, ['decrypt']);
    const plaintext = await crypto.subtle.decrypt(
      { name: 'AES-GCM', iv: b64ToBytes(PAYLOAD.iv) },
      key, b64ToBytes(PAYLOAD.ciphertext));
    const html = new TextDecoder().decode(plaintext);
    document.open();
    document.write(html);
    document.close();
  } catch (e) {
    err.textContent = '密码错误，请重试';
    err.classList.add('show');
    btn.disabled = false;
    btn.textContent = '解锁';
    document.getElementById('pwd').select();
  }
}
</script>
</body>
</html>
"""


def main():
    ap = argparse.ArgumentParser(description="泰坦看板加密发布")
    ap.add_argument('input', help='源 HTML 文件')
    ap.add_argument('output', help='输出加密后的 HTML（一般为 publish/index.html）')
    ap.add_argument('--password', '-p', help='加密密码（不传则从 ~/.titan_password 读取或交互输入）')
    args = ap.parse_args()

    src = Path(args.input)
    if not src.exists():
        print(f"❌ 源文件不存在: {src}")
        sys.exit(1)

    # 解析密码
    pwd = args.password
    if not pwd:
        pwd_file = Path.home() / '.titan_password'
        if pwd_file.exists():
            pwd = pwd_file.read_text(encoding='utf-8').strip()
            print(f"🔑 从 {pwd_file} 读取密码")
        else:
            pwd = getpass.getpass('密码: ')
    if not pwd:
        print("❌ 密码为空")
        sys.exit(1)

    print(f"📄 读取 {src} ({src.stat().st_size/1024:.0f} KB)")
    plaintext = src.read_text(encoding='utf-8')

    print(f"🔐 加密中 (PBKDF2 {PBKDF2_ITERATIONS} 轮 + AES-GCM-256)...")
    payload = encrypt_html(plaintext, pwd)

    import json
    payload_json = json.dumps(payload, ensure_ascii=False)
    out_html = WRAPPER_TEMPLATE.replace('__PAYLOAD__', payload_json)

    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(out_html, encoding='utf-8')
    print(f"✅ 已生成 {out} ({out.stat().st_size/1024:.0f} KB)")
    print(f"   原文 → 密文 比例: {len(plaintext)} → {len(payload['ciphertext'])} 字节")


if __name__ == '__main__':
    main()
