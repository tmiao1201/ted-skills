---
name: github-cron
description: |
  把本地 Python 项目搬到 GitHub 跑定时 Actions 任务（每天/每周自动云端运行）。
  支持三种发布模式：仅运行 / 推数据到 public repo / 加密发布到 GitHub Pages（双 repo + AES-GCM）。
  触发词：GitHub Actions 定时任务、cron 任务上云、把脚本搬到 GitHub、加密私享看板、定时跑选股/爬虫脚本。
  不适用：一次性任务（直接本地跑就好）、需要桌面 GUI 的任务、长时间任务（>6h）、需要 GPU 的任务。
---

# /github-cron — 把本地脚本变成 GitHub 定时任务

把用户已有的本地 Python 项目（典型如选股、爬虫、数据处理）搬到 GitHub Actions 上**定时云端跑**，电脑关机也不影响。

## 触发场景

- 「把 X 项目搬上 GitHub 跑定时任务」「配 cron 任务到云端」
- 「做个加密的私人看板放 GitHub Pages」「每天自动生成 X 推到网站」
- 「电脑关机也要跑选股 / 爬虫 / 报表」
- 用户已有可在本地跑通的 Python 脚本，但想脱离本地依赖

## 不适用场景（When NOT to Use）

| 场景 | 用什么代替 |
|---|---|
| 一次性脚本，跑一次就完 | 本地直接跑 `python xxx.py` |
| 任务依赖桌面 GUI / Selenium 可视模式 | 本地 cron / launchd |
| 单次跑超过 6 小时（GitHub Actions 上限） | 自建服务器 / 云函数 |
| 任务需要 GPU / 大量内存（>16G） | 自建机器 |
| 用户只是想定期手动跑一下，没明确说"自动" | 直接告诉用户怎么本地手动跑 |
| 任务涉及桌面应用 / macOS 特有的 API | 本地 launchd |

## 前置条件检查（开始前先 verify）

```bash
# 1. git 是否可用
git --version

# 2. 是否有 SSH key（没有就要生成）
ls ~/.ssh/id_ed25519.pub 2>&1

# 3. 用户是否登录过 GitHub（看有没有 push 过）
git config --global user.name
git config --global user.email
```

任何一项缺失：先补齐（生成 SSH key、配 git 身份）再继续。

## 决策树（必须按顺序问用户，给 A/B/C 选项）

### 决策 1：发布模式

| 模式 | 描述 | 适用场景 |
|---|---|---|
| **A. 仅运行** | 任务跑完就完，不发布任何东西 | 跑完发邮件 / 推 Slack / 写数据库 |
| **B. 公开发布** | 跑完 push 到 public repo（GitHub Pages 自动展示） | 公开数据看板、博客、文档 |
| **C. 加密发布** ⭐ | private engine repo + public 加密 HTML repo + 密码访问 | 私人看板（如选股结果、个人数据），公开 URL 但需密码 |

### 决策 2：repo 结构

- 模式 A / B：**单 repo**（代码 + 数据/产物 在一起）
- 模式 C：**必须双 repo**（private engine + public 加密发布）—— 这次实战用的就是这个

### 决策 3：调度频率

常用 cron（GitHub Actions 用 UTC，要换算）：
- 「工作日每天 16:30 北京时间」→ `30 8 * * 1-5`（北京 = UTC+8，所以 16:30 → 08:30 UTC）
- 「每天早上 9 点北京」→ `0 1 * * *`
- 「每周一 10 点」→ `0 2 * * 1`
- 「每小时」→ `0 * * * *`

⚠️ **GitHub 调度不精准**：实际触发可能延迟 5-15 分钟（高峰期更久）。如果要求严格准时，提醒用户。

### 决策 4：依赖识别

让用户跑 `pip list 2>/dev/null | head -30` 或者扫描代码 import，列出 `requirements.txt`。
**关键检查**：是否有桌面/GUI 库（matplotlib 用 Agg 后端 OK，Tkinter / PyQt 不行）。

## 执行流程

按用户选定的模式走对应分支。**每一步做完都要让用户确认再下一步**，特别是涉及 GitHub 网页操作的步骤。

### 通用 Step 1：扫描原项目找坑（重要！）

```bash
# 找硬编码绝对路径
grep -rn '/Users/\|/home/' <项目路径>/*.py 2>/dev/null | head -20

# 找硬编码 token / 密码（任何看起来是 secret 的字符串）
grep -rEn "token\s*=\s*['\"][a-zA-Z0-9]{20,}|api_key\s*=\s*['\"]" <项目路径>/*.py | head

# 检查 token 处理是否用 os.getenv 兜底
grep -n "os.getenv\|os.environ" <项目路径>/*.py
```

发现的问题处理（**优先级从高到低**）：
1. **硬编码 secret（token/api key）** → 必须用 `os.getenv('XXX', '默认值')` 改造，secret 进 GitHub Secrets
2. **硬编码绝对路径** → 用 workflow 里的 symlink 解决（不动代码，见下方 workflow 模板）
3. **中文文件名 import** → 必须用 `importlib.util.spec_from_file_location()`（不能 `import 中文模块名`）

### 通用 Step 2：本地准备 engine 目录

```bash
mkdir -p ~/<project-name>-engine && cd ~/<project-name>-engine
mkdir -p .github/workflows

# 拷贝代码（不要数据 cache、html、xlsx 之类）
cp <源项目>/*.py .

# 写 requirements.txt（基于 Step 1 扫描结果）
# 写 .gitignore（排除 cache、产物、本地密码文件）
# 写 workflow yaml（从 references/ 选模板）
```

参考模板：
- 模式 A：`references/workflow-simple.yml`
- 模式 B：`references/workflow-publish.yml`
- 模式 C：`references/workflow-encrypted-publish.yml` + `references/encrypt-html.py`
- `.gitignore` 标准：`references/gitignore-template`

### 通用 Step 3：让用户在 GitHub 网页建 repo

**不要让 Claude 通过 API 建** —— 用户用网页建更直观且无需配 PAT。

引导用户：
1. 访问 https://github.com/new
2. 模式 A/B：**Public**（B 才能用免费 Pages）
3. 模式 C：先建 `<name>-engine` private repo，再建 `<name>` public repo
4. ⚠️ **不要勾选** Add README/.gitignore/license（必须空 repo）

### 通用 Step 4：本地推送 engine

```bash
cd ~/<project-name>-engine
git init -b main
git remote add origin git@github.com:<user>/<repo>.git
git add -A
git commit -m "init"
git push -u origin main
```

### 模式 C 特定 Step：deploy key + secrets

**4a. 生成 deploy key 并绑定 public repo**：
```bash
ssh-keygen -t ed25519 -C "<name>-deploy@github" -f ~/.ssh/<name>_deploy -N ""
cat ~/.ssh/<name>_deploy.pub | pbcopy   # 公钥已在剪贴板
```
让用户：访问 `https://github.com/<user>/<public-repo>/settings/keys/new` → 标题随便 → 粘贴公钥 → ⚠️ **必须勾 "Allow write access"** → Add key

**4b. 把私钥 base64 给用户加到 secret**：
```bash
base64 -i ~/.ssh/<name>_deploy | tr -d '\n' && echo
```
让用户：访问 `https://github.com/<user>/<engine-repo>/settings/secrets/actions/new` → Name: `DEPLOY_KEY` → Value: 粘贴**单行 base64** → Add secret

⚠️ **不要让用户直接粘 PEM 私钥** —— 在 GitHub Secret UI 里 PEM 的多行格式经常被损坏，导致 `error in libcrypto`。**永远用 base64 单行**。

**4c. 加其他 secrets**：
- `TS_TOKEN` 或类似 API token（如果项目要用）
- `<NAME>_PASSWORD`（加密发布用的密码）
- 其他业务相关 secrets

### 通用 Step 5：触发首次运行 + 调试

让用户访问 `https://github.com/<user>/<engine-repo>/actions/workflows/<file>.yml` → **Run workflow** 按钮（蓝色下拉，不是 Re-run）→ Run workflow（绿色）

**关键：等待用户告知结果，准备调试。**

### 通用 Step 6：模式 B/C 启用 Pages

让用户访问 `https://github.com/<user>/<public-repo>/settings/pages`：
- Source: **Deploy from a branch**
- Branch: **main** + **/ (root)** → Save
- 等 1-2 分钟首次部署

## Common Rationalizations（坑表）

Agent 容易找的偷懒借口 vs 现实：

| Agent 可能想 | 现实 |
|---|---|
| 「PEM 私钥应该能直接粘进 secret，base64 太麻烦」 | **不行**。GitHub Secret UI 处理多行私钥经常出问题，必须用 base64 单行。这是实战验证的坑。 |
| 「硬编码绝对路径在 Linux runner 上肯定会失败，要改代码」 | 不一定要改代码。workflow 里 `sudo ln -sf "$PWD" /Users/xxx/yyy` 一行解决，最小侵入。改代码风险更高。 |
| 「Re-run failed jobs 应该能拉到新代码」 | **不能**。Re-run 用的是失败 run 当时的 commit。改完代码 push 后必须用 **Run workflow** 触发新 run。 |
| 「让用户看 README 自己配就行」 | 用户大概率不会配 secrets / deploy key 这些 GitHub 网页操作。**必须一步一步引导**，每一步等用户确认。 |
| 「不用问发布模式，默认仅运行」 | 错。必须问清楚 A/B/C，否则方向走偏后回头成本极高（建错 repo、配错 key）。 |
| 「workflow 写完直接推上去就行」 | 推之前看 workflow 里所有 path、branch、repo URL 是否填对。push 后报错排查成本高。 |

## Red Flags（看到立刻停下纠正）

- 🚩 用户的 secret 里出现 `-----BEGIN OPENSSH PRIVATE KEY-----` 多行格式 → 转 base64 重粘
- 🚩 错误信息含 `error in libcrypto` 或 `Permission denied (publickey)` → 99% 是 deploy key 格式 / 写权限问题
- 🚩 错误信息含 `base64: invalid input` → secret 里不是 base64（用户还没 update，或粘了垃圾字符）
- 🚩 Generate dashboard 步骤瞬间失败（< 5s）→ 不是 tushare 问题，多半是 import / 路径错误，看 traceback 上面几行

## 已知陷阱（实战验证过，写代码 / workflow 时必须考虑）

1. **代码硬编码绝对路径**：用 workflow 的 `sudo mkdir -p /原路径前缀 && sudo ln -sf "$PWD" /原路径前缀/项目名` symlink 解决，不动代码。
2. **API token 必须用 `os.getenv('TS_TOKEN', '默认值兜底')`**：`os.getenv` 优先环境变量，本地有兜底也能跑。
3. **SSH 私钥粘 secret 必用 base64**：直接粘 PEM 经常 `error in libcrypto`。workflow 里自动判断 raw PEM vs base64 兼容两种（见模板）。
4. **Re-run vs Run workflow**：改 workflow 后，旧 run 的 Re-run 用旧 commit 不会生效。必须 **Run workflow** 触发新 run。
5. **Deploy key 必须勾 Allow write access**：默认是只读，push 会报 Permission denied。
6. **中文文件名 import**：`importlib.util.spec_from_file_location('mod', '/path/to/中文.py')` + `spec.loader.exec_module(mod)`。
7. **macOS 没装 cryptography**：`pip install --user cryptography`（如果模式 C 要用加密）。
8. **GitHub 调度延迟**：cron 触发延迟 5-15 分钟正常，高峰期可能更久。要求精准的告诉用户。
9. **同一时间点全球 cron 拥堵**：避开整点（`30 8 * * *` 比 `0 8 * * *` 更准时）。
10. **Pages 首次部署需 1-2 分钟**：first push 后访问 404 是正常的，等。
11. **public repo 名 = pages URL 路径**：`<user>.github.io/<repo>`，repo 名定下后 URL 就定了，谨慎选名。
12. **Engine 推送 != 触发 Actions**：workflow 只在 schedule 或 workflow_dispatch 触发，push 不触发（除非 workflow 配了 `on: push`）。

## Verification（退出检查清单）

宣布完成前必须满足：

- [ ] **Step 1 项目扫描已做**：硬编码 secret 全部改成 `os.getenv`，硬编码绝对路径已识别（symlink 或改代码）
- [ ] **本地 engine 目录已建** + `git push origin main` 成功
- [ ] **GitHub 上 repo 可访问**（让用户去网页 verify 一下）
- [ ] **所有 secrets 已配** + DEPLOY_KEY 是 base64 格式（如果模式 C）
- [ ] **首次 workflow_dispatch 跑成功**（绿色对号）—— 不能跳过这一步
- [ ] **模式 B/C：Pages 已启用 + URL 可访问**（密码框出现 / 内容显示）
- [ ] **告诉用户怎么改代码 / 改密码 / 改时间**：指明哪个文件改、push 哪个 repo
- [ ] **告诉用户 cron 触发延迟可能 5-15 分钟**

## 输出规范

最后给用户一份「资产 + 管理」清单，格式如下（基于实战经验）：

```markdown
## 你现在拥有的
| 资产 | 用途 |
|---|---|
| https://github.com/<user>/<engine-repo> | private，存代码 + Actions |
| https://github.com/<user>/<public-repo> | public，存 [产物类型] |
| https://<user>.github.io/<public-repo>/ | 访问 URL [+ 密码（如有）] |
| ~/<engine-local>/ | 本地 engine 镜像 |

## 自动化运行时间表
- 调度：cron `<expr>` = <人话时间>
- 跑约 X 分钟
- 完成后 ~ HH:MM 数据更新

## 怎么管理
- 改代码：在 ~/<engine-local>/ 修改 → git add/commit/push
- 改 secret：GitHub repo → Settings → Secrets and variables → Actions
- 改时间：编辑 .github/workflows/<file>.yml 的 cron 行 → push
- 手动触发：Actions 页 → Run workflow
```

## References

| 文件 | 用途 |
|---|---|
| `references/workflow-simple.yml` | 模式 A：仅运行（无发布）的 workflow 模板 |
| `references/workflow-publish.yml` | 模式 B：单 repo 直推产物的 workflow 模板 |
| `references/workflow-encrypted-publish.yml` | 模式 C：双 repo 加密发布的 workflow 模板 |
| `references/encrypt-html.py` | 模式 C 配套的加密脚本（PBKDF2 + AES-GCM-256，纯前端 Web Crypto 解密） |
| `references/gitignore-template` | 标准 `.gitignore`（排除 cache / 产物 / 本地密码文件） |
| `references/troubleshooting.md` | 常见错误对照表（exit code 128 / libcrypto / base64 invalid / 等） |
