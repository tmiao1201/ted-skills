---
name: kendiag
description: >
  专业图表生成技能：根据需求自动选择合适的图表类型，默认输出 HTML（PNG 按需）。
  覆盖 30 种图表：结构图（流程图、泳道图、时序图、架构图、状态图、ER图、类图、思维导图、甘特图等）、
  统计图（柱状图、折线图、饼图、雷达图、热力图、桑基图、散点图等）、
  竞争分析图（象限定位、BCG矩阵、波特五力、价值链）。
  统一工具：HTML/SVG + 内联 JS 布局计算。ER/类图使用 ELKjs 布局引擎。
  所有图表遵循统一的设计规范（配色/字体/组件/间距），风格现代简洁。
  支持三种输出：PNG（默认）、HTML（富文档嵌入）、DSL（Mermaid/Graphviz 文本，嵌入 MD 文档）。
  三 Theme：默认（Tailwind 风格）+ Professional（Dual-Blue 企业级）+ Blueprint（工程蓝图，含 Light/Dark 变体）。
  Annotation 层：Callout 标注、Data Badge、关键路径高亮、趋势指示器、峰谷标记。
  与 kendresearch/kenwar/kencourse/wxcomanaly 无缝协同，支持批量渲染。
  触发词：画图、画一个、生成图表、流程图、架构图、时序图、柱状图、对比图、关系图、五力、象限、蓝图、blueprint。
  即使用户没有说"画图"，只要需求中涉及可视化展示（流程、架构、数据对比、关系），都应触发此技能。
  被 deep-research 等其他技能调用时，同样遵循本规范生成图表。
---

# 画图技能（Diagram Skill）

> 用自然语言描述需求，自动生成专业的 PNG 图表，直接嵌入 Markdown 文档。

---

## 第一步：理解需求，选择图表类型

收到画图需求后，判断：
1. **画什么** — 需要展示的信息类型（流程？架构？数据对比？关系？）
2. **哪种图表** — 根据信息类型匹配最合适的图表
3. **用什么布局** — 根据图表类型选择布局策略

### Mermaid / Graphviz 标记语言转换

当发现 Markdown 中有 ` ```mermaid ` 或 ` ```dot ` 代码块时：

1. **解读**图结构（节点、边、标签、类型、分组等）
2. **映射**到对应的图表类型模板数据结构
3. **渲染**为设计规范统一的 PNG
4. **替换**原始文本块为图片引用

映射规则：

| 源格式 | 关键字/语法 | 映射目标 |
|--------|-----------|---------|
| Mermaid `graph TD` / `flowchart` | 节点 + 箭头 | flowchart 模板 |
| Mermaid `sequenceDiagram` | 参与者 + 消息 | sequence 模板 |
| Mermaid `classDiagram` | 类 + 关系 | class 模板 |
| Mermaid `stateDiagram` | 状态 + 转换 | state 模板 |
| Mermaid `erDiagram` | 实体 + 关系 | er 模板 |
| Mermaid `gantt` | 任务 + 日期 | gantt 模板 |
| Mermaid `pie` | 标签 + 数值 | pie 模板 |
| Mermaid `journey` | 阶段 + 评分 | journey 模板 |
| DOT `digraph` | 有向图 | flowchart / state / class（按结构判断） |
| DOT `graph` | 无向图 | er / network（按结构判断） |

> **注意**：不是调用 Mermaid/Graphviz 工具渲染，而是 Claude 理解标记语言描述的图结构，转成我们的模板数据，用统一设计规范渲染。这样所有图表风格一致。

### 图表类型速查

| 要展示什么 | 图表类型 | 布局策略 | 专属规范 |
|-----------|---------|---------|---------|
| 工作流程、决策逻辑（单路径） | 流程图（线性） | 手动布局 | `references/diagrams/flowchart.md` |
| 多源汇聚、资源流转、关系图 | 流程图（DAG） | **ELKjs** | `references/diagrams/flowchart.md` |
| 多角色协作流程 | 泳道图 | 手动网格 | `references/diagrams/swimlane.md` |
| API 调用、消息交互 | 时序图 | 自定义顺序堆叠 | `references/diagrams/sequence.md` |
| 系统分层、技术栈 | 架构图 | 手动层堆叠 | `references/diagrams/architecture.md` |
| 数据库表结构 | ER 图 | **ELKjs** | `references/diagrams/er.md` |
| 面向对象设计 | 类图 | **ELKjs** | `references/diagrams/class.md` |
| 状态迁移 | 状态图 | ELKjs | `references/diagrams/state.md` |
| 网络拓扑 | 网络图 | 手动分层 | `references/diagrams/network.md` |
| 选型决策 | 决策树 | 树形布局 | `references/diagrams/decision-tree.md` |
| 数据管道 | 数据流图 | 手动分层 | `references/diagrams/dataflow.md` |
| C4 系统视图 | C4 图 | 手动分层 | `references/diagrams/c4.md` |
| 知识结构 | 思维导图 | 双侧树形 | `references/diagrams/mindmap.md` |
| 项目排期 | 甘特图 | 日期轴网格 | `references/diagrams/gantt.md` |
| 发展历程 | 时间线 | 纵向列表 | `references/diagrams/timeline.md` |
| 组织架构 | 组织结构图 | 树形 | `references/diagrams/orgchart.md` |
| 优劣势分析 | SWOT 图 | 卡片四象限 | `references/diagrams/swot.md` |
| 根因分析 | 鱼骨图 | 鱼骨骨架 | `references/diagrams/fishbone.md` |
| 集合关系 | 文氏图 | 圆形交叠 | `references/diagrams/venn.md` |
| 用户体验 | 旅程图 | 卡片横向 | `references/diagrams/journey.md` |
| 离散对比 | 柱状图 | 笛卡尔坐标 | `references/diagrams/bar-chart.md` |
| 趋势变化 | 折线图 | 笛卡尔坐标 | `references/diagrams/line-chart.md` |
| 占比构成 | 饼图 | 径向 | `references/diagrams/pie-chart.md` |
| 多维评估 | 雷达图 | 径向 | `references/diagrams/radar-chart.md` |
| 矩阵数据 | 热力图 | 网格 | `references/diagrams/heatmap.md` |
| 流量路径 | 桑基图 | 流带分层 | `references/diagrams/sankey.md` |
| 分布关系 | 散点图 | 笛卡尔坐标 | `references/diagrams/scatter.md` |
| 竞争定位 | 象限图 | 笛卡尔 + 气泡 | `references/diagrams/quadrant.md` |
| 业务组合 | BCG 矩阵 | 笛卡尔 + 气泡 | `references/diagrams/bcg-matrix.md` |
| 价值创造 | 价值链图 | 箭头横向 | `references/diagrams/value-chain.md` |
| 行业竞争 | 五力模型 | 中心辐射 | `references/diagrams/five-forces.md` |

---

## 第二步：读取规范，生成图表

### 2.1 规范体系

- **公共规范** `references/design-system.md` — 配色、字体、组件、间距
- **公共工具** `references/diagram-utils.md` — SVG 工具函数、文字测量、碰撞检测
- **专属规范** `references/diagrams/<type>.md` — 每种图表的数据结构、布局规则、渲染细节

### 2.2 布局策略

图表布局分两种：

**ELKjs 自动布局**（ER图、类图、状态图）：
- 引用 `lib/elk.bundled.js`
- 定义 ELK 图结构（nodes + edges）
- `elk.layout(graph).then(result => { /* 渲染 */ })`
- 注意：ELKjs 是异步的，所有渲染代码放在 `.then()` 回调里

**手动布局**（流程图、泳道图、架构图、时序图等）：
- 根据图表类型的领域规则计算坐标
- 流程图：主路径向下，"否"分支向右
- 泳道图：列 × 行网格，泳道固定行序
- 架构图：预定义层级从上到下堆叠
- 时序图：参与者横排等距，消息纵向堆叠

### 2.3 生成流程

```
1. 读取专属规范 → 了解数据结构和布局规则
2. 定义数据（nodes/edges/steps/tables 等）
3. 计算布局坐标（ELKjs 或手动）
4. 渲染 SVG（节点 → 连线 → 标签，按层级顺序）
5. 写入 HTML 文件（含内联 JS + CSS）
6. 启动 HTTP 服务 → Playwright 截图 → PNG
```

### 2.4 HTML 模板结构

所有模板遵循统一结构：

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: -apple-system, system-ui, 'PingFang SC', sans-serif;
    background: #ffffff;
    padding: 24px;
    display: inline-block;  /* 关键：画布收缩包裹内容 */
  }
</style>
<!-- ELKjs 仅在 ER/类图/状态图中引入 -->
<script src="lib/elk.bundled.js"></script>
</head>
<body>
<svg id="canvas"></svg>
<script>
(function() {
  // 1. 数据定义（title, subtitle, nodes, edges 等）
  // 2. 主题定义（colors, fonts, spacing）
  // 3. 工具函数（el, measureText）
  // 4. 布局计算（ELKjs 或手动）
  // 5. 渲染（背景层 → 连线层 → 节点层 → 标签层）
})();
</script>
</body>
</html>
```

### 2.5 标题规范

- 位置：左上角（x=0, y=18）
- 标题：16px bold，颜色 `#1a1a2e`
- 副标题：12px，颜色 `#888888`，y=36
- 标题区高度：52px

---

## 第三步：输出规范

### 3.1 文件格式

**HTML（默认）** — 自包含单文件，浏览器直接打开：
- 所有 CSS/JS 内联，无外部依赖
- 矢量 SVG 无损缩放，文字可选中/搜索
- 适用场景：日常查看、嵌入报告、二次编辑
- **除非用户明确要求 PNG，否则只输出 HTML**

**PNG（按需）** — 用户明确说"生成 PNG"、"要图片"、"截图"时才额外生成：
- 背景：白色 `#FFFFFF`
- 四周 padding：至少 24px
- 缩放：原生设备 DPI（Retina 设备自动输出 2x 清晰图）
- 通过 `npx playwright screenshot --full-page` 从 HTML 截图

**DSL（可选）** — 用于嵌入 Markdown 文档，文本可 diff、可版本控制：
- 结构图 + 部分统计图支持 Mermaid DSL 输出
- 输出为 Mermaid 语法的纯文本
- 适用场景：MD 文档配图不想维护 PNG 文件、需要 preview-md 实时渲染、GitHub/GitLab 原生渲染
- 生成方式：直接输出文本，用户复制到 MD 文件的代码块中

DSL 选择规则：

| 图表类型 | DSL | 代码块标记 |
|---------|-----|----------|
| flowchart / sequence / class / state / er | Mermaid | ` ```mermaid ` |
| gantt / mindmap / timeline / c4 / sankey / journey | Mermaid | ` ```mermaid ` |
| architecture / swimlane / network / dataflow / orgchart / decision-tree | Mermaid（flowchart + subgraph） | ` ```mermaid ` |
| bar / line（柱状图、折线图） | Mermaid（xychart-beta） | ` ```mermaid ` |
| pie（饼图） | Mermaid | ` ```mermaid ` |
| radar / heatmap / scatter / funnel / waterfall 等 | **不支持 DSL** | 继续用 PNG |
| quadrant（竞争定位象限） | Mermaid（quadrantChart） | ` ```mermaid ` |
| five-forces / value-chain / bcg-matrix | **不支持 DSL** | 继续用 PNG |
| gitGraph / block | **暂不支持** | 后续按需开放 |

DSL 输出格式示例：

```
用户：画一个用户登录的流程图，输出 mermaid

输出：
` ` `mermaid
flowchart TD
    A[用户访问登录页] --> B{已有账号?}
    B -->|是| C[输入用户名密码]
    B -->|否| D[跳转注册页]
    C --> E{验证通过?}
    E -->|是| F[跳转首页]
    E -->|否| G[提示错误]
    G --> C
` ` `
```

```
用户：画一个微服务架构图，输出 dot

输出：
` ` `dot
digraph architecture {
    rankdir=TB; compound=true;
    node [shape=box, style="rounded,filled", fontname="PingFang SC"];

    subgraph cluster_gateway {
        label="网关层"; style="dashed"; color="#94A3B8";
        nginx [label="Nginx\n负载均衡", fillcolor="#EFF6FF"];
        api_gw [label="API Gateway", fillcolor="#EFF6FF"];
    }

    subgraph cluster_services {
        label="服务层"; style="dashed"; color="#94A3B8";
        user_svc [label="用户服务", fillcolor="#F0FDF4"];
        order_svc [label="订单服务", fillcolor="#F0FDF4"];
        pay_svc [label="支付服务", fillcolor="#F0FDF4"];
    }

    subgraph cluster_data {
        label="数据层"; style="dashed"; color="#94A3B8";
        mysql [label="MySQL", fillcolor="#FEF3C7"];
        redis [label="Redis", fillcolor="#FEF3C7"];
    }

    nginx -> api_gw;
    api_gw -> user_svc; api_gw -> order_svc; api_gw -> pay_svc;
    user_svc -> mysql; order_svc -> mysql; pay_svc -> redis;
}
` ` `
```

### 3.2 截图方式（仅在需要 PNG 时）

**优先用 `npx playwright screenshot`：**

```bash
npx playwright screenshot --full-page "file:///<html路径>" <输出路径>.png
```

**备选（有 browser MCP 时）用 `browser_run_code`：**

```javascript
async (page) => {
  await page.locator('body').screenshot({
    path: '<输出路径>.png',
    type: 'png'
  });
}
```

**注意：** 默认只输出 HTML，不截图。用户说"要 PNG"、"生成图片"、"截图"时才执行截图。

### 3.3 文件命名
`<图表类型>-<描述>.html`（英文小写 + 连字符，PNG 同名 `.png`）

### 3.4 存放位置

**路径选择规则（按优先级）：**

| 条件 | 存放路径 | 示例 |
|------|----------|------|
| 用户指定了路径 | 用户指定的路径 | 用户说"放到 docs/" → `docs/` |
| 当前在 git 项目目录中 | **项目根目录** | `/Users/kenno/my-project/architecture-bom.html` |
| 被其他 skill 调用（kendresearch 等） | 调用方指定的 `assets/` 目录 | `docs/research/assets/` |
| 其他情况（home 目录、无项目） | **`~/Downloads/`** | `/Users/kenno/Downloads/flowchart-login.html` |

**判断是否在项目中：** 检查当前工作目录是否为 git 仓库（`git rev-parse --show-toplevel` 成功）。是则放项目根目录，否则放 `~/Downloads/`。

---

## 工具依赖

| 工具 | 安装方式 | 用途 |
|------|---------|------|
| Playwright | MCP 插件（已集成） | HTML → PNG 截图 |
| ELKjs | `lib/elk.bundled.js`（已内联） | ER图/类图/状态图的自动布局 |

### ELKjs 使用说明

ELKjs 仅用于**自由图布局**（节点和边的位置需要算法优化的场景）。以下图表类型**不用 ELKjs**：
- 流程图 **线性模式**（领域规则：主路径向下，否分支向右）
- 泳道图（领域规则：泳道固定行序）
- 架构图（领域规则：层级预定义）
- 时序图（领域规则：参与者横排，消息纵向）

原因：这些图表有明确的领域布局规则，ELKjs 的自动优化会打破这些规则（比如重排泳道顺序、改变分组位置）。

**例外**：流程图的 **DAG 模式**（多根节点、汇聚、非决策分支）使用 ELKjs，因为此类拓扑无法用简单的"主路径+侧分支"手动布局。详见 `references/diagrams/flowchart.md`。

### 流程图 DAG 模式注意事项

- **忠实还原拓扑**：不存在的连线绝不添加，多个独立入口不能强行归到同一根节点
- **节点类型忠实原图**：同层级/同角色的节点用相同 type。`highlight` 仅用于原图明确标注为关键/核心的节点，不要用它来区分"不同类别"——类别差异用 `process`/`external`/`datastore` 等语义类型表达

---

## 被其他 Skill 调用

> diagram skill 是 Kenno 工具链中的可视化基础设施。以下 skill 可无缝调用 diagram 生成图表。

### 调用协议

调用方只需在 prompt 中描述需要的图表，diagram skill 自动处理选型和渲染。标准调用格式：

```
[调用方 skill] 需要生成一张 [图表类型] 图表：
- 数据：[结构化数据或自然语言描述]
- 风格：default | professional（Dual-Blue）| blueprint（工程蓝图）| blueprint-dark（暗色蓝图）
- 输出：PNG（默认）| HTML | DSL
- 存放：[目标路径]
- Annotations：[可选：需要高亮的关键路径、数据标注等]
```

### 与 kendresearch 协同

| kendresearch 输出 | 自动触发的图表类型 |
|-------------------|-------------------|
| 竞争格局分析 | 五力模型、象限图、BCG 矩阵 |
| 市场规模与份额 | 柱状图、饼图（带数据标注） |
| 技术架构对比 | 架构图（多方案对比） |
| 产业链分析 | 价值链图、桑基图 |
| 时间线梳理 | 时间线图、甘特图 |
| SWOT 分析 | SWOT 图 |
| 数据趋势 | 折线图（带趋势指示器 + 峰谷标记） |

**kendresearch 调用示例：**
```
生成一张五力分析图：
- 数据：{ center: { name: '行业竞争', level: 'high' }, forces: [...] }
- 风格：professional
- 存放：docs/research/assets/five-forces-analysis.png
- Annotations：high level 的力自动标注 critical callout
```

### 与 kenwar 协同

| kenwar 阶段 | 可触发的图表 |
|-------------|-------------|
| 局势研判（kenThink） | 五力模型、SWOT |
| 情报搜集（kendresearch） | 象限图、价值链、折线趋势 |
| 战略规划 | BCG 矩阵、决策树 |
| 行动方案 | 甘特图（关键路径高亮）、泳道图 |
| 汇报输出（kenslide） | 所有统计图（Professional Theme） |

**kenwar 自动图表规则：**
- kenwar 的每个 Phase 完成后，检查是否有可视化需求
- 战略分析 → 优先使用五力/象限/BCG
- 行动方案 → 优先使用甘特/泳道/流程图
- 所有图表默认使用 Professional Theme（Dual-Blue）
- 技术架构评审场景 → 使用 Blueprint Theme（工程蓝图风格，zero-decoration）

### 与 kencourse 协同

| kencourse 内容类型 | 推荐图表 |
|-------------------|---------|
| 系统架构讲解 | 架构图、C4 图 |
| 代码流程讲解 | 流程图、时序图 |
| 数据模型讲解 | ER 图、类图 |
| 概念关系 | 思维导图、文氏图 |
| 对比分析 | 雷达图、热力图 |

**kencourse 调用规则：**
- 教学图表使用默认 theme（更亲和，非正式感）
- 每张图表需配合教学上下文，标注解释性 Callout（variant: 'info'）
- 复杂流程图自动启用关键路径高亮，引导学习者阅读顺序

### 与 wxcomanaly / wxrpt 协同

| 分析类型 | 推荐图表 |
|---------|---------|
| 竞争对手对比 | 雷达图、象限图 |
| 财务指标趋势 | 折线图（带峰谷标记 + 趋势指示器） |
| 业务结构 | 饼图、桑基图 |
| 战略定位 | BCG 矩阵、五力模型 |

**规则：** 财报相关图表强制使用 Professional Theme。

### 批量渲染

当调用方需要在一份报告中生成多张图表时：

1. **串行渲染**（默认）：逐个生成，适合 <5 张图
2. **目录约定**：所有图表统一存入调用方指定的 `assets/` 目录
3. **命名规范**：`<序号>-<图表类型>-<描述>.png`（如 `01-five-forces-industry.png`）
4. **索引输出**：渲染完成后输出 Markdown 图片引用列表，供调用方直接嵌入文档

```markdown
<!-- 自动生成的图表索引 -->
![五力分析](assets/01-five-forces-industry.png)
![竞争定位](assets/02-quadrant-positioning.png)
![业务组合](assets/03-bcg-matrix-portfolio.png)
```
