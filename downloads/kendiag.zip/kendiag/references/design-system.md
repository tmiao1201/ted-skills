# 公共设计规范

> 所有图表共享的视觉规范。可视化预览见 `docs/specs/design-system-preview.html`。

---

## 一、调色板

### 基础色（Neutral）

| 色号 | 色值 | 用途 |
|------|------|------|
| N-0 | `#FFFFFF` | 画布背景 |
| N-1 | `#F8FAFC` | 容器/卡片背景 |
| N-2 | `#F1F5F9` | 次级背景、交替行 |
| N-3 | `#E2E8F0` | 边框、分割线 |
| N-4 | `#CBD5E1` | 禁用、占位 |
| N-5 | `#94A3B8` | 连线、次级图标 |
| N-6 | `#64748B` | 次级文字、图例 |
| N-7 | `#1E293B` | 主文字 |
| N-8 | `#0F172A` | 标题文字 |

### 主题色序列（Categorical）— 8 色 × 3 级

| 序号 | 名称 | 主色 | 浅底 | 中间色 | 深色 |
|------|------|------|------|--------|------|
| C-1 | Blue | `#3B82F6` | `#EFF6FF` | `#93C5FD` | `#1E40AF` |
| C-2 | Emerald | `#10B981` | `#ECFDF5` | `#6EE7B7` | `#065F46` |
| C-3 | Amber | `#F59E0B` | `#FFFBEB` | `#FCD34D` | `#92400E` |
| C-4 | Rose | `#F43F5E` | `#FFF1F2` | `#FDA4AF` | `#9F1239` |
| C-5 | Violet | `#8B5CF6` | `#F5F3FF` | `#C4B5FD` | `#5B21B6` |
| C-6 | Cyan | `#06B6D4` | `#ECFEFF` | `#67E8F9` | `#155E75` |
| C-7 | Orange | `#F97316` | `#FFF7ED` | `#FDBA74` | `#9A3412` |
| C-8 | Slate | `#64748B` | `#F8FAFC` | `#CBD5E1` | `#334155` |

### 语义色

| 语义 | 主色 | 浅底 |
|------|------|------|
| 主要/信息 | `#3B82F6` | `#EFF6FF` |
| 成功/正面 | `#10B981` | `#ECFDF5` |
| 警告/注意 | `#F59E0B` | `#FFFBEB` |
| 错误/危险 | `#F43F5E` | `#FFF1F2` |

### 层级色（架构图分层用）

| 层级 | 背景色 | 边框色 | 标签色 |
|------|--------|--------|--------|
| L-1 | `#EFF6FF` | `#BFDBFE` | `#1E40AF` |
| L-2 | `#ECFDF5` | `#A7F3D0` | `#065F46` |
| L-3 | `#FFFBEB` | `#FDE68A` | `#92400E` |
| L-4 | `#F5F3FF` | `#C4B5FD` | `#5B21B6` |
| L-5 | `#FFF1F2` | `#FECDD3` | `#9F1239` |
| L-6 | `#ECFEFF` | `#A5F3FC` | `#155E75` |

---

## 二、字体

```
中文：PingFang SC, "Noto Sans CJK SC", "Microsoft YaHei", sans-serif
英文：Inter, -apple-system, "Segoe UI", sans-serif
等宽："JetBrains Mono", "SF Mono", "Fira Code", monospace
```

| 级别 | 字号 | 字重 | 用途 |
|------|------|------|------|
| T-1 | 16px | Bold | 图表标题 |
| T-2 | 13px | Regular | 副标题 |
| T-3 | 13px | Medium | 节点文字 |
| T-4 | 12px | Regular | 图例、辅助说明 |
| T-5 | 11px | Medium | 数据标注 |
| T-6 | 10px | Regular | 注脚 |

---

## 三、基础组件

### 节点类型

| 类型 | 形状 | 填充 | 边框 | 文字色 | 用途 |
|------|------|------|------|--------|------|
| Process | 圆角矩形 6px | C-1 浅底 `#EFF6FF` | 1.5px `#93C5FD` | `#1E293B` | 处理步骤 |
| Terminal Start | 跑道形 | 成功浅底 `#ECFDF5` | 1.5px `#6EE7B7` | `#065F46` | 开始 |
| Terminal End | 跑道形 | `#F1F5F9` | 1.5px `#CBD5E1` | `#64748B` | 结束 |
| Decision | 菱形 | 警告浅底 `#FFFBEB` | 1.5px `#FCD34D` | `#92400E` | 判断 |
| Data Store | 圆柱 | Violet 浅底 `#F5F3FF` | 1.5px `#C4B5FD` | `#5B21B6` | 数据库 |
| External | 圆角矩形 虚线 | `#F8FAFC` | 1.5px dashed `#CBD5E1` | `#64748B` | 外部系统 |
| Highlight | 圆角矩形 6px | C-1 实心 `#3B82F6` | 无 | `#FFFFFF` | 关键节点 |
| Error | 圆角矩形 6px | Rose 浅底 `#FFF1F2` | 1.5px `#FDA4AF` | `#9F1239` | 错误 |
| Success | 圆角矩形 6px | 成功浅底 `#ECFDF5` | 1.5px `#6EE7B7` | `#065F46` | 成功 |
| Note | 矩形 左边框 | `#F8FAFC` | 左 3px `#3B82F6` | `#64748B` | 注释 |
| I/O（Parallelogram） | 平行四边形 sk=12 | C-1 浅底 `#EFF6FF` | 1.5px `#93C5FD` | `#1E293B` | 输入/输出操作 |
| Document | 波浪底矩形 | C-1 浅底 `#EFF6FF` | 1.5px `#93C5FD` | `#1E293B` | 文档/报告 |
| Double Circle | 双圆同心 gap=4px | 成功浅底 `#ECFDF5` | 1.5px `#6EE7B7` | `#065F46` | 终态/子流程 |
| Trapezoid | 梯形 ins=16 | Cyan `#ECFEFF` | 1.5px `#67E8F9` | `#155E75` | 手动操作 |
| Flag | 旗帜（凹口五边形） | Orange `#FFF7ED` | 1.5px `#FDBA74` | `#9A3412` | 事件/信号 |

节点内间距：上下 `10px`，左右 `16px`。最小宽度 `120px`。

节点与容器的关系：
- 容器内的节点用**白底**（`#FFFFFF`）+ 彩色边框，与容器浅色背景形成层次
- 不要让节点填充色和容器背景色相同，否则融在一起看不出来
- 圆柱形（数据库）的绘制顺序：底部椭圆 → 矩形 body → 顶部椭圆（盖子在最上层）

### 连线类型

| 类型 | 线宽 | 颜色 | 样式 | 箭头 |
|------|------|------|------|------|
| 标准 | 1.5px | `#94A3B8` | 实线 | 实心三角 12×10 |
| 虚线 | 1.5px | `#94A3B8` | dasharray 6 3 | 实心三角 |
| 成功路径 | 2px | `#10B981` | 实线 | 实心三角 |
| 失败路径 | 2px | `#F43F5E` | 实线 | 实心三角 |
| 高亮路径 | 2px | `#3B82F6` | 实线 | 实心三角 |
| 返回/回退 | 1px | `#CBD5E1` | dasharray 4 2 | 开放箭头 |
| 组合（类图） | 1.5px | `#94A3B8` | 实线 | 起点实心菱形 |
| 聚合（类图） | 1.5px | `#94A3B8` | 实线 | 起点空心菱形 |
| 继承（类图） | 1.5px | `#94A3B8` | 实线 | 终点空心三角 |
| 实现（类图） | 1.5px | `#94A3B8` | dasharray 5 3 | 终点空心三角 |
| 依赖（类图） | 1px | `#CBD5E1` | dasharray 5 3 | 开放箭头 |
| ER Identifying | 1.5px | `#94A3B8` | 实线 | crow's foot 符号 |
| ER Non-identifying | 1.5px | `#94A3B8` | dasharray 5 3 | crow's foot 符号 |

连线规则：
- 锚点在节点边缘**中点**（上/下/左/右边的正中间），不连到角
- 转角用 **10px 圆角**（Q 贝塞尔曲线），不用直角硬转
- 连线**不能穿过**其他节点或表，必须绕开
- 标签统一放在连线**上方**，用白底 padding 避让线条
- 同一张图内所有标签位置一致（都在上方或都在下方，不混用）
- 自调用（self-call）的折线转角也要用圆角

### 容器类型

| 类型 | 背景 | 边框 | 圆角 | 标签 |
|------|------|------|------|------|
| 分组容器 | 层级色浅底 | 1px + 层级色边框 | 8px | 左上角，13px Bold |
| 泳道容器 | 交替 N-0/N-1 | 1px `#E2E8F0` | 8px | 左侧色条，14px Bold 白色 |

---

## 四、间距规范

| 位置 | 间距 |
|------|------|
| 图表四周 padding | 24px |
| 标题 → 副标题 | 4px |
| 副标题 → 内容区 | 16px |
| 内容区 → 图例 | 12px |
| 纵向步骤间距 | 36px |
| 含判断节点间距 | 48px |
| 横向节点间距 | 48px |
| 分支间距 | ≥ 60px |
| 容器 padding | 16px |
| 容器标签 → 节点 | 12px |
| 连线转角半径 | 10px |

基础单位 `4px`，所有间距必须是 4 的倍数。

---

## 五、流向选择

| 条件 | 选择 |
|------|------|
| 步骤 > 5 或有判断分支 | ↓ 纵向 |
| 线性流程 ≤ 5 步无分支 | → 横向 |
| 层级/层次关系 | ↓ 纵向 |
| 多角色协作（泳道） | → 横向 |
| 时间维度 | → 横向 |
| 时序图 | ↓ 纵向（UML 标准） |

---

## 六、输出规范

- 格式：PNG，白底，2x 缩放
- 四周 padding ≥ 24px
- 文件命名：`<图表类型>-<描述>.png`
- **画布大小必须能容纳所有内容**：节点 + 连线 + 图例 + 留白，不能截断
- 图例和最近的连线/节点之间至少留 20px 间距
- body 背景用 `#F8FAFC`（N-1），图表卡片用白底 `#FFFFFF`，形成浮起层次

---

## 七、统计图专属规范（HTML/SVG）

> 适用于柱状图、折线图、饼图、散点图、雷达图、热力图、桑基图。
> 所有统计图使用纯 HTML+CSS+SVG 实现，内联 JS 仅做坐标计算，**无外部 CDN 依赖**。

### 画布与字体

- 画布：**内容自适应**，不设固定宽高。body 不写死 width/height，由内容撑开，四周保证 24px padding
- SVG 的 width/height/viewBox 由 JS 根据内容动态计算
- 节点宽度 = 文字宽度 + 左右 padding（动态计算，非固定值）
- Playwright 截图使用 `browser_run_code` + `page.locator('body').screenshot()` 捕获实际内容区域（自动裁切、2x Retina 输出）
- 模板 CSS 必须包含 `body { display: inline-block }` 确保 body 收缩包裹内容
- SVG 画布不设最小宽度约束，完全由内容撑开
- 字体：`-apple-system, system-ui, 'PingFang SC', sans-serif`
- 背景：白色 `#FFFFFF`

### 统计图配色序列

统计图使用独立的配色序列（与结构图的 Categorical 色板不同，偏向渐变/半透明风格）：

| 序号 | 名称 | 色值 | 用途 |
|------|------|------|------|
| S-1 | Indigo | `#667eea` | 系列 1 主色 |
| S-2 | Rose | `#f5576c` | 系列 2 主色 |
| S-3 | Green | `#43e97b` | 系列 3 主色 |
| S-4 | Sky | `#4facfe` | 系列 4 主色 |
| S-5 | Orange | `#fa8231` | 系列 5 主色 |
| S-6 | Purple | `#a55eea` | 系列 6 主色 |
| S-7 | Coral | `#fc5c65` | 系列 7 主色 |
| S-8 | Mint | `#26de81` | 系列 8 主色 |

柱状图渐变色（上→下）：
- S-1: `#667eea` → `#764ba2`
- S-2: `#f093fb` → `#f5576c`
- S-3: `#4facfe` → `#00f2fe`

### 透明度规范

| 元素 | 透明度 | 说明 |
|------|--------|------|
| 折线/描边 | `0.7` | 线条和数据点 fill/stroke 保持一致 |
| 散点气泡 fill | `0.35` | 半透明效果 |
| 散点气泡 stroke | `0.5` | 略深于 fill |
| 面积渐变（上） | `0.25~0.3` | 渐变起始 |
| 面积渐变（下） | `0.02` | 渐变结束，近透明 |
| 雷达图填充 | `0.12` | 减少重叠区域混色 |
| 雷达图描边 | `0.8` | 清晰区分系列 |
| 桑基流带 | `0.35` | 渐变色 source→target |

### 饼图引线规范

- 从饼边缘径向延伸到拐点，拐点后水平延伸
- **转角**：二次贝塞尔圆弧（`Q` 命令），半径 `R=6px`
- **线末**：小圆点收尾（r=2, fill=`#d0d0d8`）
- **文字位置**：在线末圆点之后，不遮挡线条
- **防碰撞**：同侧标签按 y 排序，保证最小间距 `32px`
- 线条颜色：`#d0d0d8`，`stroke-width: 1`

### 坐标轴与网格

- 网格背景：`#f8f9fc`（或 `#fafbfe`）
- 网格线：虚线 `stroke-dasharray="4,3"`，颜色 `#e8e8ef` 或 `#f0f0f5`
- 坐标轴线：`#c0c3d0` 或 `#ddd`
- 轴标签：`12~13px`，颜色 `#666` 或 `#888`
- 轴标题：`14px bold`，颜色 `#555`

### 标题层级

| 元素 | 字号 | 字重 | 颜色 |
|------|------|------|------|
| 主标题 | 22px | Bold 700 | `#1a1a2e` |
| 副标题 | 14px | Regular | `#888` |
| 图例文字 | 14px | Regular | `#555` |

### 生成方式

1. 生成 HTML 文件（纯 HTML+CSS+SVG，内联 JS 仅做坐标/路径计算）
2. Playwright 截图为 PNG（fullPage 模式，内容自适应尺寸）

---

## 八、专业报告模式（Professional Theme）

> 用于 kendresearch、kenwar、kencourse 等输出的正式报告场景。通过 `theme: 'professional'` 切换。
> 默认 theme 不受影响——Professional 是可选叠加层。

### Dual-Blue 主色

| 名称 | 色值 | 用途 |
|------|------|------|
| Corporate Blue | `#1226AA` | 标题、主要强调、关键节点 |
| Tech Blue | `#00A0DF` | 辅助强调、连线高亮、交互元素 |
| Deep Navy | `#0A1628` | 深色背景文字 |
| Ice Blue | `#E8F4FD` | 浅底卡片、容器背景 |
| Frost | `#F0F6FF` | 次级背景 |

### Dual-Blue 扩展色阶（6 级渐变）

| 级别 | 色值 | 用途 |
|------|------|------|
| DB-100 | `#E8F4FD` | 容器浅底 |
| DB-200 | `#B8DDFB` | 边框、分割线 |
| DB-300 | `#5BB8F0` | 中间强调 |
| DB-400 | `#00A0DF` | Tech Blue 主色 |
| DB-500 | `#1226AA` | Corporate Blue 主色 |
| DB-600 | `#0C1A6E` | 深色强调 |

### Professional 节点类型

| 类型 | 填充 | 边框 | 文字色 | 备注 |
|------|------|------|--------|------|
| Primary | `#E8F4FD` | 1.5px `#1226AA` | `#0A1628` | 主流程步骤 |
| Accent | `#1226AA` | 无 | `#FFFFFF` | 关键/高亮节点 |
| Secondary | `#F0F6FF` | 1px `#B8DDFB` | `#1226AA` | 辅助步骤 |
| Decision | `#FFF8E1` | 1.5px `#F59E0B` | `#92400E` | 判断节点（保持 Amber 语义） |
| Success | `#E8F5E9` | 1.5px `#4CAF50` | `#1B5E20` | 成功状态 |
| Warning | `#FFF3E0` | 1.5px `#FF9800` | `#E65100` | 警告状态 |
| Critical | `#FFEBEE` | 1.5px `#F44336` | `#B71C1C` | 错误/风险 |

### Professional 连线

| 类型 | 线宽 | 颜色 | 说明 |
|------|------|------|------|
| 标准 | 1.5px | `#94A3B8` | 普通流转 |
| 高亮/关键路径 | 2.5px | `#00A0DF` | 关键路径，带脉冲动画可选 |
| 成功路径 | 2px | `#4CAF50` | 正向流转 |
| 风险路径 | 2px | `#F44336` | 风险/失败路径 |

### Professional 统计图配色

| 序号 | 色值 | 用途 |
|------|------|------|
| PS-1 | `#1226AA` | 系列 1（Corporate Blue） |
| PS-2 | `#00A0DF` | 系列 2（Tech Blue） |
| PS-3 | `#5BB8F0` | 系列 3（中蓝渐变） |
| PS-4 | `#F59E0B` | 系列 4（Amber 对比色） |
| PS-5 | `#10B981` | 系列 5（Emerald） |
| PS-6 | `#8B5CF6` | 系列 6（Violet） |

柱状图渐变（上→下）：
- PS-1: `#1226AA` → `#0C1A6E`
- PS-2: `#00A0DF` → `#1226AA`
- PS-3: `#5BB8F0` → `#00A0DF`

### Professional 微阴影

```css
/* 节点卡片阴影 — 比默认 theme 更精致 */
filter: drop-shadow(0 1px 3px rgba(18,38,170,0.08))
        drop-shadow(0 4px 12px rgba(18,38,170,0.04));

/* 容器阴影 */
filter: drop-shadow(0 2px 8px rgba(10,22,40,0.06));
```

### theme 对象（Professional 模式）

```javascript
var professionalTheme = {
  title: { color: '#0A1628' },
  subtitle: { color: '#64748B' },
  line: { color: '#94A3B8', width: 1.5, label: '#64748B' },

  node:      { bg: '#E8F4FD', border: '#1226AA', text: '#0A1628' },
  highlight: { bg: '#1226AA', border: '#1226AA', text: '#FFFFFF' },
  decision:  { bg: '#FFF8E1', border: '#F59E0B', text: '#92400E' },
  success:   { bg: '#E8F5E9', border: '#4CAF50', text: '#1B5E20' },
  error:     { bg: '#FFEBEE', border: '#F44336', text: '#B71C1C' },
  external:  { bg: '#F0F6FF', border: '#B8DDFB', text: '#1226AA' },
  datastore: { bg: '#F0F6FF', border: '#00A0DF', text: '#1226AA' },

  lineYes: { color: '#4CAF50', width: 2 },
  lineNo:  { color: '#F44336', width: 2 },
  lineHighlight: { color: '#00A0DF', width: 2.5 },

  series: ['#1226AA', '#00A0DF', '#5BB8F0', '#F59E0B', '#10B981', '#8B5CF6'],

  layers: [
    { bg: 'rgba(18,38,170,0.04)', border: 'rgba(18,38,170,0.12)', color: '#1226AA' },
    { bg: 'rgba(0,160,223,0.04)', border: 'rgba(0,160,223,0.12)', color: '#00A0DF' },
    { bg: 'rgba(91,184,240,0.04)', border: 'rgba(91,184,240,0.12)', color: '#5BB8F0' },
    { bg: 'rgba(245,158,11,0.04)', border: 'rgba(245,158,11,0.12)', color: '#F59E0B' },
    { bg: 'rgba(16,185,129,0.04)', border: 'rgba(16,185,129,0.12)', color: '#10B981' },
    { bg: 'rgba(139,92,246,0.04)', border: 'rgba(139,92,246,0.12)', color: '#8B5CF6' }
  ]
};
```

### 切换方式

调用方在需求中指定主题：
- `theme: 'default'` 或不指定 → 默认 Tailwind 风格
- `theme: 'professional'` 或 `style: dual-blue` → Professional Dual-Blue
- `theme: 'blueprint'` → 工程蓝图（浅色）
- `theme: 'blueprint-dark'` → 工程蓝图（暗色）

详见 `diagram-utils.md` 第七章的 `getTheme()` 工厂函数。

---

## 九、工程蓝图模式（Blueprint Theme）

> 灵感来源：[yofine/blueprinter](https://github.com/yofine/skills/blob/main/blueprinter/SKILL.md) 的 "Flat Engineering Blueprint" 设计哲学。
> 适用于技术文档、RFC、架构评审、内部 spec——追求「技术规格书」观感：零装饰、高数据墨水比、工程师友好。
> 通过 `theme: 'blueprint'`（浅色）或 `theme: 'blueprint-dark'`（暗色蓝图）切换。

### 设计铁律（6 条）

1. **NO shadows** — 禁止一切阴影（drop-shadow, box-shadow, filter shadow）
2. **NO gradients** — 禁止渐变填充（柱状图等统计图用纯色）
3. **NO glassmorphism/blur** — 禁止毛玻璃/模糊效果
4. **NO rounded buttons** — border-radius = 0（直角矩形，工程图纸标准）
5. **Monochrome base** — 单色灰度系统 + 最多 1 个语义色（红=错误）
6. **Data in monospace** — 所有数值、路径、代码、技术标签强制等宽字体

### Blueprint Light 调色板（浅色技术规格书）

| 元素 | 色值 | CSS 变量 | 说明 |
|------|------|----------|------|
| 画布背景 | `#f8fafc` | `--bp-bg` | 浅灰纸面 |
| 内容区 | `#ffffff` | `--bp-canvas` | 白色绘图区 |
| 主边框 | `#cbd5e1` | `--bp-border` | Slate-300 |
| 强调边框 | `#0f172a` | `--bp-border-strong` | 黑色，用于决策/高亮 |
| 主文字 | `#0f172a` | `--bp-text` | Slate-900 高对比 |
| 副文字 | `#64748b` | `--bp-text-sub` | Slate-500 |
| 淡文字 | `#94a3b8` | `--bp-text-muted` | Slate-400 |
| 唯一语义色 | `#dc2626` | `--bp-accent-error` | Red-600，仅限错误/危险 |
| 网格线 | `rgba(0,0,0,0.04)` | `--bp-grid` | 工程网格背景 |

### Blueprint Dark 调色板（暗色蓝图/Cyanotype）

| 元素 | 色值 | CSS 变量 | 说明 |
|------|------|----------|------|
| 画布背景 | `#0a1628` | `--bp-bg` | Deep Navy |
| 内容区 | `#0f1d32` | `--bp-canvas` | 深蓝绘图区 |
| 主边框 | `#1e3a5f` | `--bp-border` | 暗蓝描线 |
| 强调边框 | `#4a9eff` | `--bp-border-strong` | 亮蓝高亮 |
| 主文字 | `#e0f0ff` | `--bp-text` | 浅蓝白 |
| 副文字 | `#7ab8ff` | `--bp-text-sub` | 中蓝 |
| 淡文字 | `#3d6a9e` | `--bp-text-muted` | 暗蓝 |
| 唯一语义色 | `#ff5050` | `--bp-accent-error` | 亮红 |
| 网格线 | `rgba(74,158,255,0.08)` | `--bp-grid` | 蓝光网格 |

### Blueprint 字体

```
标题/标签：Inter, -apple-system, 'Helvetica Neue', sans-serif
数据/路径/代码：'JetBrains Mono', 'IBM Plex Mono', 'SF Mono', monospace
```

| 级别 | 字号 | 字重 | 附加样式 | 用途 |
|------|------|------|----------|------|
| BP-T1 | 20px | 600 | — | 图表标题 |
| BP-T2 | 11px | 500 | `text-transform: uppercase; letter-spacing: 0.05em` | 副标题 |
| BP-T3 | 12px | 500 | — | 节点文字（等宽） |
| BP-T4 | 10px | 500 | `text-transform: uppercase; letter-spacing: 0.05em` | 组件标签 |
| BP-T5 | 14px | 500 | 等宽 | 组件值 |

### Blueprint 节点类型

| 类型 | 填充（Light） | 填充（Dark） | 边框 | 文字色 | 说明 |
|------|-------------|-------------|------|--------|------|
| node | `#ffffff` | `rgba(74,158,255,0.06)` | 1px `--bp-border` | `--bp-text` | 标准步骤 |
| highlight | `--bp-text` | `#4a9eff` | 无 | 反色白 | 关键节点（反转） |
| decision | `#ffffff` | `rgba(74,158,255,0.1)` | 2px `--bp-border-strong` | `--bp-text` | 判断（加粗边框区分） |
| success | `#ffffff` | `rgba(74,158,255,0.06)` | 1px `--bp-border` | `--bp-text` | 成功（无色差，靠标签区分） |
| error | `#ffffff` | `rgba(255,80,80,0.1)` | 1.5px `--bp-accent-error` | `--bp-accent-error` | 唯一允许的语义色 |
| external | `--bp-bg` | `rgba(74,158,255,0.03)` | 1px dashed `--bp-border` | `--bp-text-sub` | 虚线=外部 |
| datastore | `--bp-bg` | `rgba(74,158,255,0.03)` | 1px `--bp-text-muted` | `--bp-text-sub` | 数据库 |

> **无色差设计原则**：Blueprint 模式用**边框粗细**、**虚线/实线**、**填充反转**来区分节点类型，而非颜色。唯一例外是 error 节点用红色——这是工程图纸的通用惯例。

### Blueprint 连线

| 类型 | Light | Dark | 线宽 | 说明 |
|------|-------|------|------|------|
| 标准 | `#cbd5e1` | `#1e3a5f` | 1px | 最细，退后 |
| 是/正向 | `#0f172a` | `#4a9eff` | 1.5px | 加粗=重要 |
| 否/负向 | `#94a3b8` | `#3d6a9e` | 1px dashed | 虚线=否定 |
| 高亮/关键路径 | `#0f172a` | `#4a9eff` | 2px | 最粗=关键 |

### Blueprint 统计图配色（灰度系列）

| Light | Dark | 用途 |
|-------|------|------|
| `#0f172a` | `#4a9eff` | 系列 1（最深/最亮） |
| `#334155` | `#e0f0ff` | 系列 2 |
| `#64748b` | `#7ab8ff` | 系列 3 |
| `#94a3b8` | `#3d6a9e` | 系列 4 |
| `#cbd5e1` | `#1e3a5f` | 系列 5 |
| `#e2e8f0` | `#152238` | 系列 6（最浅/最暗） |

> 柱状图**无渐变**——纯色填充。折线图可用灰度区分系列。饼图推荐不超过 4 扇区（灰度辨识度有限）。

### Blueprint 分层/分组色

Light 模式用灰度梯度区分层级（不用色彩）：

```javascript
layers: [
  { bg: '#ffffff', border: '#cbd5e1', color: '#0f172a' },
  { bg: '#f8fafc', border: '#e2e8f0', color: '#64748b' },
  { bg: '#f1f5f9', border: '#cbd5e1', color: '#334155' },
]
```

Dark 模式用蓝度梯度：

```javascript
layers: [
  { bg: 'rgba(74,158,255,0.04)', border: '#1e3a5f', color: '#e0f0ff' },
  { bg: 'rgba(74,158,255,0.02)', border: '#152238', color: '#7ab8ff' },
  { bg: 'rgba(30,58,95,0.3)',    border: '#1e3a5f', color: '#4a9eff' },
]
```

### Blueprint ER/类图配色

| 表类型 | 表头背景（Light） | 表头背景（Dark） | 表头文字 |
|--------|-----------------|-----------------|----------|
| core | `#0f172a` | `#4a9eff` | `#ffffff` / `#0a1628` |
| normal | `#64748b` | `#1e3a5f` | `#ffffff` / `#e0f0ff` |
| junction | `#94a3b8` | `#152238` | `#ffffff` / `#7ab8ff` |

字段行：等宽字体，类型标注用 `--bp-text-muted`。

### theme 对象（Blueprint Light）

```javascript
var blueprintTheme = {
  title: { color: '#0f172a' },
  subtitle: { color: '#64748b', transform: 'uppercase', letterSpacing: '0.05em' },
  line: { color: '#cbd5e1', width: 1, label: '#64748b' },

  node:      { bg: '#ffffff', border: '#cbd5e1', text: '#0f172a' },
  highlight: { bg: '#0f172a', border: '#0f172a', text: '#ffffff' },
  decision:  { bg: '#ffffff', border: '#0f172a', text: '#0f172a' },
  success:   { bg: '#ffffff', border: '#cbd5e1', text: '#0f172a' },
  error:     { bg: '#ffffff', border: '#dc2626', text: '#dc2626' },
  external:  { bg: '#f8fafc', border: '#cbd5e1', text: '#64748b' },
  datastore: { bg: '#f8fafc', border: '#94a3b8', text: '#64748b' },

  lineYes: { color: '#0f172a', width: 1.5 },
  lineNo:  { color: '#94a3b8', width: 1 },
  lineHighlight: { color: '#0f172a', width: 2 },

  series: ['#0f172a', '#334155', '#64748b', '#94a3b8', '#cbd5e1', '#e2e8f0'],

  layers: [
    { bg: '#ffffff', border: '#cbd5e1', color: '#0f172a' },
    { bg: '#f8fafc', border: '#e2e8f0', color: '#64748b' },
    { bg: '#f1f5f9', border: '#cbd5e1', color: '#334155' },
  ],

  laneHeaders: [
    { bg: '#0f172a', text: '#ffffff' },
    { bg: '#64748b', text: '#ffffff' },
    { bg: '#94a3b8', text: '#ffffff' },
  ],

  tableTypes: {
    core:     { headerBg: '#0f172a', headerText: '#ffffff', pkColor: '#0f172a' },
    normal:   { headerBg: '#64748b', headerText: '#ffffff', pkColor: '#64748b' },
    junction: { headerBg: '#94a3b8', headerText: '#ffffff', pkColor: '#94a3b8' },
  },
  field: { text: '#0f172a', type: '#94a3b8', fk: '#64748b', divider: '#f1f5f9' },
  table: { bg: '#ffffff', border: '#cbd5e1' },

  // 视觉约束
  shadow: 'none',
  borderRadius: 0,
  gridBackground: true,
  gridColor: 'rgba(0,0,0,0.04)',
  gridSize: 20,
  subtitleTransform: 'uppercase',
  subtitleLetterSpacing: '0.05em',
  fontMono: "'JetBrains Mono', 'IBM Plex Mono', 'SF Mono', monospace",
  fontUI: "'Inter', -apple-system, 'Helvetica Neue', sans-serif",
};
```

### theme 对象（Blueprint Dark）

```javascript
var blueprintDarkTheme = {
  title: { color: '#e0f0ff' },
  subtitle: { color: '#4a9eff', transform: 'uppercase', letterSpacing: '0.05em' },
  line: { color: '#1e3a5f', width: 1, label: '#4a9eff' },

  node:      { bg: 'rgba(74,158,255,0.06)', border: '#1e3a5f', text: '#e0f0ff' },
  highlight: { bg: '#4a9eff', border: '#4a9eff', text: '#0a1628' },
  decision:  { bg: 'rgba(74,158,255,0.1)', border: '#4a9eff', text: '#e0f0ff' },
  success:   { bg: 'rgba(74,158,255,0.06)', border: '#1e3a5f', text: '#e0f0ff' },
  error:     { bg: 'rgba(255,80,80,0.1)', border: '#ff5050', text: '#ff8080' },
  external:  { bg: 'rgba(74,158,255,0.03)', border: '#1e3a5f', text: '#7ab8ff' },
  datastore: { bg: 'rgba(74,158,255,0.03)', border: '#3d6a9e', text: '#7ab8ff' },

  lineYes: { color: '#4a9eff', width: 1.5 },
  lineNo:  { color: '#3d6a9e', width: 1 },
  lineHighlight: { color: '#4a9eff', width: 2 },

  series: ['#4a9eff', '#e0f0ff', '#7ab8ff', '#3d6a9e', '#1e3a5f', '#152238'],

  layers: [
    { bg: 'rgba(74,158,255,0.04)', border: '#1e3a5f', color: '#e0f0ff' },
    { bg: 'rgba(74,158,255,0.02)', border: '#152238', color: '#7ab8ff' },
    { bg: 'rgba(30,58,95,0.3)',    border: '#1e3a5f', color: '#4a9eff' },
  ],

  laneHeaders: [
    { bg: '#4a9eff', text: '#0a1628' },
    { bg: '#1e3a5f', text: '#e0f0ff' },
    { bg: '#3d6a9e', text: '#e0f0ff' },
  ],

  tableTypes: {
    core:     { headerBg: '#4a9eff', headerText: '#0a1628', pkColor: '#4a9eff' },
    normal:   { headerBg: '#1e3a5f', headerText: '#e0f0ff', pkColor: '#7ab8ff' },
    junction: { headerBg: '#152238', headerText: '#7ab8ff', pkColor: '#3d6a9e' },
  },
  field: { text: '#e0f0ff', type: '#3d6a9e', fk: '#7ab8ff', divider: '#1e3a5f' },
  table: { bg: '#0f1d32', border: '#1e3a5f' },

  // 视觉约束
  shadow: 'none',
  borderRadius: 0,
  gridBackground: true,
  gridColor: 'rgba(74,158,255,0.08)',
  gridSize: 20,
  subtitleTransform: 'uppercase',
  subtitleLetterSpacing: '0.05em',
  fontMono: "'JetBrains Mono', 'IBM Plex Mono', 'SF Mono', monospace",
  fontUI: "'Inter', -apple-system, 'Helvetica Neue', sans-serif",

  // Dark 模式专属：body 和画布背景
  bodyBg: '#0a1628',
  canvasBg: '#0f1d32',
  canvasBorder: '#1e3a5f',
};
```

### Blueprint HTML 模板差异

Blueprint 模式的 HTML `<style>` 部分需要额外调整：

```html
<style>
  body {
    font-family: var(--font-ui, 'Inter', sans-serif);
    /* Light: */ background: #f8fafc; padding: 40px;
    /* Dark:  */ background: #0a1628; padding: 40px;
  }
  /* 网格背景（blueprint 专属） */
  body.blueprint-grid {
    background-image:
      linear-gradient(var(--bp-grid) 1px, transparent 1px),
      linear-gradient(90deg, var(--bp-grid) 1px, transparent 1px);
    background-size: 20px 20px;
  }
</style>
```

### 适用场景

| 场景 | 推荐 |
|------|------|
| 技术文档配图（RFC、ADR、设计文档） | `blueprint` |
| 架构评审、code review 图解 | `blueprint` |
| 演讲亮点图、暗色主题展示 | `blueprint-dark` |
| 终端/CLI 工具文档 | `blueprint-dark` |
| 与 kenhtml/kencopyweb 暗色页面协同 | `blueprint-dark` |

---

## 十、Annotation 组件规范

> 数据标注、关键路径高亮、洞见强调——让图表不只是结构展示，更能传递洞见。

### 9.1 Callout 标注

用于在图表上标注关键信息、决策依据、风险提示。

| 属性 | 规范 |
|------|------|
| 形状 | 圆角矩形 6px + 三角指向箭头 |
| 背景 | `#FFFBEB`（默认）或语义色浅底 |
| 边框 | 1px `#FCD34D`（默认）或语义色中间色 |
| 文字 | 11px Medium，颜色 `#92400E`（默认）或语义深色 |
| 最大宽度 | 200px，超出自动换行 |
| 连接线 | 1px 虚线，从三角尖端到目标元素 |
| z-index | 最高层——在节点层之上 |

**语义变体：**

| 变体 | 背景 | 边框 | 文字 | 图标前缀 |
|------|------|------|------|----------|
| info | `#EFF6FF` | `#93C5FD` | `#1E40AF` | ℹ |
| success | `#ECFDF5` | `#6EE7B7` | `#065F46` | ✓ |
| warning | `#FFFBEB` | `#FCD34D` | `#92400E` | ⚠ |
| critical | `#FFF1F2` | `#FDA4AF` | `#9F1239` | ✕ |
| insight | `#F5F3FF` | `#C4B5FD` | `#5B21B6` | ★ |

### 9.2 Data Badge 数据标签

用于在节点上附加数值、百分比、状态指标。

| 属性 | 规范 |
|------|------|
| 形状 | 药丸形（全圆角） |
| 大小 | 高 20px，宽度自适应（最小 36px） |
| 位置 | 节点右上角（offset: -8px, -8px） |
| 文字 | 10px Bold，白色 |
| 背景 | 语义色实心（info=`#3B82F6`，success=`#10B981`，warning=`#F59E0B`，critical=`#F43F5E`） |

**用途示例：**
- 流程图节点上标注耗时：`3.2s`
- 架构图组件上标注 QPS：`10K/s`
- 甘特图任务上标注完成度：`80%`

### 9.3 关键路径高亮 (Critical Path)

用于流程图、甘特图、数据流图中标识关键路径。

| 属性 | 规范 |
|------|------|
| 连线样式 | 2.5px 实线，颜色 `#00A0DF`（Professional）或 `#3B82F6`（默认） |
| 节点边框 | 加粗到 2.5px，颜色同连线 |
| 节点阴影 | 增加 `drop-shadow(0 0 8px rgba(主色, 0.2))` 光晕 |
| 标签 | 路径上方显示累计值（如总工期、总延迟） |
| 非关键路径 | 自动降低透明度到 0.4，突出对比 |

### 9.4 趋势指示器

用于统计图中标注趋势方向和变化幅度。

| 元素 | 规范 |
|------|------|
| 上升箭头 | `▲` 或 SVG 上三角，颜色 `#10B981` |
| 下降箭头 | `▼` 或 SVG 下三角，颜色 `#F43F5E` |
| 持平 | `━` 横线，颜色 `#94A3B8` |
| 变化值 | 紧跟箭头，11px Bold，颜色与箭头同色 |
| 位置 | 数据点上方或柱顶上方，间距 6px |

### 9.5 峰值/谷值标记

用于折线图、柱状图标注最大最小值。

| 属性 | 规范 |
|------|------|
| 峰值标记 | 空心圆 r=5px + 数值标签，颜色 `#F43F5E` |
| 谷值标记 | 空心圆 r=5px + 数值标签，颜色 `#3B82F6` |
| 连接线 | 1px 虚线，从标记到数据点 |
| 标签 | 11px Medium，带白底 padding 4px 8px |

### 9.6 决策节点强调

用于决策树、流程图中突出关键决策点。

| 属性 | 规范 |
|------|------|
| 菱形加大 | 决策节点尺寸 ×1.15 |
| 脉冲阴影 | 可选 CSS animation，`box-shadow` 呼吸效果（仅 HTML 输出） |
| 分支标注 | "是/否" 标签加大到 12px Bold，颜色与分支线同色 |
| 概率标注 | 分支线旁可附加概率值（如 "70%"），10px，灰色 |
