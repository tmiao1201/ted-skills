# 波特五力模型图规范（Porter's Five Forces）

> 工具：HTML/SVG · Playwright 截图

---

## 适用场景

- 行业竞争态势分析
- 新市场进入可行性评估
- 战略规划中的外部环境分析
- kendresearch / kenwar 竞争分析输出

---

## 数据结构

```javascript
var data = {
  title: '波特五力分析',
  subtitle: '行业竞争态势',
  center: {
    name: '行业内竞争',
    level: 'high',        // 'low'|'medium'|'high'
    factors: ['价格战激烈', '产品同质化', '退出壁垒高']
  },
  forces: [
    {
      position: 'top',
      name: '新进入者威胁',
      level: 'medium',
      factors: ['资本门槛中等', '品牌忠诚度高', '规模经济显著']
    },
    {
      position: 'bottom',
      name: '替代品威胁',
      level: 'low',
      factors: ['替代品少', '转换成本高']
    },
    {
      position: 'left',
      name: '供应商议价能力',
      level: 'medium',
      factors: ['供应商集中', '原料差异化']
    },
    {
      position: 'right',
      name: '买方议价能力',
      level: 'high',
      factors: ['买方集中度高', '信息透明', '转换成本低']
    }
  ]
};
```

---

## 布局规则

1. **中心节点**：圆角矩形，位于画布正中央，宽 200px，高 120px
   - 颜色按 level 映射：low=Emerald, medium=Amber, high=Rose
   - 文字：名称 14px Bold + 等级标签 11px
2. **四个外力节点**：分布在上/下/左/右四个方位
   - 距中心 140px
   - 圆角矩形 180×100px
   - 颜色同样按 level 映射
3. **连接箭头**：从外力节点指向中心节点
   - 双向粗箭头（表示力的方向）
   - 线宽：2px（low）/ 3px（medium）/ 4px（high）
   - 颜色：与对应力的 level 色相同
4. **因素列表**：在每个节点下方/旁边，以小字列出关键因素
   - 10px Regular，灰色 `#64748B`
   - 每行一个因素，bullet 前缀
5. **力度标签**：每个力的 level 用色块 badge 标注（LOW/MED/HIGH）

---

## level 颜色映射

| Level | 节点背景 | 节点边框 | 箭头颜色 | Badge |
|-------|----------|----------|----------|-------|
| low | `#ECFDF5` | `#6EE7B7` | `#10B981` | 绿色 |
| medium | `#FFFBEB` | `#FCD34D` | `#F59E0B` | 黄色 |
| high | `#FFF1F2` | `#FDA4AF` | `#F43F5E` | 红色 |

---

## Annotation 支持

- 每个力自动附加 Data Badge 显示 level
- `level: 'high'` 的力自动添加 Callout（variant: 'critical'）
- 中心节点可附加综合评分 badge

---

## 模板

`templates/html/five-forces.html`（待创建）

---

## 生成方式

1. 生成 HTML 文件（纯 HTML+CSS+SVG，无外部依赖）
2. Playwright 截图为 PNG
