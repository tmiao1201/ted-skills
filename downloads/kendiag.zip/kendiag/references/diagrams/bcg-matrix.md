# BCG 矩阵规范（BCG Matrix / Growth-Share Matrix）

> 工具：HTML/SVG · Playwright 截图

---

## 适用场景

- 业务组合分析（产品线 / 事业部 / 投资组合）
- 资源配置决策
- kenwar 战略分析输出

---

## 数据结构

```javascript
var data = {
  title: 'BCG 矩阵',
  subtitle: '业务组合分析',
  xAxis: { label: '相对市场份额', high: '高', low: '低' },
  yAxis: { label: '市场增长率', high: '高', low: '低' },
  quadrants: [
    { name: '明星 ★', position: 'top-left', color: '#F59E0B', icon: '★',
      strategy: '加大投入，维持领先' },
    { name: '问号 ?', position: 'top-right', color: '#8B5CF6', icon: '?',
      strategy: '选择性投资或退出' },
    { name: '现金牛 $', position: 'bottom-left', color: '#10B981', icon: '$',
      strategy: '收割利润，控制投入' },
    { name: '瘦狗 ×', position: 'bottom-right', color: '#94A3B8', icon: '×',
      strategy: '剥离或关闭' }
  ],
  items: [
    { name: '产品线A', x: 0.7, y: 0.8, revenue: 500, trend: 'up' },
    { name: '产品线B', x: 0.3, y: 0.6, revenue: 200, trend: 'down' },
    { name: '产品线C', x: 0.8, y: 0.2, revenue: 800, trend: 'flat' }
    // x: 相对市场份额 (0-1, 越大表示份额越高)
    // y: 市场增长率 (0-1, 越大表示增长越快)
    // revenue: 映射为气泡大小
    // trend: 趋势箭头 ('up'|'down'|'flat')
  ]
};
```

---

## 布局规则

1. **与 quadrant.md 共享基础布局**，但有 BCG 特化：
   - 坐标轴方向：x 轴从右到左（高→低，市场份额），y 轴从下到上（低→高，增长率）
   - 这是 BCG 标准：左上=明星（高份额高增长），右下=瘦狗
2. **象限背景**：使用各象限对应的极淡色（opacity 0.06）
3. **象限标签**：名称 + icon + 策略描述
   - 名称：16px Bold，象限色
   - Icon：22px，象限色
   - 策略：10px Regular，`#64748B`，名称下方
4. **气泡**：圆形，大小映射 revenue（面积正比，最小 r=15，最大 r=50）
   - 填充：所在象限的颜色，opacity 0.5
   - 边框：同色，opacity 0.8
   - 标签：气泡内部或下方 8px
5. **趋势箭头**：气泡右上角小箭头（使用 `addTrendIndicator`）

---

## 与 Quadrant 的区别

| 维度 | Quadrant（通用） | BCG（特化） |
|------|-----------------|------------|
| 坐标轴 | 自由定义 | 固定：份额（右→左） × 增长率（下→上） |
| 象限含义 | 用户自定义 | 固定：明星/问号/现金牛/瘦狗 |
| 策略标注 | 无 | 每象限附带策略建议 |
| 气泡含义 | 可选第三维 | 固定映射营收/规模 |

---

## Annotation 支持

- 趋势箭头：使用 `addTrendIndicator`
- 气泡标注：revenue 用 Data Badge
- 象限策略：自动附加在象限标签下方

---

## 模板

`templates/html/bcg-matrix.html`（待创建）

---

## 生成方式

1. 生成 HTML 文件（纯 HTML+CSS+SVG，无外部依赖）
2. Playwright 截图为 PNG
