# 价值链图规范（Value Chain）

> 工具：HTML/SVG · Playwright 截图

---

## 适用场景

- 波特价值链分析（主要活动 + 支持活动）
- 企业内部价值创造流程
- 供应链/产业链分析
- 利润池分析

---

## 数据结构

```javascript
var data = {
  title: '价值链分析',
  subtitle: 'Porter Value Chain Model',
  // 主要活动（横向箭头形，从左到右）
  primary: [
    { name: '入站物流', desc: '原材料采购与仓储', value: '12%', status: 'normal' },
    { name: '生产运营', desc: '制造与组装', value: '25%', status: 'highlight' },
    { name: '出站物流', desc: '成品配送', value: '8%', status: 'normal' },
    { name: '市场与销售', desc: '营销、定价、渠道', value: '20%', status: 'warning' },
    { name: '服务', desc: '售后、维修、培训', value: '10%', status: 'normal' }
  ],
  // 支持活动（横向条带，叠在主要活动上方）
  support: [
    { name: '企业基础设施', desc: '管理、财务、法务、战略规划' },
    { name: '人力资源管理', desc: '招聘、培训、薪酬' },
    { name: '技术开发', desc: 'R&D、流程改进、IT' },
    { name: '采购', desc: '供应商管理、谈判' }
  ],
  // 利润标注（最右侧）
  margin: { label: '利润', value: '25%' }
};
```

---

## 布局规则

1. **整体形状**：经典"人字形"——主要活动为 5 个箭头形色块横向排列，右端汇聚成箭头尖
2. **主要活动**：每个活动是梯形/箭头形色块，从左到右依次排列
   - 宽度均等（或按 value 加权）
   - 高度：120px
   - 间距：2px（紧密排列，形成连续流）
   - 填充：C-1 浅底（默认）、highlight 用 C-1 主色、warning 用 Amber 浅底
3. **支持活动**：4 个横向条带叠在主要活动上方
   - 高度：40px each
   - 间距：2px
   - 填充：交替使用 N-1/N-2
   - 跨越所有主要活动的宽度
4. **利润区**：最右侧三角形/箭头尖端区域，Emerald 填充
5. **标签**：活动名称 13px Bold 居中，描述 11px Regular 换行，value 用 Data Badge

---

## Annotation 支持

- `status: 'highlight'` 的活动自动高亮 + 添加 Callout
- `value` 字段在色块内用 Data Badge 展示（variant 按数值大小映射颜色）
- 支持在活动间添加趋势箭头标注改进方向

---

## 模板

`templates/html/value-chain.html`（待创建）

---

## 生成方式

1. 生成 HTML 文件（纯 HTML+CSS+SVG，无外部依赖）
2. Playwright 截图为 PNG
