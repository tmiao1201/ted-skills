# 甘特图规范（Gantt Chart）

> 工具：HTML/SVG · Playwright 截图

---

## 适用场景

- 项目开发排期、迭代计划、里程碑跟踪

---

## 布局规则

1. 任务按 section 分组（需求、开发、测试、部署等）
2. 时间轴从左到右
3. 关键任务标注 `crit`
4. 里程碑标注 `milestone`
5. 今日线自动标注

---

## Mermaid 主题配置

```
%%{init: {'theme':'base','themeVariables':{
  'fontSize':'13px',
  'fontFamily':'PingFang SC, Inter, sans-serif',
  'sectionBkgColor':'#EFF6FF',
  'altSectionBkgColor':'#F8FAFC',
  'taskBkgColor':'#3B82F6',
  'taskTextColor':'#FFFFFF',
  'activeTaskBkgColor':'#2563EB',
  'critBkgColor':'#F43F5E',
  'critBorderColor':'#9F1239',
  'todayLineColor':'#F43F5E',
  'gridColor':'#E2E8F0',
  'textColor':'#1E293B'
}}}%%
```

---

## 模板

`templates/html/gantt.html`

---

## 生成方式

1. 生成 HTML 文件（纯 HTML+CSS+SVG，无外部依赖）
2. Playwright 截图为 PNG

---

## Annotation 增强

### 里程碑标注

里程碑使用菱形标记（◆），而非普通任务条：
- 标记：宽度为 0 的特殊 task，渲染为菱形 12×12px
- 颜色：`#F59E0B`（Amber），内部填充
- 标签：菱形右侧 8px 处，11px Medium
- 连接线：从里程碑到相关任务的虚线（1px dashed `#CBD5E1`）

### 关键路径高亮

当数据中标注 `critical: true` 的任务链时：
- 任务条：使用 `#F43F5E` 填充（而非默认蓝色）
- 连接线：任务间的依赖线加粗到 2px，颜色 `#F43F5E`
- 非关键任务：透明度降至 0.5，突出关键路径
- 汇总标签：关键路径总工期显示在甘特图右上角，使用 `addDataBadge` 样式

### 进度标注

任务条支持进度填充：
- 已完成部分：原色填充
- 未完成部分：同色 + 条纹纹理（`stroke-dasharray: 4,2`，45° 斜线）
- 进度百分比：任务条右侧 badge 标注（使用 `addDataBadge`）
