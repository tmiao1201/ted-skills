# 竞争定位象限图规范（Quadrant / Positioning Matrix）

> 工具：HTML/SVG · Playwright 截图

---

## 适用场景

- 竞争定位分析（市场份额 vs 增长率、功能 vs 易用性）
- 2×2 战略矩阵（Gartner Magic Quadrant 风格）
- 产品/品牌定位图
- 技术选型对比

---

## 数据结构

```javascript
var data = {
  title: '竞争定位分析',
  subtitle: '市场份额 vs 增长率',
  xAxis: { label: '市场份额', min: 0, max: 100 },
  yAxis: { label: '增长率 (%)', min: -10, max: 50 },
  quadrants: [
    { name: '明星', position: 'top-right', color: '#10B981' },    // 高份额 高增长
    { name: '问号', position: 'top-left', color: '#F59E0B' },     // 低份额 高增长
    { name: '现金牛', position: 'bottom-right', color: '#3B82F6' }, // 高份额 低增长
    { name: '瘦狗', position: 'bottom-left', color: '#94A3B8' }    // 低份额 低增长
  ],
  items: [
    { name: '公司A', x: 70, y: 35, size: 40, color: '#3B82F6', highlight: true },
    { name: '公司B', x: 30, y: 25, size: 25 },
    { name: '公司C', x: 60, y: 10, size: 55 }
    // size: 气泡大小（可选，表示第三维度如营收）
    // highlight: 高亮标注（可选，突出焦点公司）
  ]
};
```

---

## 布局规则

1. 画布区域：正方形或近正方形（宽高比 1:1 ~ 4:3）
2. 十字线：位于画布中央，1px `#E2E8F0`
3. 象限背景：四个象限使用极淡的语义色填充（opacity 0.04）
4. 象限标签：各象限中心偏角位置，14px Bold，颜色与象限色相同
5. 坐标轴：外框 1px `#CBD5E1`，刻度线 4px，轴标签 12px `#64748B`
6. 气泡：圆形，大小映射 `size` 字段（默认 r=20px），fill opacity 0.6
7. 标签：气泡下方 8px，12px，居中
8. 高亮项：边框加粗 2px + 深色，附加 callout 标注

---

## Annotation 支持

- `highlight: true` 的项自动添加 Data Badge（显示具体数值）
- 焦点公司可附加 Callout（variant: 'insight'），标注竞争优势
- 支持趋势箭头：从历史位置指向当前位置（虚线箭头）

---

## 模板

`templates/html/quadrant.html`（待创建）

---

## 生成方式

1. 生成 HTML 文件（纯 HTML+CSS+SVG，无外部依赖）
2. Playwright 截图为 PNG
