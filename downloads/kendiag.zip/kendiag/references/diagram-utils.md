# 图表公共工具库（diagram-utils）

> 所有动态布局模板共享的标准函数集。生成图表时内联到 HTML `<script>` 中。

---

## 使用方式

不是独立 JS 文件。Claude 生成图表时，将所需函数直接内联到 HTML 的 `<script>` 标签中。按需引入——只嵌入当前图表用到的函数。

---

## 一、SVG 基础工具

```javascript
var NS = 'http://www.w3.org/2000/svg';

// 创建 SVG 元素
function el(tag, attrs) {
  var e = document.createElementNS(NS, tag);
  if (attrs) for (var k in attrs) e.setAttribute(k, attrs[k]);
  return e;
}

// 创建文本元素
function txt(str, x, y, opts) {
  opts = opts || {};
  var t = el('text', {
    x: x, y: y,
    'font-size': opts.size || 13,
    'font-weight': opts.weight || 'normal',
    'font-family': opts.font || "-apple-system, system-ui, 'PingFang SC', sans-serif",
    fill: opts.color || '#334155',
    'text-anchor': opts.anchor || 'middle',
    'dominant-baseline': opts.baseline || 'central'
  });
  t.textContent = str;
  return t;
}
```

---

## 二、文字与尺寸计算

```javascript
// 估算文字渲染宽度（中英文混排）
// 中文字符按 fontSize 宽度，英文按 0.6 * fontSize
function measureText(str, fontSize) {
  var w = 0;
  for (var i = 0; i < str.length; i++) {
    w += str.charCodeAt(i) > 127 ? fontSize : fontSize * 0.6;
  }
  return w;
}

// 根据文字内容计算节点宽高
// opts: { padX, padY, fontSize, minW, minH, maxW }
function calcNodeSize(label, opts) {
  opts = opts || {};
  var padX = opts.padX || 16;
  var padY = opts.padY || 10;
  var fontSize = opts.fontSize || 13;
  var w = measureText(label, fontSize) + padX * 2;
  var h = fontSize + padY * 2;
  return {
    w: Math.min(Math.max(w, opts.minW || 80), opts.maxW || 300),
    h: Math.max(h, opts.minH || 32)
  };
}

// 多行文字：计算最宽行的宽度和总高度
function calcMultilineSize(lines, opts) {
  opts = opts || {};
  var fontSize = opts.fontSize || 13;
  var lineH = opts.lineHeight || fontSize * 1.6;
  var padX = opts.padX || 16;
  var padY = opts.padY || 10;
  var maxW = 0;
  lines.forEach(function(line) {
    var w = measureText(line, fontSize);
    if (w > maxW) maxW = w;
  });
  return {
    w: maxW + padX * 2,
    h: lines.length * lineH + padY * 2
  };
}
```

---

## 三、碰撞检测

```javascript
// 检测两个矩形是否重叠（含可选间距）
function isOverlap(a, b, gap) {
  gap = gap || 0;
  return !(a.x + a.w + gap <= b.x ||
           b.x + b.w + gap <= a.x ||
           a.y + a.h + gap <= b.y ||
           b.y + b.h + gap <= a.y);
}

// 检测节点数组中的所有重叠对
// 每个节点需有 { x, y, w, h } 属性
function findOverlaps(nodes, minGap) {
  minGap = minGap || 0;
  var pairs = [];
  for (var i = 0; i < nodes.length; i++) {
    for (var j = i + 1; j < nodes.length; j++) {
      if (isOverlap(nodes[i], nodes[j], minGap)) {
        pairs.push([i, j]);
      }
    }
  }
  return pairs;
}

// 推开重叠节点（简单策略：沿重叠方向各推一半）
function resolveOverlaps(nodes, minGap, maxIterations) {
  minGap = minGap || 8;
  maxIterations = maxIterations || 10;
  for (var iter = 0; iter < maxIterations; iter++) {
    var pairs = findOverlaps(nodes, minGap);
    if (pairs.length === 0) break;
    pairs.forEach(function(pair) {
      var a = nodes[pair[0]], b = nodes[pair[1]];
      var dx = (a.x + a.w / 2) - (b.x + b.w / 2);
      var dy = (a.y + a.h / 2) - (b.y + b.h / 2);
      // 沿主方向推开
      if (Math.abs(dx) > Math.abs(dy)) {
        var push = (a.w / 2 + b.w / 2 + minGap - Math.abs(dx)) / 2;
        if (dx >= 0) { a.x += push; b.x -= push; }
        else { a.x -= push; b.x += push; }
      } else {
        var push = (a.h / 2 + b.h / 2 + minGap - Math.abs(dy)) / 2;
        if (dy >= 0) { a.y += push; b.y -= push; }
        else { a.y -= push; b.y += push; }
      }
    });
  }
}
```

---

## 四、连线工具

```javascript
// 直线连接（从 source 边缘到 target 边缘）
// direction: 'tb'(上下), 'lr'(左右), 'auto'(自动判断)
function connectNodes(src, tgt, direction) {
  if (direction === 'auto') {
    var dx = Math.abs((tgt.x + tgt.w / 2) - (src.x + src.w / 2));
    var dy = Math.abs((tgt.y + tgt.h / 2) - (src.y + src.h / 2));
    direction = dy > dx ? 'tb' : 'lr';
  }
  if (direction === 'tb') {
    var x1 = src.x + src.w / 2, x2 = tgt.x + tgt.w / 2;
    var y1 = src.y + src.h, y2 = tgt.y;
    if (src.y > tgt.y) { y1 = src.y; y2 = tgt.y + tgt.h; }
    return { x1: x1, y1: y1, x2: x2, y2: y2 };
  } else {
    var x1 = src.x + src.w, x2 = tgt.x;
    var y1 = src.y + src.h / 2, y2 = tgt.y + tgt.h / 2;
    if (src.x > tgt.x) { x1 = src.x; x2 = tgt.x + tgt.w; }
    return { x1: x1, y1: y1, x2: x2, y2: y2 };
  }
}

// 贝塞尔曲线连线（更美观）
function bezierPath(x1, y1, x2, y2, direction) {
  if (direction === 'tb') {
    var cy = (y1 + y2) / 2;
    return 'M' + x1 + ',' + y1 + ' C' + x1 + ',' + cy + ' ' + x2 + ',' + cy + ' ' + x2 + ',' + y2;
  } else {
    var cx = (x1 + x2) / 2;
    return 'M' + x1 + ',' + y1 + ' C' + cx + ',' + y1 + ' ' + cx + ',' + y2 + ' ' + x2 + ',' + y2;
  }
}

// L 形折线连线（先水平/垂直再转向）
function elbowPath(x1, y1, x2, y2, direction) {
  if (direction === 'tb') {
    var midY = (y1 + y2) / 2;
    return 'M' + x1 + ',' + y1 + ' L' + x1 + ',' + midY + ' L' + x2 + ',' + midY + ' L' + x2 + ',' + y2;
  } else {
    var midX = (x1 + x2) / 2;
    return 'M' + x1 + ',' + y1 + ' L' + midX + ',' + y1 + ' L' + midX + ',' + y2 + ' L' + x2 + ',' + y2;
  }
}
```

---

## 五、画布自适应

```javascript
// 根据所有节点计算最小画布尺寸
// 返回 { w, h, offsetX, offsetY } — offset 用于整体平移
function calcCanvasSize(nodes, opts) {
  opts = opts || {};
  var pad = opts.padding || 24;
  var minW = opts.minW || 1000;
  var minH = opts.minH || 400;
  var minX = Infinity, minY = Infinity, maxX = 0, maxY = 0;
  nodes.forEach(function(n) {
    if (n.x < minX) minX = n.x;
    if (n.y < minY) minY = n.y;
    if (n.x + n.w > maxX) maxX = n.x + n.w;
    if (n.y + n.h > maxY) maxY = n.y + n.h;
  });
  var contentW = maxX - minX + pad * 2;
  var contentH = maxY - minY + pad * 2;
  return {
    w: Math.max(contentW, minW),
    h: Math.max(contentH, minH),
    offsetX: -minX + pad + Math.max(0, (minW - contentW) / 2),
    offsetY: -minY + pad
  };
}
```

---

## 六、验证检查

```javascript
// 验证图表质量，返回问题列表
function validateDiagram(nodes, lines, canvas) {
  var issues = [];

  // 1. 节点重叠
  var overlaps = findOverlaps(nodes, 8);
  overlaps.forEach(function(pair) {
    issues.push({ type: 'overlap', severity: 'error', a: pair[0], b: pair[1] });
  });

  // 2. 内容超出画布
  nodes.forEach(function(n, i) {
    if (n.x < 0 || n.y < 0 || n.x + n.w > canvas.w || n.y + n.h > canvas.h) {
      issues.push({ type: 'out_of_bounds', severity: 'error', node: i });
    }
  });

  // 3. 间距不足
  for (var i = 0; i < nodes.length; i++) {
    for (var j = i + 1; j < nodes.length; j++) {
      var a = nodes[i], b = nodes[j];
      var dx = Math.abs((a.x + a.w / 2) - (b.x + b.w / 2)) - (a.w + b.w) / 2;
      var dy = Math.abs((a.y + a.h / 2) - (b.y + b.h / 2)) - (a.h + b.h) / 2;
      var gap = Math.max(dx, dy);
      if (gap >= 0 && gap < 20) {
        issues.push({ type: 'too_close', severity: 'warn', a: i, b: j, gap: gap });
      }
    }
  }

  return issues;
}
```

---

## 七、配色（Theme）

所有模板的 theme 对象从 design-system.md 的配色表取值。以下是标准 theme 接口，按用途分区。

### 主题注册表与切换机制

kendiag 支持三套主题：`default`（Tailwind 风格）、`professional`（Dual-Blue 企业级）、`blueprint`（工程蓝图）。

**主题选择方式**：调用方在需求中指定 `theme: 'professional'` 或 `theme: 'blueprint'` 或 `theme: 'blueprint-dark'`。未指定时使用 `default`（保持向后兼容）。

**主题工厂函数**（生成图表时内联到 HTML `<script>` 中）：

```javascript
// 主题注册表 — 三套主题 + blueprint 暗色变体
var THEMES = {
  'default': { /* 见下方 defaultTheme */ },
  'professional': { /* 见 design-system.md 第八章 */ },
  'blueprint': { /* 见 design-system.md 第十章 */ },
  'blueprint-dark': { /* 见 design-system.md 第十章暗色变体 */ }
};

// 主题工厂 — 返回完整 theme 对象，缺省字段从 default 补全
function getTheme(name) {
  var base = THEMES['default'];
  var target = THEMES[name] || base;
  // 浅合并：target 覆盖 base 的同名顶层字段
  var merged = {};
  for (var k in base) merged[k] = base[k];
  for (var k in target) merged[k] = target[k];
  return merged;
}
```

**模板中的使用方式**（替代原来的硬编码 `var theme = {...}`）：

```javascript
// 在模板 <script> 的开头声明主题名（由调用方/Claude 在生成时替换）
var THEME_NAME = 'default';  // 'default' | 'professional' | 'blueprint' | 'blueprint-dark'

// 内联对应的 theme 定义 + getTheme
var theme = getTheme(THEME_NAME);
```

> **注意**：不需要把所有 4 个主题定义都内联——只内联 `default`（作为 base）+ 当前选中的主题。非 default 主题只需声明与 default 不同的字段。

### 扩展 theme 属性（三主题共用接口）

以下属性为新增，default 和 professional 保持原值，blueprint 使用不同值：

```javascript
// 视觉约束属性（新增）
shadow: 'drop-shadow(0 2 3 rgba(0,0,0,0.06))',  // default 有微阴影
borderRadius: 6,         // default 圆角 6px
gridBackground: false,   // default 无网格背景
subtitleTransform: 'none',        // default 不做文字变换
subtitleLetterSpacing: 'normal',  // default 无字间距
fontMono: "'JetBrains Mono', 'SF Mono', 'Fira Code', monospace",
fontUI: "-apple-system, system-ui, 'PingFang SC', sans-serif",
```

### 通用字段（所有图表都有）

```javascript
var theme = {
  // 标题（所有模板统一：左上角 16px bold）
  title: { color: '#1a1a2e' },       // N-8 近似
  subtitle: { color: '#888888' },

  // 连线（所有结构图共用）
  line: { color: '#94A3B8', width: 1.5, label: '#64748B' },  // N-5, N-6

  // 视觉约束（新增 — 默认值）
  shadow: 'drop-shadow(0 2px 3px rgba(0,0,0,0.06))',
  borderRadius: 6,
  gridBackground: false,
  subtitleTransform: 'none',
  subtitleLetterSpacing: 'normal',
  fontMono: "'JetBrains Mono', 'SF Mono', 'Fira Code', monospace",
  fontUI: "-apple-system, system-ui, 'PingFang SC', sans-serif",
};
```

### 流程图/泳道图节点色

```javascript
  // 节点类型 → 配色（来自语义色 + 主题色序列）
  node:      { bg: '#EFF6FF', border: '#93C5FD', text: '#1E293B' },  // C-1 浅底/中间/N-7
  highlight: { bg: '#3B82F6', border: '#3B82F6', text: '#FFFFFF' },  // C-1 实心
  decision:  { bg: '#FFFBEB', border: '#FCD34D', text: '#92400E' },  // C-3 Amber
  success:   { bg: '#ECFDF5', border: '#6EE7B7', text: '#065F46' },  // C-2 Emerald
  error:     { bg: '#FFF1F2', border: '#FDA4AF', text: '#9F1239' },  // C-4 Rose
  external:  { bg: '#F8FAFC', border: '#CBD5E1', text: '#64748B' },  // N-1/N-4/N-6
  datastore: { bg: '#F5F3FF', border: '#C4B5FD', text: '#5B21B6' },  // C-5 Violet

  // 连线（判断分支）
  lineYes: { color: '#10B981', width: 2 },   // 语义：成功
  lineNo:  { color: '#F43F5E', width: 2 },   // 语义：错误
```

### ER 图表色

```javascript
  // 表类型 → 表头配色
  tableTypes: {
    core:     { headerBg: '#3B82F6', headerText: '#FFFFFF', pkColor: '#3B82F6' },  // C-1
    normal:   { headerBg: '#10B981', headerText: '#FFFFFF', pkColor: '#10B981' },  // C-2
    junction: { headerBg: '#64748B', headerText: '#FFFFFF', pkColor: '#64748B' }   // N-6
  },
  field: { text: '#1E293B', type: '#94A3B8', fk: '#8B5CF6', divider: '#F1F5F9' },
  table: { bg: '#FFFFFF', border: '#E2E8F0' },
```

### 类图类型色

```javascript
  typeColors: {
    'class':     { header: '#3B82F6', border: 'rgba(59,130,246,0.3)' },   // C-1
    'interface': { header: '#10B981', border: 'rgba(16,185,129,0.3)' },   // C-2
    'abstract':  { header: '#8B5CF6', border: 'rgba(139,92,246,0.3)' },   // C-5
    'enum':      { header: '#F59E0B', border: 'rgba(245,158,11,0.3)' }    // C-3
  },
  depLine: { color: '#B0B8C4', width: 1 },  // 依赖线（更细更淡）
```

### 分层/分组色（架构图、流程图分组、泳道标题）

```javascript
  // 6 色循环，半透明背景 + 实色标签
  layers: [
    { bg: 'rgba(102,126,234,0.06)', border: 'rgba(102,126,234,0.15)', color: '#667eea' },
    { bg: 'rgba(67,233,123,0.06)',  border: 'rgba(67,233,123,0.15)',  color: '#43e97b' },
    { bg: 'rgba(79,172,254,0.06)',  border: 'rgba(79,172,254,0.15)',  color: '#4facfe' },
    { bg: 'rgba(245,158,11,0.06)',  border: 'rgba(245,158,11,0.15)',  color: '#f59e0b' },
    { bg: 'rgba(139,92,246,0.06)',  border: 'rgba(139,92,246,0.15)',  color: '#8b5cf6' },
    { bg: 'rgba(244,63,94,0.06)',   border: 'rgba(244,63,94,0.15)',   color: '#f43f5e' }
  ],

  // 泳道标题色（实色背景）
  laneHeaders: [
    { bg: '#3B82F6', text: '#FFFFFF' },  // C-1
    { bg: '#10B981', text: '#FFFFFF' },  // C-2
    { bg: '#F59E0B', text: '#FFFFFF' },  // C-3
    { bg: '#8B5CF6', text: '#FFFFFF' },  // C-5
    { bg: '#06B6D4', text: '#FFFFFF' },  // C-6
    { bg: '#F43F5E', text: '#FFFFFF' }   // C-4
  ],
```

### 统计图序列色

```javascript
  series: ['#667eea', '#f5576c', '#43e97b', '#4facfe', '#fa8231', '#a55eea', '#fc5c65', '#26de81'],
```

### 使用规则

- **不硬编码颜色**：所有颜色从 theme 对象取值
- **每个模板只引入需要的字段**：流程图不需要 `tableTypes`，ER 图不需要 `decision`
- **颜色值来源**：全部来自 `design-system.md` 的配色表，对应关系用注释标明（如 `// C-1`）
- **title/subtitle 统一**：所有模板使用相同的标题颜色和字号（16px/12px），不在 theme 里定义 size（避免声明了不用的混乱）

---

## 八、标准 SVG defs

常用的 SVG 定义（箭头 marker、阴影 filter），所有模板复用：

```javascript
function addStandardDefs(svg, theme) {
  theme = theme || defaultTheme;
  var defs = el('defs');

  // 标准箭头
  var arrow = el('marker', {
    id: 'arrow', markerWidth: 8, markerHeight: 6,
    refX: 8, refY: 3, orient: 'auto'
  });
  arrow.appendChild(el('path', {
    d: 'M0,0.5 L7,3 L0,5.5',
    fill: 'none', stroke: theme.line.color,
    'stroke-width': 1.2, 'stroke-linecap': 'round'
  }));
  defs.appendChild(arrow);

  // 成功箭头（绿色）
  var arrowG = el('marker', {
    id: 'arrow-g', markerWidth: 8, markerHeight: 6,
    refX: 8, refY: 3, orient: 'auto'
  });
  arrowG.appendChild(el('path', {
    d: 'M0,0.5 L7,3 L0,5.5',
    fill: 'none', stroke: theme.lineSuccess.color,
    'stroke-width': 1.2, 'stroke-linecap': 'round'
  }));
  defs.appendChild(arrowG);

  // 错误箭头（红色）
  var arrowR = el('marker', {
    id: 'arrow-r', markerWidth: 8, markerHeight: 6,
    refX: 8, refY: 3, orient: 'auto'
  });
  arrowR.appendChild(el('path', {
    d: 'M0,0.5 L7,3 L0,5.5',
    fill: 'none', stroke: theme.lineError.color,
    'stroke-width': 1.2, 'stroke-linecap': 'round'
  }));
  defs.appendChild(arrowR);

  // 节点阴影
  var shadow = el('filter', {
    id: 'shadow', x: '-10%', y: '-10%', width: '130%', height: '140%'
  });
  shadow.appendChild(el('feDropShadow', {
    dx: 0, dy: 2, stdDeviation: 3, 'flood-color': 'rgba(0,0,0,0.06)'
  }));
  defs.appendChild(shadow);

  svg.appendChild(defs);
}
```

---

## 九、渲染顺序规范

所有模板必须按以下顺序渲染 SVG 元素：

```javascript
// 1. 背景层（层容器、泳道背景等）
var bgGroup = el('g');
svg.appendChild(bgGroup);

// 2. 连线层（箭头、关系线）
var lineGroup = el('g');
svg.appendChild(lineGroup);

// 3. 节点层（节点矩形、文字、图标）
var nodeGroup = el('g');
svg.appendChild(nodeGroup);
```

这确保连线不会遮挡节点，节点不会被背景覆盖。

4. **标注层（Annotation）** — 在节点层之上，最高 z-index

```javascript
// 4. 标注层（callout、badge、趋势标记等）
var annotationGroup = el('g');
svg.appendChild(annotationGroup);
```

---

## 十、Annotation 工具函数

> 对应 `design-system.md` 第九章的组件规范。按需内联到 HTML `<script>` 中。

### 10.1 Callout 标注

```javascript
// 在指定位置绘制带指向箭头的标注气泡
// target: { x, y } — 箭头指向的点
// text: 标注文字（支持多行，\n 分割）
// opts: { variant, position, maxWidth }
//   variant: 'info'|'success'|'warning'|'critical'|'insight' (default: 'warning')
//   position: 'top'|'right'|'bottom'|'left' (default: 'top')
//   maxWidth: 最大宽度 (default: 200)
function addCallout(group, target, text, opts) {
  opts = opts || {};
  var variants = {
    info:     { bg: '#EFF6FF', border: '#93C5FD', color: '#1E40AF', icon: 'ℹ' },
    success:  { bg: '#ECFDF5', border: '#6EE7B7', color: '#065F46', icon: '✓' },
    warning:  { bg: '#FFFBEB', border: '#FCD34D', color: '#92400E', icon: '⚠' },
    critical: { bg: '#FFF1F2', border: '#FDA4AF', color: '#9F1239', icon: '✕' },
    insight:  { bg: '#F5F3FF', border: '#C4B5FD', color: '#5B21B6', icon: '★' }
  };
  var v = variants[opts.variant || 'warning'];
  var pos = opts.position || 'top';
  var maxW = opts.maxWidth || 200;
  var fontSize = 11;
  var padX = 8, padY = 6;
  var lines = text.split('\n');
  var lineH = fontSize * 1.5;

  // 计算气泡尺寸
  var textW = 0;
  lines.forEach(function(l) {
    var w = measureText(v.icon + ' ' + l, fontSize);
    if (w > textW) textW = w;
  });
  var bubbleW = Math.min(textW + padX * 2, maxW);
  var bubbleH = lines.length * lineH + padY * 2;

  // 根据 position 计算气泡位置
  var arrowSize = 6;
  var gap = 8;
  var bx, by;
  if (pos === 'top')    { bx = target.x - bubbleW / 2; by = target.y - bubbleH - arrowSize - gap; }
  if (pos === 'bottom') { bx = target.x - bubbleW / 2; by = target.y + arrowSize + gap; }
  if (pos === 'left')   { bx = target.x - bubbleW - arrowSize - gap; by = target.y - bubbleH / 2; }
  if (pos === 'right')  { bx = target.x + arrowSize + gap; by = target.y - bubbleH / 2; }

  // 绘制气泡
  var rect = el('rect', {
    x: bx, y: by, width: bubbleW, height: bubbleH,
    rx: 6, fill: v.bg, stroke: v.border, 'stroke-width': 1
  });
  group.appendChild(rect);

  // 绘制指向箭头（三角形）
  var ax, ay, points;
  if (pos === 'top') {
    ax = target.x; ay = by + bubbleH;
    points = (ax - arrowSize) + ',' + ay + ' ' + ax + ',' + (ay + arrowSize) + ' ' + (ax + arrowSize) + ',' + ay;
  } else if (pos === 'bottom') {
    ax = target.x; ay = by;
    points = (ax - arrowSize) + ',' + ay + ' ' + ax + ',' + (ay - arrowSize) + ' ' + (ax + arrowSize) + ',' + ay;
  } else if (pos === 'left') {
    ax = bx + bubbleW; ay = target.y;
    points = ax + ',' + (ay - arrowSize) + ' ' + (ax + arrowSize) + ',' + ay + ' ' + ax + ',' + (ay + arrowSize);
  } else {
    ax = bx; ay = target.y;
    points = ax + ',' + (ay - arrowSize) + ' ' + (ax - arrowSize) + ',' + ay + ' ' + ax + ',' + (ay + arrowSize);
  }
  group.appendChild(el('polygon', { points: points, fill: v.bg, stroke: v.border, 'stroke-width': 1 }));

  // 绘制文字（带 icon 前缀）
  lines.forEach(function(line, i) {
    var label = (i === 0 ? v.icon + ' ' : '  ') + line;
    group.appendChild(txt(label, bx + padX, by + padY + i * lineH + fontSize / 2 + 2, {
      size: fontSize, weight: '500', color: v.color, anchor: 'start', baseline: 'central'
    }));
  });
}
```

### 10.2 Data Badge 数据标签

```javascript
// 在节点右上角绘制药丸形数据标签
// node: { x, y, w } — 宿主节点
// value: 显示的数值（如 "3.2s", "80%", "10K"）
// opts: { variant, position }
//   variant: 'info'|'success'|'warning'|'critical' (default: 'info')
//   position: 'top-right'|'top-left'|'bottom-right' (default: 'top-right')
function addDataBadge(group, node, value, opts) {
  opts = opts || {};
  var colors = {
    info: '#3B82F6', success: '#10B981',
    warning: '#F59E0B', critical: '#F43F5E'
  };
  var bg = colors[opts.variant || 'info'];
  var fontSize = 10;
  var padX = 6, h = 20;
  var w = Math.max(measureText(value, fontSize) + padX * 2, 36);

  // 位置计算
  var pos = opts.position || 'top-right';
  var bx, by;
  if (pos === 'top-right')   { bx = node.x + node.w - w + 8; by = node.y - 8; }
  if (pos === 'top-left')    { bx = node.x - 8; by = node.y - 8; }
  if (pos === 'bottom-right') { bx = node.x + node.w - w + 8; by = node.y + (node.h || 36) - 12; }

  // 药丸形背景
  group.appendChild(el('rect', {
    x: bx, y: by, width: w, height: h,
    rx: h / 2, fill: bg
  }));

  // 白色文字
  group.appendChild(txt(value, bx + w / 2, by + h / 2, {
    size: fontSize, weight: 'bold', color: '#FFFFFF', anchor: 'middle', baseline: 'central'
  }));
}
```

### 10.3 关键路径高亮

```javascript
// 高亮一组连线和节点为关键路径
// pathEdges: [{ from, to }] — 关键路径的边列表
// pathNodes: [nodeIndex] — 关键路径上的节点索引
// allNodes: 完整节点数组
// allLines: SVG line/path 元素数组
// opts: { color, dimOpacity, label }
function highlightCriticalPath(pathEdges, pathNodes, allNodes, allLines, opts) {
  opts = opts || {};
  var color = opts.color || '#00A0DF';  // Professional Theme Tech Blue
  var dimOpacity = opts.dimOpacity || 0.35;

  // 1. 降低非关键路径的透明度
  allLines.forEach(function(lineEl) {
    lineEl.setAttribute('opacity', dimOpacity);
  });

  // 2. 高亮关键路径连线
  pathEdges.forEach(function(edge) {
    if (edge.element) {
      edge.element.setAttribute('stroke', color);
      edge.element.setAttribute('stroke-width', '2.5');
      edge.element.setAttribute('opacity', '1');
    }
  });

  // 3. 高亮关键路径节点
  pathNodes.forEach(function(idx) {
    var node = allNodes[idx];
    if (node && node.element) {
      node.element.setAttribute('stroke', color);
      node.element.setAttribute('stroke-width', '2.5');
      node.element.style.filter = 'drop-shadow(0 0 8px ' + color + '33)';
    }
  });
}
```

### 10.4 趋势指示器

```javascript
// 在数据点旁绘制趋势箭头和变化值
// point: { x, y } — 数据点位置
// delta: 变化值（正数=上升，负数=下降，0=持平）
// opts: { format, position }
//   format: 函数，格式化 delta 值（默认：toFixed(1) + '%'）
//   position: 'above'|'right' (default: 'above')
function addTrendIndicator(group, point, delta, opts) {
  opts = opts || {};
  var fmt = opts.format || function(d) { return (d > 0 ? '+' : '') + d.toFixed(1) + '%'; };
  var pos = opts.position || 'above';
  var fontSize = 11;
  var gap = 6;

  var color, arrow;
  if (delta > 0)      { color = '#10B981'; arrow = '▲'; }
  else if (delta < 0) { color = '#F43F5E'; arrow = '▼'; }
  else                { color = '#94A3B8'; arrow = '━'; }

  var label = arrow + ' ' + fmt(delta);
  var tx = pos === 'above' ? point.x : point.x + gap + 4;
  var ty = pos === 'above' ? point.y - gap - fontSize / 2 : point.y;

  group.appendChild(txt(label, tx, ty, {
    size: fontSize, weight: 'bold', color: color,
    anchor: pos === 'above' ? 'middle' : 'start', baseline: 'central'
  }));
}
```

### 10.5 峰值/谷值标记

```javascript
// 标记数据序列中的最大最小值
// points: [{ x, y, value }] — 数据点数组
// opts: { showPeak, showValley, fontSize }
function markPeakValley(group, points, opts) {
  opts = opts || {};
  var showPeak = opts.showPeak !== false;
  var showValley = opts.showValley !== false;
  var fontSize = opts.fontSize || 11;

  if (points.length === 0) return;

  var peak = points[0], valley = points[0];
  points.forEach(function(p) {
    if (p.value > peak.value) peak = p;
    if (p.value < valley.value) valley = p;
  });

  function drawMarker(p, color, labelText) {
    // 空心圆标记
    group.appendChild(el('circle', {
      cx: p.x, cy: p.y, r: 5,
      fill: '#FFFFFF', stroke: color, 'stroke-width': 1.5
    }));
    // 虚线连接
    group.appendChild(el('line', {
      x1: p.x, y1: p.y - 5, x2: p.x, y2: p.y - 20,
      stroke: color, 'stroke-width': 1, 'stroke-dasharray': '3,2'
    }));
    // 数值标签（白底）
    var tw = measureText(labelText, fontSize) + 16;
    group.appendChild(el('rect', {
      x: p.x - tw / 2, y: p.y - 38, width: tw, height: fontSize + 8,
      rx: 3, fill: '#FFFFFF', stroke: color, 'stroke-width': 0.5
    }));
    group.appendChild(txt(labelText, p.x, p.y - 38 + (fontSize + 8) / 2, {
      size: fontSize, weight: '500', color: color, anchor: 'middle', baseline: 'central'
    }));
  }

  if (showPeak && peak !== valley) drawMarker(peak, '#F43F5E', String(peak.value));
  if (showValley && peak !== valley) drawMarker(valley, '#3B82F6', String(valley.value));
}
```

---

## 十一、工程绘图组件（Blueprint 专属）

> Blueprint Theme 专属的工程图纸组件。当 `theme.gridBackground === true` 时启用。
> 灵感来源：[yofine/blueprinter](https://github.com/yofine/skills) 的 Flat Engineering Blueprint 设计 + 工程制图标准。

### 11.1 网格背景（Grid Background）

工程图纸的标志性元素。在 SVG 画布底层绘制 20px 小格 + 100px 大格双层网格。

```javascript
// 在 SVG 底层添加工程网格背景
// 仅在 theme.gridBackground === true 时调用
function addGridBackground(svg, canvasW, canvasH, theme) {
  if (!theme.gridBackground) return;

  var defs = svg.querySelector('defs') || svg.insertBefore(el('defs'), svg.firstChild);
  var gridColor = theme.gridColor || 'rgba(0,0,0,0.04)';
  var gridSize = theme.gridSize || 20;
  var majorGridSize = gridSize * 5;  // 100px 大格

  // 小格 pattern
  var minorPattern = el('pattern', {
    id: 'grid-minor', width: gridSize, height: gridSize,
    patternUnits: 'userSpaceOnUse'
  });
  minorPattern.appendChild(el('path', {
    d: 'M ' + gridSize + ' 0 L 0 0 0 ' + gridSize,
    fill: 'none', stroke: gridColor, 'stroke-width': 0.5
  }));
  defs.appendChild(minorPattern);

  // 大格 pattern
  var majorPattern = el('pattern', {
    id: 'grid-major', width: majorGridSize, height: majorGridSize,
    patternUnits: 'userSpaceOnUse'
  });
  majorPattern.appendChild(el('rect', {
    width: majorGridSize, height: majorGridSize,
    fill: 'url(#grid-minor)'
  }));
  majorPattern.appendChild(el('path', {
    d: 'M ' + majorGridSize + ' 0 L 0 0 0 ' + majorGridSize,
    fill: 'none', stroke: gridColor, 'stroke-width': 1
  }));
  defs.appendChild(majorPattern);

  // 网格矩形（插入到最底层）
  var gridRect = el('rect', {
    width: canvasW, height: canvasH, fill: 'url(#grid-major)'
  });
  svg.insertBefore(gridRect, svg.querySelector('g') || svg.firstChild);
}
```

### 11.2 Title Block（工程标题栏）

工程图纸右下角的标准标题栏：图号、版本、日期、比例。

```javascript
// 在 SVG 右下角绘制工程标题栏
// opts: { title, version, date, scale, author }
function addTitleBlock(group, canvasW, canvasH, opts, theme) {
  opts = opts || {};
  var blockW = 240, blockH = 80;
  var x = canvasW - blockW - 16;
  var y = canvasH - blockH - 16;
  var borderColor = theme.line ? theme.line.color : '#cbd5e1';
  var textColor = theme.title ? theme.title.color : '#0f172a';
  var subColor = theme.subtitle ? theme.subtitle.color : '#64748b';
  var mono = theme.fontMono || "'JetBrains Mono', monospace";
  var ui = theme.fontUI || "'Inter', sans-serif";

  // 外框
  group.appendChild(el('rect', {
    x: x, y: y, width: blockW, height: blockH,
    fill: theme.node ? theme.node.bg : '#ffffff',
    stroke: borderColor, 'stroke-width': 1
  }));

  // 水平分割线
  group.appendChild(el('line', {
    x1: x, y1: y + 28, x2: x + blockW, y2: y + 28,
    stroke: borderColor, 'stroke-width': 0.5
  }));
  // 垂直分割线
  group.appendChild(el('line', {
    x1: x + blockW / 2, y1: y + 28, x2: x + blockW / 2, y2: y + blockH,
    stroke: borderColor, 'stroke-width': 0.5
  }));
  group.appendChild(el('line', {
    x1: x, y1: y + 54, x2: x + blockW, y2: y + 54,
    stroke: borderColor, 'stroke-width': 0.5
  }));

  // 标题（顶栏，全宽）
  group.appendChild(txt(opts.title || 'UNTITLED', x + blockW / 2, y + 16, {
    size: 12, weight: '600', color: textColor, anchor: 'middle', font: ui
  }));

  // 左下格：标签 + 值
  var cellPad = 6;
  group.appendChild(txt('REV', x + cellPad, y + 38, {
    size: 8, weight: '500', color: subColor, anchor: 'start', font: mono
  }));
  group.appendChild(txt(opts.version || 'v1.0', x + cellPad, y + 48, {
    size: 10, weight: '500', color: textColor, anchor: 'start', font: mono
  }));
  group.appendChild(txt('SCALE', x + cellPad, y + 64, {
    size: 8, weight: '500', color: subColor, anchor: 'start', font: mono
  }));
  group.appendChild(txt(opts.scale || '1:1', x + cellPad, y + 74, {
    size: 10, weight: '500', color: textColor, anchor: 'start', font: mono
  }));

  // 右下格
  var rx = x + blockW / 2 + cellPad;
  group.appendChild(txt('DATE', rx, y + 38, {
    size: 8, weight: '500', color: subColor, anchor: 'start', font: mono
  }));
  group.appendChild(txt(opts.date || new Date().toISOString().slice(0, 10), rx, y + 48, {
    size: 10, weight: '500', color: textColor, anchor: 'start', font: mono
  }));
  group.appendChild(txt('AUTHOR', rx, y + 64, {
    size: 8, weight: '500', color: subColor, anchor: 'start', font: mono
  }));
  group.appendChild(txt(opts.author || '—', rx, y + 74, {
    size: 10, weight: '500', color: textColor, anchor: 'start', font: mono
  }));
}
```

### 11.3 尺寸标注线（Dimension Annotation）

工程图纸中的标准测量标注——双向箭头 + 中间数值。

```javascript
// 绘制双向箭头尺寸标注线
// p1, p2: { x, y } — 两个端点
// label: 标注文字（如 "300px", "48dp"）
// opts: { offset, color, fontSize }
//   offset: 标注线距目标的偏移量（默认 20）
function addDimension(group, p1, p2, label, opts, theme) {
  opts = opts || {};
  var color = opts.color || (theme.subtitle ? theme.subtitle.color : '#64748b');
  var fontSize = opts.fontSize || 10;
  var offset = opts.offset || 20;
  var mono = theme.fontMono || "'JetBrains Mono', monospace";

  // 判断方向（水平或垂直）
  var isHoriz = Math.abs(p2.x - p1.x) > Math.abs(p2.y - p1.y);
  var ax1, ay1, ax2, ay2;  // 标注线端点

  if (isHoriz) {
    ay1 = ay2 = Math.min(p1.y, p2.y) - offset;
    ax1 = p1.x; ax2 = p2.x;
  } else {
    ax1 = ax2 = Math.max(p1.x, p2.x) + offset;
    ay1 = p1.y; ay2 = p2.y;
  }

  // 引出线（从目标到标注线）
  group.appendChild(el('line', {
    x1: p1.x, y1: p1.y, x2: ax1, y2: ay1,
    stroke: color, 'stroke-width': 0.5, 'stroke-dasharray': '2,2'
  }));
  group.appendChild(el('line', {
    x1: p2.x, y1: p2.y, x2: ax2, y2: ay2,
    stroke: color, 'stroke-width': 0.5, 'stroke-dasharray': '2,2'
  }));

  // 标注主线（双向箭头）
  group.appendChild(el('line', {
    x1: ax1, y1: ay1, x2: ax2, y2: ay2,
    stroke: color, 'stroke-width': 1,
    'marker-start': 'url(#dim-arrow-start)',
    'marker-end': 'url(#dim-arrow-end)'
  }));

  // 中间文字标签
  var midX = (ax1 + ax2) / 2;
  var midY = (ay1 + ay2) / 2;
  // 白底遮罩（让文字不被线穿过）
  var tw = measureText(label, fontSize) + 8;
  group.appendChild(el('rect', {
    x: midX - tw / 2, y: midY - fontSize / 2 - 2, width: tw, height: fontSize + 4,
    fill: theme.node ? theme.node.bg : '#ffffff', stroke: 'none'
  }));
  group.appendChild(txt(label, midX, midY, {
    size: fontSize, weight: '500', color: color, anchor: 'middle', baseline: 'central',
    font: mono
  }));
}

// 尺寸箭头 marker defs（需在 addStandardDefs 后或独立添加）
function addDimensionDefs(svg, theme) {
  var defs = svg.querySelector('defs') || svg.insertBefore(el('defs'), svg.firstChild);
  var color = theme.subtitle ? theme.subtitle.color : '#64748b';

  ['start', 'end'].forEach(function(side) {
    var marker = el('marker', {
      id: 'dim-arrow-' + side, markerWidth: 8, markerHeight: 6,
      refX: side === 'end' ? 8 : 0, refY: 3,
      orient: 'auto-start-reverse'
    });
    marker.appendChild(el('path', {
      d: side === 'end' ? 'M0,0 L8,3 L0,6 Z' : 'M8,0 L0,3 L8,6 Z',
      fill: color
    }));
    defs.appendChild(marker);
  });
}
```

### 11.4 交叉阴影线（Cross-Hatching Pattern）

工程图纸中表示截面、填充区域的标准方式。可选方向：45度、-45度、十字。

```javascript
// 添加交叉阴影线 pattern 到 SVG defs
// direction: '45' | '-45' | 'cross' (default: '45')
// 返回 pattern ID，用于 fill="url(#hatch-xxx)"
function addHatchPattern(svg, opts, theme) {
  opts = opts || {};
  var direction = opts.direction || '45';
  var spacing = opts.spacing || 8;
  var color = opts.color || (theme.line ? theme.line.color : '#cbd5e1');
  var id = 'hatch-' + direction + '-' + spacing;

  var defs = svg.querySelector('defs') || svg.insertBefore(el('defs'), svg.firstChild);

  // 检查是否已存在
  if (defs.querySelector('#' + id)) return id;

  var pattern = el('pattern', {
    id: id, width: spacing, height: spacing,
    patternUnits: 'userSpaceOnUse',
    patternTransform: direction === '45' ? 'rotate(45)' :
                      direction === '-45' ? 'rotate(-45)' : ''
  });

  pattern.appendChild(el('line', {
    x1: 0, y1: 0, x2: 0, y2: spacing,
    stroke: color, 'stroke-width': 0.5
  }));

  if (direction === 'cross') {
    pattern.appendChild(el('line', {
      x1: 0, y1: 0, x2: spacing, y2: 0,
      stroke: color, 'stroke-width': 0.5
    }));
  }

  defs.appendChild(pattern);
  return id;
}
```

### 11.5 Blueprint 组件使用规则

1. **网格背景**：blueprint 主题自动启用（`theme.gridBackground === true`），在 SVG 渲染最开始调用 `addGridBackground()`
2. **Title Block**：可选。当图表有明确的版本/文档号时添加，日常图表可省略。通过 `opts.titleBlock: true` 启用
3. **尺寸标注**：用于架构图中标注组件间距、时序图中标注延迟时间等场景。不要滥用——只标注有意义的数值
4. **交叉阴影**：用于表示"占位/待定"区域，或区分已实现/未实现的组件。不要用于纯装饰
5. **Dark 模式**：所有工程组件自动适配 theme 颜色——不硬编码色值，从 theme 对象取值
