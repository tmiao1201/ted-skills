# 06 · 完整时间线（出生到 2026 年 5 月）

> 维度定位：建立 Ian Cutress 的完整人生 / 职业 / 思想节点。
> 重点是 2022-2026 最近 4 年（离开 AnandTech 后），这是他独立 analyst 身份的真实时期。

---

## A. 早期 / 学术阶段（出生到 2011）

| 时间 | 事件 | 备注 |
|------|------|------|
| 早期（不公开年份） | 出生于英国 | 公开材料未给出生年份；社交媒体偶尔暗示 80 年代生 |
| 本科 + 研究生（2000s） | 在英国接受高等教育 | 网上有提及 University of Hull 等，但公开 bio 主要强调 Oxford PhD |
| **2007-2011** | **PhD: Computational Chemistry, University of Oxford** | 使用第一代 CUDA + NVIDIA GPU 研究 reaction dynamics 和 material interface kinetics。来源：RAISE Summit 2025 speaker bio + Google Scholar |
| 2011 毕业 | 完成 PhD | **关键决策**：不走博后/学术路线，转 tech journalism |

**注意**：用户原 prompt 提到 "剑桥/华威"，但所有公开材料（RAISE Summit bio、ResearchGate、Google Scholar、AppliedMaterials IR 引用）一致显示 **Oxford** PhD。本时间线以公开材料为准。

---

## B. AnandTech 时期（2011-2022）

| 时间 | 事件 | 影响 |
|------|------|------|
| **2011** | 加入 AnandTech，初期为 reviewer | PhD 一毕业即转记者，跳过博后 |
| 2012-2014 | 大量 CPU / 工艺早期 review | 建立"会写架构"的声誉 |
| 2014-08 | Anand Lal Shimpi 离职加入 Apple，Ryan Smith 接任 EiC | Ian 从此与 Anand 不再共事 |
| 2015 前后 | 升任 Senior Editor | 主导 CPU/工艺 deep-dive 主轴 |
| 2016-2019 | Intel 10nm 反复推迟期，Ian 早期信任→后期怀疑 | 形成"node name ≠ reality"框架 |
| 2017-2019 | 大量 AMD Zen / Zen 2 deep-dive | 建立与 AMD 的稳定 brief 关系 |
| 2019 | 开通 TechTechPotato YouTube channel | early stage，set up 渠道 |
| 2019-08 | AMD Hot Chips 2019: Zen 2 + Navi GPU 架构 disclosure | Ian 现场长 live blog |
| **2020-06** | Apple WWDC 宣布 Apple Silicon | Ian 与 Andrei Frumusanu 立即开始准备 |
| **2020-11** | M1 deep-dive 长文发布 | "Apple Shooting for the Stars" — 标志性长文 |
| **2020-12** | Lisa Su Q&A（首次大牌 1-on-1） | 与 AMD 建立标志性关系 |
| 2021-03 | Intel 宣布 IDM 2.0 / Pat Gelsinger 上任 | Ian 多次 Q&A roundtable |
| 2021-06 | **Jim Keller 长访谈系列启动**（"Silicon Wizard"） | 标志性独立分析师品牌建设 |
| 2021-07 | Intel Accelerated event：Intel 7/4/3/20A/18A 工艺重命名 | Ian 撰文解析 node naming |
| 2021-08 | Hot Chips 33 系列 Live Blog（覆盖 Alder Lake/Zen 3/Sapphire Rapids/IBM Z/Graphcore/Cerebras/SambaNova/Anton） | 单兵覆盖全场 |
| 2021-08-31 | "Intel Xeon Sapphire Rapids: How To Go Monolithic with Tiles" | 标志性 tile architecture deep-dive |
| **2022-02-18** | **宣布离开 AnandTech，发表 "From There to Here, and Beyond"** | 创立 More Than Moore；最后一篇是 Ann Kelleher 访谈 |

---

## C. More Than Moore 独立阶段（2022-2026）

### 2022（创立年）
- **2022-02-18** 正式离开 AnandTech，创立 More Than Moore（独立分析公司） + Substack newsletter
- 2022-Q2 早期 newsletter 摸索 + TechTechPotato 节奏建立
- 2022-09 与 ServeTheHome 合作（Intel Max CPU/GPU 解读）
- 2022-Q4 大量覆盖 AMD MI250X / Nvidia Hopper（H100）keynote

### 2023
- **2023-02-18** LinkedIn 一周年自述："good, fun, intense"
- 2023-02 Jim Keller 第二集（Tenstorrent AI Hardware on PCIe Cards）
- 2023-04 AI Hardware Show 系列（TPU、A100、AIU、BR100、MI250X 对比）
- 2023-09 持续覆盖 Intel Meteor Lake / Granite Rapids 早期信息
- 2023-Q4 ISSCC 2024 预览开始

### 2024
- **2024-02** **Intel Foundry Direct Connect**：1-on-1 Pat Gelsinger 20 分钟，覆盖 High-NA EUV economics、external #2 foundry positioning
- 2024-Q2 Apple WWDC / Apple Intelligence 发布，Ian 在 podcast hedge "marketing-first, technology-second"
- **2024-07** **Intel 13/14代 i9 退化案例**：Ian 公开假设 physical degradation 而非软件设置问题；与 Wendell 私下讨论后发推
- **2024-08-30** **AnandTech 关闭**（27 年历史），Ian 发情感推文："the end of an era... it gets a little emotional"
- 2024-10 AMD Advancing AI：Lisa Su Q&A、MI325X / MI355X roadmap
- 2024-Q4 Intel Lunar Lake / Arrow Lake 评测 + Panther Lake 路线 hedge

### 2025
- **2025-01** Panther Lake (18A lead product) 2H 2025 launch 推文：https://x.com/IanCutress/status/1885087436746711364
- 2025-01-14 The Tech Poutine #14: CES 2025 After Party（与 George of Chips and Cheese）
- **2025-03** **@HPCpodcast Episode 100** 客串：State of AI and Advanced Chips、GPU landscape (NV/AMD/Intel)、global chip manufacturing、GTC25 预期 — https://insidehpc.com/2025/03/hpcpodcast-dr-ian-cutress-on-the-state-of-advanced-chips-the-gpu-landscape-global-chip-manufacturing-and-gtc-expectations/
- 2025-Q1 ISSCC 2025 recap，包括 HBM Safety in autonomous vehicles 专题
- 2025-Q2 NVIDIA GTC 2025（与 Acquired podcast 团队合作 Nvidia 报道）
- **2025-07 RAISE Summit 2025 巴黎主舞台**：speaker bio https://tickets.raisesummit.com/2025/speaker/1775726/dr.-ian-j-cutress
- 2025-07-24 Lip-Bu Tan 入职 Intel CEO 后首份给员工的信，Ian 发 Substack 评论 + 原文：https://morethanmoore.substack.com/p/intel-ceo-letter-to-employees
- 2025-Q3 Intel Q2 2025 财报 + Lip-Bu Tan 新方向 Substack 长 essay
- 2025-Q4 Panther Lake 正式 launch 跟进
- 2025-Q4 AMD MI355X 发布（ISSCC 2026 提前 disclosure）

### 2026
- **2026-01** Apple 宣布 Siri 接 Google Gemini，Ian 在 newsletter / podcast 综合"Apple AI 真实状况"
- 2026-Q1 Apple M5 / M5 Pro / M5 Max（Fusion Architecture）发布，Ian 写架构解析
- **2026-02** Pat Gelsinger 离任后访谈（Playground Global）：https://morethanmoore.substack.com/p/an-interview-with-pat-gelsinger-2026
- 2026-Q1 Intel Foundry Direct Connect 2026 / 18A 量产追踪
- 2026-Q1 NVIDIA GTC 2026 / Rubin 早期信息
- 2026-Q2 ISSCC 2026 后续报道（AMD MI355X 细节、Apple Silicon 解析、Intel 18A 工艺细节）
- 2026-Q2 持续覆盖 AMD MI400 (UALoE72)、MI500 (UAL256) roadmap、Nvidia Rubin
- **2026-05-24（本 skill 调研截止日）** 当前活跃在 X (@IanCutress)、TechTechPotato YouTube、More Than Moore Substack

---

## D. 思想转折点（按主题）

| 转折点 | 早期立场 | 转折 | 近期立场 |
|--------|---------|------|---------|
| Intel 工艺 | 信任 | 2018 起反复跳票 + 改名风波 | 强烈怀疑 + "node name ≠ reality" |
| chiplet | 描述性（"AMD 的有趣做法"） | 2019-2021 多个 case | thesis 化（"结构性变化"） |
| Apple Silicon | 谨慎乐观（2020） | M1 实测验证 | 持续推崇架构 |
| AI accelerator startup | 高 enthusiasm | 2024 商业落地慢 | 挑剔 + 强调 software stack |
| AGI / 远期 AI | 回避 | 一直 | 仍回避（诚实边界） |
| 独立分析师商业模式 | 假设可行 | 2022 创业 | 已验证 |

---

## E. 最近 12 个月动态（2025-05 到 2026-05）

| 月份 | 关键事件 |
|------|---------|
| 2025-05 | 持续覆盖 Computex 2025 + 各家 AI server roadmap |
| 2025-06 | AMD Advancing AI（MI350X / MI400 UALoE72 / MI500 UAL256 path） |
| 2025-07 | **RAISE Summit Paris 主舞台**；Lip-Bu Tan Intel CEO 信报道 |
| 2025-08 | Intel Q2 财报评论；Panther Lake 早期 sampling |
| 2025-09 | Apple iPhone 17 / A19 + M5 发布前预热 |
| 2025-10 | Intel Foundry 2025 进展；Nvidia 数据中心 quarterly |
| 2025-11 | Panther Lake 正式发布跟进 |
| 2025-12 | ISSCC 2026 paper 提前 leak / disclosure |
| 2026-01 | **Apple-Google Gemini 合作**；Apple M5 Pro/Max Fusion Architecture |
| 2026-02 | **Pat Gelsinger 离任后访谈**（Playground Global） |
| 2026-03 | **AMD ISSCC 2026 MI355X disclosure** 解析 |
| 2026-04 | Apple Tim Cook 接班传闻 + 半导体相关影响评论 |
| 2026-05 | NVIDIA GTC 2026 + Rubin 早期信息追踪（截止本 skill 调研日 2026-05-24） |

---

## F. 关键里程碑数字（提供叙事锚点）

- 工作年限：AnandTech 11 年（2011-2022） + More Than Moore 4 年（2022-2026） = 15 年职业总长
- 长访谈数：Jim Keller 至少 2 集、Pat Gelsinger 多次、Lisa Su 多次、Tenstorrent CEO/CTO、Ann Kelleher 等
- 覆盖大会：Hot Chips（年度）、ISSCC、IEDM、VLSI Symposium、CES、Computex、GTC、SC、Intel Foundry Direct Connect、Apple WWDC、AMD Advancing AI、SC（Supercomputing）
- Substack 订阅：tens of thousands（公开 about 页表述）
- YouTube 频道：TechTechPotato 5 万+ 订阅（推断）
- X follower：约 5 万（推断）
- PhD 论文：2011 Oxford computational chemistry，被引用记录在 Google Scholar（约低三位数引用，与他工业界知名度不成正比 — 这是他选择转行的一个信号）

---

## G. 与其他 perspective skill 的时间线交集

| 时间 | Ian 在做什么 | Tim Cook 在做什么 | 黄仁勋在做什么 |
|------|------------|-----------------|--------------|
| 2011 | 进入 AnandTech | 接任 Apple CEO | NVIDIA 转向 mobile (Tegra) |
| 2020-11 | Apple M1 deep dive | M1 发布 | Hopper 早期 |
| 2022-02 | 离开 AnandTech | Apple 历史营收高峰 | NVIDIA GTC + Hopper 大热 |
| 2024-02 | Pat Gelsinger 1-on-1 | Apple Vision Pro 发布 | Blackwell 发布 |
| 2026-01 | 评论 Apple-Gemini 合作 | 宣布转 Executive Chairman | Rubin roadmap 推进 |

---

## H. 我推断 / 标注的不确定性

1. **出生年份 / 早期教育细节**：公开材料不完整。本 skill 不伪造具体日期
2. **私人生活**：完全不公开，本 skill 不进入
3. **公司财务 / employee count**：More Than Moore 是 small operation，具体规模不公开
4. **NDA briefing 频率 / 大客户**：consulting 客户名单不公开（这是行业规矩）

## 关键发现

1. **职业轨迹是 academic → media → 独立 analyst 三段** —— 在每个阶段都有"被验证的判断"
2. **AnandTech 11 年 + More Than Moore 4 年** —— 总职业长度还在加速期
3. **2022 跳跃决策被 2024-08 前东家关闭强烈印证**
4. **2025-2026 进入"业内重要 voice"阶段** —— RAISE Summit 主舞台、HPCpodcast Ep 100、各家 1-on-1 高管

---

## 附录 A：年度关键大会覆盖节奏（年度循环）

Ian 的 12 个月覆盖周期相对稳定：

| 月份 | 主要事件 | Ian 的覆盖形态 |
|------|---------|---------------|
| 1 月 | CES Las Vegas | YouTube 现场连线 + The Tech Poutine 录制 + 短推文 |
| 2 月 | Intel Foundry Direct Connect / ISSCC（旧金山） | Substack 长 essay + 1-on-1 访谈 |
| 3 月 | NVIDIA GTC（San Jose）+ Apple 春季公告 | 多个 newsletter + podcast 客串 |
| 4 月 | Intel Vision / 各家 Q1 财报 | 短评 + 推文 |
| 5 月 | Computex Taipei | YouTube 现场 + 多个推文流 |
| 6 月 | AMD Advancing AI / Apple WWDC / VLSI Symposium | 多个 long-form + Q&A transcript |
| 7 月 | Imec ITF / IFA pre-briefing | newsletter |
| 8 月 | Hot Chips（年度大型架构 disclosure） | 大量 Live Blog / 多日推文流 |
| 9 月 | Apple iPhone / A 系列发布 | M 系列预热 |
| 10 月 | IEDM / OCP Summit / Samsung Foundry Forum / Lenovo Tech World | newsletter |
| 11 月 | Supercomputing (SC) / TSMC OIP | 与 Patrick Kennedy (STH) 联动 |
| 12 月 | 年度 retrospective / 来年 preview | newsletter 季度总结 |

## 附录 B：与 Neil Shah 时间线交集（对比视角）

| 时间 | Ian Cutress 在做什么 | Neil Shah 在做什么 |
|------|---------------------|-------------------|
| 2011 | 进入 AnandTech (PhD 毕业) | 在 Counterpoint 成立前夕，转型 market intelligence |
| 2014 | AnandTech Senior Editor | Counterpoint Research 联合创立期 |
| 2020 | Apple M1 deep-dive | 评论 Apple India 市场份额突破 |
| 2022 | 离开 AnandTech，创立 More Than Moore | Counterpoint 印度市场 quarterly tracker 持续输出 |
| 2024 | Pat Gelsinger 1-on-1 | iPhone 印度产量首次突破全球 10% |
| 2026 | 评论 Apple-Gemini 合作（架构层） | 评论 Apple-Gemini 合作（市场份额层） |

差异化清晰：**同一事件，Ian 看架构 / 工艺细节，Neil 看出货 / 份额 / ASP 信号。**

