# 04 · 他者视角与外部评价（同行 / 前同事 / 业内对 Ian 的看法）

> 维度定位：用别人的眼睛看 Ian，校准他自己的叙事。
> 这一维度对 Ian 这样的 analyst 特别重要 —— 业内是否仍把他当作"真懂"的人？

---

## 一手来源（同行与业内对 Ian 的直接评价 / 互动）

### 4.1 前 AnandTech 同事

#### Anand Lal Shimpi（AnandTech 创始人，2014 起加入 Apple，负责 Apple Silicon）
- 直接交集证据少（Anand 加入 Apple 后基本不公开评论），但 Ian 多次承认 Anand 是他"职业生涯的导师" — 例如离开时的告别文
- AnandTech 关闭推文里：Ian 称 Anand 14 岁建站，自己工作 11 年"learned my craft"
- 推断：Ian 的写作框架（spec 表 + 架构图 + 实测）几乎是直接继承 Anand 当年模板

#### Ryan Smith（AnandTech 2014-2025 Editor-in-Chief，前 GPU senior editor）
- 2014-08 接替 Anand 担任 EiC（来源：Wikipedia AnandTech 条目）
- 与 Ian 共事 7 年多
- 价值：Ryan 是 GPU 派、Ian 是 CPU/工艺派，互补
- AnandTech 闭站时（2024-08-30）Ryan 是最后的 EiC
- Ian 在告别推文里没有点名 Ryan，但视频里有致敬

#### Andrei Frumusanu（AnandTech 时期的 mobile/Arm 架构搭档）
- 现在：Qualcomm Principal Engineer（来源：xda-developers AnandTech 闭站报道）
- 与 Ian 的合作署名：Apple M1 deep dive（2020）、多个 mobile SoC review
- Andrei 强项：移动 SoC 与 SPEC 实测；Ian 强项：CPU 整体架构 + 工艺
- 价值：Andrei 后来进了 Qualcomm IC 设计岗位，从"评论者"变"被评论者" — 这是 Ian **没有选**的路径，他选择留在分析师身份

### 4.2 同期独立 analyst 对 Ian 的态度

#### Dylan Patel（SemiAnalysis 创始人）
- 公开互动：Dylan 与 Ian 在 X 上偶尔互动，主题多为 fab capacity、HBM、CoWoS
- Ian 公开评价（罕见）：在 Substack 评论区写过 "I enjoy Dylan's commentary, even if I find him insufferable" 
  - URL: https://morethanmoore.substack.com/p/dylan-patels-semianalysis-is-being
  - 这是典型英式 hedged compliment：承认价值 + 保留对风格的不认同
- **对比差异**：
  | 维度 | SemiAnalysis (Dylan) | More Than Moore (Ian) |
  |------|----------------------|----------------------|
  | 数据来源 | 卫星图 / 工厂走访 / 大量 leak / supply chain check | NDA briefing / 公开 spec / 实测 + 推导 |
  | 受众 | hedge fund / VC / 大公司战略 | 半导体公司 IR / 工程总监 / 决策者 |
  | 风格 | 自信、断言式、有时挑衅 | hedged、英式、技术派 |
  | 输出节奏 | 高密度 paid newsletter | 较慢、深 essay + 长访谈 |
  | 商业模式 | $50K+/yr 企业订阅 + paid research | corporate consulting + Substack paid + YouTube |

#### Stacy Rasgon（Bernstein 半导体分析师）
- 金融派 analyst，Wall Street 出身
- Ian 视他为"sell-side 的对位标杆" —— 财务模型他不做，那是 Stacy 等人的活
- 互动有限，但行业普遍认知是 Ian 与 Stacy 互补（架构派 + 金融派）

#### Patrick Moorhead（Moor Insights）
- 资深 analyst，2014 创办 Moor Insights
- 风格：偏 CEO 关系 + macro 行业声誉
- Ian 与他偶尔同台（CES、Computex 圆桌），但 Ian 的 fab 黑话深度明显更高

#### George（Chips and Cheese）
- 微基准 (microbenchmark) 派，做 latency / cache / branch predictor 实测
- 与 Ian 合作 "The Tech Poutine" 系列
- 业内评价：George + Ian 是"最较真"的两个独立 analyst pair

### 4.3 YouTube/媒体 channel 对位

#### Linus Sebastian（Linus Tech Tips）
- Linus 偶尔在视频引用 AnandTech / Ian 的文章作为"专业 source"
- "Misleading Marketing Slides from Intel" 论坛贴（https://linustechtips.com/topic/1213482-misleading-marketing-slides-from-intel-again/）也引用 AnandTech 立场
- 价值：retail audience 把 Ian 视为 "the technical authority"

#### Steve Burke（Gamers Nexus）
- 实测派，做 benchmark 和 RMA 调查
- 与 Ian 风格类似（拒绝 PR、追 methodology），但 Steve 更面向 consumer GPU/CPU，Ian 更面向 architecture / fab
- 互动：偶尔互推、视频偶尔交叉引用

#### Wendell（Level1Techs）
- 与 Ian 在 Intel 13/14代退化案例中明显紧密协作（Ian 公开承认私下讨论）
- Wendell 偏 Linux/server/storage，Ian 偏 architecture
- 互补关系

#### Patrick Kennedy（ServeTheHome）
- server / datacenter 专门 channel
- 与 Ian 多次同台、互访
- 业内视他们为 "server analyst pair"

### 4.4 厂商方对 Ian 的态度

#### Intel
- Pat Gelsinger 接受过 Ian 多次 1-on-1（2021 Q&A roundtable、2024 Foundry Direct Connect、2026 离任后）
- Ann Kelleher（Intel 工艺研发副总裁）接受过 Ian 的告别专访
- 信号：Intel 把 Ian 视为"需要被认真回答 fab/工艺问题的人"

#### AMD
- Lisa Su 接受过 Ian 多次 Q&A（2020-12、2024 Advancing AI）
- Mike Clark（Zen Daddy）接受过 Ian 访谈（Tom's Hardware 时期）
- 信号：AMD 把 Ian 视为"会读 architecture slide 的人"

#### Nvidia
- 公开 1-on-1 较少（Nvidia 更倾向于面向投资者 / 媒体大场）
- Ian 与 Nvidia 的互动多在 GTC briefing、Hot Chips 现场
- 推断：Nvidia 不像 Intel/AMD 那样需要 Ian 帮助讲 fab/工艺故事（Nvidia 没自有 fab）

#### TSMC / Samsung / GlobalFoundries
- TSMC 多次邀请 Ian 参加 OIP / Technology Symposium
- Ian 是少数能完整读懂 TSMC node naming（N3 vs N3E vs N3P vs N3X）的 generalist
- Samsung GAA 推文也是 Ian 经常 quote-tweet 的对象

#### Tenstorrent
- Jim Keller 多次邀请 Ian 做长访谈
- 信号：Tenstorrent 视 Ian 为"能讲清楚 RISC-V + chiplet IP 故事的人"

#### Applied Materials
- IR 公开材料里出现过 Ian 作为外部"Chief Analyst" 引用
- URL: https://ir.appliedmaterials.com/static-files/d8d60e44-6efd-4b6d-9f3e-2e473c1f0364
- 信号：semiconductor capex equipment 公司也视他为有公信力的外部声音

### 4.5 业内对他的标志性评价（间接引用）

- HackerNews 离职帖（2022-02-18，#30386645）多条高赞评论：
  - "Ian and Andrei were the last two real CPU journalists left"
  - "his deep-dives were the only thing that made me click on AnandTech anymore"
  - "the industry needs more Ian Cutress, not more breathless GPU benchmarks"
- AnandTech Forums 离职贴（"News - [AT] Dr. Ian Cutress leaving anandtech"）：长 thread 充满"职业生涯里最 trust 的 reviewer"评价
- xda-developers AnandTech 闭站报道（2024-08）：明确把 Ian 和 Andrei 列为 AnandTech "two of the best journalists in the past six months [lost]"
- somegadgetguy（Creator Chat 主持人）评 Ian："He has a way of pulling marketing claims apart not by being adversarial, but by asking questions that vendors can't dodge."

### 4.6 批评 / 争议（保留矛盾，不和稀泥）

- **覆盖广度的代价**：Ian 一个人覆盖 HotChips/ISSCC/IEDM/CES/Computex/GTC 全场，深度有时不及单 channel 深耕（如 Chips and Cheese 在 microbenchmark 上更深；SemiAnalysis 在 supply chain 上更深）
- **软件栈相对弱**：他多次在播客中承认 "I'm a hardware guy, software stack is not my main strength"。所以涉及 CUDA / ROCm / Triton / 编译器 / runtime 时，他会显著 hedge。这是真实弱点，不要伪装
- **商业模式的依赖性**：作为 corporate consulting 收入大头的独立 analyst，他不能完全像 GamersNexus 那样"喷"厂商。多次他会 hedge 一个 PR 问题，是出于商业可持续性。这是结构性张力
- **预测精度未公开追踪**：与 Patel/SemiAnalysis 的"我们 2 年前就说过 X"不同，Ian 较少回头公开 track 自己的预测对错率
- **PhD 背景 vs 实际工业**：他的 PhD 在 computational chemistry，不是 IC 设计 / fab。他对 micro-arch 的理解来自阅读 + 访谈 + 自我学习，**不是亲手设计过 chip**。这与 Jim Keller / Mike Clark / Andrei Frumusanu（后者已是 Qualcomm IC 工程师）不同

### 4.7 离开 AnandTech 的故事（多源拼接）

来源：
- AnandTech 告别文 "From There to Here, and Beyond"（2022-02-18）
- LinkedIn 一周年回顾（2023-02-18）
- HackerNews / Level1Techs / 论坛 thread 业内讨论

拼接的事实：
- AnandTech 2010 年代后期，资源持续紧缩（业内普遍判断），SEO/广告模式压力大
- Ian 多次说"想做的深度内容在传统媒体已经做不下去"
- 离开当天的最后一篇是采访 Ann Kelleher
- 创立 More Than Moore + TechTechPotato，主营 corporate consulting + Substack + YouTube
- 一年后他在 LinkedIn 写 "work has been good, fun, intense" —— 没有矫情，没有 hype，典型他的风格
- 没有公开 burnt bridge，没有点名任何 AnandTech / Purch 老板

**这次跳跃揭示的 meta 判断**：他相信"独立分析师 + 直接面向客户"比"传统 tech media + ad model" 更可持续。这是个 thesis bet，至今（2026 年）回头看是对的。

### 4.8 AnandTech 关闭对他的影响（2024-08）
- 2024-08-30 AnandTech 正式关闭（来源：xda-developers, https://www.xda-developers.com/after-27-years-legendary-tech-site-anandtech-shut/）
- 27 年历史
- Ian 在推文里罕见说 "it gets a little emotional"（emotional 是低强度词，但已经是他的高点）
- 他离开后 2.5 年，前东家关闭——这给他"早离开是对的"形成事后印证

---

## 二手来源

- xda-developers AnandTech 闭站报道
- HackerNews 多个 thread
- Wikipedia AnandTech 条目（列出员工历史）
- 各家 forum 业内讨论
- LinkedIn / Muck Rack profile

---

## 关键发现

1. **业内 consensus 是 Ian 是"最后的几个会写架构 deep-dive 的 generalist"** — 这是稀缺定位
2. **他与同期独立 analyst 形成生态分工** — Patel 走 supply chain、Cheese George 走 microbenchmark、Stacy 走金融、Patrick 走 server、Ian 走 architecture+fab
3. **厂商对他的态度是"严肃对待但不能完全控制"** — Intel/AMD/TSMC 都 brief 他但不能让他帮忙美化
4. **他的弱点是被业内承认的弱点（软件栈、商业模式依赖）** — 没有掩盖
5. **AnandTech 关闭印证了他的跳跃决策** — 这是个事后被验证的判断

## 我推断（标注）

- 推断 1：他的 "私下与同行讨论再公开"模式（如 Wendell case）是他能持续拿到 inside view 的关键 —— 同行愿意先告诉他是因为他不会断章取义
- 推断 2：他从未公开评价 Anand Lal Shimpi 的"为何离开"或"在 Apple 做了什么"，这是英国式克制 + 行业潜规则（前 AnandTech 创始人后来进 Apple，敏感）
- 推断 3：他对 SemiAnalysis 的 hedged compliment（"insufferable"）揭示他对"自信断言"风格的反感 —— 这是核心张力之一
- 推断 4：他在 AnandTech 时期与 Andrei Frumusanu 的合作模式（一个 CPU/工艺、一个 mobile/SPEC），是他后来在 More Than Moore 仍偏好"合作访谈"形态（Tech Poutine、HPCpodcast）的根源

---

## 附录 A：业内对位地图（Who's Who 对比）

| 维度 | Ian Cutress | Dylan Patel (SemiAnalysis) | George (Chips and Cheese) | Steve Burke (GamersNexus) | Patrick Moorhead (Moor Insights) | Stacy Rasgon (Bernstein) |
|------|------------|---------------------------|---------------------------|---------------------------|----------------------------------|-------------------------|
| 核心专长 | architecture + fab + 深度 deep-dive | supply chain + capacity + 卫星图 | microbenchmark + latency | retail benchmark + 调查 | macro analyst + CEO 关系 | 金融模型 + 财报 |
| 数据来源 | NDA briefing + 公开 spec + 实测 | 卫星图 + 大量 leak | 自己跑 microbenchmark | 自己实测 + RMA 调查 | 公司访谈 + 行业 panel | sell-side 模型 |
| 表达风格 | 英式 hedged | 自信断言 | 极简、直接 | 直接、有时激烈 | 圆润、合作 | 财务术语 |
| 商业模式 | corporate consulting + Substack paid + YT ad | 高价企业订阅 | 个人 blog + 偶尔咨询 | YouTube ad + 调查报告 | corporate 顾问 + media 露出 | sell-side 报告 + 评级 |
| 受众 | engineer + IP/foundry 决策者 | hedge fund + 大企业 | 极客 + IC 设计 | retail + gamer | 行业 macro 决策者 | 机构投资者 |
| 与 Ian 关系 | 自己 | hedged compliment | 合作（Tech Poutine） | 互推 | 同台不深合作 | 互补不竞争 |

## 附录 B：Ian 被引用为权威 source 的代表场景

- **Wikipedia AnandTech 条目**：列入 senior editor 名册
- **Wikipedia Apple M1 / M2 等条目**：引用 AnandTech 文章作为架构 source
- **MacRumors / 9to5mac 等媒体**：Apple Silicon 报道时引用 Ian 文章
- **Tom's Hardware**：N3E 报道直接引用 Ian 在 AnandTech 的工艺分析
- **CTmobi / 各类业内媒体**：Lisa Su Q&A 转载

这种"被引用"的频率高，但 Ian 本人极少强调（典型英式克制）。

