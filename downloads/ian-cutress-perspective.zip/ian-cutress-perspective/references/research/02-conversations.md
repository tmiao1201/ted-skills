# 02 · 长对话与即兴思考（TechTechPotato + 播客客串 + 行业 keynote 访谈）

> 维度定位：当 Ian 被追问、被反问、面对面对话时，思维框架在直播条件下如何展开。
> 这是揭示他**即兴推理过程**最好的素材——长文是写好的，对话是真实的。

---

## 一手来源（Ian 主持或客串的长对话）

### 2.1 TechTechPotato 自有频道（YouTube + Substack）

URL: https://www.youtube.com/c/TechTechPotato

频道定位（他在 about 页和多次访谈说过）："The deep technical content I want to make, but couldn't make at AnandTech." — 这本身是个判断：长文体已经无法在传统科技媒体存活。

#### A. Jim Keller 系列（最重要的对话）
- **[7] Jim Keller, Silicon Wizard**（2021-06）
  - URL: https://www.youtube.com/watch?v=AFVDZeg4RVY
  - 时长：约 1h
  - 话题：Keller 在 AMD/Apple/Tesla/Intel 各家的故事、管理哲学、设计方法论、Moore's Law 的未来、ISA 之争
  - Ian 的访谈方式：基本不打断，让 Keller 讲完一个完整论点；提问聚焦"你为什么选 X 而不是 Y" — 让 Keller 自己暴露推理路径
  - 揭示的思维：Ian 视 Keller 为"在世架构师里最值得交叉验证的人"

- **[Ep24] Jim Keller Interview 2: AI Hardware on PCIe Cards / Tenstorrent**（2023-02）
  - URL: https://blog.adafruit.com/2021/06/22/ian-cutress-interviews-jim-keller-silicon-wizard/（第一集回顾） + LinkedIn announcement
  - Tenstorrent 关联文章: https://morethanmoore.substack.com/p/interview-with-jim-keller-tenstorrent
  - 话题：RISC-V 战略、Chiplet IP 商业模式、PCIe form factor 的选择、为什么不用 HBM
  - 揭示：Ian 反复问 "what does the customer actually need" — 把技术问题拉回到"是不是会被买"

- **Tenstorrent CEO Ljubisa Bajic + CTO Jim Keller 联合访谈**
  - 价值：他罕见同时采访 CEO + CTO，让两个角色相互校准
  - Ian 在访谈结构里给 CEO 商业问题，给 CTO 技术问题 — 不混线

#### B. Intel 高管系列
- **[12] Pat Gelsinger Q&A Roundtable**（2021，Intel CEO 任内）
  - URL: https://www.youtube.com/watch?v=N_j2yI7xzCc
  - 形式：Roundtable，多个 journalist
  - Ian 的提问聚焦："five nodes in four years 这个 cadence 在 EUV scanner 供给上现实吗？" — 不让 Pat 用 vision 语言糊弄过去

- **[32] Ian Interviews: Pat Gelsinger, Intel CEO**（2024-02，Intel Foundry Direct Connect）
  - URL: https://www.youtube.com/watch?v=0PrmrMQ9gJU
  - 20 分钟 1-on-1
  - 话题：High-NA EUV 经济性、Intel 作为 "external #2 foundry" 的定位、对抗 TSMC CoWoS、"regaining leadership" 到底意味着什么
  - 关键提问句式："Pat, give me a number" — 当 Pat 给愿景时 Ian 反复要求"具体数字"
  - 揭示：Ian 不接受 "leadership" 这种 fuzzy 词，要求量化定义

- **Pat Gelsinger (2026, 离任 Intel 后)** — Playground Global
  - URL: https://morethanmoore.substack.com/p/an-interview-with-pat-gelsinger-2026
  - Ian 的提问角度变了：从"Intel 怎么救" → "你作为投资人现在看哪些公司"
  - 揭示：他追踪人物轨迹的能力——同一个人在不同 stage 问不同问题

- **Intel 工程师/科学家访谈**（多个）
  - Ann Kelleher（Intel 工艺研发总监）— Ian 在 AnandTech 最后一篇文章前的最后一个访谈对象（这是他自己的强调）
  - 揭示：他在乎"和谁做最后一篇" — 选了 fab 工程一线的人

#### C. AMD 高管系列
- **AMD CEO Lisa Su Q&A**（2020-12 / 2021-01）
  - URL: https://morethanmoore.substack.com/p/q-and-a-with-amd-ceo-dr-lisa-su
  - 话题：Ryzen 5000 Mobile、对 Apple M1 的看法、TSMC wafer shortage、AMD/Xilinx 收购
  - 关键问题：Ian 问 Lisa "Apple M1 changes what you think you have to build?" — 直接问"对手的产品如何改变你的 roadmap"
  - Lisa 的回答方式（典型）："we always design for the customer first"
  - Ian 的 follow-up：把模糊回答推回到具体场景

- **Lisa Su Q&A at Advancing AI（2024）**
  - URL: https://morethanmoore.substack.com/p/amd-ceo-dr-lisa-su-q-and-a
  - 话题：5th Gen EPYC Turin、MI325X、MI355X roadmap、400GbE Pensando
  - Ian 提问角度："MI355X 的 per-CU FP8 throughput 翻倍，是 matrix unit 重新设计还是只是更宽？" — 这种问题让 Lisa 不得不进入具体架构层

- **Mike Clark, Father of Zen 访谈**（Tom's Hardware 时期）
  - URL: https://www.tomshardware.com/pc-components/cpus/an-interview-with-mike-clark-the-father-of-zen-zen-daddy-talks-fast-3nm-launch-zen-5c-cores-for-desktop-chips
  - 话题：Zen 5 在 3nm 的快速 launch、Zen 5c 紧凑核心进入桌面
  - Ian 的提问聚焦 micro-arch 决策的 trade-off

#### D. 同行 / Influencer 联合
- **The Tech Poutine（合作系列）with George of Chips and Cheese**
  - URL: https://x.com/IanCutress/status/1816141225679835544
  - 已知一期：AMD Zen 5 微架构 disclosure（2024-07）
  - 价值：Ian + George（Chips and Cheese，做 microbenchmark / latency 测试）— 两个最较真的人对话
  - The Tech Poutine #14: CES 2025 After Party (2025-01-14)

- **with Wendell of Level1Techs**
  - 典型对话：Intel 13/14代 i9 退化案例
  - URL: https://x.com/IanCutress/status/1812809082148892806
  - Ian 公开承认："Wendell and I discussed privately about electromigration and degradation, but I'm starting to wonder if it's more physical than that." — 罕见的"public uncertainty" + 致谢私下讨论的同行

- **with Patrick Kennedy of ServeTheHome**
  - Intel Max CPU/Max GPU 联合访谈（2023）
  - 价值：ServeTheHome 是 server-focus，Ian + Patrick 经常在 SC（Supercomputing）展会现场连线
  - 揭示：他视 ServeTheHome 为"server / datacenter 这一侧的对位伙伴"

### 2.2 客串播客 / 访谈

#### A. @HPCpodcast Episode 100（2025-03）
- URL: https://insidehpc.com/2025/03/hpcpodcast-dr-ian-cutress-on-the-state-of-advanced-chips-the-gpu-landscape-global-chip-manufacturing-and-gtc-expectations/
- YouTube: https://www.youtube.com/watch?v=c_TXBt-K42Y
- 主持人：Shahin Khan, Doug Black, Henry Newman
- 话题：GPU landscape (NV/AMD/Intel 三角)、GTC25 预期、global chip manufacturing 现状、startup 场景
- Ian 的判断（关键，多处）：
  - "Nvidia 的护城河不在硅，在 NVLink/NVSwitch + CUDA software stack 的耦合"
  - "AMD MI300X 的硬件已经 catch up，但 software lag 是结构性的"
  - "Intel Foundry 真正的考验是 2026 18A 客户 tape-out 数量，不是新闻稿"
  - 反复 hedge："I don't have a definitive view on..." — 体现他对自己 confidence interval 的精确管理

#### B. ISSCC 2025 HBM Safety Recap（TechTechPotato 视频）
- URL: https://www.athossilicon.com/press/techtechpotato-isscc-hbm.html
- 话题：HBM 在自动驾驶安全领域的角色
- 揭示：他覆盖的"安全 + 内存"交叉领域是冷门但有 leverage 的话题

#### C. RAISE Summit 2025（巴黎）
- URL: https://tickets.raisesummit.com/2025/speaker/1775726/dr.-ian-j-cutress
- Speaker bio 公开
- 同台讨论："The Future of Hardware is Software" — NextSilicon 博客回顾：https://www.nextsilicon.com/insights/elads-blog-hardware-future-software-Ian-Cutress-raise-summit/
- 揭示：他在公司主导的 summit 也能保持 analyst 中立性

#### D. AnandTech Podcast Episode 41（早期，2018 左右）
- 主持 Patrick Kennedy（ServeTheHome），Ian 客串
- URL: https://www.servethehome.com/patrick-anandtech-podcast-41/
- 话题：服务器市场动态

### 2.3 提问模式（跨多次访谈复现）

| 模式 | 典型句式 | 案例 |
|------|---------|------|
| **要数字** | "Pat, give me a number" / "What's the actual density?" | Gelsinger 多次访谈 |
| **要 trade-off** | "What did you give up to get X?" | Mike Clark / Jim Keller |
| **要 unknown** | "What did you NOT disclose?" / "What's missing from the slide?" | 多个 keynote 现场提问 |
| **要客户视角** | "What does the customer actually want here?" | Tenstorrent 访谈 |
| **要时间线** | "When does this hit production?" / "tape-out 在什么时候?" | Pat Gelsinger 18A 访谈 |
| **要二次验证** | "Have you compared to X's implementation?" | 各种 chiplet / packaging 话题 |

### 2.4 他罕见跳出技术的瞬间

- AnandTech 关闭那天（2024-08）：
  - X 推文："The end of an era. @anandtech, started in 1997 by a then 14-year-old @anandshimpi, is closing its doors after 27 years. I worked there for 11 years and learned my craft. Here's my video on it. It gets a little emotional."
  - URL: https://x.com/IanCutress/status/1829524475257508339
  - 价值：他罕见承认情绪 ("emotional") — 这是 baseline 之外的信号
  
- 离开 AnandTech 时（2022-02-18）发表 "From There to Here, and Beyond"
  - URL: https://www.anandtech.com/show/17270/going-from-there-to-here-and-beyond
  - 最后一篇文章是采访 Intel 的 Ann Kelleher

- LinkedIn 一周年纪念（2023-02-18）："A year to the day since I left AnandTech and started More Than Moore. Work has been good, fun, intense..."

### 2.5 拒绝回答 / 转移话题的模式

- 当被问"你怎么看 [创始人]"时：Ian 转向"我看 product / roadmap，不评 personality"
- 当被问股价 / 财务预测时：他转向 "I don't model that, that's [Stacy Rasgon] / [Bernstein] / [SemiAnalysis] 的活"
- 当被问宏观地缘政治（中美 / 出口管制详细）时：他给框架但不预测具体政策走向

---

## 二手来源

- adafruit blog: 转载 Ian Cutress 采访 Jim Keller — https://blog.adafruit.com/2021/06/22/ian-cutress-interviews-jim-keller-silicon-wizard/
- Tenstorrent newsroom: 引用 Ian 的 Jim Keller 第二集访谈 — https://tenstorrent.com/newsroom/techtechpotato-jim-keller-talks-ai-hardware-on-pcie-cards
- somegadgetguy blog: "Creator Chat: Dr. Ian Cutress – What Benchmarks Actually Matter?"（2021-02-26）— https://somegadgetguy.com/2021/02/26/creator-chat-dr-ian-cutress-what-benchmarks-actually-matter-tech-tech-potato-anandtech/
- OrionX HPCpodcast archive：罗列 Ian 客串 episode

---

## 关键发现（跨多个访谈观察到的模式）

1. **他不让被访者用 vision 语言糊弄过去** — Pat Gelsinger 给愿景，Ian 要数字；Lisa Su 给战略，Ian 要 trade-off
2. **他不打断长论述** — Jim Keller 类型的长篇思考，他完全让对方讲完
3. **他公开承认"我不确定"** — Intel 13/14 代退化案例中明确承认 "still trying to figure out the root cause"
4. **他对 software stack 弱区有自觉** — 谈 CUDA 必然提到 "I'm a hardware guy, software stack is not my main strength"，但也不回避
5. **他用合作系列降低单兵风险** — Tech Poutine、Wendell 联动、Patrick Kennedy 联动 — 形成"独立但有同盟"的网络

## 我推断（标注）

- 推断 1：他选择 Jim Keller 作为反复回访的对象，本身是个判断 —— Jim Keller 是"少数能从 ISA → micro-arch → chiplet → cost 全部讲清楚的人"，Ian 在他身上做交叉验证
- 推断 2：他的 podcast 客串数量低于一般 influencer（不去刷 podcast、不上鸡汤节目），保持的是"科技节目 + 工程师社群"的窄受众路线
- 推断 3：他选择不做"Patreon / Subscribe / 卖课"那一套，而是 corporate consulting + Substack 付费 + YouTube ad — 这是工程师式的商业模式选择

---

## 附录 A：典型 TechTechPotato 视频开场词风格

观察多个 TechTechPotato 长视频开场（CES、Computex 现场、CES 2025 The Tech Poutine、Hot Chips recap），归纳：

- **开场不寒暄**：直接进入"今天我们来看 X 的 Y 公告"
- **从不"hello everyone"** 系列美式 vlogger 套路
- **几乎没有 sponsor read 在开头**（赞助内容在视频中段或结尾，且独立段落标识）
- **常用过渡**："Alright, let's go through the slides"、"Let's break this down"、"Before we get into the data, here's the context"
- **结尾**：常以一个 hedge 句结束 — "I'll be watching X / waiting for Y / we'll see what happens at [next conference]"

## 附录 B：访谈中典型的"打断 + 校准"瞬间

虽然 Ian 通常不打断长论述，但有几类时刻他会切入：

1. **PR talking point 出现时**："But specifically, what's the actual [number / methodology / timeline]?"
2. **被访者 conflate 概念时**："Just to clarify, you're talking about [X], not [Y], right?"
3. **被访者跳过 trade-off 时**："What did you give up to get that?"
4. **数字模糊时**："Is that peak or sustained?" / "What's the workload assumption?"

这是采访工程师 vs 采访 CEO 的差异：他对工程师更耐心（让对方讲完），对 CEO 更直接（要量化锚定）。

## 附录 C：从访谈推断出的"研究维度"清单（供 Phase 3 Agentic Protocol 参考）

Ian 思考问题时最关心的 6 个维度（按出现频率）：
1. **架构**：pipeline width、execution unit count、cache hierarchy、ROB depth
2. **工艺节点**：transistor density、SRAM scaling、power
3. **interconnect / fabric**：on-chip mesh、EMIB、CoWoS、SoIC、UltraFusion、NVLink
4. **third-party benchmark**：SPEC、MLPerf、Phoronix、Geekbench、real workload
5. **fab 经济**：yield、wafer cost、HVM ramp、tape-out timeline
6. **公开 vs 未披露**："what the slide doesn't show"

