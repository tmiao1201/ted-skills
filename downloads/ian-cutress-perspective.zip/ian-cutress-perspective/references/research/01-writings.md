# 01 · 著作与系统性长文（AnandTech 深度文章 + More Than Moore Substack）

> 维度定位：Ian Cutress 的"长文遗产" — 这是判断他思维框架最硬的素材。
> 他不是 macro 行业分析师（那是 Patrick Moorhead、Neil Shah），也不是金融模型派（那是 Stacy Rasgon），
> 他是**架构 + 工艺 + 实测三轴 deep-dive 派**，每一篇大文都贯彻同一套方法论。

---

## 一手来源（Ian 本人署名长文）

### 1.1 AnandTech 时期代表作（2011–2022 任 Senior Editor）

按主题聚类，注明发表年份和核心论点。

#### A. Intel 工艺 / 数据中心架构
- **Intel Xeon Sapphire Rapids: How To Go Monolithic with Tiles**（2021-08-31）
  - URL: https://www.anandtech.com/show/16921/intel-sapphire-rapids-nextgen-xeon-scalable-gets-a-tiling-upgrade
  - 可信度：一手，本人署名
  - 核心论点：Sapphire Rapids 是 Intel 首个 multi-die（tile）服务器 CPU；用 10 个 EMIB 连接 4 个 tile，55 micron 连接 pitch；横纵切 mesh 让 OS 看起来仍是 monolithic；UPI 2.0 从 3 链路升到 4 链路、最多 8 socket
  - 揭示的思维框架：**chiplet/tile 不只是良率手段，更是 mesh interconnect 工程问题** — 别人讲 chiplet 讲省成本，Ian 讲 mesh 切割、连接 pitch、socket 拓扑
  - 文章典型结构：spec → 架构图 → die shot → 与上代对比（Ice Lake）→ 性能含义 → 不确定性标注

- **Intel's Accelerated Process Roadmap: 10nm/7nm → Intel 7/4 (Renaming)**（2021）
  - URL: https://www.anandtech.com/show/16823/intel-accelerated-offensive-process-roadmap-updates-to-10nm-7nm-4nm-3nm-20a-18a-packaging-foundry-emib-foveros
  - 可信度：一手
  - 核心论点：Intel 把 10nm SuperFin 改名 Intel 7，把 7nm 改名 Intel 4，是为了在 TSMC marketing 体系下"看齐"。但 "nm" 本身已经和物理尺寸脱钩，是 marketing number
  - 关键判断：他没有直接 trash Intel 改名，而是承认"既然行业已经在玩数字游戏，Intel 不玩就吃亏"——但同时反复说"看 transistor density 才是 ground truth"
  - 反复出现的论点（≥3 次跨文章复现）：**marketing node name ≠ technical reality** — 这是他最稳定的信念之一

- **Hot Chips 33 系列 Live Blog**（2021-08）
  - URL: https://www.anandtech.com/show/16901/hot-chips-2021-day-1-section-1-cpus-alder-lake-zen3-ibm-z-sapphire-rapids
  - 覆盖：Alder Lake、Zen 3、IBM Z、Sapphire Rapids、Graphcore、Cerebras、SambaNova、Anton、Infineon、EdgeQ、Samsung、Intel/AMD/Google/Xilinx GPU
  - 价值：他几乎一个人覆盖全场 — 这是他与同行的差异点之一，**会议级广度 + 单芯片级深度**

#### B. AMD Zen 系列
- **AMD Zen 3 Ryzen Deep Dive Review: 5950X, 5900X, 5800X, 5700X**（2020-11）
  - URL: https://www.anandtech.com/show/16214/amd-zen-3-ryzen-deep-dive-review-5950x-5900x-5800x-and-5700x-tested
  - 可信度：一手
  - 核心论点：Zen 3 实现 +19% IPC + 频率提升，**纯设计带来的提升，不是工艺节点的功劳**（仍是 N7）— 这是 Ian 反复强调的"架构 vs 工艺"区分
  - 重点拆解：unified 32MB L3（取消 Zen 2 的 split-L3）、front-end 改进、load/store 改进
  - 标志性表达："IPC is a single number summarizing many things" — 警告读者不要 worship 单一数字

- **AMD Zen 2 Microarchitecture Analysis**（2019）— 同样的范式
- **AMD EPYC 系列服务器 review**（多次）— 与 Andrei Frumusanu 合作做 SPEC2017 实测

#### C. Apple Silicon
- **Apple Announces The Apple Silicon M1: Ditching x86 - What to Expect, Based on A14**（2020-11）
  - URL: https://www.anandtech.com/show/16226/apple-silicon-m1-a14-deep-dive
  - 可信度：一手（与 Andrei Frumusanu 合作署名 deep-dive）
  - 核心论点：M1 的 Firestorm 核心是 **8-wide microarchitecture**，比 x86 行业主流（4–5 wide）宽得多；ROB 深度 ~630 instructions，远超 A13 的 560；4 条 128-bit NEON pipeline 与 x86 桌面对齐
  - 性能判断："Apple's fastest CPU core claim is **extremely plausible**" — 标志性"低调但承认"语气
  - 揭示的判断习惯：**Apple 的 IPC 优势是真实的、可测量的、不是 Apple PR 编出来的** — 即使他对 PR 整体怀疑，但 spec 数据能验证时他会公开承认
  - "Apple Shooting for the Stars: x86 Incumbents Beware" — 标题本身就是他罕见的 dramatic 用词

#### D. 工艺节点 / Foundry
- **TSMC's 3nm Update: N3E on Schedule, N3P/N3X Deliver Five Percent Gains**（2023，已迁移到 Tom's Hardware）
  - URL: https://www.tomshardware.com/news/tsmc-n3p-n4x-on-track-with-density-and-power-gains
  - 可信度：一手
  - 核心论点：N3E 是 TSMC 3nm 的主力节点，N3 是过渡品；N3E 相对 N5 提供 ~1.6× logic density、20% speed、>30% power saving
  - 反复警告："**chip density ≠ logic density**" — 当 SRAM 和 analog 加入后，混合密度只有 ~1.3×（vs 纯 logic 1.6×）
  - 这是他与 marketing slide 之间最大的张力之一

### 1.2 More Than Moore Substack（2022 至今）

URL: https://morethanmoore.substack.com/

#### 已知具名文章（按主题）
- **An Interview with Pat Gelsinger (2026)**
  - URL: https://morethanmoore.substack.com/p/an-interview-with-pat-gelsinger-2026
  - 地点：Playground Global（Gelsinger 离开 Intel 后的新东家）
  - 话题：当一个前 Intel CEO 评估初创公司而不是 product roadmap 时，视角如何变；agentic AI workload、scientific AI、计算精度/resilience/optical links/dataflow machines/post-von Neumann
  - 价值：体现 Ian 与"在位高管"和"离任高管"两种状态下访谈技术对比

- **An Interview with Pat Gelsinger**（更早一版，2022/2023）
  - 提问角度：High-NA economics、external #2 foundry、competing against CoWoS、什么叫"regaining leadership"
  - 揭示：他不问"你怎么看 AMD"，他问"你 EUV per layer cost 怎么算"

- **AMD CEO Dr. Lisa Su Q&A**
  - URL: https://morethanmoore.substack.com/p/amd-ceo-dr-lisa-su-q-and-a
  - 话题：Advancing AI 2024、5th Gen EPYC Turin、Instinct MI325X、MI355X、Pensando 400GbE
  - 提问风格：聚焦 silicon-level 改动而非"长期愿景"

- **Intel Foundry Event: Press Q&A**
  - URL: https://morethanmoore.substack.com/p/intel-foundry-event-press-q-and-a
  - 价值：他把 press Q&A 完整 transcript 化 — 这是同行少做的事，体现"原始数据优先"

- **Dylan Patel's SemiAnalysis Is Being Sued**
  - URL: https://morethanmoore.substack.com/p/dylan-patels-semianalysis-is-being
  - 罕见的"业内同行"评论文，公开表达："enjoy Dylan's commentary, find him insufferable" — 典型英式 hedged compliment
  - 价值：揭示他对同业 analyst 的态度边界 — 尊重输出、保留风格不认同

- **Intel CEO Letter to Employees**（2025-07）
  - URL: https://morethanmoore.substack.com/p/intel-ceo-letter-to-employees
  - 转发 Lip-Bu Tan 给 Intel 员工的内部信原文 + 简短点评
  - 体现：**document the moment** — 他经常把"原文 + 极简评论"作为内容形态

- **Intel 2025 Q2 Financials**
  - URL: https://morethanmoore.substack.com/p/intel-2025-q2-financials
  - 价值：Ian 罕见进入财务分析领域（通常是其他 analyst 的活），但即使在这里他也是从"segment revenue → fab utilization → process node ramp"的视角，而非 EPS / multiple

- **An Update on the Timing Industry**、**No Time Like MEMS Time**、**AI Needs Better Than Quartz**
  - 系列：MEMS 振荡器/时钟分发
  - URL: https://morethanmoore.substack.com/p/an-update-on-the-timing-industry
  - 价值：他覆盖**别人不覆盖的角落**（quartz、MEMS、timing、PMIC、power delivery）— 这是 More Than Moore 与 SemiAnalysis 等大流量号的差异化

- **The Future of Semiconductor Freight**
  - URL: https://morethanmoore.substack.com/p/the-future-of-semiconductor-freight
  - 主题：晶圆运输/物流——再一次跑到 supply chain 的极端冷门角落

- **Interview with Jim Keller, Tenstorrent**
  - URL: https://morethanmoore.substack.com/p/interview-with-jim-keller-tenstorrent
  - 双访（Jim Keller CTO + Ljubisa CEO）
  - 话题：Tenstorrent 的 RISC-V 战略、chiplet IP、PCIe form factor

### 1.3 学术 / PhD 出处
- **PhD: Computational Chemistry, University of Oxford (2011)**
  - Source: RAISE Summit 2025 speaker bio (https://tickets.raisesummit.com/2025/speaker/1775726/dr.-ian-j-cutress)
  - 论文方向：用第一代 CUDA 和 NVIDIA GPU 研究 reaction dynamics 和 material interface kinetics
  - Google Scholar: https://scholar.google.com/citations?user=8ZSmKjAAAAAJ
  - **核心信号**：Ian 是少数从"用 GPU 跑科学计算的研究者"转型到"分析 GPU 的人"的角色，所以他对 CUDA、kernel、memory hierarchy 的理解比典型 tech journalist 深一层
  - **修正用户原 prompt 中的事实**：用户 prompt 写"剑桥/华威"，但所有公开材料证实是 **Oxford** PhD（部分早期学位可能在 Hull / Warwick，但 PhD 是 Oxford）。本 skill 以公开材料为准

### 1.4 反复出现 ≥3 次的核心论点（这些是真信念）

| 论点 | 出现场景数 | 证据 |
|------|----------|------|
| **marketing node name ≠ technical reality** | ≥6 | Intel 10/7 改名、TSMC N3 vs N3E、Samsung GAA 命名、HD vs HC cell density、SRAM scaling 停滞 |
| **架构 first，然后才讲性能** | ≥10 | 所有 Zen / M1 / Sapphire Rapids deep-dive 都是先讲 pipeline/cache/ROB，再贴 benchmark |
| **chiplet 是结构性变化不是渐进创新** | ≥4 | Sapphire Rapids tile、Zen 2/3 CCD、Apple M2 Ultra UltraFusion、MI300X |
| **单一 benchmark 不能代表 workload** | ≥5 | 多次警告"IPC is a single number summarizing many things"，坚持跑 SPEC + 实应用 + power 测量 |
| **More than Moore**（与节目同名）：晶体管缩小已减速，creative packaging 是下一个十年 | ≥3 | newsletter 标题本身、Pat Gelsinger 访谈话题、Lisa Su 访谈话题 |
| **不要相信 PR slide 上的相对性能图** | ≥7 | 多次推文/视频回应 Intel/AMD/NV 的 marketing chart，要求 absolute units + test methodology |

### 1.5 自创术语 / 偏好术语

- **"die shot"** / **"floor plan"** — 几乎每篇深度文都会贴
- **"transistor density"**（不说 "node size"）— 信号性术语
- **"SRAM scaling"** — 他比同行更频繁讨论 SRAM 在新节点的缩小（或不缩小）
- **"chiplet"** / **"tile"** — 区分 Intel 的 tile（EMIB 连接）和 AMD/Apple 的 chiplet（更广义）
- **"on-chip mesh"** / **"interconnect topology"** — 强调 fabric 层
- **"advanced packaging"**（CoWoS、SoIC、Foveros、EMIB、UltraFusion）— 几乎每周都会用
- **"yield"** / **"wafer cost"** — 把工艺讨论拉回到经济现实
- **"PPA"**（Performance / Power / Area）— 工业界标准三元组，他高频使用
- **"DTCO"**（Design-Technology Co-Optimization）— 比一般 journalist 频繁
- **"HD vs HC vs HP cell library"** — 这是 fab 内部黑话，他公开使用
- **"More than Moore"** —— 节目名 + newsletter 名，借自 IEEE IRDS / Gordon Moore 后续讨论的术语

### 1.6 推荐书单 / 智识谱系（从他公开提及推断）

- **Hennessy & Patterson, Computer Architecture: A Quantitative Approach** — 多次在视频中作为 baseline 引用
- **Bob Colwell, The Pentium Chronicles** — 架构设计访谈思路源头
- **Mead & Conway, Introduction to VLSI Systems** — 引用频率较低但出现过
- **IEEE 期刊**（JSSC、TED）、**ISSCC / VLSI Symposium / IEDM / Hot Chips 论文集** — 这是他的"日常 reading list"
- 频繁提及的当代架构师：**Jim Keller**、**Ann Kelleher**（Intel）、**Mark Papermaster**（AMD）、**Mike Clark**（AMD Zen Daddy）、**Raja Koduri**

---

## 二手来源（他人总结 Ian 的写作）

- Muck Rack profile: https://muckrack.com/ian-cutress/articles — 列出他在 AnandTech、Tom's Hardware、More Than Moore、TechTechPotato 的署名文章索引
- Wikipedia AnandTech 条目：列他为 2011-2022 senior editor，参与重大架构 deep-dive
- HackerNews 离职贴讨论（30386645）：业内对其"AnandTech 最后还能写 deep-dive 的两个人之一"（与 Andrei Frumusanu 并列）评价
- NextSilicon blog 评 RAISE Summit 2025：称其为"few industry analysts to cover both video and written media, with a technical background and the ability to form an accessible and detailed story from complex semiconductor topics"

---

## 写作框架共识（跨多篇文章复现的结构）

| 段落 | 内容 |
|------|------|
| 1. 背景 | 上代是什么、为什么这次有意思 |
| 2. Spec 表 | 完整、不删减、附 footnote |
| 3. 架构图 / die shot | 公司公开 + 自己标注或推断 |
| 4. 关键 block 拆解 | front-end → execution → memory hierarchy → fabric / interconnect |
| 5. 工艺节点说明 | node name、density、SRAM、power 数据 |
| 6. 性能预期 | SPEC、实测、对比上代 + 友商 |
| 7. 不确定性 / 没透露的部分 | 明确写"this is what Intel/AMD did NOT disclose" |
| 8. 结论 | hedged、给场景化建议（"if you do X workload, this matters"），几乎不下"必买"结论 |

**这套结构本身就是一种心智模型**：先架构后性能、先 spec 后判断、先承认 unknown 后推断。

---

## 我推断（标注）

- 推断 1：Ian 的"长文 vs 推文 vs 视频"是分层的——长文负责系统性论证、推文负责快速更正/diss PR、视频负责对话和推广 newsletter。三个介质互不替代，构成他独立分析师的商业模式
- 推断 2：他离开 AnandTech 的决定可能与编辑部资源萎缩、广告模型崩塌、SEO 压力增加有关（HN 离职贴有相关讨论），但他从未公开归因为某个具体事件——这是他英式 hedged 风格
- 推断 3：MEMS / timing / freight 这些冷门题材，揭示他的真信念是"semi 比你想的更广"，不只是 CPU/GPU 焦点

---

## 附录 A：AnandTech 经典 deep-dive 结构（按 Ian 的 Zen 3 review 还原）

读 Ian 的 Zen 3 review（https://www.anandtech.com/show/16214/amd-zen-3-ryzen-deep-dive-review-5950x-5900x-5800x-and-5700x-tested ），完整文章约 30 页 web pagination，结构如下：

| 页 | 主题 | Ian 的处理方式 |
|---|------|---------------|
| 1 | 引言 + 路标 | 设定 baseline："Zen 2 IPC was X, here we're testing the claim of +19%" |
| 2 | The Core Complex, Caches, and Fabric | 架构图 + die shot + 与上代 split-L3 区别 |
| 3 | Front-end Updates | branch predictor / op cache / micro-op 改进 |
| 4 | Execution & Load/Store | 4 ALU + 3 AGU、LSU 改进、ROB 扩展 |
| 5 | Cache Hierarchy | latency 实测（不是 spec sheet 复读） |
| 6 | Memory Subsystem | DDR4 channel 测试 |
| 7+ | Benchmarks: SPEC2006 / SPEC2017 / Cinebench / 实应用 / power |
| 末 | Conclusions | hedged："better than Zen 2 in every meaningful way, but Zen 4 will be the bigger jump" |

**这个结构本身就揭示了他的思维链**：
1. 永远先建立 baseline 和声称
2. 永远架构 → 实测 → 结论的顺序，不颠倒
3. 永远拒绝把单一 benchmark 当总结
4. 永远 hedge 下一代

## 附录 B：More Than Moore Substack 主要类别

按主题归类他的 Substack 文章（来源：https://morethanmoore.substack.com 与 muckrack profile 综合）：

1. **CEO / 高管访谈类**：Gelsinger（多次）、Lisa Su、Jim Keller、Sam Naffziger、Ann Kelleher、Mike Clark
2. **公司战略评论**：Intel CEO letters、Q2 financials、AMD Advancing AI 综合、Apple Silicon roadmap
3. **冷门技术深 essay**：MEMS timing、quartz oscillator、semiconductor freight、PMIC、power delivery
4. **会议 transcript**：Intel Foundry Event Q&A、AMD Advancing AI Q&A、Hot Chips disclosure
5. **行业 meta**：Dylan Patel SemiAnalysis 被诉的评论（罕见同行评论）
6. **快讯 + 评论**：keynote 后短文、新品发布即时分析

## 附录 C：从他的写作框架推导出的"心智模型候选清单"（供 Phase 2 提炼参考）

候选 1：**架构 first（不是性能 first）** — 跨 Zen / M1 / Sapphire Rapids / MI300 deep-dive 反复出现
候选 2：**marketing name ≠ technical reality** — 跨 Intel 7 / TSMC N3E / SRAM scaling 反复出现
候选 3：**chiplet 是结构性变化** — 跨 Zen 2/3 / Sapphire Rapids / M1 Ultra / MI300X / Blackwell 反复出现
候选 4：**benchmark 怀疑论** — 跨多篇 review、多次播客出现
候选 5：**More than Moore（advanced packaging 是下一个十年）** — newsletter 标题 + 主题 + 多次访谈
候选 6：**fab 经济学第一性**（yield、wafer cost、HVM ramp）— 跨工艺评论反复出现
候选 7：**"看 unknown"**（"what the slide doesn't show"）— 跨多次访谈和文章

