# 05 · 关键决策 / 转折点 / 应验与失误案例

> 维度定位：这一节追踪 Ian 的"言行一致 / 预测验证"轨迹。
> 他公开材料中较少回顾"我两年前说对了 X"，但通过文章 + 推文 + 时间戳，可以反向重建他的判断轨迹。

---

## 一手来源（基于已发表文章 + 推文时间戳重建）

### 5.1 重大职业决策

#### 决策 1：离开 AnandTech 创立 More Than Moore（2022-02-18）
- **背景**：在 AnandTech 工作 11 年（2011-2022），从 reviewer 到 Senior Editor
- **触发**：行业广告模式持续恶化、SEO 主导的内容工业化、深度长文越来越难做
- **行动**：成立 More Than Moore（独立分析公司）+ TechTechPotato（YouTube）+ Substack newsletter
- **当时的判断**：
  - 长文 deep-dive 仍有需求，但传统 tech media 不再是合适载体
  - 半导体公司需要 third-party voice 帮助讲技术故事（这是 consulting 营收）
  - YouTube + Substack 直接面向终端读者，跳过 publisher
- **2 年后回看**（2024-08 AnandTech 关闭）：
  - 决策被强烈印证 —— 前东家完全关闭
  - 他没有以"我早就说过"的姿态回应，而是只说 "it gets a little emotional"
- **价值**：揭示他在职业转折点上的"安静下注"风格

#### 决策 2：选择 corporate consulting + paid newsletter，而非 pure media
- **对比**：
  - 纯 media 路线（GamersNexus）：retail audience、激烈批评 vendor、靠订阅 + sponsor
  - SemiAnalysis 路线：hedge fund / 大企业 paid 订阅
  - Ian 选择：semiconductor 企业 consulting（messaging / 技术沟通）+ Substack paid + YouTube ad
- **trade-off**：限制了他能多 aggressively 批评客户的程度，但保住了 inside access
- **结构性张力**：他不能完全"喷"任何一家 OEM —— 因为下个月可能就要 brief 他们

#### 决策 3：拓宽覆盖到冷门角落（MEMS / timing / freight / packaging）
- 2023-2025 newsletter 大量篇幅写 MEMS timing、晶圆物流、advanced packaging
- 这些是 mainstream 不报的话题，但是 IP 公司、equipment 公司、freight 公司有付费意愿
- **判断**：避开 NV/AMD/Intel/Apple 主战场（已饱和），跑到冷门赛道建立 unique authority

### 5.2 关键技术预测 / 判断（按时间）

#### 判断 A：Apple Silicon M1 "extremely plausible"（2020-11）
- **背景**：Apple 宣布弃用 Intel，转 ARM 自研
- **Ian + Andrei 文章**："Apple's Humongous CPU Microarchitecture" + "Apple Shooting for the Stars: x86 Incumbents Beware"
- **核心判断**：
  - Firestorm 是 8-wide microarchitecture（vs x86 主流 4-5 wide）
  - ROB 深度 ~630 instructions（A13 是 560）
  - 4 条 128-bit NEON pipeline 与 x86 desktop 对齐
  - Apple 的 "fastest CPU core" 主张 **extremely plausible**
- **应验**：M1/M2/M3/M4/M5 后续完全证实，Apple Silicon 性能与功耗远超当时 Intel 移动芯片
- **价值**：他用 spec/架构而非 PR 信任做出的早期 call，给他带来巨大声誉

#### 判断 B：Intel "5 nodes in 4 years" 怀疑论（2021-2024）
- **背景**：Pat Gelsinger 2021 上任，提出"5 节点 4 年"激进计划
- **Ian 立场**（多次推文 / 访谈）：
  - 不公开否认"做不到"，但反复要求 quantitative milestones
  - 在与 Pat 的 roundtable 反复问"EUV scanner 供给 / wafer cost / yield 数据"
  - "Tell me when, not if" 类型的提问
- **2024-2025 实际进展**：
  - Intel 7 已 HVM
  - Intel 4 / Intel 3 推迟但落地
  - 20A 跳过，直接押 18A
  - Panther Lake (18A 首发) 推到 2H 2025
- **Ian 在 2025-01 推文**：
  > "➡️ Launch of Panther Lake (18A lead product) in 2H 2025. ➡️ Intel Foundry is making on performance and yields."
  > —— https://x.com/IanCutress/status/1885087436746711364
- **判断回看**：他没说错（"5 in 4"实际是激进表述，落地略晚），他的 hedged 立场被印证

#### 判断 C：Intel 13/14代 i9 退化为 physical degradation 假设（2024-07）
- **背景**：业内多个用户报告 i9-13900K / 14900K 不稳定，最初怀疑是过激 PL2 设置
- **Ian 关键推文**（2024-07-14）：
  > "Been thinking about the root cause of the Intel CPU issues. It happens even on non-K/KS, even in stable environments. Wendell and I discussed privately about electromigration and degradation, but I'm starting to wonder if it's more physical than that."
  > —— https://x.com/IanCutress/status/1812809082148892806
- **应验**：Intel 数月后承认是 microcode + electromigration 问题，并发布 patch（已退化的不可逆）
- **价值**：他在公开 narrative 还在归因 motherboard 设置时，已 hedge 到 "physical" 层面

#### 判断 D：chiplet/tile 是结构性变化，不是渐进创新（多年）
- 从 AMD Zen 2 CCD（2019）开始反复打这个 thesis
- Sapphire Rapids tile（2021）写大长文 case study
- M1 Ultra UltraFusion（2022）"this is a chiplet question, not a node question"
- MI300X（2023）：he correctly framed it as "the chiplet integration is doing more work than the silicon scaling"
- **应验**：2024-2026 全行业（NV Blackwell B100/B200/GB200、AMD MI355X、Apple M5 Fusion）全部走向 chiplet/advanced packaging

#### 判断 E：Siri / Apple AI 落后的早期识别
- 2024 Apple Intelligence 发布时，他在播客中 hedge 了"this looks marketing-first, technology-second"
- 2026-01 Apple 接 Google Gemini 时，被业内视为对他早期判断的印证

### 5.3 失误 / 不准 / 修正案例

公开材料中 Ian 不常主动 retrospect 自己的错误，但可识别的修正：

#### 修正 1：Intel 10nm 早期判断
- 2014-2016 期间 Intel 10nm 反复推迟，Ian 早期在 AnandTech 较温和（仍信任 Intel 工艺承诺）
- 后期（2018-2020）逐渐转为强硬怀疑，建立"node name ≠ reality"框架
- **意义**：他的 anti-PR 立场是经验性形成的，不是天生的

#### 修正 2：Intel Arc GPU 早期乐观
- 2021-2022 Raja Koduri 主导 Arc 时，Ian 在多个访谈给较积极框架
- 后续 Arc Alchemist 性能不达预期、Raja 离职
- Ian 没有公开"打脸"自己，但在 podcast 中 dedicated 较少时间给 Intel GPU

#### 修正 3：Tenstorrent 路线评估
- 2021-2022 与 Jim Keller 长访谈中给出较 positive 框架
- 2024-2025 Tenstorrent 商业落地慢于预期
- Ian 没有公开否定，但 newsletter 中提及 Tenstorrent 频率下降

**关键观察**：他失误时不写"打脸"文章，但通过频率下降 / 话题转移、间接修正立场。这是英国式克制，也是商业利益（不能太公开 burn）的副产品。

### 5.4 立场演化（时间性矛盾）

| 话题 | 早期立场 | 近期立场 | 演化 |
|------|---------|---------|------|
| Intel 工艺 leadership | 信任（2014-2016 AnandTech 时期） | 怀疑（2020-2024） | 经验性 |
| Apple Silicon | 谨慎乐观（2020） | 强烈推荐架构（2021-2026 持续验证） | 一致 + 强化 |
| chiplet trend | 描述性（2019 Zen 2） | thesis 化（2022-2026） | 升格为核心信念 |
| AI accelerator startup | 高 enthusiasm（2022 Tenstorrent / Cerebras / Graphcore） | 更挑剔（2024-2026） | trim 过度乐观 |
| AGI/通用 AI hype | 完全回避（一直） | 仍回避 | 一致 |

### 5.5 行动一致性 vs 言论

- **行动**：他真的离开 AnandTech 创业；真的不去刷大众 podcast；真的在 paywall newsletter 上写最 deep 的东西
- **言论**：他公开说"我是 hardware guy not software guy"；公开说"我不预测股价"
- **一致**：高。他言行匹配度强 —— 该 hedge 的 hedge，该说"I don't know"的说，该拒绝的拒绝
- **反例**（个人小型）：偶尔他在 X 上 quote-tweet 一个 PR 时会有较锐利的措辞，但与 long-form 风格一致（不是另一个 Ian）

### 5.6 关键决策清单（一句话版）

1. **2011** 入职 AnandTech（PhD 一毕业就转记者，跳过博后/学术）
2. **2015** 升任 AnandTech Senior Editor（CPU/工艺主轴）
3. **2019** 开启 TechTechPotato YouTube channel（早期不温不火，但 set up 了渠道）
4. **2021-06** 启动 Jim Keller 系列长访谈（标志性的"独立 analyst 品牌"建设）
5. **2022-02-18** 离开 AnandTech，创立 More Than Moore + Substack
6. **2023-02** 一周年 LinkedIn 自评 "good, fun, intense"
7. **2024-02** Intel Foundry Direct Connect 1-on-1 Pat Gelsinger（标志性"被严肃对待"的 milestone）
8. **2024-07** Intel 13/14代退化 physical degradation 假设公开
9. **2024-08-30** AnandTech 关闭，Ian 发情感推文
10. **2025-03** HPCpodcast Ep 100 客串（行业认可"现状大评估"邀请）
11. **2025-07** RAISE Summit 2025 巴黎主舞台
12. **2026-Q1** Pat Gelsinger 离任后访谈、Lip-Bu Tan 上任 Intel CEO 报道
13. **2026-持续** 覆盖 Apple M5 / Intel Panther Lake / AMD MI355X / Nvidia GB200/GB300 / 各家 advanced packaging

---

## 二手来源

- LinkedIn 自述（一周年 / 离开 AnandTech / RAISE Summit speaker bio）
- HackerNews 历史 thread
- 业内 podcast 引用（HPCpodcast、somegadgetguy、ServeTheHome）

---

## 关键发现

1. **他的高价值预测都有 quantitative 锚定** —— Apple M1 8-wide、Intel 退化 physical、chiplet thesis；不是空喊
2. **他不公开 self-retrospect** —— 不写"我两年前说对了"系列，体现英式克制
3. **他失误时不写"打脸"文章** —— 通过频率调整修正，不公开否定旧立场
4. **他的职业决策（离开 AnandTech）是 calculated bet** —— 不是冲动，是结构性判断
5. **言行一致度高** —— 该 hedge hedge，该拒绝拒绝，该 skin in the game 的（自己创业）就上

## 我推断（标注）

- 推断 1：他较少公开 self-retrospect 既有英式克制原因，也有商业 / 个人原因 —— self-retrospect 容易引来"那这次你又错了什么"的拷问，对独立 analyst 是 PR 风险
- 推断 2：他的 chiplet thesis 押对，是因为他的 fab 经济学直觉 —— "单 die 良率 vs chiplet 良率 + packaging cost" 的权衡他早早算清
- 推断 3：他对 Tenstorrent / AI accelerator startup 的乐观调整，揭示他对"硬件好 ≠ 商业成功"的认知更新 —— software stack / 客户 adoption 才是真瓶颈
- 推断 4：他选择不预测股价 / 财务 / 时间表精确数字，是 hedging 自己的预测准确率被 retrospectively 评分的风险
- 推断 5：他对 AGI / 奇点 / 远期 AI 完全回避公开评论，是基于"不属于我的覆盖区，超出我的训练"的诚实边界，不是怯懦

---

## 附录 A：决策中体现的元规则（meta-heuristics）

观察上述所有决策的共同模式，可以提炼出 Ian 的元决策规则：

1. **量化优先**：所有判断必须有数字锚定（density、frequency、power、TOPS、yield）
2. **结构性 > 渐进性**：押注架构变化（chiplet）> 押注规模化迭代（更快 clock）
3. **hedged but directional**：表达上 hedge，方向上明确
4. **拒绝预测精确时间**：押节奏不押日期（"by mid-decade" 而非 "by Q3 2026"）
5. **沉默 = 不知道**：不知道就不写，不撑场面
6. **修正不张扬**：错了就少提，不写"打脸文"
7. **承认弱点**：软件栈是弱区，他公开说，不伪装

## 附录 B：未公开但可推断的判断（供 skill 使用者参考）

基于他的模式 + 当前行业状态，他在 2026 年很可能持以下立场（标注为"推断"，使用时需让用户验证）：

- **Intel Foundry**：18A 量产前景比 Pat Gelsinger 时期承诺更现实，但客户 tape-out 数量仍是 2026-2027 关键 KPI
- **Apple Silicon**：M5 Fusion Architecture 是 advanced packaging 路线的延续，不是革命；下一个跳跃要等 angstrom-era 节点 + 完全 chiplet
- **NV vs AMD GPU**：硬件差距缩小，软件 stack 差距仍是结构性，AMD ROCm 至少还要 2-3 年才能威胁 CUDA
- **HBM**：HBM4 周期内 supply 仍紧，3D stacking / co-packaged optics 是下一关键点
- **中国半导体**：SMIC 的 7nm 类似工艺已存在，但 EUV 限制下 5nm 以下短期难实现 HVM
- **chiplet IP marketplace**：仍处于早期，标准化（UCIe）落地慢于预期

**强约束**：这些是从他的框架推断的，不是他本人 verified 的判断。

