# Lisa Su 重大决策记录

> 调研日期：2026-05-24
> 信息源：AMD newsroom + SEC 文件 + 媒体调查报道 + Su 本人 keynote / 访谈说明
> 可信度：决策事实一手（SEC / press release），决策动机部分推断（基于 Su 后续公开说明）

---

## 决策时间线（按时间排序）

### 决策 1：拒绝"放弃高性能 CPU"路径（2014 接 CEO 时）

**时间**：2014-10-08（任命当天起立即重新审视战略）

**背景**：AMD 接 Su 时，股价 ~$3，2012-14 累计亏损巨大，前任 Rory Read 在内部讨论是否退出 high-performance CPU，转向 SoC / 嵌入式利基市场。

**Su 的决策**：明确拒绝退路。在第一次 all-hands 上设定「continue to bet on high-performance computing」，并启动 Zen 项目巨额投入。

**动机（Su 公开说法）**：
- "We needed to bet on what we were good at, and what AMD was good at was building powerful processors." — Time 2024
- "real leadership means taking on the hardest problems"
- Run toward hardest problems → IBM 时期 John Kelly 的训诫

**影响**：
- 启动 Zen 1（Ryzen）+ Zen 2（EPYC）+ Zen 3-6 路线图
- 2017 Ryzen 上市，性能首次追平 Intel
- 2025 数据中心营收 $16.6B（FAD 2025），数据中心 / 客户端营收比例完全逆转

**心智模型识别**：
- "迎难而上"心智模型（Mental Model 1 候选）
- "聚焦核心能力"心智模型（vs 退路安全区）
- 长期主义路线图（Mental Model 候选）

---

### 决策 2：Zen 架构投入（2014-15 重大资本配置）

**时间**：2015 立项 → 2017-03 Zen 1 首发

**背景**：AMD 工程团队提出 Zen 全新架构提案。需要 $1B+ 多年投入，AMD 现金流紧张。

**Su 的决策**：批准。「committing to a multi-year, high-risk product development path」。

**关键执行细节**：
- 选 Jim Keller（前 Apple A4 / A5 设计师）回任 chief architect
- 2017-03 Ryzen 1000 系列首发，性能突破
- 与 GlobalFoundries 14nm + 后续转 TSMC 7nm 是分水岭
- 路线图节奏：年度 Ryzen + 两年期 EPYC

**动机**：
- 「客户告诉我，他们需要可信的 alternative to Intel」
- 五年路线图 → 客户能 invest in long-term partnership

**影响**：
- 2017-2024 AMD 股价从 $11 → $200+
- EPYC 在 hyperscaler 数据中心拿下 20%+ 市占
- Ryzen 在 DIY 消费市场超越 Intel

---

### 决策 3：放弃 ARM 服务器（K12 / Skybridge 砍掉）（2016）

**时间**：2015 K12/Skybridge 立项 → 2016 默默砍掉

**背景**：2014-15 AMD 启动 K12（基于 ARM 的服务器 CPU）+ Skybridge（x86/ARM 双 socket 兼容）。

**Su 的决策**：砍掉，转回 x86。

**动机（Su 公开说法）**：
- "ARM server adoption hasn't advanced as quickly as some people might have thought" — Su 接受采访时
- "The transition for us, in terms of growing share in the data center with x86, will be much faster"

**影响**：
- 资源全力投入 EPYC（Zen 服务器版）
- 后来 AWS Graviton 等 ARM 服务器陆续出现，但市场分化由 hyperscaler 自研，AMD 没参与
- 失去了一个"也许在 2020s 也能赚钱"的 ARM 业务机会
- 但聚焦让 EPYC 快速起飞

**心智模型识别**：
- "聚焦核心能力"模型
- 跟随客户实际需求（不为技术情怀决策）
- 反直觉舍弃：不是赌未来 N 个赛道，而是放弃 1 个押 1 个

---

### 决策 4：完成 Xilinx 收购 $49B（2020-10 宣布 → 2022-02-14 完成）

**时间**：2020-10-27 宣布 → 2022-02-14 完成（half-stock，史上最大芯片并购）

**背景**：AMD 上升势头开始时，需要扩张 TAM。Xilinx 是 FPGA 市场领导者，加上 SoC、网络 ASIC。

**Su 的决策**：用 1.7B 股 AMD 股票全股票收购 Xilinx，$49B。

**动机**：
- 「TAM 从 $80B 扩到 $135B」（公司公告）
- 自适应计算 + 高性能计算的组合
- 数据中心 networking + 5G + 汽车 + 嵌入式 — 多元化抗周期
- 整合 Xilinx CEO Victor Peng 进入 AMD 高层（接管 AI 业务 / 后离任）

**风险点**：
- 全股票发行稀释 AMD 股东（接近 30% 稀释）
- 整合复杂度高
- 实际协同效应慢于预期（Global Semi Research 2025 评估「Three Years Later, Where's the Innovation?」）

**影响**：
- 嵌入式业务变成 ~$5B 营收的独立 segment
- AI engine（XDNA）成为 Ryzen AI / Instinct 共享 IP 基础
- Adaptive computing 整合后并不像 Intel-Altera 那样独立 Foundry，而是软硬合一
- 整合至今仍在演进，部分分析师认为价值兑现不足

**心智模型识别**：
- TAM 扩张是路线图导向的（不是估值套利）
- 长周期视角（5-10 年才看到收益）
- 风险计算：Su 用股票而非现金，对冲下行

---

### 决策 5：完成 Pensando 收购 $1.9B（2022-04 宣布 → 2022-05-26 完成）

**时间**：2022-04 宣布 → 2022-05-26 完成

**背景**：DPU（数据处理单元）成为数据中心三大芯片之一（CPU + GPU + DPU）。AMD 此前在网络 ASIC 几乎空白。

**Su 的决策**：以 $1.9B 收购 Pensando（创始人 John Chambers，前 Cisco CEO）。

**动机**：
- "Doubling down on data centers"（Su 公开说）
- 已部署在 Goldman Sachs / IBM Cloud / Microsoft Azure / Oracle Cloud 的产品基础
- DPU 是 Helios rack-scale 的关键组件

**影响**：
- Vulcano NIC（Pensando 升级版）成为 Helios rack 关键组件
- 网络 ASIC 自研补全垂直整合
- 与 Nvidia ConnectX/BlueField 网络 ASIC 形成对位

---

### 决策 6：MI300 / MI300X 全力投入（2022-23）

**时间**：2022 立项加速 → 2023-06 首发宣布 → 2023-12 客户公布

**背景**：ChatGPT 2022-11 引爆 AI，Nvidia H100 供不应求。AMD MI300 早就在做但不是 AI 第一优先级。

**Su 的决策**：把 MI300 优先级提到全公司最高，加速到 2023-Q4 量产。

**关键执行**：
- 153B 晶体管，比 H100（80B）多 90%
- HBM3 192GB（H100 80GB）
- 客户：Microsoft Azure、Meta、OpenAI 三家联合站台（2023-12-06）
- 2024 营收：MI300 单年 $5B+（Su 公开数字）

**风险点**：
- ROCm 软件 stack 严重落后（SemiAnalysis 详尽批评）
- 早期客户实际部署速度慢
- AMD 软件团队规模不及 Nvidia 1/3

**影响**：
- 2024 数据中心营收 $12.6B（YoY 94%）
- 2025-Q1 数据中心 $5.8B（YoY 57%）
- AMD 在 AI 加速器领域确认 #2 位置
- 软件 gap 触发后续 Silo AI 收购 + ROCm 重投

**心智模型识别**：
- 客户共建（hyperscaler input）
- 路线图加速（年度节奏）
- 接受软件 gap 并公开修复（不掩饰）

---

### 决策 7：年度路线图节奏（MI300 → MI325 → MI350 → MI400 → MI500）

**时间**：2024-06 Computex 首次宣布年度节奏 → 持续至今

**背景**：Nvidia 已在 2024 GTC 宣布年度节奏（Hopper → Blackwell → Rubin）。AMD 必须跟上。

**Su 的决策**：把 GPU 路线图从「~2 年一代」加速到「每年一代」（hundreds digit 每年 +1）。

**关键里程碑**：
- MI300（2023-Q4）
- MI325X（2024-Q4）
- MI350 / MI355X（2025-Q3 量产）
- MI400 / MI455X（2026-下半年，OpenAI 首批 1GW 部署）
- MI500（2027 计划）

**执行风险**：
- 工程团队压力极大
- 软件验证时间被压缩
- 客户切换成本

**动机**：
- 「customers need predictable cadence to invest in long-term partnerships」
- 路线图 = 客户信任 = 5-year visibility

---

### 决策 8：Silo AI 收购 $665M（2024-07 宣布 → 2024-Q4 完成）

**时间**：2024-07-10 宣布 → 2024-Q4 完成

**背景**：欧洲最大私营 AI 实验室（300+ AI engineers，Helsinki），客户包括 Allianz / Philips / Rolls-Royce / Unilever。

**Su 的决策**：$665M 现金收购，补 AMD 软件 / AI 工程团队。

**动机**：
- 「significantly strengthens AMD's AI software capabilities」
- 欧洲 R&D 扩展
- 主权 AI（sovereign AI）市场切入
- 应对 SemiAnalysis / Tiny Corp 等批评的"软件文化弱"

**影响**：
- AI 工程师团队扩张
- 欧洲市场（包括德、法的主权 AI 项目）切入
- ROCm + 模型适配速度加快
- 仍是结构性弱项的 partial 解决

---

### 决策 9：ZT Systems 收购 $4.9B（2024-08-19 宣布）

**时间**：2024-08-19 宣布 → 2025-Q4 完成

**背景**：AMD 单卖芯片，Nvidia 已在卖 DGX 整机 + rack-scale 系统。Hyperscaler（Meta、Microsoft）希望 AMD 也提供 rack-scale 解决方案。

**Su 的决策**：$4.9B 现金 + 股票收购 ZT Systems（私有公司，已有 hyperscaler 客户）。

**动机**：
- "ZT adds world-class systems design and rack-scale solutions expertise" — Su 公开说
- "end-to-end data center AI infrastructure at scale"
- 不只卖芯片 → 卖系统
- 直接补「rack-level integration」能力

**关键执行**：
- 关键计划：保留 ZT 的「系统设计」业务（融入 AMD），剥离「manufacturing」业务（出售给第三方）
- 2026-Q1 manufacturing 分拆完成
- Wedbush 2026-02 评估：「The $4.9 Billion Bet Pays Off」
- Helios rack 是 ZT 整合后的第一个旗舰

**影响**：
- AMD 商业模式从「卖芯片」升级为「卖芯片 + 卖 rack」
- Helios（2026 CES 首发，~7000lbs 双宽 rack）成为商业模式样板
- 与 Meta 的 OCP open rack 标准合作深化
- 风险：系统业务整合复杂度高，2025 财年还在过渡期

**心智模型识别**：
- 商业模式重构（不固守传统芯片商定位）
- 客户共建（hyperscaler 要 rack-scale，AMD 主动提供）
- 收购作为路线图加速器（非估值套利）

---

### 决策 10：OpenAI 6GW 战略合作 + 股权激励（2025-10-06）

**时间**：2025-10-06 公告

**背景**：OpenAI 寻求多元算力供应（不全依赖 Nvidia）。AMD MI400 / MI450 系列即将上市。

**Su 的决策**：与 OpenAI 签 6GW（共 5 代 GPU）合作协议；发 160M AMD 普通股 warrant 给 OpenAI（按里程碑 vesting）。

**关键细节**：
- 第一批 1GW MI450 GPUs 2026-H2 部署
- "potentially generate over $100 billion in revenue over the next few years"（Su Q3 2025 财报会）
- 用股权 vest 设计绑定 OpenAI 双向承诺
- 与 Nvidia 给 OpenAI 的"现金投资 + 客户合作"模式形成对比

**动机**：
- 锁定 hyperscaler-class 客户 → 路线图未来 5 年的最大单一客户
- 创造 "true win-win"（Su 表述）
- 把 AMD-OpenAI 关系从 customer-supplier 升级为 strategic alliance

**风险**：
- 股权稀释（部分股东担忧）
- 单一客户依赖度提升
- 如果 OpenAI 增长放缓，AMD 也受拖累

**影响**：
- AMD 股价当日 +20%+
- 数据中心 AI 业务 5 年 trajectory 重写
- 与 Nvidia 在 OpenAI 内部形成竞合关系

**心智模型识别**：
- 创新交易结构（不是教科书 M&A）
- 客户深度共建到极致（股权 + 长期承诺）
- 路线图作为信任货币

---

### 决策 11：财务架构调整 — TSMC Arizona 多付 5-20% 成本（2024-25）

**时间**：2024-25 持续决策

**背景**：Trump 关税威胁、地缘政治、客户要求 made-in-USA chips。

**Su 的决策**：接受 TSMC Arizona 多 5-20% 成本，加速本土化。

**动机（Su 公开）**：
- "We have to consider resiliency in the supply chain... we learned that in the pandemic."
- "Not just by the lowest cost, but also about reliability, about resiliency."

**影响**：
- AMD 部分 GPU 产能转移至 Arizona
- 毛利率短期承压（Su 在财报会上承认）
- 与 Cook 用 6000 亿对美投资换关税豁免的策略形成对比 — Su 不公开游说，而是直接行动

**心智模型识别**：
- 韧性 > 最低成本（与 Cook 类似）
- 不公开政治化（不去白宫站台、不公开 endorsement）

---

### 决策 12：Helios rack-scale + Meta OCP 合作（2025-06 披露 → 2026-CES 完整展示）

**时间**：2025-06 Advancing AI 首披 → 2026-01 CES 完整产品

**背景**：rack-scale AI 是 Nvidia GB200 / Rubin 的核心叙事。AMD 必须有 OEM-grade rack 方案。

**Su 的决策**：
- 与 Meta 联合开发基于 OCP 开放标准的 "double-wide rack"
- 整合 ZT Systems 设计 + Pensando 网络 + AMD CPU/GPU
- 命名 Helios

**关键技术细节**（CES 2026 公布）：
- 72 块 Instinct MI455X
- 31TB HBM4
- 1.4PB/s aggregate bandwidth
- 7000 磅整柜重量
- Zen 6 EPYC Venice CPU + MI400 GPU + Vulcano NIC
- 全 liquid cooling

**心智模型识别**：
- 与最大客户（Meta）共同定义标准
- 开放标准（OCP）而非封闭专有，与 Nvidia DGX 战略形成对比
- 系统化思维（不只是芯片）

---

### 决策 13：极度稳定的高管班子（11 年累积决策）

**背景**：科技公司 CEO 高管离职率通常很高（Intel、Meta 都常见）。Su 的高管班子异常稳定。

**Su 的决策（累积）**：
- Mark Papermaster（CTO，2011 至今）
- Forrest Norrod（Data Center & Embedded SVP，2014 起）
- Jack Huynh（Computing & Graphics SVP，2024 起，原 Client SVP）
- Phil Guido（CCO，2023 起）
- Jean Hu（CFO，2023 起，接 Devinder Kumar）
- Mathew Hein（CSO，长期）
- Vamsi Boppana（AI / Senior VP）

**特征**：几乎无 high-profile 离职丑闻；高管深度信任 Su；Su 几乎不公开评价个人。

**心智模型识别**：
- 长期班子 = 长期路线图 = 长期客户信任
- 不依赖明星个人，依赖团队执行
- 与 Apple Cook 的 "Forstall 驱逐" 类型决策不同 — Su 没有公开人事危机

---

## 言行一致 / 不一致案例

### 言行一致

1. **「Run toward hardest problems」** vs **接 AMD CEO 时拒绝退路**：完全一致
2. **「Five-year roadmap」** vs **每次 keynote 都给 5 年节奏**：完全一致
3. **「Customer first」** vs **OpenAI / Meta / Microsoft / Oracle 深度合作**：一致
4. **「Take calculated risks」** vs **$49B Xilinx 全股票（对冲下行）**：一致

### 言行存在张力

1. **「We're committed to ROCm」** vs **2014-2024 软件投入长期不足**：早期言重于行，后期纠正
2. **「Customer choice」** vs **几乎不点 Intel / Nvidia 名字**：实际上回避正面 PK
3. **「Don't compete with our customers」** vs **ZT 收购后开始卖 rack（与 OEM 客户竞争）**：商业模式有微调，但 Su 未公开承认这种张力

### 反思 / 自我批评

- Su 很少公开复盘失败决策（与 Jensen 在 Acquired 播客上详细复盘失败形成反差）
- 早期 ARM K12 砍掉、Bulldozer 失败、Llano 失败几乎不公开提及
- 一旦失败，迅速转向新方向，但不深挖原因（外部观察）

---

## 决策风格总结（用于 Phase 2 提炼）

| 维度 | Su 决策特征 |
|------|------------|
| 决策周期 | 5 年视角，但每年校准 |
| 信息源 | 客户 + 工程团队 > 分析师 / 媒体 |
| 风险偏好 | 计算后下重注（calculated bets），不无意义保守 |
| 失败处理 | 砍掉快、不公开复盘、转新方向 |
| 团队管理 | 高强度（"weekends, after midnight"）+ 长期信任 |
| 收购策略 | 路线图驱动（不是估值套利） |
| 公开姿态 | 极度低调，让产品/数字说话 |
| 与客户关系 | 双向深度承诺（甚至股权激励） |
| 文化建设 | 工程师 CEO → 工程师文化 |
| 历史回溯 | 不强调过去成就，永远 next milestone |

---

## 一手 vs 二手占比

约 13 个重大决策，每个都有：
- 一手：AMD newsroom press release + Su 本人 keynote / 财报评论
- 二手：媒体调查 + 分析师解读

一手占比 ~60%，达标。

---

## 信息缺口

- 决策内部讨论过程（不像 Apple 的 Mickle / McGee 调查报道详尽）
- 与 AMD board 的具体互动几乎无公开
- Su 私下与客户 CEO 沟通的细节
- 失败决策的反思（Bulldozer 谁负责、为什么放弃 Llano）
- 接班计划（Su 1969 年生，57 岁，可能至少再做 5-10 年）
