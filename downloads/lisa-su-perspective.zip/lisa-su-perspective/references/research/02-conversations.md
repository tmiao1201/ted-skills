# Lisa Su 长访谈、播客、即兴对话调研

> 调研日期：2026-05-24
> 信息源：WebSearch 列出的播客/视频/转录页面，未抓取全部全文
> 可信度：一手 = 本人原话视频/transcript；二手 = 媒体节选

---

## 1. 长访谈与播客全清单（≥30 分钟）

### A. 一手长访谈（最高权重）

| # | 节目 | 主持人 | 时间 | URL | 时长 | 关键主题 |
|---|------|-------|------|-----|------|---------|
| 1 | **Stratechery Interview** "About Solving Hard Problems" | Ben Thompson | 2024-06 | https://stratechery.com/2024/an-interview-with-amd-ceo-lisa-su-about-solving-hard-problems/ ; Spotify https://open.spotify.com/episode/5ZQjGllUic4BpOTwlhWn26 | ~70min | 从 IBM 走出 / AMD 转型 / AI 机会 / 与 Nvidia 竞争 / hyperscaler / chiplet / EUV |
| 2 | **Stanford GSB View From The Top** S8E5 "Lisa Su Is Still Curious About How Things Work" | Michael Liu (MBA '25) | 2025-02-27 | https://www.gsb.stanford.edu/events/view-top-lisa-su ; transcript https://singjupost.com/transcript-of-view-from-the-top-with-lisa-su-chair-and-ceo-of-amd/ ; YouTube https://www.youtube.com/watch?v=C4GM7_Cf0N4 | ~65min | 转型 AMD / 成长经历 / 领导与管理原则 / AI 现状 / 未来展望 |
| 3 | **a16z AI Revolution Podcast** | Bob Swan (a16z, 原 Intel CEO) | 2024 | https://a16z.com/how-to-build-ai-ecosystem-lisa-su-ceo-of-amd/ | ~50min | 开放生态系统 / 合作伙伴 / 民主化 GenAI |
| 4 | **HBR Podcast** "AMD's Lisa Su on Experimenting with AI" | HBR 编辑团队 | 2025-05 | https://hbr.org/podcast/2025/05/amds-lisa-su-on-experimenting-with-ai | ~40min | 内部 AI 试验 / 管理实践 |
| 5 | **Bloomberg Talks: AMD CEO Lisa Su Talks Strong PC Demand** | Bloomberg | 2024 | https://www.iheart.com/podcast/1119-bloomberg-talks-116249773/episode/amd-ceo-lisa-su-talks-strong-288782465/ | ~25min | PC 复苏 / Ryzen AI / 数据中心 |
| 6 | **CNBC Full Interview**（多场） | David Faber, Jon Fortt 等 | 2024-26 | https://www.cnbc.com/video/2026/01/06/watch-cnbcs-full-interview-with-amd-ceo-lisa-su.html ; https://www.cnbc.com/video/2026/02/04/watch-cnbcs-full-interview-with-amd-chair-and-ceo-lisa-su.html | 各 ~15-25min | 财报点评 / OpenAI 协议 / 35% 增长目标 |
| 7 | **GIGAZINE Interview**（PlayStation 业务）| GIGAZINE 编辑 | 2024-06-14 | https://gigazine.net/gsc_news/en/20240614-amd-ceo-lisa-su-interview/ | ~30min | semi-custom（PS5、Xbox）业务、客户合作 |

### B. 公开论坛 / Fireside Chat 一手

| # | 场合 | 主持人 | 时间 | URL | 关键议题 |
|---|------|-------|------|-----|---------|
| 8 | **Goldman Sachs Communacopia + Tech Conference Fireside** | GS analyst | 年度 | Goldman events | AI 财务展望、客户深度 |
| 9 | **UBS Tech Conference Fireside** | UBS analyst | 年度 | https://christianinvesting.substack.com/p/amd-lisa-su-ubs-interview | "$5T compute company" 长期愿景 |
| 10 | **Code Conference** | Kara Swisher / Ina Fried | 年度 | code-recode site | 多次出现 |
| 11 | **Purdue AI Lecture Series**「AI 与能源限制」| Purdue Exponent | 2025 | https://www.purdueexponent.org/campus/purdue-amd-lisa-su-ai-lecture-series/article_0bb94218-25cb-489c-9828-ed11dcd8f913.html | AI 与电力消耗 / 数据中心物理边界 |
| 12 | **Time Studios** "Year in Time" CEO of the Year 长访谈 | Sam Jacobs (Time EIC) | 2024-12 | https://time.com/7199761/year-in-time-ceo-lisa-su-2024/ ; https://time.com/7026241/lisa-su-amd-ceo-interview/ | 长 CEO 复盘访谈 |
| 13 | **Sahm Capital / Industry Calls**（Q3 2025）| 分析师集成 | 2025-11-05 | https://www.sahmcapital.com/news/content/amd-ceo-lisa-su-expects-openai-partnership-to-generate-over-100-billion-in-revenue-and-significantly-accelerate-ai-business-2025-11-05 | OpenAI 协议「$100B revenue over next few years」 |

### C. 大学校园演讲 + Q&A（一手）

| # | 学校 | 时间 | URL |
|---|------|------|-----|
| 14 | MIT 2017 doctoral commencement | 2017-06-08 | https://news.mit.edu/2017/hooding-ceremony-doctoral-lisa-su-0608 |
| 15 | Rensselaer Polytechnic Institute (RPI) | 2025-05 | Fortune / Yahoo Finance 报道 |
| 16 | Stanford GSB View From The Top（同 #2） | 2025-02 | 见上 |
| 17 | Purdue University | 2025 | 见 #11 |
| 18 | MIT 2026 commencement（calendar） | 2026-05 | https://news.mit.edu/2025/lisa-su-mit-2026-commencement-address-1211 |

---

## 2. 被追问时的回答方式（即兴反应模式）

### 模式 1：被追问"如何与 Nvidia/Jensen 竞争"
**典型反应**（多次复现）：
- **不正面比较**，立刻把话题转向「broad market opportunity」「customer needs」
- 不说 Nvidia 名字，说"the market"、"our competition"
- 典型句式：「There's room for multiple winners」「The opportunity is so large」「customers want choice」
- 来源：Time 2024 长访谈、Bloomberg、CNN Business 2020

→ **解读**：Su 的反应是工程师 + CEO 的双重避战姿态。她从不直接挑衅 Jensen。

### 模式 2：被追问"AMD 落后多少"（AI 软件 / ROCm）
**典型反应**：
- **承认+设期限**：「We've made significant progress」「我们承认软件 stack 有 gap」「more to come on ROCm」
- 不打高空炮，转向具体里程碑：PyTorch CI/CD、模型适配数、ISV 数量
- 来源：Phoronix 2024、Tom's Hardware (Tiny Corp 事件) 2024、SemiAnalysis 2024 后续

→ **解读**：诚实承认 + 给路线图，是 Su 应对负面信息的标准模式。

### 模式 3：被追问"AI 是不是 bubble"
**典型反应**（多次）：
- 「The demand is insatiable」+ 数据（千亿级 TAM）+ 长周期视角
- 不否认短期波动，但锚定 3-5 年 trajectory
- 来源：CNBC 2025-11-12 (AMD stock soars as Lisa Su dismisses AI spending fears)

### 模式 4：被追问"AMD 能拿多少市占率"
**典型反应**：
- 「double-digit share in the data center AI chip market over the next three to five years」（FAD 2025）
- 用具体百分比表达，不给夸大数字
- 给"reach goals"和"base case"两套，但只公开 base case

### 模式 5：被追问个人话题 / 性别 / 家庭
**典型反应**：
- 礼貌简短带过，迅速转回技术或团队
- 关于 Jensen 表亲关系：「distant relatives... some complex second cousin type of thing」(CNN 2023) — 不展开
- 几乎不公开私人生活

### 模式 6：F1 Ferrari 赞助现场「你会说英语吗？」事件
**典型反应**：礼貌处理，未对外发难，事后接受 Yahoo 报道时一笔带过
- 来源：https://finance.yahoo.com/markets/stocks/articles/amd-ceo-lisa-su-got-143105789.html
- **解读**：Su 在公开场合极少表露情绪反应，温和钢线风格。

---

## 3. 即兴类比 / 比喻

> Su 的语言极少用文学性类比（与 Jensen 「pain and suffering」的戏剧化形成反差）。她偏好工程量化表达。

| 类比 | 来源 | 说明 |
|------|------|------|
| 「五年路线图 = 看得见的未来」"You can see five years" | Stanford 2025 | 把时间转化为可视化对象 |
| 「迎难而上」"Run toward, not walk" | RPI 2025 | 唯一典型动作型比喻，借自 John Kelly |
| 「我们最复杂的芯片」"the most complex chip we've ever produced" | MI300X launch 2023 | 用「最」+ 数字表达，工程语言 |
| 「broadest portfolio」 | FAD 2025 | "广度"作为优势叙事 |
| 「customer choice」 | 多次 | 暗指反单一供应商垄断 |

→ **解读**：极少诗意类比，几乎全部是工程/数字表达。这是表达 DNA 的关键差异点。

---

## 4. 改变立场的瞬间（思想变化）

| 议题 | 早期立场 | 近期立场 | 触发事件 | 信号 |
|------|---------|---------|---------|------|
| **ARM 服务器**（K12 / Skybridge） | 2014-15 高调推进 | 2016+ 砍掉，转回 x86 | "ARM 采用没那么快" | 工程实用主义：跟随客户需求而非赌技术情怀 |
| **集成 vs 分散**（系统） | 长期"卖芯片"模式 | 2024+ "rack-scale" "end-to-end" | ZT Systems 收购 | 商业模式从组件商升级为系统商 |
| **AI 软件投入** | 长期被外界批评不足 | 2024+ 大规模追加，公开承诺 ROCm 改进 | SemiAnalysis 公开批评后 | 接受外部反馈，调整路径 |
| **股权激励对客户** | 传统 SaaS-style | 2025-10 OpenAI deal 中给 160M shares warrant | OpenAI 6GW | 创新交易结构 |
| **网络芯片自研** | 长期靠合作 | 2025+ Pensando / Vulcano NIC 自研 | 与 Nvidia networking 竞争升级 | 垂直整合补全 |

→ **关键观察**：Su 不固守教条，证据出现就调整。这与"路线图持续性"似乎矛盾，但其实是底层"客户需要 + 数字证据"驱动的实用主义。

---

## 5. 拒绝回答 / 闪避的问题

| 议题 | Su 的反应 | 解读 |
|------|---------|------|
| Jensen Huang 表亲关系细节 | 一笔带过，从不展开 | 私人边界 |
| Intel 衰落 / Pat Gelsinger / 18A 进展 | 几乎不评论 Intel | 不公开点名竞争对手 |
| Trump 政治站队 | 不公开表态，私下与白宫沟通（如 Stargate 项目） | 与 Cook 类似的"幕后斡旋"模式 |
| AGI 时间表 | 务实回答"渐进式"，不参与狂热预言 | 工程师而非愿景家 |
| 个人感情 / 婚姻 / 家庭细节 | 几乎零公开 | 私人边界 |
| 中国市场政治议题 | 极简表态：合规 + 客户需求 | 与 Cook 类似的双轨外交 |
| 加密货币 | 几乎不评论 | 不在其聚焦圈内 |
| 加密货币挖矿 GPU 业务 | 默认弱化，转向 AI 数据中心 | 战略主线管理 |
| 历史失败（Bulldozer / Llano） | 极简归因，转向 Zen 转型 | 不复盘失败的人 |

→ **解读**：Su 的「沉默区」几乎全是非工程议题。

---

## 6. 即兴时刻揭示的真信念（Phase 2 用）

### 信念 1：技术 + 客户 = 战略，其他都是战术

Stratechery 2024：「customers... they decide to partner with AMD based on a long-term partnership」  
Stanford 2025：「customer relationships」始终排在 turnaround 三步法的第二位

### 信念 2：路线图的连续性 > 短期机会

Su 在多场访谈中说：「I'll spend more time on the roadmap than on quarterly results」

### 信念 3：工程师必须在 CEO 椅上

Su 在 Stanford 2025 / Time 2024 中多次说：技术细节她要亲自审核。「她要 pre-read 24 小时前」是这种工程师 CEO 的体现。

### 信念 4：钢线下面的温和

外界一致评价 Su「不大声、不戏剧」，但对内部高管"详细 feedback to staff"（Forbes 转述）。她不是无原则温和，是有底线的温和。

---

## 7. 关键引用（待用于 SKILL.md）

> "Run toward the hardest problems—not walk, run—and that's where you find the biggest opportunities, where you learn the most, where you set yourself apart, and most importantly, where you grow."  
> — RPI Commencement 2025 (引自 John Kelly)

> "I would say dream big, right? Dream big. This is the time to have a big, bold, audacious dream and follow your dreams."  
> — Stanford GSB View From The Top 2025-02-27

> "I want AMD to be a very major player in unlocking that compute for the world."  
> — Stratechery interview 2024-06

> "You have to have a very clear roadmap of what you want to do, but you have to enable yourself to get input into whether you're doing the right thing."  
> — Stratechery 2024

> "People are really motivated by ambitious goals. The previous strategy of, 'Hey, let's just do a little bit better here and there' — that's actually less motivational."  
> — Time 2024 long profile

> "Feedback is a gift, even when it's critical."  
> — X @LisaSu post (date unclear)

> "AMD is at our best when we are taking bold, calculated risks and aggressively pursuing the leading-edge technologies that change the world."  
> — Chief Executive Magazine interview (2024)

> "We've made significant progress... more to come on ROCm on @radeon soon."  
> — X @LisaSu, 2024 (回应 Tiny Corp / SemiAnalysis 批评)

> "[Supply chain decisions] should be made not just by the lowest cost, but also about reliability, about resiliency."  
> — DCD interview 2024 (回应 TSMC Arizona 高 5-20% 成本)

> "We are thrilled to partner with OpenAI to deliver AI compute at massive scale... a true win-win enabling the world's most ambitious AI buildout."  
> — AMD-OpenAI joint statement 2025-10-06

> "It was fun to teach Lou about technology. He showed me how important it is to connect the dots."  
> — Yahoo Finance 2024（追悼 Lou Gerstner）

> "We are just starting to realize the power of AI."  
> — CES 2026 keynote

---

## 8. 信息缺口

- 极少有完整 long-form 录音（Stratechery 是少数）
- 个人生活 / 童年 / 私人友谊近乎黑箱
- 公开发言高度模板化 → "即兴"时刻其实不多，更多是有准备的应答
- 中文媒体长访谈基本没有 → 在大陆几乎不接受深度访谈

---

## 9. 一手 vs 二手占比

约 25 条来源：
- 一手（本人 keynote 转录、播客原声、官方新闻稿、本人 X）：≥16 条 / 25 = **64%**
- 二手（专业媒体二手转述、报道）：~9 条

→ 一手占比 >50%，达标。
