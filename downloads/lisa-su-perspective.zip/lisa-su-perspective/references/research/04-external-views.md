# Lisa Su 外部视角：媒体特写、行业评论、前同事观察、批评

> 调研日期：2026-05-24
> 信息源：Time / Fortune / Bloomberg / WSJ / CNBC / 学术媒体 / 独立分析师（SemiAnalysis, Stratechery）
> 可信度：二手为主，但优质媒体经过编辑严审；本文件目的是补一手的不足

---

## 1. 标志性长篇人物特写（最高权重二手）

| # | 媒体 | 标题 | 时间 | URL | 作者/角度 |
|---|------|------|------|-----|----------|
| 1 | **Time** | Lisa Su Is TIME's 2024 CEO of the Year | 2024-12-11 | https://time.com/7200909/ceo-of-the-year-2024-lisa-su/ | Sam Jacobs (Time EIC) 长访谈 |
| 2 | **Time** | CEO of the Year Lisa Su Discusses the Semiconductor Industry | 2024-12 | https://time.com/7199761/year-in-time-ceo-lisa-su-2024/ | 长 Q&A |
| 3 | **Time 100 Most Influential 2025** | Lisa Su | 2025-04 | https://time.com/collections/100-most-influential-people-2025/7273802/lisa-su/ | 入榜 |
| 4 | **Time** | Lisa Su on AMD's Strategy for Growth and the Future of AI | 2024-10 | https://time.com/7026241/lisa-su-amd-ceo-interview/ | 战略访谈 |
| 5 | **Fortune** | Who is Lisa Su? Time's CEO of the year 2024 holds meetings on weekends and is related to Nvidia's CEO Jensen Huang | 2024-12-18 | https://fortune.com/2024/12/18/lisa-su-amd-ceo-share-price-jensen-huang/ | 长篇汇总 |
| 6 | **Fortune** | AMD chipmaker CEO Lisa Su leadership | 2024-12-17 | https://fortune.com/2024/12/17/amd-chipmaker-ceo-lisa-su-leadership/ | 领导力深度 |
| 7 | **Fortune** | AMD CEO Lisa Su tells Gen Z grads 'don't walk, run' | 2025-05-14 | https://fortune.com/2025/05/14/amd-ceo-lisa-su-gen-z-college-graduates-advice-run-to-challenges-fast-track-promotions/ | RPI 演讲报道 |
| 8 | **Bloomberg** | AMD CEO Lisa Su Is Ready for the AI Spotlight | 2024-12-05 | https://www.bloomberg.com/news/articles/2024-12-05/amd-ceo-lisa-su-is-ready-for-the-ai-spotlight | 长稿 |
| 9 | **CNBC** | How AMD CEO Lisa Su rebuilt struggling chipmaker, became a billionaire | 2024-12-14 | https://www.cnbc.com/2024/12/14/how-amd-ceo-lisa-su-rebuilt-struggling-chipmaker-became-billionaire.html | 财富故事 |
| 10 | **CNBC** | How AMD CEO Lisa Su gets the best out of her employees | 2024-12-13 | https://www.cnbc.com/2024/12/13/amd-ceo-lisa-su-holds-meetings-on-weekends-expects-work-after-midnight.html | 工作伦理 |
| 11 | **CNN Business** | How Lisa Su brought AMD from the brink of bankruptcy to the top of its game | 2020-03-27 | https://www.cnn.com/2020/03/27/tech/lisa-su-amd-risk-takers | "Risk Takers" 系列 |
| 12 | **CNN** | Nvidia and AMD CEOs: The Taiwanese American cousins | 2023-11-05 | https://www.cnn.com/2023/11/05/tech/nvidia-amd-ceos-taiwan-intl-hnk | 表亲关系 |
| 13 | **IEEE Spectrum** | AMD's Lisa Su Breaks Through the Silicon Ceiling | 2024 | https://spectrum.ieee.org/amds-lisa-su-breaks-through-the-silicon-ceiling | 工程师视角 |
| 14 | **Chief Executive Magazine** | CEO Of The Year: A Conversation With AMD's Revolutionary Lisa Su | 2024 | https://chiefexecutive.net/ceo-of-the-year-a-conversation-with-amds-revolutionary-lisa-su/ | CEO 同行视角 |
| 15 | **Yahoo Finance / Benzinga** | AMD's Lisa Su Pays Tribute To Former IBM CEO Lou Gerstner | 2024 | https://finance.yahoo.com/news/amds-lisa-su-pays-tribute-023106844.html | 追悼文 |
| 16 | **Stratechery** | AMD / Xilinx 战略系列 | 多年 | https://stratechery.com/company/amd/xilinx/ | Ben Thompson 战略分析 |
| 17 | **Goldsea Asian American** | How Lisa Su Rebuilt AMD into Nvidia's Main AI Rival | 2025-10 | https://goldsea.com/article_details/how-lisa-su-rebuilt-amd-into-nvidias-main-ai-rival | 族裔传记角度 |
| 18 | **AOL/CNN** | Lisa Su says she never met her distant cousin Jensen Huang | 2024 | https://www.aol.com/amd-ceo-lisa-su-says-014208683.html | 家族关系 |

---

## 2. 独立技术分析师评价（高权重 — 专业批判）

### SemiAnalysis（Dylan Patel 等）

最有影响力的 AMD 批判性研究：

| 主题 | URL | 关键评价 |
|------|-----|---------|
| MI300X vs H100/H200 训练对比 | https://newsletter.semianalysis.com/p/mi300x-vs-h100-vs-h200-benchmark-part-1-training | "The MI300 is not usable out of the box and requires considerable amounts of work and tuning" — ROCm bug 严重 |
| AMD 2.0 新紧迫感 / MI450X 机会 | https://newsletter.semianalysis.com/p/amd-2-0-new-sense-of-urgency-mi450x-chance-to-beat-nvidia-nvidias-new-moat | "If Lisa Su and the AMD Leadership redouble their investment with a focus on their software and testing stack, they have a chance" |
| Su 接见后的进展报道 | 多篇 | "Over the past four months, AMD has made rapid progress on its AI software stack" — Su 在见 SemiAnalysis 后立即调整资源 |

**关键观察**：Su 与外部最严厉的批评家（Dylan Patel）保持公开对话渠道——这是工程师 CEO 标志。她的反应是「邀请 SemiAnalysis 进公司、整改、再请回来评估」，不是「PR 反击」。

### Tiny Corp / George Hotz 事件

- Tiny Corp 公开批评 Radeon 7900 XTX 驱动 "unfit for our customers"
- 要求 AMD 开源 GPU firmware
- **Su 个人亲自介入**："Lisa Su steps in to fix driver issues" — Tom's Hardware
- URL：https://www.tomshardware.com/pc-components/gpus/amds-lisa-su-steps-in-to-fix-driver-issues-with-new-tinybox-ai-servers-tiny-corp-calls-for-amd-to-make-its-radeon-7900-xtx-gpu-firmware-open-source

**关键观察**：Su 不让 PR 团队挡，自己亲自处理。这是 Time 2024 报道反复强调的"工程师 CEO 亲手干活"特征。

### Phoronix / Tom's Hardware（Linux & ROCm 社区）

- "Lisa Su Reaffirms Commitment To Improving AMD ROCm Support" — Phoronix
- URL：https://www.phoronix.com/news/Lisa-Su-ROCm-Commitment
- 社区评价：「Su 接受了批评，给出时间表，但 AMD 软件文化长期是弱项」

---

## 3. 行业评价（外部 CEO / 高管 / 分析师）

### 正面评价

- **Jay Goldberg (Global Semiconductor Alliance CEO)**：「She doesn't need to be the loudest person in the room.」（多次被引用）
- **Bob Swan (a16z / 原 Intel CEO)**：在 a16z 播客中给予高度评价，强调 Su 的「customer-centricity 和 long-term roadmap discipline」
- **Sam Altman (OpenAI)**：在 2025-10 联合公告中赞 AMD 是「true partner」
- **Mark Zuckerberg (Meta)**：在 MI300X launch（2023-12）和 Helios（2025）反复站台，Meta 是 Helios rack-scale 设计的合作方
- **Satya Nadella (Microsoft)**：站台 Azure 上 MI300X 部署（2023-12）
- **John Chambers (前 Cisco CEO, Pensando 创始人)**：被 AMD 收购后多次正面评价

### 中立/混合评价

- **Ben Thompson (Stratechery)**：Su 是 "the discipline executor"，但战略上仍然是 follow Nvidia 的，软件生态滞后是结构性问题（Stratechery 多篇）
- **Patrick Moorhead (Moor Insights)**：早期反复正面，但 2024 后开始指出软件 gap 必须自己解决，不能靠 acquisition
- **Tae Kim (Barron's, 也是 Jensen 传记作者)**：对比 Jensen 时强调 Su 的工程基础和路线图执行力

### 负面/批评评价

- **SemiAnalysis（早期）**：ROCm software stack 严重落后、内部测试 / CI 文化薄弱
- **George Hotz (Tiny Corp)**：Radeon 驱动质量问题
- **Daring Fireball / John Gruber**（非主流但有影响）：偶尔评论 AMD 的消费 GPU 性价比
- **The Information / Wayne Ma**：关于 MI300X 早期出货延迟和软件 bug 的内部消息源

---

## 4. 反复出现的外部观察模式

### 4.1 "She doesn't need to be the loudest"
- 出现 10+ 次（媒体一致评价）
- 与 Jensen 戏剧化、Musk 推特化形成 explicit 反差
- 解读：Su 的影响力来自执行 + 客户信任，不是个人 brand

### 4.2 "Most underrated CEO in tech"
- 出现 5+ 次
- 直到 2024 Time CEO of the Year 之前几乎不上消费媒体头版
- 解读：与"低调 → 被低估"的循环

### 4.3 "Engineer's engineer"
- 出现 8+ 次
- 1990s 在 IBM 的 copper interconnect、SOI、Cell 都是技术贡献
- 解读：极少数有 hands-on technical 背景的 Fortune 500 CEO

### 4.4 "Work-from-home? She works on weekends and after midnight"
- 来自 Time 2024 长篇 + CNBC 转述
- "holds meetings on weekends, expects work after midnight"
- "People are really motivated by ambitious goals."
- 解读：高强度工作伦理，与 Cook 4:30am 晨练形成不同的 work-ethic 表达

### 4.5 "Roadmap is her religion"
- 出现 5+ 次
- 多家媒体观察：Su 花最多时间在路线图上
- 解读：路线图 = 客户信任的载体

### 4.6 "Customer obsession"
- 出现 6+ 次
- 与 hyperscaler / OEM 关系直接管理
- 解读：客户深度共建是 AMD 与 Nvidia 差异化的核心

---

## 5. 批评与争议

### 5.1 软件 / ROCm 生态长期落后

- 来源：SemiAnalysis 多篇、Tiny Corp、Phoronix 社区
- 时长：2014-2024 持续问题
- Su 的回应：2024 起大规模追投 + Silo AI 收购 + 公开承认 + 邀请批评家入内部
- 现状：2026 还有 gap，但收窄速度明显
- **结构性问题**：硬件文化（CPU/GPU 工程师）VS 软件文化（CUDA-style 生态运营）

### 5.2 消费 GPU 业务（Radeon）长期未达对手

- 来源：消费媒体（Tom's Hardware、PCWorld）
- Su 在战略上偏向数据中心 GPU（Instinct），消费 GPU 投入相对克制
- 这与 Nvidia 投入消费/AI 双线对比

### 5.3 MI300X 早期出货 / 客户准备不足

- 来源：The Information、Stratechery
- 2024 初 MI300X 出货后客户实际部署进度慢于预期
- AMD 软件团队规模不及 Nvidia

### 5.4 与 Intel 不同的「无 fab」战略风险

- 完全依赖 TSMC → 地缘政治风险（Taiwan strait）
- Su 的回应：分散到 TSMC Arizona（多 5-20% 成本），但仍 TSMC 单一供应商
- 来源：DCD 2024、Cambridge World Trade Review 2025

### 5.5 ZT Systems 整合执行力（待验证）

- 2024-08 收购，2026-Q1 才完成 manufacturing 业务剥离
- 部分分析师质疑系统级业务复杂度
- 来源：M&A Watch、Wedbush 2026-02

### 5.6 中国市场 / 出口管制处理

- 美国对华芯片出口限制持续升级
- Su 的应对：低调，几乎不公开评论（与 Jensen 公开游说形成对比）
- 来源：多家媒体推断

### 5.7 OpenAI deal 的稀释 / 估值争议

- 给 OpenAI 160M shares warrant —— 部分股东担心稀释
- 但 Su 在 Q3 2025 财报会上用「$100B revenue」框架辩护
- 来源：CNBC 2025-11、Sahm Capital

---

## 6. 与 Jensen Huang 的外部对比叙事

| 维度 | Su（外部评价） | Jensen（外部评价） |
|------|---------------|-------------------|
| **气质** | calm, calculated, consistent | flamboyant, visionary, intense |
| **决策风格** | roadmap-driven, customer-input | bet-driven, future-bending |
| **公开姿态** | low-key | dramatic |
| **技术深度** | hands-on engineer | systems visionary |
| **客户关系** | partnership, long-term roadmap | ecosystem hostage（CUDA moat） |
| **媒体头版** | 2024 才登 Time | 2023 起持续聚光灯 |
| **核心争议** | software lag | regulatory risk + China |

→ 媒体一致结论：「Jensen 创造市场，Su 占领市场份额」。

---

## 7. 前 IBM / Freescale / AMD 内部观察（推断 + 二手）

- **Lou Gerstner（前 IBM CEO）**：Su 一年技术助理，本人称 "amazingly curious"
- **John Kelly III（IBM SVP）**：直接给 Su 「Run toward hardest problems」建议
- **Hector Ruiz（前 AMD CEO）**：注：无证据说明对 Su 早期 IBM 时期有直接影响（与原任务描述需要修正）
- **Rory Read（前 AMD CEO 2011-14）**：Su 接替；Read 与 Su 共同制定 turnaround 策略
- **Bruce Claflin（AMD board chair）**：2014 任命 Su 时说「Lisa's expertise and proven leadership make this an ideal time for her to lead the company」
- **Mark Papermaster（AMD CTO）**：Su 长期搭档，2011 接 Apple iPhone Antennagate 后转 AMD
- **Forrest Norrod（AMD Data Center GM, SVP）**：Su 提拔到核心位置，负责 EPYC / Instinct 业务
- **Jack Huynh（Computing & Graphics SVP）**：Ryzen / Radeon 负责人

→ Su 的高管班子相对稳定，几乎无重大公开冲突或 high-profile 离职（与 Jensen 几位早期联创已离开形成对比）。

---

## 8. 「她不像谁」的反向定义

观察家反复说 Su「不是」：
- 不是 Jensen 那种 visionary speaker
- 不是 Musk 那种推特斗士
- 不是 Cook 那种 PR-craft 道德发言人
- 不是 Bezos 那种 Day 1 / Day 2 哲学家
- 不是 Jobs 那种产品大师
- 不是 Bill Gates 那种慈善公开转型者

**她是**：工程师 CEO + customer-obsessed + roadmap-discipline 的纯执行派。

---

## 9. 一手 vs 二手占比

本文件约 30 条来源：
- 二手占主导：~30 / 30 = 100%（这是本文件的设计目的）
- 但其中一手引用占比高：媒体大量引用 Su 本人 keynote / 财报 / 演讲原话

→ 本文件作为「他者视角」补充，是 6 个调研维度中唯一以二手为主的，与整体一手 >50% 目标不冲突。

---

## 10. 信息缺口

- 内部员工 first-person 看法极少（不像 Cook / Jobs 有 ex-employee tell-all）
- 私下 Su 与 Jensen / Pat Gelsinger 等同行的关系几乎无可信泄露
- 童年 / 移民经历的二手史料较薄（仅 LCR Capital / Wikipedia / Goldsea 等）
- 与 TSMC 张忠谋的关系几乎无公开记录
- 与中国客户的私下沟通 100% 黑箱
