# kautoresearch — 自主优化研究循环

受 Karpathy autoresearch 启发的**数值实验**自主优化框架。适用于有明确评估脚本（evaluate.py、pytest、scoring function）的项目：ML 模型精度、算法性能、预测模型、超参数调优等。

> **选择指南**：如果任务有 `evaluate.py` 或可量化的数值指标 → 用 `/kautoresearch`（本 skill，有 results.tsv 实验追踪和 combat-log）。如果任务是非数值优化（PPT 质量、UI 改进、代码重构、文案打磨）→ 用 `/k1autoresearch`（通用迭代，支持 rubric 评分）。

## 触发方式

用户运行 `/kautoresearch` 时，你作为自主研究员开始工作。

支持的参数：
- `/kautoresearch` — 顺序模式（默认），逐个实验迭代
- `/kautoresearch --parallel` — 并行模式，派出 4 个 Agent 同时探索不同方向
- `/kautoresearch --parallel 6` — 并行模式，指定 6 路并发
- `/kautoresearch --dag` — DAG 模式，多阶段 bracket tournament，赢家晋级下阶段

**三种模式选择**：
- 不知道该试什么 → **顺序**（逐个尝试、快速反馈）
- 方向不定、想快速排除死胡同 → **并行**（4 个独立探索，扁平）
- 探索有阶段结构（例如：先特征 → 再模型 → 再调参）→ **DAG**（有依赖的多波次）

---

## 第一步：读取或初始化研究配置

首先在当前项目目录查找 `RESEARCH.md`：

**如果 `RESEARCH.md` 存在**：读取它，理解目标、指标和约束，然后跳到「环境检查与基准建立」。

**如果 `RESEARCH.md` 不存在**：与用户协作创建，包含以下内容：

```markdown
# 研究目标
[用一句话描述目标，例如：提升销售预测模型的 MAE]

## 可修改的文件
[哪些文件 / 模块是实验对象，例如：model.py, train.py, features.py]

## 不可修改的文件
[固定不动的文件，例如：data_loader.py, evaluate.py]

## 评估指标
- 指令：[如何运行评估，例如：python evaluate.py]
- 目标字段：[从输出中提取的关键指标，例如：val_mae, accuracy, f1]
- 方向：[lower_is_better 或 higher_is_better]
- 资源字段（可选）：[从输出中提取的资源指标，例如：peak_vram_mb, memory_mb, elapsed_sec]

## 时间预算
[每次实验最长运行时间，例如：5min，超时视为失败]

## 背景与约束
[其他说明：内存限制、不允许安装新包、硬件情况等]
```

创建好后，向用户确认，然后继续。

### 跨会话记忆检索（Mem Recall）

读取 RESEARCH.md 后、进入环境检查前，搜索 Nowledge Mem 中该项目的历史实验记录：

```bash
nmem --json m search "<项目名/模型名> experiment autoresearch" -n 5 -l autoresearch
```

**如果有结果：**
- 提取过去的"死胡同"方向 → 写入 `combat-log.md` 的初始条目，避免重复
- 提取过去的"最有效改动" → 在第三步构思实验时优先探索同类方向
- 报告给用户：`Mem 恢复了 [N] 条历史实验智慧，已预置 [M] 条死胡同标记`

**如果无结果：** 正常流程，首次实验。

**如果 nmem 不可用（命令不存在或连接失败）：** 跳过，不阻塞流程。

---

## 第二步：环境检查与基准建立

1. **通读项目代码**：读取 `RESEARCH.md` 中列出的所有可修改文件和不可修改文件，建立完整的项目理解。不理解代码就无法提出好的实验 —— 这一步不可跳过。
2. **检查依赖**：确认评估命令可以运行（试跑一次，确认输出格式符合预期）。
3. **创建实验分支**：
   ```
   git checkout -b autoresearch/<今日日期标签>
   ```
   分支名示例：`autoresearch/mar21`，如已存在则加后缀 `-v2`。
4. **初始化结果日志**：创建 `results.tsv`（不纳入 git 追踪）：
   ```
   commit\tmetric_value\tresource_usage\tstatus\tdescription
   ```
   其中 `resource_usage` 记录资源消耗（如 peak_vram_mb、memory_mb、elapsed_sec 等，取决于 RESEARCH.md 中配置的资源字段）。若未配置资源字段，此列填 `-`。
5. **跑基准实验**：不修改任何代码，直接运行评估，记录基准值。
6. **估算实验吞吐量**：根据基准实验耗时，报告预估实验速率：
   > 基准实验耗时 X 分钟，预计每小时可完成约 Y 次实验，过夜（8h）约 Z 次。
7. **向用户确认**：报告基准指标、资源使用量和实验速率估算，询问是否开始自主实验循环。

---

## 第三步：自主实验循环（LOOP FOREVER）

每轮实验流程：

### 3.1 构思实验

基于以下思路提出一个改动方向（每次专注一个）：

- **模型结构**：层数、宽度、激活函数、注意力机制、归一化方式
- **特征工程**：新特征、特征选择、特征变换、交叉特征
- **优化器/训练策略**：学习率、调度器、正则化、早停、批次大小
- **数据处理**：增强、采样策略、异常值处理、归一化方法
- **算法替换**：换一个更适合的模型族或集成方式
- **超参数**：任何数值参数的调整
- **简化**：删除复杂组件看性能是否持平（简化胜利！）

### 3.2 实施修改

- **只修改 `RESEARCH.md` 中列出的可修改文件**
- 保持改动聚焦，每次改一件事，便于归因
- git commit（简短描述本次实验思路）

### 3.3 运行实验

```bash
[评估命令] > run.log 2>&1
```

**Context 窗口保护**：必须将所有输出重定向到 `run.log`，绝不使用 `tee` 或让输出直接打到 context 中。长时间运行会消耗 context 窗口，导致后续实验质量下降。

设置超时监控：若超过时间预算的 2 倍，强制终止，记录为超时失败。

### 3.4 读取结果

从 `run.log` 精准提取关键指标（只读必要行，不读全文）：
```bash
grep "<目标字段>\|<资源字段>" run.log
```

- 若输出为空 → 运行崩溃，执行 `tail -n 50 run.log` 读取 stack trace 进行崩溃诊断
- 若有结果 → 提取性能指标和资源指标，与当前最优对比

### 3.5 判断与记录

| 情况 | 操作 |
|------|------|
| 指标改善 | ✅ 保留提交，更新最优值，记录 `keep`，**立即执行安全提交（见下方）** |
| 指标改善但资源暴增 | ⚠️ 资源使用是软约束：若资源增幅远超性能增幅，权衡后决定 keep 或 discard |
| 指标持平或变差 | ❌ `git reset --hard` 回到上次好的提交，记录 `discard` |
| 崩溃/超时 | 🔥 分析原因：简单 bug 则修复重试；根本性问题则跳过，记录 `crash` |

**原子安全提交（keep 后必做）**：每次 keep 判定后，立即执行：
```bash
git add -A && git commit -m "experiment-{N}: keep — {一句话描述} (metric: {值})"
```
这确保每个成功实验都是独立提交。后续 discard 的 `git reset --hard` 只会回退到上一个 keep 提交，不会丢失更早的成功实验。**这是防止回归的核心机制——没有这一步，一次 reset 可能丢掉多轮成果。**

**回退审慎原则**：`git reset --hard` 仅用于丢弃当前失败实验，回退到上一个 keep 提交。大幅度回退（跳过多个成功提交回到更早版本）应极为罕见 —— 这会丢失已验证的探索空间，几乎永远不应该这么做。

**战斗日志（discard/crash 时必写）**：回退代码前，先将失败分析写入 `combat-log.md`（不纳入 git）：
```markdown
### 实验 {N}: {一句话描述}
- **假设**：预期什么会发生，为什么
- **结果**：实际发生了什么（指标值、错误信息等）
- **失败原因**：根因分析
- **死胡同**：YES（此方向已穷尽）/ NO（变体可能有效）
---
```
每轮 3.1 构思实验前，必须先检查 `combat-log.md` 中标记为 `死胡同: YES` 的方向，绝不重复尝试。

`results.tsv` 格式（5 列）：
```
<7位commit hash>\t<指标值>\t<资源使用>\t<keep/discard/crash>\t<实验描述>
```

示例：
```
a1b2c3d	0.9500	128.3mb	keep	baseline
b2c3d4e	0.9320	130.1mb	keep	increase learning rate to 0.04
c3d4e5f	0.9600	128.0mb	discard	switch to GeLU activation
d4e5f6g	0.0000	-	crash	double model width (OOM)
```

### 3.6 收敛检测与继续

**绝不停下来询问用户是否继续。** 用户可能在睡觉。自主运行直到被手动中断或收敛。

**收敛信号（任一触发则换方向或停止）**：
- 连续 8 次 discard → 当前方向已枯��
- `combat-log.md` 中连续 5 个 `死胡同: YES` → 所有假设已穷尽
- 目标已达成 → 完成
- 当前方向已跑满 2 小时 → 递减回报

收敛后：若 `RESEARCH.md` 中有多个探索方向，切换到下一个方向并重置计数器。若所有方向都已穷尽，输出实验摘要并停止。

若感觉思路枯竭但未达收敛阈值：
- 重读 `RESEARCH.md`、`combat-log.md` 和项目代码找新角度
- 尝试组合之前「差一点」的实验
- 尝试更激进的架构变化
- 从论文或已知最佳实践中寻找灵感

---

## 并行实验模式（Parallel Mode）

当用户运行 `/kautoresearch --parallel N`（N 默认为 4）或在顺序循环中连续 5 次 discard 时，自动切换到并行模式。

### 原理

顺序实验每次只探索一个方向，遇到死胡同才换。并行模式同时派出 N 个独立 Agent，各走不同方向，跑完后比较选最优。适合：
- 方向不确定时快速排除死胡同（探索效率 ×N）
- 每次实验耗时较长（≥3min）时大幅压缩总时长
- 参数调优已收敛，需要同时尝试多个结构性变化

### 执行流程

#### P1. 策略分配

从当前最优提交出发，为 N 个 Agent 各分配一个**不同方向**的策略。策略从以下池中选取（优先覆盖不同类别）：

| 策略槽 | 方向 | 示例 |
|--------|------|------|
| Agent-A | 结构性变化 | 换模型架构、换算法族 |
| Agent-B | 特征工程 | 新特征、特征变换、交叉特征 |
| Agent-C | 训练策略 | 优化器、调度器、正则化 |
| Agent-D | 简化/减法 | 删除组件看性能是否持平 |

如果 `combat-log.md` 中某方向已标记为 `死胡同: YES`，跳过该方向，换下一个。

#### P2. 创建隔离环境

为每个 Agent 创建 git worktree：

```bash
# 从当前最优提交创建 N 个 worktree
BEST_COMMIT=$(git rev-parse HEAD)
for i in A B C D; do
  git worktree add ../autoresearch-${i} ${BEST_COMMIT} -b autoresearch/parallel-${i}
done
```

每个 worktree 是完全独立的代码副本，互不干扰。

#### P3. 并行派发

使用 Agent 工具同时派发 N 个子 Agent（在一个 message 中发出所有 Agent 调用）：

每个子 Agent 的指令模板：
```
你是 kautoresearch 并行实验的 Agent-{X}。

工作目录：../autoresearch-{X}
策略方向：{分配的方向}
评估命令：{从 RESEARCH.md 读取}
目标字段：{从 RESEARCH.md 读取}
方向：{lower/higher_is_better}
当前最优指标：{基准值}
时间预算：每个实验 {时间预算}，总共最多跑 3 轮顺序实验

规则：
1. 每轮只改一件事，git commit 后运行评估
2. 输出重定向到 run.log，不打到 stdout
3. 跑完 3 轮后（或提前收敛），报告你的最优结果：
   - best_metric: {值}
   - best_commit: {hash}
   - experiments: [{描述, 指标, keep/discard}]
4. 不要修改 RESEARCH.md 中的不可修改文件
```

**关键**：所有 Agent 调用必须在**同一个 message** 中发出，确保真正并行执行。

#### P4. 收集结果

所有子 Agent 完成后，汇总比较：

```
## 并行实验结果

| Agent | 策略 | 最优指标 | vs 基准 | 实验次数 |
|-------|------|---------|---------|---------|
| A | {方向} | {值} | {+/-变化} | 3 |
| B | {方向} | {值} | {+/-变化} | 2 |
| C | {方向} | {值} | {+/-变化} | 3 |
| D | {方向} | {值} | {+/-变化} | 3 |

🏆 胜出：Agent-{X}（{方向}），指标 {值}，提升 {%}
```

#### P5. 合并胜出方 & 清理

```bash
# 切回主实验分支
cd <原项目目录>

# 合并胜出 Agent 的所有 keep 提交
git merge autoresearch/parallel-{胜出Agent} --no-ff -m "parallel: merge winner Agent-{X} ({方向})"

# 清理所有 worktree
for i in A B C D; do
  git worktree remove ../autoresearch-${i} --force
  git branch -D autoresearch/parallel-${i}
done
```

将所有 Agent 的实验结果追加到主 `results.tsv`（包括 discard 的，标注 `parallel-{X}`）。
将失败 Agent 的方向写入 `combat-log.md`。

#### P6. 继续迭代

合并胜出方后，回到**顺序模式**（第三步），基于新的最优值继续迭代。

如果再次连续 5 次 discard → 自动触发下一轮并行模式。

### 并行模式的边界条件

| 情况 | 处理 |
|------|------|
| 所有 Agent 都没有改善 | 记录所有方向为死胡同，回到顺序模式尝试更激进的变化 |
| 多个 Agent 指标接近（差距 < MAD） | 选简单的那个（简洁性原则）|
| 某个 Agent 崩溃 | 忽略该 Agent，从其余中选最优 |
| 所有 Agent 都崩溃 | 回到顺序模式，问题不在方向而在基础设施 |
| 项目不支持 git worktree | 退回顺序模式（如 worktree 创建失败） |

### 何时不用并行模式

- 实验耗时 < 1 分钟（顺序已经够快，并行的 worktree 开销不值得）
- 磁盘空间紧张（每个 worktree 是项目的完整副本）
- 项目有硬件独占资源（如单 GPU 不能同时跑多个实验）——此时并行的 Agent 只做代码修改，评估仍需排队

---

## DAG 实验模式（DAG Mode）

> 灵感来源：open-multi-agent 的 Coordinator 模式 + TaskQueue 拓扑解锁算法。

当实验空间有**阶段依赖**时（例如：先跑特征工程 → 用胜者跑模型选择 → 再跑超参数调优），扁平并行不合适。DAG 模式把实验组织为 **任务图**：每波运行无依赖的任务，赢家的 commit 成为下游任务的 baseline。

### 何时使用 DAG 模式

- 探索空间有**阶段结构**（feature → model → tuning → simplify）
- 想做**bracket tournament**：多路探索 → 选冠军 → 冠军进入下一阶段
- 已经跑过 1-2 轮并行，想用**累积最优**深入优化而非每次重头
- 明确知道某些实验**必须先完成**才能跑另一些（如特征工程必须先定型）

### 执行流程

#### D1. Coordinator 分解（一次性 LLM 调用）

你作为 Coordinator，读完 `RESEARCH.md` 和 `combat-log.md` 后，把研究目标分解为**任务 DAG**。输出 JSON 格式（严格遵守）：

```json
{
  "goal": "提升销售预测模型的 MAE",
  "baseline_commit": "<当前最优 commit hash>",
  "metric_direction": "lower_is_better",
  "tasks": [
    {"id": "T1", "title": "feature: 添加时间滞后特征", "strategy": "feature", "depends_on": []},
    {"id": "T2", "title": "feature: 添加类别交叉特征", "strategy": "feature", "depends_on": []},
    {"id": "T3", "title": "model: XGBoost 跑最佳特征", "strategy": "structural", "depends_on": ["T1","T2"]},
    {"id": "T4", "title": "model: LightGBM 跑最佳特征", "strategy": "structural", "depends_on": ["T1","T2"]},
    {"id": "T5", "title": "tuning: 胜出模型学习率扫描", "strategy": "tuning", "depends_on": ["T3","T4"]},
    {"id": "T6", "title": "simplify: 删除低重要性特征", "strategy": "simplify", "depends_on": ["T5"]}
  ]
}
```

**DAG 设计原则**：
- 每阶段 2-4 个任务（太多 worktree 开销大，太少失去 bracket 意义）
- 深度不超过 4 层（超出往往是想太远，先跑前两层再规划下两层）
- `strategy` 字段复用并行模式的分类（feature/structural/tuning/simplify）
- `depends_on` 用父任务 ID 数组，空数组 = 第一波
- 同阶段任务**互相独立**（都从最佳父节点的 commit 开始）

向用户展示 DAG 并确认后，保存为 `dag-spec.json`。

**JSON 自检清单**（写入前务必人工确认）：
- [ ] 所有 `id` 唯一
- [ ] 所有 `depends_on` 引用的 ID 都存在于 tasks 数组中
- [ ] 没有自引用（`T1.depends_on` 不含 `T1`）
- [ ] 没有环（通过直觉检查：沿依赖链走不会回到起点）
- [ ] 至少有 1 个任务的 `depends_on` 为空（第一波）

如果 `init` 命令报错，修正 JSON 后重新保存。`dag-orchestrator.py init` 内置了环检测和未知依赖检测，会拒绝非法 DAG。

#### D2. 初始化 DAG 状态

```bash
python ~/.claude/scripts/dag-orchestrator.py init dag-spec.json
```

这会在 `.autoresearch/dag-state.json` 建立状态，把无依赖任务置 `pending`，其他置 `blocked`。

#### D3. 波次循环（LOOP UNTIL DONE）

每一波：

**a) 查询可运行任务**：
```bash
python ~/.claude/scripts/dag-orchestrator.py next
```
返回所有 status=pending 且父节点全部 completed 的任务。

**b) 为本波每个任务创建 worktree**：
每个任务从它的**最佳父节点的 commit** 出发（由 orchestrator 自动推断）：
```bash
# 对每个 task_id
BASELINE=$(python ~/.claude/scripts/dag-orchestrator.py baseline ${task_id} | jq -r .baseline_commit)
git worktree add ../autoresearch-${task_id} ${BASELINE} -b autoresearch/dag-${task_id}
```
> `baseline` 命令逻辑：若任务无依赖 → 用 `baseline_commit`；若有依赖 → 选择依赖中 metric 最好的那个父节点的 commit。

**c) 并行派发**（在**同一个 message** 中发出所有 Agent 调用）：

每个子 Agent 指令模板：
```
你是 kautoresearch DAG 模式的 Agent，负责任务 {task_id}。

工作目录：../autoresearch-{task_id}
任务标题：{title}
策略类别：{strategy}
评估命令：{从 RESEARCH.md}
目标字段：{从 RESEARCH.md}
方向：{lower/higher_is_better}
baseline（你的起点指标）：{父节点 metric 或 基准 metric}
时间预算：最多 3 轮顺序实验

规则：
1. 围绕本任务标题做定向实验（不要跑别的策略类别）
2. 每轮只改一件事，git commit 后运行评估
3. 输出重定向到 run.log
4. 跑完后报告你的最优结果：
   - best_metric: {值}
   - best_commit: {hash}
   - experiments: [{描述, 指标, keep/discard}]
```

**d) 收集本波结果 & 更新 DAG**：

每个 Agent 返回后：
- 成功（有 keep 提交）：
  ```bash
  python ~/.claude/scripts/dag-orchestrator.py complete ${task_id} \
    --commit=${best_commit} --metric=${best_metric}
  ```
  这会自动解锁所有依赖它的任务（如果所有父节点都完成了）。
- 失败（无 keep / 全部 discard / 崩溃）：
  ```bash
  python ~/.claude/scripts/dag-orchestrator.py fail ${task_id} --reason="..."
  ```
  这会**级联跳过**所有依赖它的任务（及这些任务的下游）。

**关键**：本波所有任务状态更新完后，把它们的 worktree 清理掉（失败的也清），然后回到 (a) 查下一波。

**e) 写入 results.tsv**：每个任务完成后追加一行，commit 列记录 best_commit，描述列标注 `dag-${task_id}:{title}`。

**f) 写入 combat-log.md**：失败的任务按现有格式记录"死胡同"分析。

#### D4. DAG 完成

当 `next` 返回空数组且无任务处于 `blocked`/`in_progress` 状态，DAG 完成：

```bash
python ~/.claude/scripts/dag-orchestrator.py status
python ~/.claude/scripts/dag-orchestrator.py export
```

#### D4.5. Supervisor 审计（防止贪心陷阱）

> 背景：DAG 模式每阶段只让**赢家**的 commit 传下去，close-loser 的下游路径从未被探索。审计层识别这种盲区并提议救援实验。

**自动触发条件**：DAG 深度 ≥ 2 层（单波 DAG 无下游，跳过）。

合并赢家**之前**，运行：

```bash
python ~/.claude/scripts/dag-orchestrator.py audit --threshold 0.10
```

审计逻辑：
1. 对每组"兄弟节点"（同一 parent-set 下的任务）识别**赢家** 和 **close-losers**（gap ≤ 10%）
2. 对每个 close-loser：如果它在 DAG 中有下游子任务，但下游**只从赢家 commit 跑过**，则标记为可疑
3. 为每个可疑项生成**救援提案**：从 loser 的 commit 出发，跑一次下游赢家策略

**输出示例**（对应你提的 T2+T4 盲区）：
```json
{
  "suspicious_discards": [{
    "unused_loser": {"id": "T2", "metric": 0.90, "commit": "c_T2"},
    "beaten_by": {"id": "T1", "metric": 0.85},
    "gap_pct": 5.88,
    "rescue_proposal": {
      "from_commit": "c_T2",
      "apply_strategy_title": "model X",
      "note": "Try 'model X' starting from T2's commit — this combination was never explored."
    }
  }]
}
```

**行动流程**：
1. `suspicious_count == 0` → 无盲区，直接合并赢家（D5）
2. 有可疑项 → **必须向用户汇报**，格式如下：
   ```
   🔍 Supervisor 审计发现 N 个可疑盲区：
   
   1. T2 (0.90) vs 赢家 T1 (0.85) —— gap 5.88%
      未探索组合：T2 commit + T3 策略（model X）
      建议：跑 1 个救援实验
   
   合计 N 个救援实验，预计耗时 ~X min。
   [Y] 全跑  [N] 跳过直接合并  [1,3] 只跑指定的
   ```
3. 用户同意 → 为每个 rescue_proposal 创建 worktree：
   ```bash
   git worktree add ../autoresearch-rescue-${loser_id} ${from_commit} \
     -b autoresearch/rescue-${loser_id}
   ```
4. 派发救援 Agent（复用 D3.c 的指令模板，只跑 1 轮实验）
5. 救援 metric vs 原赢家 metric：
   - 救援更好 → 改用救援分支合并，记录到 combat-log "DAG 贪心陷阱被救援补正"
   - 救援持平/更差 → 记录"救援未发现更优解"，合并原赢家

**救援上限**：每次 DAG 最多 3 个救援实验（audit 自动按 gap_pct 升序取前 3）。超出的 close-losers 仅汇报、不自动跑。

**阈值调整**：
- `--threshold 0.05` → 更严格（只找非常接近的 loser）
- `--threshold 0.15` → 更宽松（搜索范围更大）
- 默认 0.10 适合大多数情况

#### D5. 合并胜出方 & 下一步

**合并全局胜出方**：
```bash
# 从 export 结果找 completed 且 metric 最好的任务（按 RESEARCH.md 的 metric_direction）
# higher_is_better：
BEST_ID=$(python ~/.claude/scripts/dag-orchestrator.py export | \
  jq -r '.results | map(select(.status=="completed")) | sort_by(.metric) | last | .id')
# 若 lower_is_better，把 last 改成 .[0]

BEST_TITLE=$(python ~/.claude/scripts/dag-orchestrator.py export | \
  jq -r ".results[] | select(.id==\"$BEST_ID\") | .title")

cd <原项目目录>
git merge autoresearch/dag-${BEST_ID} --no-ff \
  -m "dag: merge overall winner ${BEST_ID} (${BEST_TITLE})"
```

然后清理所有剩余 worktree 和 branch：
```bash
git worktree list | grep autoresearch-dag | awk '{print $1}' | \
  xargs -I{} git worktree remove {} --force
git branch | grep autoresearch/dag- | xargs -I{} git branch -D {}
```

**清理 DAG 状态文件**（可选，保留可做事后分析）：
```bash
rm -rf .autoresearch/dag-state.json
```

**下一步迭代**：DAG 完成后，回到顺序模式继续迭代（基于新的最优值），或用户再次触发 DAG 模式规划下一个阶段。

### DAG 模式的边界条件

| 情况 | 处理 |
|------|------|
| 所有 T1/T2（第一波）都失败 | DAG 根断，向用户汇报"起点方向已穷尽"，不启动后续波次 |
| 某波部分失败 | 继续跑依赖于成功父节点的任务；被级联 skip 的任务记录到 combat-log |
| 所有任务都 completed 但无一个超过 baseline | 记录为"探索无收益"，不合并，回退到顺序模式做激进变化 |
| 用户手动中断 | 保留 `.autoresearch/dag-state.json`，下次可手动恢复 |
| worktree 创建失败 | 该任务标 fail，级联 skip 下游 |

### 与并行模式的区别

| 维度 | Parallel | DAG |
|------|----------|-----|
| 每个 Agent 的 baseline | 全部同一个 commit | 各自最佳父节点 |
| 结构 | 扁平 4 slot | 多层 DAG |
| 适合 | 方向不定、快速排除 | 已知阶段、层级优化 |
| 轮次 | 1 轮（每 Agent 3 实验）| 多波（每波 2-4 任务）|
| 总实验量 | 12 个 | 可变（取决于 DAG 深度）|
| **贪心风险** | 无 | **有**（局部最优 ≠ 全局最优）|
| **补救机制** | — | **Supervisor 审计 + 救援实验**（D4.5）|

---

## 崩溃处理原则

- **简单 bug**（typo、import 缺失、shape 不匹配）→ 立即修复，重跑
- **OOM / 内存不足** → 减小批次大小或模型规模后重试
- **根本性失败**（思路本身错误）→ 放弃，回退，换思路
- **连续 3 次崩溃** → 回到上一个成功的实验，彻底换方向

---

## 简洁性原则

所有条件相同时，**简单优先**：

- 增加 20 行复杂代码换来 0.001 的提升 → 不值得
- 删除代码但性能持平 → 必须保留（简化胜利）
- 改动越小越好，除非收益显著

---

## 实验结束汇报

当用户手动中断时，输出：

```
## 实验摘要
- 总实验次数：N
- 保留：K 次 / 丢弃：D 次 / 崩溃：C 次
- 基准指标：X（资源：R_baseline）
- 最终最优指标：Y（提升 Z%）（资源：R_best）
- 当前最优提交：<hash>

## 进度趋势
[用 results.tsv 中的 keep 记录绘制文本趋势图，展示指标随实验轮次的变化]
例如：
#1 baseline  0.9500 ████████████████████
#3 keep      0.9320 ██████████████████
#7 keep      0.9180 █████████████████
#12 keep     0.9050 ████████████████

## Top 3 有效改动
1. <描述> → 指标从 A 到 B（资源变化：R1 → R2）
2. ...
3. ...

## 建议下一步方向
...
```

### 实验知识沉淀（Mem Distill）

汇报完毕后，自动将本轮实验核心经验存入 Nowledge Mem：

```bash
nmem m add "Project: <项目名>. Best: <最有效改动描述> (metric: <基准> → <最优>). Dead ends: <死胡同列表>. Next: <建议方向>." \
  -t "Autoresearch: <项目名> — <目标简述>" \
  -i 0.7 \
  --unit-type learning \
  -l autoresearch -l <项目名> \
  -s claude-code
```

**只存 4 样东西：** 最有效改动、指标变化、死胡同、下一步方向。不存每次实验的细节。

**如果 nmem 不可用：** 跳过，不影响汇报。

---

## 评估防火墙强化

> 灵感来源：[awesome-autoresearch](https://github.com/WecoAI/awesome-autoresearch) 中的 tennis prediction 案例——Agent 能修改评估代码时，它"改写了裁判"实现了虚假提升。

在现有「不修改评估函数」的基础上增加主动检测：

1. **异常跳变检测**：如果某次实验的指标提升超过之前所有 keep 实验平均提升的 3 倍，触发审查：
   - 检查修改是否直接或间接影响了评估逻辑（import 链、数据管道）
   - 检查输出的分布特征是否正常（预测值范围、统计特性）
   - 确认正常后才记录为 keep
2. **简化胜利的反面**：删除代码后性能**大幅提升**（>3x 平均增幅），同样触发审查——可能删掉了某个必要的约束

---

## Rubric 评估模式（非数值指标）

当优化目标不是单一数值（如 UI 质量、文案效果、代码可读性），在 `RESEARCH.md` 的评估指标部分使用 rubric 模式：

```markdown
## 评估指标
- 模式：rubric
- 评估方式：LLM-as-judge（用独立 Agent 评分，不由实验 Agent 自评）
- rubric：
  | 维度 | 权重 | 10 分标准 | 1 分标准 |
  |------|------|----------|---------|
  | {维度1} | 40% | {具体描述} | {具体描述} |
  | {维度2} | 35% | {具体描述} | {具体描述} |
  | {维度3} | 25% | {具体描述} | {具体描述} |
- 方向：higher_is_better
```

Rubric 模式下，`results.tsv` 的 metric_value 列记录加权总分。评估必须由独立 Agent 执行（Generator-Evaluator 分离），防止自评偏差。

---

## 结构性 vs 参数性搜索

> 来自地球系统建模的经验：将幂律函数替换为 sigmoid 使相关系数从 0.09 跳到 0.65——结构性变化的收益远超参数调优。

**实验策略优先级**：

1. **结构性变化**（高风险高回报）：替换算法、改变模型架构、重新设计特征管道
2. **组件替换**（中等风险）：换激活函数、换优化器、换损失函数
3. **参数调优**（低风险低回报）：学习率、批次大小、正则化系数

当参数调优连续 5 次 discard 时，强制切换到结构性变化方向。

---

## 注意事项

- `results.tsv`、`combat-log.md` 和 `.autoresearch/` 目录始终不纳入 git（只保留在工作区）
- 不安装 `RESEARCH.md` 中未列出的新依赖
- **不修改评估函数**（评估是固定的标尺）—— 这是结构性防线而非建议。每次 commit 前检查 `RESEARCH.md` 中「不可修改的文件」是否被改动，若有则立即 `git checkout` 恢复
- 硬件/平台无关：适配用户当前环境（CPU、MPS、CUDA 均可）
- **MAD 置信度**：累积 3+ 数据点后，计算 `confidence = |best - baseline| / MAD`。≥2.0 = 大概率真实改善，<1.0 = 可能是噪声，需确认跑
