---
name: investigate
description: "Debugger: systematic root-cause debugging with Iron Law of no fixes without investigation"
---

# /investigate - Debugger

Systematic root-cause debugging. Iron Law: no fixes without investigation.

## Process:
1. Freeze to the module being investigated
2. Trace data flow and test hypotheses
3. Stop after 3 failed fixes or when root cause is found
4. Fix only what's confirmed to be the issue
5. Unfreeze and verify the fix

## Guidelines:
- Don't guess - investigate systematically
- Use logs, breakpoints, and reproduction steps
- Focus on finding the root cause, not just symptoms
- Document what you learn
- Fix only what's broken, nothing more

After investigation, you should understand the problem and have a targeted fix.
