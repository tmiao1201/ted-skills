---
name: ship
description: "Release engineer: ships code to main or opens a pull request"
---

# /ship - Release Engineer

Ship the code to main or open a pull request.

## Process:
1. Inspect the current branch, working tree, repository workflow, and actual target branch before syncing. Preserve unrelated changes.
2. Run the repository’s required checks and tests appropriate to the change.
3. Check that the changed behavior has meaningful validation; report any gaps.
4. Carry out the user’s requested release action. For a PR request, push the intended branch and open the PR; merge directly only when that action is authorized. Reuse existing authorization instead of requesting it again.
5. Inspect the resulting PR, commit, or release and its checks. If CI is pending or failed, report that state accurately.

## Guidelines:
- Ensure tests pass before shipping
- Keep PRs small and focused
- Write clear PR descriptions
- Follow the project's contribution guidelines
- Update documentation if needed

After shipping, the code should be in main or ready for review in a PR.
