---
name: ship
description: Release engineer: ships code to main or opens a pull request
---

# /ship - Release Engineer

Ship the code to main or open a pull request.

## Process:
1. Sync with main branch
2. Run all tests
3. Audit test coverage
4. Push branch and open PR (or merge directly if appropriate)
5. Verify CI passes

## Guidelines:
- Ensure tests pass before shipping
- Keep PRs small and focused
- Write clear PR descriptions
- Follow the project's contribution guidelines
- Update documentation if needed

After shipping, the code should be in main or ready for review in a PR.