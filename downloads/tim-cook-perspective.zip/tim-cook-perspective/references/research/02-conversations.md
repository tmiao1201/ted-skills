# Tim Cook 长对话调研

> 调研维度：长对话/访谈/播客中的即兴反应、改口瞬间、回避边界、价值-商业冲突时的话术。
> 数据节点：2026-05-24。优先英文一手 transcript/视频；二手媒体转述会注明。

---

## 一、关键长访谈清单（按重要性排序）

| 访谈 | 时间 | 时长 | 主题 | URL / 可信度 |
|------|------|------|------|--------------|
| Charlie Rose（两期） | 2014-09-12/15 | 约 90 分钟 | Apple Watch、Beats、Steve Jobs 遗产、隐私、NSA | charlierose.com/videos/25887；transcript 见 singjupost.com — 一手 |
| Tsinghua SEM Dean Qian Yingyi 对谈 | 2014-10-23 | 约 90 分钟 | Apple Watch、接班 Steve、IBM 合作、中国战略、环保 | sem.tsinghua.edu.cn/en/info/1135/2394.htm — 一手（官方记录，中文转译需注意） |
| TIME（Nancy Gibbs + Lev Grossman） | 2016-03-10 | 长篇专访 | 与 FBI 加密对抗（San Bernardino） | time.com/4261796 — 一手 transcript |
| Recode/MSNBC（Kara Swisher + Chris Hayes） | 2018-03-27 录 / 04-06 播 | 约 60 分钟 | 隐私、Zuckerberg、社交媒体监管、Trump、DACA | recode.net/2018/4/6/17206532 — 一手 transcript |
| PBS Amanpour & Co.（Christiane Amanpour，布鲁塞尔 Apple Store） | 2018-10-24 | 约 25 分钟 | 隐私 crisis point、欧洲监管 GDPR、个人生活 | pbs.org/wnet/amanpour-and-company — 一手 |
| 60 Minutes / CBS（Norah O'Donnell，WWDC） | 2019-06 | 长访谈 | 关税、移民、屏幕时间、Sign in with Apple | cbsnews.com/news/apple-tim-cook-interview-wwdc-2019 — 一手 |
| Outside Podcast（Michael Roberts，Apple Park 散步访） | 2020-12 | 约 60+ 分钟 | 健身、国家公园、Apple Watch 健康研究、屏幕脱机 | outsideonline.com/podcast/tim-cook-health-fitness-podcast — 一手 |
| NYT Sway（Kara Swisher） | 2021-04-05 | 约 50 分钟 | iOS 14.5 ATT、Facebook、Parler、Project Titan、AR、Epic | nytimes.com Sway；loopinsight.com 与 ped30.com 有完整 transcript — 一手 |
| Code Conference 2022（Kara Swisher 收官场，与 Jony Ive、Laurene Powell Jobs 同台） | 2022-09-07 | 约 60 分钟 | Steve Jobs 遗产、Steve Jobs Archive 启动 | YouTube 全片 sdvzYtgmIjs — 一手 |
| Dua Lipa "At Your Service" | 2023-11-17 | 约 45 分钟 | 童年、Steve Jobs、AI、儿童与屏幕、接班、慈善 | open.spotify.com / service95.com — 一手音频 |
| GQ（Zach Baron 长 profile） | 2023-04 | 长访 + 多日陪同 | AR/VR、Steve Jobs 创造力非垄断、不"正常"、邮件回复 | gq.com / tidbits.com 摘录 — 一手 |
| WSJ（Joanna Stern） | 2024-10 | 多次访谈 | Apple Intelligence、not first, but best、Vision Pro | wsj.com — 一手 |
| Wired（Steven Levy） | 2024-12 | 长 profile | AI、Vision Pro、退休、Michael Dell 1998 旧事 | wired.com / fortune 摘录 — 一手 |
| China Development Forum + 媒体见面 | 2017、2018、2023、2026 | 主旨+Q&A | 共生论、symbiotic relationship、partnership/trust/shared commitment | globaltimes / 9to5mac / fortune — 一手发言+二手转述 |
| All-hands 内部会议（多次泄露） | 2025-08、2026-02 | 内部 | AI 落后、we've rarely been first、移民 | macrumors.com / bloomberg — 二手（泄露引用） |
| GMA（Michael Strahan） | 2026-02 | 短访 | 退休传闻、That's a rumor | techspot.com / macrumors — 一手 |
| Stratechery（Ben Thompson 长篇 essay，非直接访谈但深度对话基础） | 2013、2026 | — | Cook 战略评价 | stratechery.com — 二手（分析） |

---

## 二、被追问时的典型反应模式

库克的反应不是"反驳"，而是把问题重新放到他想讨论的框架里。下面是 7 个具体案例。

### 1. Kara Swisher 追问 Zuckerberg（2018 Recode/MSNBC）
- 问：如果你是 Mark Zuckerberg，你会怎么做？
- 答（原话）：「What would I do? I wouldn't be in this situation.」
- 模式：用一句利落的拒答 + 价值评判，避免正面给建议。这是他著名的 moral one-liner。

### 2. Amanpour 追问隐私是否真是"危机"（2018 PBS）
- 问：你是不是夸大了隐私问题？
- 答：「I do see it as a crisis. I see privacy as one of the top issues, the top few issues of this century… because of the number of nefarious things that can happen.」
- 模式：把具体技术问题升格为"世纪级议题"——议题升维。

### 3. Norah O'Donnell 追问"我们是不是花太多时间在手机上"（2019 CBS WWDC）
- 问：库克自己用手机吗？多吗？
- 答：「If I'm picking up my phone too much, you want to know that. We've never wanted people to use our products a lot.」
- 模式：承认前提 → 把镜头反转向"我们也在帮你管理"（Screen Time）。绝不为成瘾辩护。

### 4. Kara Swisher 追问 Project Titan / Apple Car（2021 Sway）
- 问：你们到底造不造车？
- 答：「I'm gonna look at you and say, you are talking about something that I will not talk about.」
- 模式：极少数会明确说"我不谈"的话题。这种 hard no 反而不可被追问。

### 5. Kara Swisher 追问 Hong Kong 应用 / 中国合规（2021 Sway，2018 MSNBC 两次）
- 问：为什么 Apple 对中国合规、对美国对抗？是双标吗？
- 答模式：「We follow the law wherever we do business.」+ 「You don't change things by leaving.」
- 模式：法律 + engagement 哲学两件套，从不进入价值评判。

### 6. Joanna Stern 追问"为什么 Apple 在 AI 上落后"（2024 WSJ）
- 问：你们是不是赶不上 Google、OpenAI 了？
- 答：「We're perfectly fine with not being first… As it turns out, it takes a while to get it really great. It takes a lot of iteration. It takes worrying about every detail.」+ 列举 Mac、iPhone、iPad、iPod 都不是第一。
- 模式：用历史模式 reframe 当下质疑——"你只是没意识到我们一向如此"。

### 7. Michael Strahan 追问退休（2026 GMA）
- 问：你是不是要 step back？
- 答：「I didn't say that. That's a rumor.」+「I love what I do deeply. I can't imagine life without Apple.」
- 模式：直接定性传闻 → 用情感化承诺收尾。

---

## 三、即兴类比与思维方式（非稿件）

库克的即兴类比通常来自三个母题：Alabama 工业经验、自然/户外、Steve Jobs 留下的工厂术语。

1. **Rock tumbler（岩石抛光机）** —— CBS：「We bring people with different lenses and different viewpoints… put them in a rock tumbler and turn it to see what comes out.」 工程师式类比——粗糙石头通过持续摩擦变光滑。

2. **No one should have a key that turns a billion locks** —— 2016 TIME：「No one should have a key that turns a billion locks. It shouldn't exist.」 把密码学翻译成锁匠常识。

3. **Palate cleanser for the mind** —— 2020 Outside：「[Nature is] like a palate cleanser for the mind.」 厨房用语解释 CEO 必须脱机。

4. **Working in a national park** —— 2020 Outside，形容 Apple Park 设计哲学。

5. **They would have to cart us out in a box** —— 2014 Charlie Rose 谈 NSA：「We would never allow that to happen. They would have to cart us out in a box before we would do that.」 南方人式硬话，罕见激烈修辞。

6. **This too shall pass** —— 内部和多次外部，对抗短期波动焦虑。

7. **The carpenter who finishes the back of the drawer** —— Code 2022（Jony Ive 引用 Steve 原话，库克附议）。

8. **You are not our product** —— 多次，2014 Charlie Rose 最早：「Our business is not based on having information about you. You are not our product.」 一句话区分硬件 vs 广告商业模式，刻意打 Facebook/Google。

9. **A single tree does not make a forest** —— 2026 China Development Forum，配合 partnership/trust 框架。中国场合的本地化类比。

---

## 四、立场变化记录

库克最大特点是几乎没有立场反转。但有 3 个微妙变化：

1. **AI 节奏论的细化**：2017-2023 措辞模糊（"focus on user experience"）。2024 起在 WSJ 和 Wired 中主动列出 Mac/iPhone/iPad/iPod 都不是第一——从被动防守升级为主动叙事。

2. **接班问题口径松动**：2021 Sway "I'll probably not be at Apple in 10 years"——罕见具体时间。2023 Dua Lipa 改口 "I'll be there a while"，2026 GMA 强硬否认。少有的他给过具体数字然后又收回的话题。

3. **Trump 关系定性**：2016 中立 memo → 2018 MSNBC 较强硬批评分裂言论 → 2026 转向「I'm not political on either side」。从价值表态撤退到中立技术专家。

---

## 五、刻意回避的话题（hard no zone）

- **Apple Car / Project Titan 细节**：唯一会明说 "I will not talk about" 的产品话题。
- **新产品发布前任何剧透**：自嘲 "I'm full of secrets"（WWDC 2019 前 iMore）。
- **Steve Jobs 私人关系细节**：谈影响、原话、Steve 最后建议（"Never ask what would Steve do"），但不谈具体冲突或意见不合。
- **个人感情生活 / 伴侣**：2014 出柜后公开谈 LGBT 议题和身份，但从未提及任何具体伴侣关系。Amanpour 2018 试探，用 "I value my privacy" 挡回。
- **具体竞争对手 CEO 个人评价**：除 Zuckerberg 罕见破例外，不点名 Sundar/Elon/Satya。
- **中国政府具体决策的评价**：永远谈"合规"，从不谈"合理性"。
- **股价 / 短期财务指标**：永远说 "we focus on the long term"。
- **接班人具体名字**：只说 "we have very deep bench"，从不点 Jeff Williams。

---

## 六、价值观 vs 商业利益冲突时的话术（库克最独特的一面）

**三步式 dodge**：

### 步骤 1：把冲突重新定义为"双方都对"
"We can both protect privacy and serve customers." / "We can both be in China and uphold our values." 永不承认存在 trade-off。

### 步骤 2：用"法律 + engagement"作为最后防线
- 中国问题：「We follow the law wherever we do business.」
- HKmap 事件：「This decision best protects our users.」（把"服从中国"翻译成"保护用户"）
- 与政府对抗（FBI）也是同一句话：「We follow the law」——但此时指宪法第四修正案。
- **同一句话在不同场景指不同的法律，库克从不澄清这种切换**。

### 步骤 3：把分歧议题升格为"世纪级议题"
- 隐私 = "one of the top issues of this century"
- 气候 = 同样级别
- 教育 = "great equalizer"
升维后，对方很难继续追问操作细节。

### 经典案例：HKmap Live 事件（2019）
内部信原话 ——「We have credible information… the app had been used maliciously to target individual officers… This decision best protects our users.」
话术结构：(1) 不正面回答"是否屈服中国"；(2) 把下架定性为"保护"（保护谁？保护警察+居民）；(3) 用 "credible information" 但不出示证据。

### 经典案例：AI 落后
「We've rarely been first… sometimes you can be first and best, but any time you have to choose between the two, there's only one answer.」 构造虚假二选一（first vs best），让落后变成主动选择。

---

## 七、引用案例（一手原话，标注来源）

- 「No one should have a key that turns a billion locks. It shouldn't exist.」—— TIME 2016-03
- 「Privacy is a fundamental human right.」—— 多次，最早 NPR/Charlie Rose 2014/15
- 「We would never allow that to happen. They would have to cart us out in a box before we would do that.」—— Charlie Rose 2014-09，谈 NSA 后门
- 「You are not our product.」—— Charlie Rose 2014-09
- 「What would I do? I wouldn't be in this situation.」—— Recode/MSNBC 2018-04
- 「I do see it as a crisis. I see privacy as one of the top issues, the top few issues of this century.」—— PBS Amanpour 2018-10
- 「I'm gonna look at you and say, you are talking about something that I will not talk about.」—— Sway 2021-04，Apple Car
- 「For us, privacy is a basic human right. It's a right that other rights are built off of. It's bedrock.」—— Sway 2021-04
- 「I'm religious about exercising. For me, it's the thing that keeps stress at bay because I can't go to a national park every day unfortunately.」—— Outside 2020-12
- 「[Nature is] like a palate cleanser for the mind.」—— Outside 2020-12
- 「I'm good at blocking out the noise. I come back to: Are we doing the right things? Are we remembering our North Star?」—— 多次
- 「We've rarely been first. There was a PC before the Mac; there was a smartphone before the iPhone; there were many tablets before the iPad; there was an MP3 player before iPod.」—— All-hands 2025-08 + WSJ 2024-10
- 「Sometimes you can be first and best, but any time you have to choose between the two, there's only one answer.」—— 同上
- 「I've never been described as normal. I always hate the word normal in a lot of ways, because what some people use to describe normal equals straight.」—— GQ 2023-04
- 「Steve was original. Only he could have created Apple. If Steve were alive, he would still be the CEO.」—— Dua Lipa 2023-11
- 「I'll continue to work until the voice in my head says, 'It's time,' and then I'll go and focus on what the next chapter looks like.」—— Wired 2024-12
- 「I didn't say that. That's a rumor.」+「I can't imagine life without Apple.」—— GMA 2026-02
- 「A single tree does not make a forest; a single string cannot make music.」—— China Development Forum 2026-03
- 「This has been a symbiotic kind of relationship.」—— 2023 北京之行
- 「Apple would not exist without immigration.」+「We have been a smarter, wiser, more innovative company because we've attracted the best and brightest from all corners of the world.」—— All-hands 2026-02
- 「[care is] very often felt, and not necessarily seen.」+ 引 Steve 的 "finish the back of the drawer" —— Code 2022-09
- 「I love hearing his voice.」—— Apple Event 2017-09，Steve Jobs Theater 启用

---

## 八、信息不足的地方

1. 中国大学讲话的中文 Q&A 全文：清华 2014 只有官方简报，无完整 transcript。
2. Apple Board / 股东大会 Q&A：几乎无公开 transcript。
3. Stratechery / Ben Thompson 的访谈是否存在：未找到正式 transcript，可能是邮件交流未公开。
4. 早期（2011-2013）的访谈：D Conference 2010、2012 资料零散。
5. Dua Lipa 完整 transcript：第三方摘录较多，完整逐字稿需听音频或订阅 service95。
6. John Dickerson 60 Minutes：检索显示是 CBS Sunday Morning 2020 而非 60 Minutes 本体，需核实。
7. Outside Magazine 封面长文（2021-02）vs 同期 podcast：本次主要依赖 podcast 摘录。
8. 库克对 Vision Pro 销售不及预期的私下回应：是否有长访谈流露不同情绪？未见。

---

## 三个最具洞察的回答模式（精炼）

1. **议题升维（Reframe Upward）**：当被追问具体争议（隐私漏洞、AI 落后、中国合规），库克稳定地把问题升格为"世纪级议题"——隐私 = "top issue of the century"，AI = 比互联网+智能手机还大。一旦升维成功，对方就难以继续追问操作细节。这是他最稳定的脱困工具。

2. **三步式 dodge（trade-off 不存在 → 法律托底 → 升维收尾）**：价值 vs 商业冲突时，他从不承认存在二选一。先说"两者都可以"，再用"We follow the law wherever we do business"作万能挡板（同一句话在中国指中国法、在 FBI 案指宪法第四修正案，他从不澄清切换），最后议题升维。HKmap 事件是教科书级展示——把"配合中国下架"翻译成"this decision best protects our users"。

3. **构造虚假二选一让落后变成主动选择（false dichotomy as defense）**：经典就是 AI 上的 "first vs best"——「Sometimes you can be first and best, but any time you have to choose between the two, there's only one answer.」 实际上不存在这种被迫二选一，但这个修辞让 Apple 节奏慢变成了价值观胜利。配合"Mac/iPhone/iPad/iPod 都不是第一"的历史模式叙事，把当前焦虑解释成"你只是没意识到我们一向如此"。

另一发现：库克极少 hard no——但 Apple Car 是唯一会明说 "I will not talk about" 的产品话题；个人感情生活则用 "I value my privacy" 挡回，14 年从未提及任何具体伴侣关系。这是他自我设定的两条最硬边界。
