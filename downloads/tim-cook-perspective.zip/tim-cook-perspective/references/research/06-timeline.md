# Tim Cook 人物时间线

## 一、年表（按年/事件）

| 年份 | 阶段 | 关键事件 | 影响/意义 | 来源 |
|------|------|---------|----------|------|
| 1960-11-01 | 早年 | 出生于 Alabama 州 Mobile，在 Robertsdale 长大 | 南方蓝领家庭底色 | Wikipedia / Encyclopedia of Alabama |
| 1960s | 早年 | 父亲 Donald 在 Pascagoula 船厂当工人，母亲 Geraldine 在药店工作 | 形成"努力工作、克制消费"的价值观 | CNBC 2024 |
| 1960s-70s | 早年 | 童年时期在南方亲历民权运动余波；多次在演讲中提及目睹 KKK 焚十字架场景 | 日后民权与少数派立场的原点（注：cross-burning 细节出自他本人 Auburn / HRC 演讲，主流文献未独立佐证） | Cook 公开演讲（Auburn 2013、HRC 2013） |
| 1972 | 早年 | 12 岁起开始打工（送报、餐馆、药店帮母亲） | "everybody was expected to work" | CNBC 2024 |
| 1978 | 教育 | Robertsdale High School 毕业，毕业生代表（salutatorian）、学生会成员 | 学术与组织能力同步 | Britannica |
| 1978-1982 | 教育 | Auburn University 工业工程 BS | 工程师方法论训练 | Wikipedia |
| 1982 | IBM 起步 | 加入 IBM PC 业务，做制造与分销 | 进入"硬件+供应链"主线 | Wikipedia |
| 1986-1988 | 教育 | Duke Fuqua MBA（Fuqua Scholar，前 10%）夜读 | 边工作边读，强化运营＋财务训练 | Britannica |
| 1988-1994 | IBM | 升至 IBM 北美 PC 业务 Director of Fulfillment | JIT inventory 思想形成期 | Wikipedia |
| 1994-1997 | 中间 | 加入 Intelligent Electronics，任 Reseller Division COO | 第一个 COO 头衔 | Wikipedia |
| 1997-1998 | 中间 | Compaq VP of Corporate Materials（仅 6 个月） | 表面理性最优选择 | Wikipedia |
| 1998-03 | 加入 Apple | 经 Jobs 5 分钟面谈即决定加入，任 SVP Worldwide Operations | "Intuition over rational analysis"原点案例 | Auburn 2010 演讲 |
| 1998-1999 | Apple 早期 | 砍库存：从 30 天降至 6 天；关闭工厂、外包给富士康等中国厂商 | 重塑现代 Apple 供应链 | 多源 |
| 2002 | Apple 早期 | 升任 Worldwide Sales & Operations EVP | 销售也并入运营体系 | Britannica |
| 2004 | Apple 早期 | Jobs 第一次胰腺癌手术，Cook 临时代理 CEO 数月 | 第一次"摄政" | Wikipedia |
| 2005-10 | COO | 正式被任命为 COO | 接班序列确立 | Wikipedia |
| 2009-01 | COO | Jobs 肝移植期间，Cook 第二次代理 CEO 约 6 个月 | 第二次"摄政"；同期发生捐肝被拒事件 | Wikipedia |
| 2009 | 思想转折 | 主动提出捐部分肝脏给 Jobs（同稀有血型），被 Jobs 当场怒拒 | 个人情感与公司未来交织 | TIME / Becoming Steve Jobs |
| 2011-08-24 | CEO 上任 | 接任 Apple CEO | 接班 | Apple Newsroom |
| 2011-10-05 | CEO | Steve Jobs 去世 | 完全自主时代开始 | 多源 |
| 2012-09 | CEO | Apple Maps 灾难发布；Cook 公开道歉并推荐用户用 Google Maps、Waze | 罕见的官方道歉 | TechCrunch |
| 2012-10 | CEO | Scott Forstall 拒签 Maps 致歉信，被驱逐 | 树立"团队协作高于明星个人"治理风格 | MacRumors |
| 2013 | CEO | 美国国会反垄断/避税听证 | 首次政治对线 | 多源 |
| 2014-05 | CEO | $30 亿收购 Beats Electronics | 服务化业务的种子 | SEC 8-K |
| 2014-09-10 | CEO | 发布 Apple Watch、Apple Pay | 自主新品类首秀 | Apple |
| 2014-10-30 | 思想转折 | 在 Bloomberg Businessweek 公开出柜，成首位公开同志身份的 Fortune 500 CEO | "公私边界"重置 | Bloomberg Businessweek |
| 2014-12 | CEO | 与中国移动正式合作 iPhone 销售 | 中国市场加速器 | 多源 |
| 2015-06 | CEO | Apple Music 上线 | 服务订阅化 | CBS News |
| 2016-02-17 | 思想转折 | 在 San Bernardino 案中拒绝 FBI 解锁要求，发表"Message to Our Customers"公开信 | 与美国政府正面对抗，"隐私即权利"叙事确立 | Apple / NBC News |
| 2016-05 | CEO | 投资滴滴 $10 亿 | 中国关系深耕 | 多源 |
| 2016 | CEO | 与北京签 $2750 亿研发与采购协议（多年） | 进一步绑定中国 | Wall Street Journal |
| 2017 | CEO | iPhone X / HomePod 发布；应北京要求下架中国区 VPN App | "在中国遵守中国法律" | 多源 |
| 2018-08-02 | CEO | Apple 成首家市值 $1 万亿美企 | 财务里程碑 | Statista |
| 2018-10-24 | 思想转折 | Brussels 数据保护大会演讲，痛斥"data-industrial complex"，盛赞 GDPR | 隐私话语全球化 | American Rhetoric |
| 2019-03-06 | CEO | 白宫被 Trump 当面误称"Tim Apple" | 公关迷因 | TechCrunch |
| 2019-06-27 | CEO | Jony Ive 宣布离职创立 LoveFrom（Apple 仍为客户） | "设计驱动"时代落幕 | Engadget / WSJ |
| 2019-10-10 | CEO | 下架香港 HKmap.live 应用，并发内部信解释 | 中国-人权两难再次外显 | MacRumors |
| 2020-03 | CEO | COVID-19 关闭全球零售；推出全球供应链应急 | 危机管理 | 多源 |
| 2020-06 | 思想转折 | George Floyd 事件后，Cook 在公司内部信和推文支持 BLM 与种族平等 | 民权议题再被激活 | 多源 |
| 2020-06-22 | CEO | WWDC 宣布 Mac 转向 Apple Silicon（2 年过渡） | 垂直整合的关键一战 | Apple Newsroom |
| 2020-08-19 | CEO | Apple 成首家市值 $2 万亿美企 | 财务里程碑 | Statista |
| 2021-04 | CEO | iOS 14.5 上线 App Tracking Transparency（ATT） | 重创 Meta 等广告业务，确立 Apple 隐私护城河 | Apple |
| 2022-01-03 | CEO | Apple 短暂触及 $3 万亿市值 | 财务里程碑 | Statista |
| 2022-03 | CEO | 暂停在俄罗斯销售，回应俄乌战争 | 道德立场延伸 | 多源 |
| 2023-06 | CEO | WWDC 发布 Apple Vision Pro（定价 $3,499） | 进入 spatial computing 赛道 | Apple |
| 2023-08 | CEO | 中国市场首次出现明显结构性下滑（华为 Mate 60 Pro 发布同期） | "中国故事"裂痕 | CNBC |
| 2024-02-01 | CEO | Vision Pro 美国上市，初期销量与回头率均承压 | 高调新品类受挫 | TechSpot / MacRumors |
| 2024-02-27 | CEO | 取消 Apple Car（Project Titan，10 年） | 砍掉非战略大项目 | TechCrunch / NPR |
| 2024-03-21 | CEO | 美国 DOJ + 16 州反垄断起诉 Apple，指控 iPhone 智能机市场垄断 | 监管压顶 | DOJ / CNBC |
| 2024-03-07 | CEO | 配合欧盟 DMA，iOS 17.4 在欧盟允许 sideloading 和第三方应用市场 | 30 年"围墙花园"首次破口 | Apple Developer |
| 2024-06-10 | CEO | WWDC24 发布 Apple Intelligence | AI 战略首秀，但 Siri 高级功能未交付 | Apple Newsroom |
| 2024-09 | CEO | iPhone 16 / Apple Intelligence 美国上线，但中国未上线（监管） | 中国 AI 战略受阻 | 多源 |
| 2024 全年 | CEO | 中国 iPhone 销量同比 -17%，市占率退至第三 | "中国故事"二次重创 | 多源 |
| 2025-03 | CEO | 个性化 Siri 大幅延期；Apple 高层重组传闻 | AI 故事失血 | Bloomberg |
| 2025-03-20 | CEO | Mike Rockwell 接管 Siri，从 Giannandrea 手中剥离 | AI 内部"重启" | Bloomberg |
| 2025-07 | CEO | 宣布 Jeff Williams 7 月底卸任 COO，Sabih Khan 接任 | 运营接班 | AppleInsider |
| 2025-08-06 | CEO | 在白宫与 Trump 同台，宣布 4 年 $6,000 亿对美投资（含 $1,000 亿新承诺），赠送 24K 金底座礼物，换取芯片关税豁免 | "贸易战外交家"角色 | CNBC / Bloomberg |
| 2025-11-15 | CEO | Jeff Williams 正式从 Apple 退休（25 年） | 老将完成交班 | The Apple Post |
| 2025 末 | CEO | 因 Cook 对 Giannandrea 失去信心，AI 高管陆续转岗 | 信任体系重建 | 多源 |
| 2026-01-12 | CEO | 官宣选 Google Gemini 为下一代 Siri 提供基础大模型（多年合作，传闻约 $10 亿/年，定制 1.2T 参数模型） | 公开承认自研 LLM 不达标 | TechCrunch / Fortune |
| 2026-02 | CEO | Siri 多项功能再次延期（原定 3 月，推到 5/9 月）；Rockwell 与 Federighi 关系紧张 | AI 落地仍然吃力 | 9to5Mac |
| 2026-03-28 | CEO | Q2 FY26 财报放弃维持 7 年的 "net cash neutral" 政策，为 AI 资本开支与潜在并购腾出弹药 | 财务哲学转向 | MacDailyNews / TNW |
| 2026-04-15 | CEO | Giannandrea 股权 vesting 完成后正式退休 | AI 老团队清场 | 多源 |
| 2026-04-20 | CEO 退任 | Apple 官宣 Cook 9-01 转任 Executive Chairman，John Ternus（50 岁，硬件工程 SVP）接任 CEO | 时代交接 | Apple Newsroom / SEC 8-K |
| 2026-05 | 现状 | Apple 市值约 $4.48 万亿；过渡期 Cook 仍执 CEO 直到夏末 | 财务峰值仍由 Cook 见证 | companiesmarketcap |

---

## 二、关键阶段总结

### 2.1 早年与教育（1960-1988）
南方蓝领家庭长子，父亲是船厂工人，母亲是药店职员。Alabama 的童年同时塑造了两个对立基因：一是工人阶级的克制与勤勉（12 岁开始打工攒大学学费），二是民权运动尾声的目击者经验——他在 Auburn 与 HRC 等多次演讲中强调亲眼见过种族暴力，将其作为"少数派立场"的根源。Auburn 工业工程 BS（1982）+ Duke MBA（1988，边在 IBM 工作边读，进入前 10% Fuqua Scholar）的组合，铸成他"工程师方法论 + 运营财务思维"的双内核。

### 2.2 IBM 与制造业训练（1982-1994）
12 年 IBM PC 业务生涯是他"被 Jobs 看上"的全部理由。这一时期他把 JIT inventory 从理论变成肌肉记忆：库存周转、分销网络、订单履约。他升到北美 PC 业务 Director of Fulfillment，是当时少有的"懂硬件、懂供应链、懂数字"的综合型管理者。Intelligent Electronics（COO of Reseller Division）与 Compaq（VP of Corporate Materials，仅 6 个月）只是过渡，但 Compaq 的"理性最优 vs 直觉"对比成为他日后最常引用的人生故事。

### 2.3 加入 Apple 与供应链革命（1998-2007）
1998 年 3 月被 Jobs 5 分钟面谈打动加入，是 Cook 个人叙事里最重要的"直觉时刻"。上任后立刻做了两件事改变 Apple DNA：库存从 30 天压到 6 天，工厂全部关闭转外包给以富士康为代表的中国制造业。这两步直接把 Apple 从一家濒临破产的电脑公司变成一家可以做 iPod、iPhone 的高利润硬件平台。2002 升任 Worldwide Sales & Operations EVP，2004 年首次代理 CEO（Jobs 胰腺癌手术）已经显示出他不可替代的运营地位。

### 2.4 COO 与 Jobs 影子（2005-2011）
2005 年 10 月正式 COO，2009 年再次代理 CEO 6 个月（Jobs 肝移植）。这一阶段两件事最关键：一是把 iPhone 推向全球规模化生产，奠定全球供应链霸权；二是中国市场全面铺开，从制造端延伸到销售端。私人层面，2009 年提出捐部分肝脏给 Jobs 被怒斥拒绝，是他与 Jobs 关系最戏剧化的瞬间——也奠定了他"忠诚、克制、长期主义"的人格底色。

### 2.5 CEO 第一阶段：守成（2011-2016）
2011 年 8 月接棒，10 月 Jobs 去世，外界普遍质疑"运营型 CEO"能否扛起创新大旗。Cook 的回答是：先稳住产品（iPhone 持续放量），再补全服务版图（2014 收购 Beats、2015 上线 Apple Music），同时建立自己的产品类目（2014 Apple Watch / Apple Pay）。2012 Maps 灾难与随后 Forstall 被驱逐是治理风格的关键转折——他不容忍拒绝团队协作的明星个人。

### 2.6 CEO 第二阶段：道德领袖姿态（2014-2020）
三件事让他从"Jobs 的运营 deputy"变成"全球道德议程的发言人"：2014-10-30 在 Bloomberg Businessweek 出柜（首位公开同志身份的 Fortune 500 CEO）；2016-02 拒绝 FBI 解锁 San Bernardino 嫌犯 iPhone，公开信"Message to Our Customers"成为隐私议题里程碑；2018-10 在 Brussels 大会上痛斥"data-industrial complex"，正式把"隐私即基本人权"作为 Apple 全球叙事。这一阶段他完成了从工程师/COO 到"道德领袖 CEO"的人格升级，也是 Apple ESG / 品牌溢价的黄金期。同期复杂面：2017 撤中国区 VPN、2019 下架香港 HKmap.live，"在每个国家遵守该国法律"成为他最被批评的中国策略表述。

### 2.7 CEO 第三阶段：增长瓶颈与 AI 焦虑（2020-2026）
2020 年宣布 Apple Silicon 转型是他最被低估的战略决策，三年完成 Mac 全线换芯。2020-08 突破 $2 万亿，2022-01 短暂触及 $3 万亿。但 2021 年 ATT 上线后 Apple 与广告行业的对立加剧；2023 年 Vision Pro 高调发布但销量长期低迷（首年不足 50 万台）；2024-02 砍掉做了 10 年的 Apple Car，2024-03 同时面临 DOJ 反垄断起诉与 EU DMA 强制开放 sideloading。2024-06 Apple Intelligence 发布，但承诺的个性化 Siri 一再延期；2025 中国市场跌 17%，2026-01 被迫公开承认靠 Google Gemini 救 Siri，2026-03 放弃 7 年的 "net cash neutral" 财务目标为 AI 资本开支腾空间。2026-04-20 官宣 Cook 9-01 转任 Executive Chairman，硬件工程 SVP John Ternus 接任 CEO——这是 Apple 历史上第二次主动安排的有序交接。

---

## 三、思想转折点（按重要性排序）

1. **童年目睹种族暴力（约 1960s-70s）** → 一辈子在 LGBTQ、移民、种族议题上公开发声的根源；他在 2013 HRC 演讲、2014 Bloomberg 出柜文章、Auburn 演讲里反复引用。
2. **1998 加入 Apple 的"intuition"故事** → 他公开思想体系里最常引用的范例：当所有数字都指向 Compaq 时，凭直觉选择已经濒临破产的 Apple。从此"直觉先行、然后用准备和执行兑现"成了他的方法论模板（Auburn 2010 演讲）。
3. **2009 捐肝给 Jobs 被拒** → 个人层面与 Jobs 关系的顶点，也强化了他"克制、不越界、长期主义"的人格特质。
4. **2014-10-30 出柜** → 公私边界重置。他用"如果能帮到一个孩子，值得拿隐私换"的句式，正式接受公共道德发言人角色。
5. **2016 FBI 案** → 第一次明确把 Apple 摆到美国政府对立面；隐私从产品属性升级为政治原则。
6. **2018 Brussels 演讲** → "data-industrial complex"成为 Apple 全球品牌叙事核心；为 2021 ATT 等强势隐私动作铺垫合法性。
7. **2024-2026 AI 战略转向** → 从"我们自研 + 集成 OpenAI"到 2026-01 公开选 Google Gemini，再到 2026-03 放弃 net cash neutral 为 AI capex 让路。这是他执掌 Apple 期间最深刻的一次"承认自己不够好"的认知更新，也直接推动了 4 月的接班宣布。

---

## 四、最近 12 个月动态

- **2025-07**：宣布 Jeff Williams 7 月底卸任 COO，Sabih Khan 接任（AppleInsider）
- **2025-08-06**：白宫与 Trump 同台，承诺 4 年 $6,000 亿对美投资（+$1,000 亿新承诺），赠 24K 金底座；同日宣布 100% 芯片关税但对 Apple 豁免（CNBC / Bloomberg）
- **2025-11-15**：Jeff Williams 正式退休（The Apple Post）
- **2025-12-10**：Williams 退休不到一个月加入 Disney 董事会（Fortune）
- **2026-01-12**：Apple 与 Google 多年协议，Gemini（定制 1.2T 参数模型）将驱动下一代 Siri（TechCrunch / Fortune）
- **2026-02**：Siri 多项延期功能从 3 月推到 5/9 月（9to5Mac）
- **2026-03-28**：Q2 FY26 财报正式放弃 "net cash neutral"（实施 7 年）；Q2 末净现金 $620 亿（MacDailyNews / The Next Web）
- **2026-04-15**：Giannandrea 完成 vesting 后正式从 Apple 退休（多源）
- **2026-04-20**：Apple 官宣 Cook 9-01 转任 Executive Chairman，John Ternus 接任 CEO（Apple Newsroom / SEC 8-K / CNBC）
- **2026-05**：Apple 市值约 $4.48 万亿（companiesmarketcap）

---

## 五、信息不足或矛盾

1. **童年 KKK 焚十字架细节**：来自 Cook 本人公开演讲（Auburn、HRC），但本次搜索未找到独立第三方实地报道或当地新闻佐证。归类为"本人口述史"，不是事实硬证据。
2. **Ternus 年龄**：任务给的是 51 岁，Apple Newsroom 与 CNBC 同日新闻写的是 50 岁。本文按官方稿采 50 岁。
3. **Jeff Williams 退休**：任务说 2025-12，实际公开记录是 2025-11-15 最后一天（前段已于 2025-07 底卸任 COO）。
4. **Mike Rockwell 接管 Siri 的官宣时间**：Bloomberg 原报道是 2025-03-20，本文按此采。任务给的 "2026-02" 实际更接近"Siri 功能再次延期"事件。
5. **Gemini 协议金额**：多家二手媒体引述约 $10 亿，但 Apple 与 Google 双方均未官方确认。
6. **童年家庭细节**：父亲岗位有"船厂工人"与"造船工人"两种译法，主流英文资料统一为 Pascagoula shipyard worker。
