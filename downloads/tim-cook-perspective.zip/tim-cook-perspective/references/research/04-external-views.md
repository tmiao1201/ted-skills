# Tim Cook 他者视角调研

> **调研范围**：传记作者、调查记者、前员工、批评者、对手、分析师对 Tim Cook 的观察。**不包含**他本人著作、访谈、社媒（其他 agent 负责）。
> **调研日期**：2026-05
> **信息源数量**：约 50+ 篇报道/书评/分析
> **方法论**：区分调查记者深度报道（高可信） vs 一般博客观点（中可信） vs 阴谋论（不收录）；保留矛盾不替任何一方站台

## 一、关键传记 / 报道源

### 1.1 核心书籍

| 书 / 报道 | 作者 | 年份 | 倾向 | 核心论点 | 可信度 |
|---|---|---|---|---|---|
| After Steve: How Apple Became a Trillion-Dollar Company and Lost Its Soul | Tripp Mickle (WSJ→NYT) | 2022 | 批判 | Apple 在 Cook 治下成了运营帝国但"丢了灵魂"；Ive 出走是文化转向的标志 | 高（200+ 高管访谈）|
| Tim Cook: The Genius Who Took Apple to the Next Level | Leander Kahney (Cult of Mac) | 2019 | 偏正面 | Cook 完成了"不可能的接班"，把 Apple 推向万亿 | 中（**未采访 Cook 本人**）|
| Inside Apple | Adam Lashinsky (Fortune) | 2012 | 中性 | 揭示 DRI、Top 100 等内部机制；Cook 接手早期画像 | 中高 |
| Haunted Empire: Apple After Steve Jobs | Yukari Iwatani Kane (前 WSJ) | 2014 | 唱衰 | Apple 没了 Jobs 必将衰落，Cook 是"传统经理人" | 低（结论先行，被股价证伪）|
| Apple in China: The Capture of the World's Greatest Company | Patrick McGee (FT 前驻华) | 2025 | 强批判 | Cook 让 Apple 投资中国 2750 亿美元，造成"史诗级技术转移" | 高（SABEW 年度商业书奖）|

### 1.2 重要长篇报道源
- **Bloomberg / Mark Gurman "Power On"** — Apple Intelligence/Siri 危机、内部权斗
- **WSJ / Tripp Mickle** — 2019 Ive 出走调查报道（出书素材源）
- **NYT / Jack Nicas、Tripp Mickle** — Apple 中国数据中心、iCloud 加密让步
- **The Information / Wayne Ma** — Vision Pro 供应链内情、产品决策
- **Stratechery / Ben Thompson** — 结构性战略分析
- **Asymco / Horace Dediu** — 数据驱动的财务/运营分析
- **Daring Fireball / John Gruber** — Apple 圈"国师"级博客，Cook 任期内转向批判

## 二、外界观察到的行为模式（≠他自己说的）

### 2.1 时间纪律
- 凌晨 3:45–4:00 起床，6 点前处理 700–800 封邮件
- 每周日晚 ops review 雷打不动，会议常持续 5–6 小时
- 每天 1 小时力量训练

### 2.2 会议风格："沉默 + 钻问"
- 1:1 会议至少 10 分钟保持沉默，面无表情（Inc、CNBC、《After Steve》一致记录）
- "awkward silence"技术，会议中只听见他拆能量棒包装的声音
- 一旦开口连环追问数小时
- **对照 Jobs**：Jobs 情绪化咆哮直接做决定；Cook 冷静数据化让你自暴露漏洞

### 2.3 与 Ive / 设计部门的疏离
- Cook 极少去设计工作室（Jobs 几乎每天中午都进去，table by table 跟 Ive 过设计）
- Apple Watch 开发期间，Cook 对 Ive 关注极少
- Ive 私下评价 Cook 引入的 CFO 背景董事 James Bell："He's another one of those accountants"

### 2.4 偏好"和谐"团队（与 Jobs 相反）
- Jobs 喜欢强人互相冲撞，Cook 受不了内部冲突
- 2012 年 Forstall 拒签 Maps 道歉信即被开除
- 偏好"共识型"而非"对抗型"决策文化

### 2.5 政治家式的"Trump whisperer"
- Trump 第一任、第二任都成功直接游说，2024 拿到对华关税整体豁免
- 2025 给 Trump 就职典礼捐 100 万美元、参加 Mar-a-Lago 晚宴
- Trump 描述风格："nakedly transactional and personalistic"
- Out.com 评价："trades dignity for tariff exemption"

### 2.6 极度低调
- 2014 年公开出柜（财富 500 第一位）
- 但出柜之外几乎不谈个人生活
- Mickle 形容"aloof and unknowable"

## 三、主要批评类别

### 3.1 创新力批评："没有真正的新品类"
**论点**：iPhone 设计自 2019 Ive 离开后没变；CSO 职位至今空缺；Vision Pro（2024）已被认为失败，团队 2026-04 被打散并入 Siri；Apple Car 2014-2024 烧约 100 亿美元后取消；Apple Watch 是配件而非独立平台。

**代表声音**：Mickle "shifted from innovation to operational excellence"；Ben Thompson 称 Cook 优化短期最优；Unherd 2026 "Time is running out for Tim Cook"。

**辩护**：Apple Watch 是品类创造者；AirPods、Apple Silicon 是任内重大突破；市值 1251% 涨幅；2025 AI capex 泡沫中 Apple 没烧钱反被夸"impeccable timing"。

### 3.2 中国关系："道德 vs 商业"双标
**论点**：
- 2019 HKmap.live 下架——Cook 解释被开发者立刻反驳；Gruber 当天写"sad and startling"
- 2018 iCloud 数据转入贵州，解密密钥也存中国境内政府数据中心
- 2024 应北京要求下架 Telegram/WhatsApp/Signal
- 2016 秘密协议：5 年内向中国投资 2750 亿美元（McGee 核心爆料）

**代表声音**：McGee "Tim Cook gave China the ability to kill Apple, almost instantly"；Amnesty International (2018)；前 Facebook CSO Alex Stamos 质疑隐私双标；Ben Thompson 称 China dependency 是"最大成就同时最大脆弱性"。

### 3.3 AI 战略落后（2023–2026）
**论点**：Bloomberg/Gurman 报道 Cook 在 ChatGPT 之前根本不信 AI；WWDC 2024 演示的"个性化 Siri" 2025-03 被迫推迟到 2026 春；John Giannandrea 2025-03 被剥权，2026 春退休；Apple 被迫选 Google Gemini 救 Siri；AI 人才被 Meta/OpenAI 挖走。

**代表声音**：
- **Gruber《Something Is Rotten in the State of Cupertino》(2025-03)**：直接质问"that person was Tim Cook"
- Gurman："The top of Apple is run like a small family business with few decision-makers"
- Computerworld："a successful CEO who stumbled over AI"

**辩护**：MIT/BCG 2025 研究 83% 企业 GenAI pilot 没上生产；Cook 保留 optionality；2025 末 AI spending fatigue 时 Apple 股价反涨。

### 3.4 垄断与 App Store
- **DOJ 2024-03 反垄断**：65% 市场份额，指控削弱 Apple Watch 竞品、限 iMessage、限 NFC
- **Epic Games**：2021 总体赢但被禁止阻止外部支付引导；2025 被判违反禁令，Cook 上诉
- **EU DMA**：2025-04 罚 5 亿欧元，被迫开放 sideloading
- Cook 用"安全/隐私"叙事辩护，但监管者不买账

### 3.5 接班与"失去灵魂"论
- Mickle epilogue："aloof and unknowable"
- 高管出走清单：Forstall (2012)、Ive (2019)、Mansfield、Ron Johnson、Ahrendts、Giannandrea (2026)
- 接班人 John Ternus（硬件副总裁，2026-09 上任）继续"运营人接运营人"

### 3.6 薪酬与劳工
- 2021 年薪 $98.7M，ISS 反对（50% 无业绩条件、$712K 私人飞机补贴）
- 2023 Cook 主动降薪 40%（罕见）
- 反工会：雇 Littler Mendelson 律所；内部 anti-union talking points 被泄露
- 2026 关 Towson 工会店——9 位国会议员联名抗议
- DEI 进展：2018-2020 全球女员工只增 2%，黑人技术岗 6%（持平）

## 四、争议事件（按时间）

| 事件 | 时间 | Cook 行为 | 批评 | 辩护 |
|---|---|---|---|---|
| Apple Maps 灾难 | 2012-09 | 公开道歉，开除 Forstall | 仓促上线、Forstall 是替罪羊 | Cook 自己 2026 称"first really big mistake" |
| 出柜 | 2014-10 | Businessweek 撰文 | (基本正面) | 财富 500 第一位，符号意义 |
| FBI iPhone | 2016 | 拒绝创建后门 | Bill Gates 不同意 | 隐私倡导高光 |
| 2750 亿在华投资协议 | 2016 | 大规模在华投资 | McGee：送钥匙给北京 | 守住中国市场 |
| iCloud 数据迁入贵州 | 2018 | 配合《网络安全法》 | Amnesty 公开谴责 | 法律合规 |
| Ive 离开 | 2019-06 | 称 WSJ 报道"absurd" | WSJ：Ive 受不了运营导向 | 未驳具体事实 |
| HKmap.live 下架 | 2019-10 | 内部信"credible information" | Gruber 当天反驳 | 安全考量 |
| ATT vs Zuckerberg | 2020-2021 | iOS 14 强制 opt-in | Zuck "misleading" | 隐私"基本人权" |
| 薪酬 1 亿美元 | 2021 | 接受 $98.7M | ISS 反对 | 2023 主动降薪 40% |
| Apple Car 取消 | 2024-02 | 烧 100 亿后终止 | "indecisive Cook blew $1B a year" | 转向 GenAI |
| DOJ 反垄断起诉 | 2024-03 | 公开反对 | 生态锁定 | 上诉中 |
| Vision Pro 上市 | 2024-02 | $3499 高调推出 | 销量 < 50 万、Cook 承认"不是大众产品" | "tomorrow's engineering today" |
| Apple Intelligence Siri 推迟 | 2025-03 | 沉默后推迟 | Gruber"Something Is Rotten" | 未公开回应 |
| EU DMA 罚款 5 亿欧元 | 2025-04 | 反对、合规复杂化 | 欧委会判故意阻碍 | 安全/隐私 |
| 给 Trump 就职捐 100 万 | 2025-01 | 出席 Mar-a-Lago | "trades dignity" | 拿到关税豁免 |
| Towson 工会店关闭 | 2026-05 | 拒绝转岗权 | 9 位国会议员联名 | 商业决策 |
| 宣布退休、Ternus 接班 | 2026-04 | 转 Executive Chair | "leaves without successor to iPhone" | "perfect timing" |

## 五、与同行的差异（外部视角）

**vs Steve Jobs**：Jobs 称 Cook "not a product person, per se"（Isaacson 承认书里软化了）。Jobs 产品直觉+情绪化+工业设计中心；Cook 运营纪律+平静+财务/供应链中心。

**vs Satya Nadella**：Nadella 把 MSFT 转向互操作、押 OpenAI 一战封神；Cook 财务优化到极致但 AI 保守。Computerworld 2026 直接对比"Who's the better CEO"——AI 时代 Nadella 占上风。

**vs Sundar Pichai**：Pichai Gemini 虽有翻车但持续投入；Cook 几乎要靠 Gemini 救 Siri。

**vs Elon Musk**：Musk 极度张扬政治高调；Cook 极度克制低调。都跟 Trump 走得近，但 Cook 是低调换利益，Musk 是高调换权力。

**vs Mark Zuckerberg**：Cook 把 Zuck 当成"商业模式造成分裂"的反面教材。2021 ATT 之战是科技圈撕得最厉害的一对。Zuck 内部"inflict pain" on Apple。

**vs Jeff Bezos**：都用"awkward silence"管理技术。Cook 更介意公共形象/道德姿态，Bezos 完全不在乎。

**vs 任正非 / 张一鸣**：与张一鸣最相似（低调+数据+运营型）；与任正非最大差异是 Cook 从不公开输出价值观叙事。

## 六、外界识别的"盲点"

1. **运营优化天花板已到**：财务工程拉高市值的边际收益递减；AI 时代需要的恰是 Cook 最弱的"产品赌博精神"
2. **道德姿态在中国失效**：西方建立的隐私/平等/环保人设在中国系统性让步，Cook 至今未正面回应
3. **"和谐文化"扼杀创意冲突**：Forstall 后没再容忍强人；Ive 出走后设计部门元气大伤
4. **Trump 关系的长期代价**：短期拿豁免，但"原则派"形象彻底破坏
5. **AI 范式认识晚 2-3 年**：不止技术差距，是**判断力差距**
6. **接班选择保守**：Ternus 又是硬件运营人，可能是又一次"准备打上一场战争"
7. **垄断指控结构性必然**：闭环帝国必然招致反垄断围剿

## 七、内在张力（外部视角）

| 维度 | 公开姿态 | 实际行为 | 外部评价 |
|---|---|---|---|
| 隐私 | "基本人权"、硬刚 FBI | iCloud 密钥存中国政府数据中心；下架 Telegram/WhatsApp/Signal | Stamos、Amnesty：双标 |
| 平等/DEI | "Inclusion inspires innovation" | 黑人/拉丁裔进展 6 年原地踏步；反工会 | 媒体反复批评 |
| 反垄断道德 | 30% 抽成"为用户安全" | DOJ、EU、Epic 全部判违规 | 监管者集体不信 |
| 环境 | 2030 全供应链碳中和 | iPhone 90% 在中国制造、煤电为主 | 部分质疑 accounting |
| 自由价值观 | 在美反对政府干预 | 配合中国审查、捐 Trump 换关税 | "trades dignity" |
| 创新文化 | "great products in pipeline" | Vision Pro 失败、Car 取消、AI 落后 | Gruber/Mickle/Thompson 一致质疑 |

## 八、信息源可信度评估

**高可信**：Mickle (NYT/WSJ)、McGee (FT)、Gurman (Bloomberg)、Wayne Ma (The Information)、Gruber (Daring Fireball)、Thompson (Stratechery)

**中等可信**：Kahney（未采访 Cook 本人）、Lashinsky（2012 较早）、Isaacson Jobs 传记的二手转述

**低可信**：Yukari Kane《Haunted Empire》（被股价证伪）；大量"daily routine"营销文章

**不收录**："Cook 与 CCP 卖国协议"类阴谋叙事；未证实的宫斗八卦

## 九、信息不足的地方

1. Cook 与董事会（Art Levinson）的真实权力分工
2. Cook 个人决策框架（Car 取消、AI 延期的具体心理过程）
3. Cook 真实政治立场（捐 Trump 是策略还是认同？）
4. 接班选择的内部博弈（为什么是 Ternus 不是 Federighi、Joswiak？）
5. Cook 私人生活（独居、不饮酒、阿拉巴马橄榄球外几无可靠信息）
6. McGee 的 2750 亿美元数字来源还需更多交叉验证
7. Cook 与中国高层实际互动内容几乎全无泄露
