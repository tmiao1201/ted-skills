---
name: skill-harden
description: |
  Skill 质量加固工具——给任意 skill 注入三层防御机制：Anti-Rationalization Table（反偷懒表）、
  When NOT to Use 排除条件、per-skill Exit Gate（退出检查）。
  灵感来源：Addy Osmani 的 agent-skills (Google 工程文化) × Kenno 自进化体系。
  当用户提到"加固 skill"、"强化 skill"、"skill-harden"、"给 skill 加防护"、
  "skill 质量检查"、"harden"时触发。
argument-hint: "<skill-name> [--from-memory] [--dry-run]"
---

# skill-harden — Skill 质量加固工具

## 定位

**不是新建 skill，而是给现有 skill 加装三层防御。**

核心理念来自 Addy Osmani 的 agent-skills 项目（https://github.com/addyosmani/agent-skills）：
AI Agent 天然趋向最短路径——跳过验证、省略测试、用"看起来对"代替"确认对"。
Anti-Rationalization Table 是对抗这一倾向最有效的武器——不是加更多规则，而是
**预判 Agent 每一个偷懒的理由，提前击碎它**。

与 Kenno 自进化体系的结合点：踩坑后的 Memory/nmem 记录可以自动反哺为新的
Rationalization 条目，形成"静态纪律 + 动态进化"双重防线。

## 触发场景

- 用户说"加固一下这个 skill"、"harden"、"skill-harden"
- 用户说"这个 skill 老出问题"、"Agent 总是在这个 skill 里偷懒"
- 新 skill 创建后主动建议："要不要跑一次 /skill-harden？"
- 从 Memory 中发现某 skill 反复踩坑 → 主动建议加固

## 不适用场景（When NOT to Use）

- Skill 只有 <20 行且逻辑无分支 → 加固的 token 成本超过收益
- 用户正在快速原型阶段 → 等稳定后再加固
- 已经有完善三层防御的 skill → 不要重复加固，去更新具体条目

## 三层防御机制

### Layer 1: Anti-Rationalization Table（反偷懒表）

**原理**：不是告诉 Agent "你必须做 X"，而是预判 Agent 想偷懒时的每个借口，
提前用事实反驳。这将隐性工程纪律（tacit knowing）显性化为可执行的反驳链。

**格式**（嵌入 SKILL.md 的 `## Common Rationalizations` 节）：

```markdown
## Common Rationalizations

| Agent 可能的借口 | 为什么这是错的 |
|-----------------|---------------|
| "改动很小，不用测试" | 上次'小改动'导致了 3 小时的 debug（ref: memory_xxx） |
| "用户没要求这个" | 用户的需求是结果，不是过程——跳过验证是你的偷懒，不是用户的意思 |
| "先完成再优化" | 如果现在不检查边界条件，完成的东西可能是错的 |
```

**生成规则**：
1. 读取目标 skill 的执行流程，识别每个"Agent 可能跳过"的步骤
2. 如果有 `--from-memory` 标志，搜索 nmem 中与该 skill 相关的踩坑记录，转化为条目
3. 每个 skill 最多 5 条 rationalization——超过 5 条说明 skill 本身设计有问题
4. 每条必须有具体的反驳理由，不能是泛泛的"这很重要"

### Layer 2: When NOT to Use 排除条件

**原理**：触发条件告诉 Agent 何时用这个 skill，排除条件告诉 Agent 何时**不要用**。
缺少排除条件会导致 skill 误触发，浪费 token 并可能产生错误输出。

**格式**（嵌入 SKILL.md 的 `## When NOT to Use` 节，紧跟触发场景之后）：

```markdown
## 不适用场景（When NOT to Use）

- {场景 1}：{为什么不适用，以及应该用什么代替}
- {场景 2}：{为什么不适用}
```

**生成规则**：
1. 分析 skill 的触发条件，找出"看起来匹配但实际不应触发"的场景
2. 检查 CLAUDE.md 的 Skill Routing 节，找出与该 skill 容易混淆的其他 skill
3. 排除条件必须是**可判断的**——Agent 能在触发时立即判断，不需要执行才知道

### Layer 3: Exit Gate（退出检查）

**原理**：将 CLAUDE.md Phase 2 的"禁止虚报完成"从全局规则下沉到每个 skill，
使检查更具体、更可执行。Exit Gate 不满足 → 不能宣布 skill 执行完成。

**格式**（嵌入 SKILL.md 的 `## Verification` 节，放在末尾）：

```markdown
## Verification（退出检查）

完成以下所有检查后，才能宣布 skill 执行完成：

- [ ] {检查项 1}：{具体的验证方法}
- [ ] {检查项 2}：{具体的验证方法}
- [ ] {检查项 3}：{具体的验证方法}
```

**生成规则**：
1. 每个检查项必须是**可验证的**——有明确的通过/失败标准
2. 避免"看起来对"类检查——必须有具体的验证动作（运行命令、读文件、对比输出）
3. 检查项数量 = skill 复杂度：简单 skill 2-3 项，复杂 skill 5-7 项，不超过 7 项
4. 如果 skill 涉及输出文件，必须包含"输出文件存在且内容正确"的检查

### Layer 4: Red Flags（执行中违规信号）

**原理**：Exit Gate 是事后检查，Red Flags 是**事中拦截**。列出 Agent 执行该 skill 时
可能出现的违规行为信号——一旦观察到就应立即停下纠正，而非等到最后验证才发现。

**格式**（嵌入 SKILL.md 的 `## Red Flags` 节，放在执行流程之后、Exit Gate 之前）：

```markdown
## Red Flags

执行过程中如果出现以下信号，立即停下来纠正：

- {信号 1}：{意味着什么，应该怎么做}
- {信号 2}：{意味着什么，应该怎么做}
```

**生成规则**：
1. 每条 Red Flag 必须是**可观察的行为**，不是内部状态（"跳过了测试" ✓，"没有认真想" ✗）
2. 每条附带纠正动作——不只是告警，还要说怎么修正
3. 最多 4 条——太多了 Agent 会忽略全部
4. 优先覆盖**高频违规**而非极端情况

## 执行流程

### Step 1: 读取目标 Skill

```bash
cat ~/.claude/skills/{skill-name}/SKILL.md
```

理解 skill 的：
- 触发条件和执行流程
- 当前是否已有部分防御机制
- 复杂度等级（简单/中等/复杂）

### Step 2: 收集踩坑记录（可选，`--from-memory`）

如果用户指定了 `--from-memory`：

```bash
nmem --json m search "{skill-name}"
```

从搜索结果中提取：
- 与该 skill 相关的 feedback 类型 memory
- 反复出现的错误模式
- 用户的纠正和确认

将踩坑记录转化为 Anti-Rationalization 条目。

### Step 3: 生成三层防御

按优先级生成：
1. **Anti-Rationalization Table** — 最高价值，优先生成
2. **When NOT to Use** — 防误触发
3. **Exit Gate** — 防虚报完成

如果 `--dry-run`：只展示生成的内容，不写入文件。
否则：直接编辑目标 SKILL.md，在适当位置插入三层防御。

### Step 4: 验证插入

重新读取修改后的 SKILL.md，确认：
- 格式正确，没有破坏原有结构
- 三层防御的位置合理（Rationalizations 在流程之后、Exit Gate 在末尾）
- 没有与原有内容矛盾

### Step 5: Red-Blue-Judge 对抗验证（关键步骤，不可跳过）

加固写完不等于有效。**同一个 Agent 出题又答题 = 自己批改自己作业**，没有意义。
必须用角色分离 + 多 Agent 对抗来验证防御的真实效力。

#### 5.1 启动三方对抗

使用**并行 Agent**同时启动 3 个 Red Team 攻击者（不同视角），每个 Agent 拿到：
- 目标 skill 的完整 SKILL.md（含刚写入的防御）
- 明确的攻击任务

**Red Agent A — 偷懒者（Lazy Agent）**
> 你的目标是找到最快完成这个 skill 的捷径。你不想做多余的事。
> 对每条防御条目，构造一个具体场景：你在执行这个 skill 时如何跳过该步骤
> 而仍然让输出"看起来"正确。说出你的内心独白——你会怎么说服自己这样做没问题。

**Red Agent B — 诡辩者（Rationalizer Agent）**
> 你是一个擅长找措辞漏洞的律师。对每条防御条目，找到它措辞中的模糊地带，
> 构造一个场景，让你可以说"这条规则不适用于此情况"——而且听起来有道理。
> 重点攻击：限定词（"通常"、"建议"、"如有"）、未定义的边界、隐含的例外。

**Red Agent C — 边界探测者（Edge Case Agent）**
> 你的目标是找到技术上满足防御条件但违背防御精神的场景。
> 例如：Exit Gate 说"运行测试"，你跑一个空测试套件——技术上通过但实际无效。
> 重点攻击：可被形式化满足但实质绕过的检查项。

每个 Red Agent 输出格式：
```
## 攻击报告

### 攻击 1: {目标防御条目}
- **场景**：{具体描述}
- **绕过方式**：{Agent 内心独白/诡辩逻辑/边界利用}
- **当前防御为什么挡不住**：{措辞漏洞/逻辑缺陷}
- **攻击可信度**：高/中/低（这种偷懒在真实使用中多大概率发生？）
```

#### 5.2 Blue Team 防御修复

收集全部 Red Team 攻击后，启动 **Blue Agent（防御者）**：

> 你是安全审计员。收到了 3 份攻击报告，共 N 条攻击。
> 对每条攻击：
> 1. 判断攻击可信度（真实场景中会不会发生？1-5 分）
> 2. 对可信度 ≥3 的攻击，给出**具体的措辞修复**——改哪个词、加什么限定
> 3. 检查修复是否引入新问题（过度约束、与其他条目矛盾、token膨胀）
> 不要泛泛说"加强措辞"，必须给出修复前→修复后的 diff。

Blue Agent 输出格式：
```
## 防御修复报告

### 攻击 1 (from Red-A): {条目名}
- **可信度**: 4/5
- **修复**:
  - 原文: "建议运行完整测试"
  - 改为: "必须运行完整测试套件且通过率 100%，空测试套件视为未通过"
- **副作用检查**: 无矛盾，+12 字符，可接受
```

#### 5.3 Judge 裁决

最后启动 **Judge Agent（裁判）**，拿到 Red 攻击 + Blue 修复的全部材料：

> 你是最终裁判。对每轮攻防：
> 1. **攻击是否真实？** — 这种偷懒在生产环境中会发生吗？（是/否 + 理由）
> 2. **修复是否有效？** — 修复后的措辞能否完全封堵该攻击？（是/否 + 理由）
> 3. **修复是否过度？** — 是否引入不必要的约束？（是/否 + 理由）
> 4. **最终裁决**：APPLY（采纳修复）/ REVISE（修复方向对但需调整）/ DISMISS（攻击不现实，无需修复）

Judge Agent 输出格式：
```
## 裁决报告

| # | 攻击来源 | 目标条目 | 攻击真实性 | 修复有效性 | 裁决 |
|---|---------|---------|:---:|:---:|------|
| 1 | Red-A | Rationalization #2 | ✅ 真实 | ✅ 有效 | APPLY |
| 2 | Red-B | Exit Gate #1 | ✅ 真实 | ⚠️ 需调整 | REVISE |
| 3 | Red-C | Red Flag #3 | ❌ 不现实 | — | DISMISS |
```

#### 5.4 应用裁决

根据 Judge 裁决自动处理：
- **APPLY**：直接将 Blue 的修复写入 SKILL.md
- **REVISE**：根据 Judge 的调整意见修改后写入
- **DISMISS**：不动，记录为"已验证可抵御"

#### 5.5 验证闭环

应用修复后，重新读取 SKILL.md，确认：
- 所有 APPLY/REVISE 条目已正确写入
- 修复没有破坏原有结构
- 最终防御条目数仍在上限内（Rationalization ≤5, Red Flags ≤4, Exit Gate ≤7）

**退出条件**：所有 Red Team 的高可信度攻击（≥3 分）都有 APPLY 或 REVISE 裁决。
如果仍有未封堵的高可信度攻击 → 回到 5.2 重跑一轮（最多 2 轮，防止无限循环）。

### Step 6: 报告

向用户展示：
- 加固了哪些内容（四层各几条）
- **Red-Blue-Judge 对抗摘要**：
  - Red Team 共发现 N 条攻击，其中高可信度 M 条
  - Blue Team 提出 M 条修复
  - Judge 裁决：X 条 APPLY / Y 条 REVISE / Z 条 DISMISS
  - 最终防御经过 K 轮对抗验证
- 如果用了 `--from-memory`，标注哪些条目来自历史踩坑
- 每条最终防御的"抗攻击等级"：经受了哪些类型攻击的考验

## 质量标准

| 维度 | 标准 |
|------|------|
| **精准** | 每条 Rationalization 针对该 skill 的具体步骤，不是通用说教 |
| **简洁** | 四层总计不超过 SKILL.md 原文的 40% 篇幅 |
| **可执行** | Exit Gate 每项都有明确的验证动作 |
| **可判断** | 排除条件在触发时即可判断，不需要执行后才知道 |
| **有来源** | 来自 Memory 的条目标注来源引用 |

## Red Flags（自检：看守者的看守者）

执行 skill-harden 时如果出现以下信号，立即停下纠正：

- **生成的 Rationalization 不引用具体步骤名**：说明你在泛泛而谈，停下来重读目标 skill 的执行流程
- **排除条件超过 5 条**：说明你在凑数，只保留最高频的误触发场景
- **Exit Gate 检查项是"确认输出正确"这类模糊表述**：必须改为具体验证动作（运行命令、读文件、对比值）
- **加固后 SKILL.md 膨胀超过原文 40%**：说明过度加固，砍掉价值最低的条目

## 已知陷阱

1. **过度加固**：给简单 skill 加太多防御 → token 成本超过收益。
   **处理**：简单 skill（<20行，无分支）只加 Exit Gate，跳过其他两层。

2. **泛泛而谈**：Rationalization 写成"测试很重要"这种废话。
   **处理**：每条必须引用具体的步骤名或具体的踩坑案例。

3. **破坏原有结构**：插入防御时打乱了 skill 的执行流程。
   **处理**：三层防御只插入到专门的 section，不修改原有步骤。

4. **与 CLAUDE.md 重复**：加固的内容和全局规则完全重复。
   **处理**：skill 级防御应该是全局规则的**具体化**，而非复制。
   例如全局说"NEVER fix A and break B"，skill 级说"修改搜索逻辑后必须跑完整 eval"。

## 与自进化体系的衔接

- **踩坑 → 加固**：用户纠正错误后，如果错误与某个 skill 相关，建议跑
  `/skill-harden {skill} --from-memory` 将教训转化为防御
- **加固 → 毕业**：如果某条 Rationalization 连续 5 次有效阻止了偷懒，
  考虑将其提升为 CLAUDE.md 全局规则（毕业机制）
- **过期 → 清理**：如果 skill 代码已经更新，加固内容可能过时，
  跑 `/skill-harden` 时自动检测并标记需要更新的条目

## 来源与致谢

- Anti-Rationalization Table 模式：[Addy Osmani / agent-skills](https://github.com/addyosmani/agent-skills)
- 六强制部分 skill 结构：agent-skills 的 skill-anatomy.md
- 战略分析：kenThink（孙子兵法 × Polanyi）研判结论——"不要引入 Addy 的 skill，要引入 Addy 的机制"
- 推文来源：[@DataChaz](https://x.com/DataChaz/status/2040357775830814798)
