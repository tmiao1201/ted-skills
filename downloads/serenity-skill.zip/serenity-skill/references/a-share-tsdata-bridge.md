# A 股证据桥接：tsdata

当本 skill 在 **A 股**做卡点验证 / 公司排序 / 估值三档时，不要只说"去查年报"。
用户本地有 `tsdata` 数据层（8 年全市场 tushare 缓存，只读本地 parquet，import 即用，不联网）。
**先用 tsdata 把能拉到的硬数据拉出来验证，再把仍需手翻原文（年报正文、问询函、招投标、客户认证）的部分明确列成"待核清单"。**

环境：`cd ~/cursor && python3`（财务接口 `get_fina` 需 `/usr/local/bin/python3.13`，因为要 pyarrow 读 parquet）。

## 核心读函数（只挂真实存在的，不要编造别的）

| 你想验证的东西 | tsdata 调用 | 关键字段 |
|---|---|---|
| 估值贵不贵 / 分位 | `get_daily_basic(start,end)` | `pe`,`pe_ttm`,`pb`,`ps_ttm`,`total_mv`,`circ_mv` |
| 价+市值+换手一张面板 | `get_panel(start,end)` | daily ⋈ daily_basic |
| 盈利质量 / 毛利率 / ROE / 成长 | `get_fina()`（全市场 fina_indicator，按 ann_date 可见，防未来函数）| `grossprofit_margin`,`roe`,`netprofit_yoy`,`or_yoy`,`debt_to_assets` 等 |
| 行业归属 / 标的池 | `get_stock_basic()` | `ts_code`,`name`,`industry`,`market`,`list_date` |
| 北向加减仓（机构信号） | `get_hk_hold(start,end)` | 陆股通持股，看趋势 |
| 主力资金流 | `get_moneyflow(start,end)` | 大中小单买卖净额 |
| 龙虎榜 / 机构席位 | `get_top_list` / `get_top_inst` | 谁在买 |
| 筹码 / 成本分位 | `get_cyq_perf(start,end)` | 套牢盘 / 胜率 |
| 技术因子（复权价+指标） | `get_stk_factor(start,end)` | MACD/KDJ/RSI/BOLL |

**tsdata 没有的（不要假装有）**：券商一致预期 / 盈利预测、订单合同金额、客户认证进度、产能数据、研报观点。
这些属于"待核清单"，给出明确的核验路径（巨潮年报章节、互动易/上证 e 互动、招投标网、海关数据）。

## 用法骨架（拉出来即可，不必每次都建脚本）

```python
import sys; sys.path.insert(0, "/Users/tedmiao/cursor")
from tsdata import get_daily_basic, get_fina, get_stock_basic, get_hk_hold

codes = ["688008.SH", "688981.SH"]          # 澜起、中芯等候选
db = get_daily_basic("20250101", "20260607")
db = db[db.ts_code.isin(codes)]
# 估值分位（每只股票自己的历史分位，判断现在贵不贵）
for c, g in db.groupby("ts_code"):
    g = g.sort_values("trade_date")
    cur = g.pe_ttm.iloc[-1]
    pct = (g.pe_ttm <= cur).mean()           # 当前 PE 在自身历史的分位
    print(c, f"PE_ttm={cur:.1f}", f"分位={pct:.0%}")
```

财务（盈利质量，用 3.13 跑）：
```python
fina = get_fina()                            # 全市场，按 ann_date 可见
sub = fina[fina.ts_code.isin(codes)].sort_values(["ts_code","end_date"])
# 看 grossprofit_margin / roe / netprofit_yoy 的趋势，验证"卡点变现"是否进了报表
```

## 把 tsdata 接进 scorecard 的两个因子

`scripts/serenity_scorecard.py` 的 8 因子里，A 股有两个可以用 tsdata **打实分而非拍脑袋**：

- `evidence_quality`：财务趋势能在 `get_fina` 里被验证（毛利率/收入连续向上）→ 给高分；只有故事没进报表 → 压低。
- `valuation_disconnect`：用上面的 PE/PB 历史分位。分位低 + 卡点逻辑硬 = 背离大（高分）；分位 >80% 已透支 = 低分。

其余因子（卡点严重度、供应商集中度、扩产难度、催化时点）tsdata 给不了，仍靠原文证据 + 推理。

## 估值三档（Bear / Base / Bull）—— 接 ZadAnthony 思路，但要用真实数据

不要凭空给目标价。三档锚在 **真实历史估值带 + 真实盈利**：

1. 用 `get_daily_basic` 取该股近 3~5 年 `pe_ttm`（或 `pb`）的 **20% / 50% / 80% 分位**作为三档估值倍数。
2. 用 `get_fina` 的最新 `roe`/`netprofit_yoy` 判断盈利处于上行还是见顶，决定用哪档倍数合理。
3. 三档表达成区间，并写清**每档对应的前提**和**证伪条件**（哪个数据出现就推翻该档）：
   - **Bear**：卡点被绕开 / 二供压价 / 毛利率掉头 → 给 20% 分位倍数。
   - **Base**：卡点维持、收入温和兑现 → 50% 分位。
   - **Bull**：卡点收紧 + 客户认证落地 + 收入加速 → 80% 分位。
4. 强调：估值三档是"如果以上前提成立"的条件推演，**不是预测，更不是买卖指令**。决策权留给用户。

## 反过拟合提醒（贴合用户历史教训）

用户做过多轮 A 股 long-only 选股法回测，**结论是横截面量价/单因子选股普遍无方向性 alpha、扣成本净亏**。
所以本 skill 在 A 股的定位是 **产业链卡点的"定性 + 证据"研究工具**，不是又一个打分选股器：
- 不要把 scorecard 总分当成"买入信号"或排序唯一依据；它只是把推理结构化。
- 不要用历史回测收益去"证明"某个卡点逻辑对——那是用户已经证伪过的路。
- 价值在于"这个环节是不是真卡、报表有没有兑现、市场是否还没 price in"，而非"历史涨得好不好"。
