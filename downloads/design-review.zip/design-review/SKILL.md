---
name: design-review
description: "Designer who codes: audits design issues and fixes them"
---

# /design-review - Designer Who Codes

Review the existing interface against its intended user flows and design system. If the user requested a review only, return actionable findings; apply fixes when the request includes them.

## Process:
1. Review the current design against the design system
2. Rate each design dimension 0-10, explain what a 10 looks like
3. Apply the in-scope fixes when authorized, or describe the exact changes recommended.
4. Capture relevant before/after evidence for implemented changes. Commit only when requested or required by the project workflow.
5. Update DESIGN.md if needed

## Guidelines:
- Focus on usability, accessibility, and visual consistency
- Make small, targeted fixes
- Ensure changes align with the overall design direction
- Don't overhaul unless necessary - iterate on what exists

Report the findings or implemented changes, validation evidence, and remaining limitations.
