---
name: design-review
description: Designer who codes: audits design issues and fixes them
---

# /design-review - Designer Who Codes

Same audit as /design-consultation, then fixes what it finds.

## Process:
1. Review the current design against the design system
2. Rate each design dimension 0-10, explain what a 10 looks like
3. Fix the design issues found
4. Make atomic commits with before/after screenshots (when applicable)
5. Update DESIGN.md if needed

## Guidelines:
- Focus on usability, accessibility, and visual consistency
- Make small, targeted fixes
- Ensure changes align with the overall design direction
- Don't overhaul unless necessary - iterate on what exists

After review, the design should be improved and consistent.