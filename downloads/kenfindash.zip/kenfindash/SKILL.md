---
name: kenfindash
description: >-
  FP&A/CFO 级财务数据门户生成器——把上市公司三表（利润表/资产负债表/现金流量表）与 CFO 关心的数据，做成类
  Excel 的在线动态网格/透视/表格，专业化人性化呈现。全免费技术栈，纯前端零后端，可离线脱敏双击运行。核心：自研
  sticky 报表网格(轨A) + 零依赖自研 pivot 内核(轨C，免费超越 AG Grid Enterprise pivot) + FINOS Perspective
  百万行重型透视(轨B，opt-in)，ExcelJS 会计级导出（千分位/负数括号/冻结窗格/加粗小计），继承 kenhtml Corporate
  Dual-Blue 设计与 kenslide-perfect 财务规范。单文件 HTML 与 Portal 门户双形态。当用户提到"财务数据网格"、
  "FP&A 看板"、"CFO 看板/决策包"、"三表门户"、"财务报表可视化"、"类 Excel 网格"、"数据透视表"、"pivot 看板"、
  "财务 dashboard"、"上市公司三表呈现"、"Excel 无缝下载的财务表格"、"kenfindash" 时触发。
  When NOT to Use：要做 PPT/路演 → /kenslide-perfect 或 /kenwebppt；个股研判辩论 → /kenaagent；通用交互
  HTML 小工具(非财务网格) → /kenhtml；纯 Excel 文件生成(非 Web 看板) → /xlsx；要 Python 抓真实财报数据 →
  本 skill 不做(用户自备脱敏 JSON/Excel)。
version: 0.1
allowed-tools:
  - Bash
  - Read
  - Write
  - Edit
---

# kenfindash — FP&A/CFO 财务数据门户

把"上市公司三表 + CFO 关心的数据"做成**类 Excel 的在线动态体验**：固定结构报表对账严谨、大明细透视分析自由、Excel 导出会计级保真，全程**全免费栈 + 纯前端 + 可离线**。

设计血统：继承一套成熟的 FP&A 门户参考框架（App Shell + 网格双轨制 + 十字定位 + Dual-Blue tokens）的优点，**把它的 8 个工程风险在设计层修掉**（固化成 9 条铁律，见 `references/hard-rules.md`）。视觉与组件继承 `kenhtml`（Corporate Dual-Blue）+ `kenslide-perfect`（财务呈现规范）。

---

## 核心架构：三轨 + 一个免费 pivot 引擎

"超越 AG Grid" 不是包一层 ag-grid，而是**免费拿到 ag-grid 收费(Enterprise $999/dev)的 pivot/聚合能力 + 财务域原生定制 + 自研内核的最大灵活性**。按场景分轨，禁止"一把抓"单一重型框架：

| 轨 | 场景 | 引擎 | 边界 |
|---|---|---|---|
| **轨A 报表网格** | 三表/P&L 固定结构、对账严、小计分层、冻结表头首列 | **自研原生 `<table>` + `position:sticky`** | 行数有界（几十~几百行）。结构固定不需虚拟化/动态列，用库反要跟默认样式死磕会计级小计。 |
| **轨B 透视分析网格** | 大明细透视、行+列分组、多维聚合、流式 | **FINOS Perspective**（Apache-2.0, WASM） | 需 HTTP 服务（WASM）。行列 pivot + 财务百分比聚合(PCT_SUM_PARENT) + 内置虚拟化（百万行）。对等并超越 AG Grid Enterprise pivot，零成本。 |
| **轨C 自研灵活 pivot【默认】** | 中等数据透视、财务定制聚合（加权/跨表勾稽） | **零依赖自研 v2**（`pivot-core.js` 计算 + `pivot-ui.js` 交互；Arquero 可选加速超大数据） | 纯 JS（无 WASM，file:// 安全）。**真 Excel 级动态透视**：拖拽四区字段面板（筛选器/列/行/值）+ 多度量两层表头 + 组折叠▸/▾ + 列头排序 + 维度筛选 + 双击下钻明细 + 数据条 + 十字定位。单次扫描累加器保证所有 agg 对小计/总计正确。**免费超越 ag-grid Enterprise pivot**。 |
| **(可选) 明细编辑网格** | 标准可编辑明细（用户点名要 ag-grid 的场景） | **AG Grid Community**（MIT） | 虚拟化/排序/筛选/树/CSV 导出。**pivot 不走它**（那是 Enterprise）。 |

**导出统一 ExcelJS（MIT）**：唯一免费能写样式 + numFmt + 冻结窗格 + 合并 + 加粗小计的库。一律从**数据模型导出 / 走库原生 API（`exportedRows:'all'`）**，**禁 DOM scrape**（虚拟化只导可见行 = 正确性 bug）。SheetJS 仅用于**读取**用户上传的 Excel。

### file:// vs WASM 的硬分流（必须遵守）

- **单文件 file:// 双击模式** → 轨A(自研 table) + 轨C(Arquero) ＝ 纯 JS、可内联、file:// 安全。真·绿色双击离线。
- **Portal/HTTP 模式** → 额外启用轨B(Perspective)，WASM 经 HTTP 加载（file:// 在部分浏览器失败）。提供 `启动Portal.command`(mac)/`.bat`(win) 拉起 `python3 -m http.server`。
- 一句话：**Perspective 是 Portal 重型 pivot；Arquero 是单文件 + 深度定制的轻量 pivot**。两者共用同一份数据 schema 与格式化层。

---

## 输出双形态

| 形态 | 何时用 | 技术 |
|---|---|---|
| **单文件 HTML** | 单看板、要双击离线/邮件发/kengit 一键分享 | `templates/single-file/index.html`：React@18.3.1 多 babel block + 轨A + 轨C，全资源内联或 `assets/vendor/` |
| **Portal 门户** | 多看板统一入口、左侧目录树 + 顶部期间/对比栏 | `templates/portal/`：Shell + iframe 子看板 + `loadPayload`(版本戳+TTL+BroadcastChannel) + 启动脚本，可启用轨B Perspective |

两形态共享：`scripts/fin-format.js`（格式化）、`references/data-schema.md`（数据契约）、Dual-Blue tokens。

---

## 9 条硬性设计铁律（摘要，全文见 `references/hard-rules.md`）

| # | 铁律 |
|---|---|
| **R1** | 全数据集导出，走原生 API（`exportedRows:'all'`）/ 数据模型，**禁 DOM scrape**。导出行数必须 == 数据源行数。 |
| **R2** | 全本地 vendored（`assets/vendor/`），**无 CDN**。兑现离线承诺。 |
| **R3** | 缩放用 CSS `zoom`/`font-size`，**禁 `transform:scale`**（破 sticky + 非整数倍字糊）。 |
| **R4** | 跨期/跨标签缓存用 sessionStorage + `{version,timestamp,ttl}` + BroadcastChannel 失效，**不靠 `window.top` 同源耦合**。 |
| **R5** | `@media print`：`<thead>` 每页重复 + `page-break-inside:avoid` + `print-color-adjust:exact` + `@page` 页码 + 三表分页。 |
| **R6** | 会计负数存**真实 -1234**，导出设 numFmt（`#,##0_);(#,##0)`）；前端 `parseAccountingNumber()` 解析括号。禁存格式化字符串。 |
| **R7** | golden 测试：小计闭合（值==Σ子项 ±0.5%）+ 导出一致性（行数/数值）。`scripts/golden-test.js`，交付前必跑。 |
| **R8** | 双轨能力一致性矩阵：十字定位/排序/搜索/导出在各轨行为不同 → 维护能力矩阵显式声明；十字定位仅对自研 table 轨启用。 |
| **R9** | Portal 跨板联动用 `postMessage` + 数据版本戳，不靠 `window.top.__CACHE` 同源小技巧。 |

---

## 继承（不重复造轮子）

- **kenhtml**（`~/.claude/commands/kenhtml/*.md`）：Corporate Dual-Blue token（`const C`）、Mission Control 布局（sticky status-bar + 可折叠左导航 + `syncHeaderHeight()`）、Dashboard/Explorer 原型、KPI Card/Waterfall/Heatmap/Gauge/Sparkline、单文件 React 多 babel block 工程规范、Lucide-style inline SVG 图标。**单一亮色主题，禁整页深底、禁 emoji、禁 CDN 图标库。**
- **kenslide-perfect**（`~/.claude/skills/kenslide-perfect/`）：`scripts/visual-helpers.js` 的 `fmtFin`（千分位/亿万/负数括号，已移植入 `scripts/fin-format.js`）、IBCS 场景编码(AC/BU/FC/PY)、管理层纪律 D1-D6、语义双轨（预算差异 vs 股价红绿）。
- **kengit**：生成 HTML 一键部署 + SHA-256 密码门（财务敏感保护）。**browse/gstack**：视觉 QA。**xlsx**：财务模型色彩编码参考。

---

## 执行流程（生成一个看板时）

1. **取数据**：用户给三表 JSON（对照 `references/data-schema.md`）或上传 Excel（SheetJS 读 → 映射）。无数据先给 `examples/sample-financials.json` 跑通。
2. **判形态**：单看板/要离线双击 → 单文件；多看板/要门户 → Portal。判轨：三表 → 轨A；大明细透视 → Portal 走轨B Perspective，单文件走轨C Arquero。
3. **读 references**：`design-system.md`（token/布局）+ `finance-conventions.md`（三表呈现规范）+ 对应轨的 `grid-tracks.md` / `pivot-engine.md` + `excel-export.md`。
4. **组装**：从 `templates/` 取模板，注入数据 + Dual-Blue tokens + `fin-format.js`。轨A 自研 sticky 网格、轨B/C pivot、ExcelJS 导出按钮。
5. **跑 golden 测试**（`scripts/golden-test.js`）：小计闭合 + 导出一致性必须绿。
6. **视觉 QA**（browse）：file:// 渲染、zoom 非 100% 表头钉住不糊、横向滚不破 sticky、`@media print` 预览、响应式三档。
7. **交付**：单文件可 kengit 部署；Portal 给启动脚本。报告附 golden 测试结果 + 能力矩阵。

---

## References 索引

| 文件 | 何时读 |
|---|---|
| `references/data-schema.md` | 取数据/定数据结构（已建，含 sample 闭合自检） |
| `references/design-system.md` | 取 Dual-Blue token + Mission Control 布局 |
| `references/finance-conventions.md` | 三表呈现规范 + 数字排版 + IBCS + 管理层纪律 |
| `references/grid-tracks.md` | 三轨选型决策 + 各引擎用法与边界 |
| `references/pivot-engine.md` | 轨B Perspective 配置 + 轨C Arquero 自研 pivot 内核 |
| `references/excel-export.md` | ExcelJS 会计级导出 + SheetJS 读取上传 Excel |
| `references/hard-rules.md` | 9 条铁律全文 + golden 测试规范 + 能力矩阵模板 |

| 脚本 | 用途 |
|---|---|
| `scripts/fin-format.js` | fmtFin / 单位切换 / parseAccountingNumber |
| `scripts/grid-kit.js` | 共享十字定位（轨A/轨C 共用，先于二者加载） |
| `scripts/statement-grid.js` | 轨A 自研 sticky 报表网格 |
| `scripts/pivot-core.js` | 轨C v2 pivot 计算+渲染（多度量/折叠/排序/筛选/下钻/数据条） |
| `scripts/pivot-ui.js` | 轨C v2 拖拽四区字段面板 + 筛选浮层 + 下钻 modal（CSS 注入式，两模板共用） |
| `scripts/excel-export.js` | ExcelJS 导出（R1/R6） |
| `scripts/golden-test.js` | 小计闭合 + 导出一致性 + 透视 v2 断言（R7），交付前必跑 |
| `scripts/build-single-file.js` | 把模板外链脚本+数据内联成真·自包含单文件 HTML（file:// 双击可跑，R2） |

**生成单文件交付物**：`node scripts/build-single-file.js <data.json> out.html` → 985KB 级自包含 HTML，零外链零 CDN，可邮件发/双击离线打开。
**生成 Portal 交付物**：拷 `templates/portal/` 整目录 + 替换 `data/financials.json` → 双击 `启动Portal.command`(mac)/`.bat`(win)。

**轨B Perspective 状态**：模板 `templates/portal/dashboards/perspective-pivot.html` 按 Perspective 3.x 官方 API 编写，作百万行重型档 **opt-in**；启用需 `bash assets/vendor/get-perspective.sh` + 经 HTTP 运行。**本 skill 默认透视用已端到端验证的轨C（pivot-core）**；Perspective 路径未在构建期实跑验证，启用时对照官网校配置。

---

## Anti-Rationalization（反偷懒）

| 借口 | 现实 |
|---|---|
| "三表也用 ag-grid 一把抓省事" | 固定结构 P&L 用库要跟默认样式死磕会计级小计/缩进。轨A 自研 sticky table 才对。 |
| "导出抓 DOM table 就行" | 虚拟化 DOM 只有可见行 → 导出 30 行而非 3000 行的正确性 bug。走原生 API / 数据模型（R1）。 |
| "Tabulator/Perspective 走 CDN 快" | 离线承诺即裂。全 vendored（R2）。 |
| "用 transform:scale 做缩放" | 破 sticky + 字糊（对账最忌）。用 `zoom`（R3）。 |
| "费用存正数显示时加负号" | 存真实负值才能闭合校验简单 + fmtFin 自动括号 + 导出真数值（R6）。 |
| "看着对就交付，golden 测试略过" | 对账是高 stakes。小计闭合 + 导出一致性必跑（R7）。 |
| "pivot 买 ag-grid Enterprise 最省心" | 用户要全免费 + 超越。Perspective 免费对等超越（轨B）。 |
| "暗色主题更高级" | 财务认深底为科技发布。Dual-Blue 单一亮色（继承 kenhtml）。 |

## When NOT to Use

- 要 PPT/路演单页 → `/kenslide-perfect`、`/kenwebppt`。
- 个股研判/多 agent 辩论 → `/kenaagent`。
- 通用交互 HTML 小工具（非财务网格） → `/kenhtml`。
- 纯 Excel 文件生成（非 Web 看板） → `/xlsx`。
- 要 Python 抓真实财报数据 → 本 skill 不做，用户自备脱敏 JSON/Excel。

## Exit Gate（交付前自检）

- [ ] 数据对照 `data-schema.md`；无数据用 sample 跑通
- [ ] 形态/轨选对（三表=轨A；透视=Portal 轨B / 单文件 轨C）
- [ ] golden 测试绿：小计闭合 + 导出行数==数据源 + 负数导出==真实负值
- [ ] 视觉 QA：zoom 非 100% 表头钉住不糊 + 横向滚不破 sticky + @media print + 响应式三档
- [ ] R1-R9 铁律逐条满足；能力一致性矩阵已声明
- [ ] 全 vendored 无 CDN；断网验证全功能
- [ ] (构建完) 走 L1 `/kencorevw` review，未过不报完成
