@echo off
REM kenfindash Portal 启动器（Windows）：拉起本地 HTTP 服务并打开门户，绕过 file:// 沙箱。
cd /d "%~dp0"
set PORT=8799
start "kenfindash-portal" cmd /c python -m http.server %PORT%
timeout /t 1 >nul
start "" "http://localhost:%PORT%/Portal.html?v=%RANDOM%%RANDOM%"
echo kenfindash Portal 运行于 http://localhost:%PORT%/  关闭弹出的 python 窗口即停止服务
