#!/bin/bash
# kenfindash Portal 启动器（macOS）：拉起本地 HTTP 服务并打开门户，绕过 file:// 沙箱。
# 双击即可运行（首次可能需在「系统设置 › 隐私与安全性」放行，或 chmod +x 本文件）。
cd "$(dirname "$0")" || exit 1
PORT=8799
# 端口被占则顺延
while lsof -i :"$PORT" >/dev/null 2>&1; do PORT=$((PORT+1)); done
echo "kenfindash Portal 运行于 http://localhost:$PORT/  （关闭本窗口即停止服务）"
python3 -m http.server "$PORT" >/dev/null 2>&1 &
SRV=$!
sleep 1
# 防缓存随机码
open "http://localhost:$PORT/Portal.html?v=$RANDOM$RANDOM"
# 保持服务直到窗口关闭
trap 'kill $SRV 2>/dev/null' EXIT
wait $SRV
