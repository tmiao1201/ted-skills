/*
 * kenfindash · loadPayload.js — Portal 顶层缓存 + 跨看板数据管道
 *
 * 修掉参考框架的两个坑：
 *  R4: window.top 同源缓存 → 加版本戳 + TTL + BroadcastChannel 失效（跨标签/跨期一致）；window.top 访问包 try/catch 防 SecurityError。
 *  R9: 跨 iframe 取数优先同源直读（快），跨域回退 postMessage 协议（不靠裸 window.top 耦合），为跨域部署/深链留路。
 *
 * 顶层 Portal:  FindashPayload.serve("data/financials.json")    // 拉一次、建版本化缓存、应答子看板
 * 子看板 iframe: FindashPayload.get().then(data => render(data)) // O(1) 命中或 postMessage 回退
 */
(function (root) {
  "use strict";
  var CHANNEL = "findash_cache";
  var DEFAULT_TTL = 10 * 60 * 1000; // 10 分钟

  function nowTs() { return new Date().getTime(); }

  // ── 顶层 Portal：建立版本化缓存 + 应答子看板 ──────────────
  function serve(url, opts) {
    opts = opts || {};
    var ttl = opts.ttl || DEFAULT_TTL;
    var p = fetch(url, { cache: "no-store" })
      .then(function (r) { if (!r.ok) throw new Error("加载失败 " + r.status + " " + url); return r.json(); })
      .then(function (data) {
        var version = (data.meta && data.meta.dataAsOf ? data.meta.dataAsOf : "v") + "@" + nowTs();
        return { data: data, version: version };
      });
    // 单例缓存挂顶层
    try {
      root.__FINDASH_CACHE = { url: url, ttl: ttl, ts: nowTs(), promise: p };
    } catch (e) { /* ignore */ }

    // 子看板 postMessage 请求应答（R9 跨域路径）
    if (typeof window !== "undefined") {
      window.addEventListener("message", function (ev) {
        if (!ev.data || ev.data.type !== "findash:req-payload") return;
        p.then(function (pkg) {
          if (ev.source) ev.source.postMessage({ type: "findash:payload", data: pkg.data, version: pkg.version }, "*");
        });
      });
      // 跨标签失效（R4）
      if (typeof BroadcastChannel !== "undefined") {
        var bc = new BroadcastChannel(CHANNEL);
        bc.onmessage = function (m) {
          if (m.data && m.data.type === "invalidate") { try { delete root.__FINDASH_CACHE; } catch (e) {} location.reload(); }
        };
        root.__FINDASH_BC = bc;
      }
    }
    return p.then(function (pkg) { return pkg.data; });
  }

  // 广播失效（结账/数据刷新后调用）
  function invalidate() {
    try { if (typeof BroadcastChannel !== "undefined") new BroadcastChannel(CHANNEL).postMessage({ type: "invalidate" }); } catch (e) {}
    try { delete root.__FINDASH_CACHE; } catch (e) {}
  }

  // ── 子看板：取数（同源直读 → 失败回退 postMessage）──────────
  function get(timeoutMs) {
    // 1) 同源直读顶层缓存（O(1)）
    try {
      var top = window.top;
      if (top && top.__FINDASH_CACHE && top.__FINDASH_CACHE.promise) {
        var c = top.__FINDASH_CACHE;
        // 命中即返回顶层版本化缓存（O(1)）。过期刷新由顶层 serve()/「刷新」按钮 invalidate()+reload 负责，
        // 跨标签由 BroadcastChannel 失效（R4）；子看板不擅自重取，避免多 iframe 并发重复拉取。
        if (nowTs() - c.ts > c.ttl && typeof console !== "undefined") console.info("[findash] 缓存超 TTL，建议点门户「刷新」");
        return c.promise.then(function (pkg) { return pkg.data || pkg; });
      }
    } catch (e) { /* SecurityError 跨域 → 走 postMessage */ }

    // 2) postMessage 回退（R9）
    return new Promise(function (resolve, reject) {
      var done = false;
      function onMsg(ev) {
        if (!ev.data || ev.data.type !== "findash:payload") return;
        done = true; window.removeEventListener("message", onMsg); resolve(ev.data.data);
      }
      window.addEventListener("message", onMsg);
      try { window.parent.postMessage({ type: "findash:req-payload" }, "*"); } catch (e) {}
      setTimeout(function () { if (!done) { window.removeEventListener("message", onMsg); reject(new Error("取数超时")); } }, timeoutMs || 5000);
    });
  }

  root.FindashPayload = { serve: serve, get: get, invalidate: invalidate };
})(typeof window !== "undefined" ? window : this);
