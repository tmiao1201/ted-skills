window.FINDASH_DATA = {
  "meta": {
    "company": "示例科技股份有限公司",
    "ticker": "688999.SH",
    "currency": "CNY",
    "displayUnit": "万",
    "dataAsOf": "2026-03-31",
    "reportType": "consolidated",
    "fiscalYearEnd": "12-31",
    "periods": [
      { "id": "2025A", "label": "2025 实际", "scenario": "AC" },
      { "id": "2024A", "label": "2024 实际", "scenario": "PY" },
      { "id": "2025B", "label": "2025 预算", "scenario": "BU" },
      { "id": "2026F", "label": "2026 预测", "scenario": "FC" }
    ]
  },

  "statements": {
    "pl": {
      "title": "利润表",
      "key": "pl",
      "rows": [
        { "id": "rev",          "label": "营业收入",       "level": 0, "type": "line",     "values": { "2025A": 1280000000, "2024A": 1050000000, "2025B": 1200000000, "2026F": 1500000000 } },
        { "id": "cogs",         "label": "营业成本",       "level": 0, "type": "line",     "values": { "2025A": -768000000, "2024A": -651000000, "2025B": -720000000, "2026F": -885000000 } },
        { "id": "gross",        "label": "毛利",           "level": 0, "type": "subtotal", "emphasis": true, "children": ["rev", "cogs"],
          "values": { "2025A": 512000000, "2024A": 399000000, "2025B": 480000000, "2026F": 615000000 } },
        { "id": "sales_exp",    "label": "销售费用",       "level": 1, "type": "line",     "values": { "2025A": -120000000, "2024A": -105000000, "2025B": -115000000, "2026F": -140000000 } },
        { "id": "admin_exp",    "label": "管理费用",       "level": 1, "type": "line",     "values": { "2025A": -85000000,  "2024A": -78000000,  "2025B": -82000000,  "2026F": -95000000 } },
        { "id": "rd_exp",       "label": "研发费用",       "level": 1, "type": "line",     "values": { "2025A": -96000000,  "2024A": -82000000,  "2025B": -90000000,  "2026F": -110000000 } },
        { "id": "op_profit",    "label": "营业利润",       "level": 0, "type": "subtotal", "emphasis": true, "children": ["gross", "sales_exp", "admin_exp", "rd_exp"],
          "values": { "2025A": 211000000, "2024A": 134000000, "2025B": 193000000, "2026F": 270000000 } },
        { "id": "fin_exp",      "label": "财务费用",       "level": 1, "type": "line",     "values": { "2025A": -12000000,  "2024A": -14000000,  "2025B": -13000000,  "2026F": -11000000 } },
        { "id": "other_income", "label": "其他收益",       "level": 1, "type": "line",     "values": { "2025A": 8000000,    "2024A": 6000000,    "2025B": 7000000,    "2026F": 9000000 } },
        { "id": "pretax",       "label": "利润总额",       "level": 0, "type": "subtotal", "children": ["op_profit", "fin_exp", "other_income"],
          "values": { "2025A": 207000000, "2024A": 126000000, "2025B": 187000000, "2026F": 268000000 } },
        { "id": "tax",          "label": "所得税费用",     "level": 1, "type": "line",     "values": { "2025A": -31050000,  "2024A": -18900000,  "2025B": -28050000,  "2026F": -40200000 } },
        { "id": "net",          "label": "净利润",         "level": 0, "type": "total",    "emphasis": true, "children": ["pretax", "tax"],
          "values": { "2025A": 175950000, "2024A": 107100000, "2025B": 158950000, "2026F": 227800000 } }
      ]
    },

    "bs": {
      "title": "资产负债表",
      "key": "bs",
      "balanceCheck": { "left": "total_assets", "right": "total_liab_equity" },
      "rows": [
        { "id": "cash",              "label": "货币资金",       "level": 1, "type": "line",     "values": { "2025A": 320000000, "2024A": 280000000 } },
        { "id": "ar",                "label": "应收账款",       "level": 1, "type": "line",     "values": { "2025A": 245000000, "2024A": 210000000 } },
        { "id": "inventory",         "label": "存货",           "level": 1, "type": "line",     "values": { "2025A": 180000000, "2024A": 165000000 } },
        { "id": "current_assets",    "label": "流动资产合计",   "level": 0, "type": "subtotal", "children": ["cash", "ar", "inventory"],
          "values": { "2025A": 745000000, "2024A": 655000000 } },
        { "id": "ppe",               "label": "固定资产",       "level": 1, "type": "line",     "values": { "2025A": 410000000, "2024A": 380000000 } },
        { "id": "intangibles",       "label": "无形资产",       "level": 1, "type": "line",     "values": { "2025A": 95000000,  "2024A": 88000000 } },
        { "id": "noncurrent_assets", "label": "非流动资产合计", "level": 0, "type": "subtotal", "children": ["ppe", "intangibles"],
          "values": { "2025A": 505000000, "2024A": 468000000 } },
        { "id": "total_assets",      "label": "资产总计",       "level": 0, "type": "total",    "emphasis": true, "children": ["current_assets", "noncurrent_assets"],
          "values": { "2025A": 1250000000, "2024A": 1123000000 } },

        { "id": "ap",                "label": "应付账款",       "level": 1, "type": "line",     "values": { "2025A": 198000000, "2024A": 175000000 } },
        { "id": "st_debt",           "label": "短期借款",       "level": 1, "type": "line",     "values": { "2025A": 150000000, "2024A": 140000000 } },
        { "id": "current_liab",      "label": "流动负债合计",   "level": 0, "type": "subtotal", "children": ["ap", "st_debt"],
          "values": { "2025A": 348000000, "2024A": 315000000 } },
        { "id": "lt_debt",           "label": "长期借款",       "level": 1, "type": "line",     "values": { "2025A": 252000000, "2024A": 240000000 } },
        { "id": "noncurrent_liab",   "label": "非流动负债合计", "level": 0, "type": "subtotal", "children": ["lt_debt"],
          "values": { "2025A": 252000000, "2024A": 240000000 } },
        { "id": "total_liab",        "label": "负债合计",       "level": 0, "type": "subtotal", "children": ["current_liab", "noncurrent_liab"],
          "values": { "2025A": 600000000, "2024A": 555000000 } },
        { "id": "share_capital",     "label": "股本",           "level": 1, "type": "line",     "values": { "2025A": 200000000, "2024A": 200000000 } },
        { "id": "retained",          "label": "留存收益",       "level": 1, "type": "line",     "values": { "2025A": 450000000, "2024A": 368000000 } },
        { "id": "total_equity",      "label": "所有者权益合计", "level": 0, "type": "subtotal", "children": ["share_capital", "retained"],
          "values": { "2025A": 650000000, "2024A": 568000000 } },
        { "id": "total_liab_equity", "label": "负债和所有者权益总计", "level": 0, "type": "total", "emphasis": true, "children": ["total_liab", "total_equity"],
          "values": { "2025A": 1250000000, "2024A": 1123000000 } }
      ]
    },

    "cf": {
      "title": "现金流量表",
      "key": "cf",
      "rows": [
        { "id": "cf_net_income", "label": "净利润",                 "level": 1, "type": "line",     "values": { "2025A": 175950000, "2024A": 107100000 } },
        { "id": "depreciation",  "label": "折旧与摊销",             "level": 1, "type": "line",     "values": { "2025A": 62000000,  "2024A": 55000000 } },
        { "id": "wc_change",     "label": "营运资本变动",           "level": 1, "type": "line",     "values": { "2025A": -45000000, "2024A": -38000000 } },
        { "id": "cfo",           "label": "经营活动现金流量净额",   "level": 0, "type": "subtotal", "emphasis": true, "children": ["cf_net_income", "depreciation", "wc_change"],
          "values": { "2025A": 192950000, "2024A": 124100000 } },
        { "id": "capex",         "label": "购建固定资产支出",       "level": 1, "type": "line",     "values": { "2025A": -98000000, "2024A": -85000000 } },
        { "id": "cfi",           "label": "投资活动现金流量净额",   "level": 0, "type": "subtotal", "children": ["capex"],
          "values": { "2025A": -98000000, "2024A": -85000000 } },
        { "id": "debt_raise",    "label": "取得借款净额",           "level": 1, "type": "line",     "values": { "2025A": 22000000,  "2024A": 30000000 } },
        { "id": "dividends",     "label": "分配股利",               "level": 1, "type": "line",     "values": { "2025A": -50000000, "2024A": -40000000 } },
        { "id": "cff",           "label": "筹资活动现金流量净额",   "level": 0, "type": "subtotal", "children": ["debt_raise", "dividends"],
          "values": { "2025A": -28000000, "2024A": -10000000 } },
        { "id": "net_change",    "label": "现金净增加额",           "level": 0, "type": "total",    "emphasis": true, "children": ["cfo", "cfi", "cff"],
          "values": { "2025A": 66950000, "2024A": 29100000 } }
      ]
    }
  },

  "kpis": [
    { "id": "gross_margin", "label": "毛利率",       "group": "收益质量", "format": "pct", "values": { "2025A": 40.0, "2024A": 38.0, "2025B": 40.0, "2026F": 41.0 }, "direction": "higher_better" },
    { "id": "net_margin",   "label": "净利率",       "group": "收益质量", "format": "pct", "values": { "2025A": 13.75, "2024A": 10.2, "2025B": 13.25, "2026F": 15.19 }, "direction": "higher_better" },
    { "id": "roe",          "label": "ROE",          "group": "收益质量", "format": "pct", "values": { "2025A": 27.07, "2024A": 18.86 }, "direction": "higher_better" },
    { "id": "debt_ratio",   "label": "资产负债率",   "group": "财务杠杆", "format": "pct", "values": { "2025A": 48.0, "2024A": 49.42 }, "direction": "lower_better" },
    { "id": "current_ratio","label": "流动比率",     "group": "财务杠杆", "format": "ratio", "values": { "2025A": 2.14, "2024A": 2.08 }, "direction": "higher_better" },
    { "id": "cfo_kpi",      "label": "经营现金流",   "group": "现金健康", "format": "auto", "values": { "2025A": 192950000, "2024A": 124100000 }, "direction": "higher_better" },
    { "id": "fcf",          "label": "自由现金流",   "group": "现金健康", "format": "auto", "values": { "2025A": 94950000, "2024A": 39100000 }, "direction": "higher_better" }
  ],

  "datasets": {
    "orders": {
      "title": "新签订单明细",
      "primaryAmount": "amount",
      "columns": [
        { "field": "date",     "title": "签约日期", "type": "date" },
        { "field": "bu",       "title": "事业部",   "type": "string" },
        { "field": "region",   "title": "区域",     "type": "string" },
        { "field": "product",  "title": "产品线",   "type": "string" },
        { "field": "customer", "title": "客户",     "type": "string" },
        { "field": "qty",      "title": "数量",     "type": "number", "numFmt": "integer" },
        { "field": "amount",   "title": "金额",     "type": "number", "numFmt": "accounting" }
      ],
      "rows": [
        { "date": "2025-01-08", "bu": "医疗器械", "region": "华东", "product": "影像设备", "customer": "甲医院", "qty": 3,  "amount": 12800000 },
        { "date": "2025-01-22", "bu": "医疗器械", "region": "华南", "product": "影像设备", "customer": "乙医院", "qty": 2,  "amount": 8600000 },
        { "date": "2025-02-05", "bu": "医疗器械", "region": "华北", "product": "监护仪",   "customer": "丙医院", "qty": 15, "amount": 4500000 },
        { "date": "2025-02-18", "bu": "体外诊断", "region": "华东", "product": "试剂",     "customer": "丁实验室", "qty": 200,"amount": 3200000 },
        { "date": "2025-03-03", "bu": "体外诊断", "region": "华南", "product": "分析仪",   "customer": "戊机构", "qty": 4,  "amount": 6800000 },
        { "date": "2025-03-19", "bu": "体外诊断", "region": "华西", "product": "试剂",     "customer": "己医院", "qty": 350,"amount": 5600000 },
        { "date": "2025-04-07", "bu": "数字健康", "region": "华东", "product": "软件平台", "customer": "庚集团", "qty": 1,  "amount": 9200000 },
        { "date": "2025-04-25", "bu": "数字健康", "region": "华北", "product": "软件平台", "customer": "辛连锁", "qty": 1,  "amount": 7400000 },
        { "date": "2025-05-12", "bu": "医疗器械", "region": "华东", "product": "影像设备", "customer": "壬医院", "qty": 5,  "amount": 21000000 },
        { "date": "2025-05-28", "bu": "医疗器械", "region": "华西", "product": "监护仪",   "customer": "癸医院", "qty": 20, "amount": 6000000 },
        { "date": "2025-06-09", "bu": "体外诊断", "region": "华北", "product": "分析仪",   "customer": "子机构", "qty": 6,  "amount": 10200000 },
        { "date": "2025-06-21", "bu": "体外诊断", "region": "华东", "product": "试剂",     "customer": "丑实验室", "qty": 500,"amount": 8000000 },
        { "date": "2025-07-04", "bu": "数字健康", "region": "华南", "product": "数据服务", "customer": "寅平台", "qty": 1,  "amount": 5500000 },
        { "date": "2025-07-30", "bu": "数字健康", "region": "华东", "product": "软件平台", "customer": "卯集团", "qty": 2,  "amount": 13600000 },
        { "date": "2025-08-15", "bu": "医疗器械", "region": "华南", "product": "影像设备", "customer": "辰医院", "qty": 4,  "amount": 17200000 },
        { "date": "2025-09-02", "bu": "体外诊断", "region": "华西", "product": "分析仪",   "customer": "巳机构", "qty": 3,  "amount": 5100000 },
        { "date": "2025-09-26", "bu": "数字健康", "region": "华北", "product": "数据服务", "customer": "午平台", "qty": 1,  "amount": 4800000 },
        { "date": "2025-10-11", "bu": "医疗器械", "region": "华东", "product": "监护仪",   "customer": "未医院", "qty": 30, "amount": 9000000 },
        { "date": "2025-11-08", "bu": "体外诊断", "region": "华南", "product": "试剂",     "customer": "申实验室", "qty": 420,"amount": 6720000 },
        { "date": "2025-12-19", "bu": "数字健康", "region": "华东", "product": "软件平台", "customer": "酉集团", "qty": 3,  "amount": 18900000 }
      ]
    }
  }
};
