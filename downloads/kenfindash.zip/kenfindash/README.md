# kenfindash — FP&A/CFO 财务数据门户生成器

把上市公司三表（利润表/资产负债表/现金流量表）和 CFO 关心的数据，做成**类 Excel 的在线动态网格/透视/表格**。全免费技术栈、纯前端零后端、可离线脱敏双击运行。

- **轨A 报表网格**：自研 sticky `<table>`，冻结表头首列、会计级小计/总计、千分位/负数括号、YoY、十字定位、缩放、打印。
- **轨C 透视（真 Excel 动态）**：拖拽四区字段面板（筛选器/列/行/值）+ 多度量两层表头 + 组折叠 ▸/▾ + 列头排序 + 维度筛选 + 双击下钻明细 + 数据条。零依赖，免费超越 AG Grid Enterprise pivot。
- **轨B Perspective**（opt-in，百万行重型档）：需跑 `assets/vendor/get-perspective.sh` vendoring。
- **Excel 导出**：ExcelJS 会计级（numFmt 负数括号 / 加粗小计 / 冻结窗格）；导出走数据模型，绝不抓 DOM（虚拟化只导可见行的 bug）。

---

## 两种用法

### A) 作为 Claude Code skill（推荐）
把整个 `kenfindash/` 目录放到 `~/.claude/skills/` 下：
```bash
cp -R kenfindash ~/.claude/skills/
```
重启 Claude Code（或新开会话），对它说「kenfindash」「FP&A 看板」「三表门户」等，并提供你的脱敏 JSON / Excel 即可。无数据时它会用 `examples/sample-financials.json` 跑通给你看。

### B) 不用 Claude，直接用模板出活
**单文件（双击离线版）**——需 Node：
```bash
cd kenfindash
node scripts/build-single-file.js 你的数据.json 输出.html
# 产出零外链、零 CDN 的自包含 HTML，双击即可打开（含三表 + KPI + 拖拽透视 + Excel 导出）
```
数据格式照 `references/data-schema.md`，仿 `examples/sample-financials.json` 填。

**Portal 门户（多看板）**——需 Python3：
```bash
cd kenfindash/templates/portal
# 换掉 data/financials.json 为你的数据
# macOS：双击 启动Portal.command   Windows：双击 启动Portal.bat
# （会本地起 http.server 打开门户，绕过 file:// 沙箱）
```

---

## 环境要求
- **用模板出活**：Node.js（构建单文件 / 跑测试）、Python3（Portal 本地服务，系统自带）、现代 Chromium/Edge/Safari 浏览器。
- **轨B Perspective**：额外需 npm（一次性 vendoring），且必须经 HTTP 运行（WASM 不能 file://）。
- 数据一律本地，无任何联网/上传。

## 自检（可选）
```bash
node scripts/golden-test.js   # 小计闭合 / BS 平衡 / 导出 parity / 负数 round-trip / 透视断言，退出码 0 = 全绿
```

## 目录
- `SKILL.md` — 给 Claude 的能力定义与执行流程（人也可读，含 9 条设计铁律摘要）
- `references/` — 数据契约 / 设计系统 / 三轨选型 / 透视引擎 / Excel 导出 / 财务规范 / 铁律全文
- `scripts/` — 引擎（格式化 / 报表网格 / 透视内核+UI / 导出 / 测试 / 构建）
- `templates/` — single-file（单文件起点）/ portal（门户）
- `examples/sample-financials.json` — 三表 + KPI + 明细示例（已通过闭合自检）

## 许可与血统
ExcelJS（MIT，已 vendored）。轨B 可选 FINOS Perspective（Apache-2.0，opt-in 脚本下载）。设计沿用 Corporate Dual-Blue 体系。本 skill 数据脱敏、离线优先，适合企业敏感财务场景。
