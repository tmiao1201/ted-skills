# kenfindash Excel 无缝衔接（ExcelJS 导出 + SheetJS 导入）

导出用 **ExcelJS**（MIT，唯一免费能写样式+冻结+合并+numFmt 的库）；导入读用户上传 Excel 用 **SheetJS**（社区版读足够）。一律**数据模型驱动，禁 DOM scrape**(R1)。

---

## 导出侧（`scripts/excel-export.js` · `window.FindashExport`）

### 输入：导出数据模型（各轨 `getExportModel()` 产出）
```js
{
  sheetName: "利润表",
  header: [ {title:"科目", numFmt:"text"}, {title:"2025 实际（万）", numFmt:"accounting"}, ... ],
  rows: [
    { cells:[ {value:"营业收入", type:"string", indent:0}, {value:128000, type:"accounting"}, ... ], style:"line" },
    { cells:[ {value:"净利润", ...}, {value:17595, type:"accounting"} ], style:"total", emphasis:true }
  ],
  freeze: { row:1, col:1 },
  meta: {...}   // 可选，写 source 脚注行
}
```

### API
```js
await FindashExport.exportStatement(model, "利润表.xlsx");       // 单 sheet
await FindashExport.exportWorkbook([plM, bsM, cfM], "三表.xlsx"); // 多 sheet（三表一次导出）
```

### 落地的会计级样式
- **表头**：blueDeep 填充 + 白色加粗。
- **小计行**：`tintSub` 浅灰 + 加粗。
- **总计行**：`tintTotal` + 加粗 + 上 thin / 下 double 边框（blueDeep）。
- **首列**：左对齐 + `indent`（科目缩进）。
- **数字列**：右对齐 + numFmt。
- **会计负数(R6)**：写**真实负值**，numFmt `#,##0;(#,##0)` 让 Excel 渲染成括号。
- **冻结窗格**：`views=[{state:'frozen', xSplit:col, ySplit:row}]`（表头+首列）。
- **列宽**：首列 28，其余 16。

### numFmt 映射（`FindashExport.nf` / `FinFmt.excelNumFmt`）
| type | numFmt |
|---|---|
| accounting | `#,##0;(#,##0)` |
| accounting2 | `#,##0.00;(#,##0.00)` |
| integer | `#,##0` |
| pct | `0.0%` |
| text/general | 无 |

### 单位
导出值 = **屏幕显示单位**（如"万"）→ 满足 R7"导出==屏幕"。表头带单位（"（万）"）。需要原始值导出可传 `unit:"raw"`（statement-grid.buildExportModel 第4参）。

---

## 导入侧（用户上传 Excel → schema）

用户拖入 `.xlsx`：
```js
const wb = XLSX.read(arrayBuffer, { type:"array" });   // SheetJS 读
const aoa = XLSX.utils.sheet_to_json(wb.Sheets[name], { header:1 });
// 映射器：用户指明 哪列=科目 / 哪几列=期间 / 表头单位 → 转成 data-schema 的 statements/datasets
```
- **会计负数解析**：`(1,234)` → `FinFmt.parseAccountingNumber` → 真实 `-1234`（R6 导入侧对称）。
- 映射需用户确认 sheet/列对应（科目列、期间列、数值起始列、单位）。SheetJS 社区版读 + 解析足够；**写样式才需 ExcelJS**，所以导出用 ExcelJS、导入用 SheetJS。
- SheetJS 需 vendored（`assets/vendor/xlsx.min.js`，导入功能启用时下载）。

---

## 红线
- **禁 DOM scrape**(R1)：虚拟化轨 DOM 只有可见行。所有导出走 `getExportModel()`/原生 API。
- `golden-test.js` round-trip 守门：写 xlsx → 读回，净利润值一致、营业成本读回真实负数。已绿。
