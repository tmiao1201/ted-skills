# kenfindash 财务呈现规范（继承 kenslide-perfect）

三表呈现 + 数字排版 + IBCS + 管理层纪律。权威源 `~/.claude/skills/kenslide-perfect/references/`（finance-charts-v3 / executive-discipline / design-tokens），本文件落地到 Web 网格。

---

## 1. 三表结构与视觉分层

| 行类型 | `type` | 视觉 |
|---|---|---|
| 科目行 | `line` | 400 字重，按 `level` 缩进（每级 18px） |
| 小计行 | `subtotal` | 700 + 浅灰底 `tintSub` + 上分割线 |
| 总计行 | `total` | 700 + 深灰底 `tintTotal` + 上下双线（blueDeep） |
| 关键科目 | `emphasis:true` | 毛利/营业利润/净利润：加粗 +（可 +行高） |

- **费用/成本存负数**（R6）：营业成本 `-768000000` → 渲染 `(76,800万)`、闭合校验为纯加法、导出真实负值。
- **列序惯例**：科目 ｜ 本期(AC) ｜ 去年同期(PY) ｜ YoY% ｜ 预算(BU) ｜ vs Budget% ｜ 预测(FC)。超 10 列分「实际/预算/预测」三面板。
- **BS 平衡**：`balanceCheck:{left:"total_assets", right:"total_liab_equity"}` → 看板底部出"✓ 资产=负债+所有者权益"。

## 2. 财务数字排版（铁律）

| 项 | 规则 |
|---|---|
| 千分位 | 强制（`FinFmt.fmtFin`），禁裸 `${value}` |
| 负数 | 会计括号 `(1,234)` + `negNum` 色，不用负号 |
| 等宽对齐 | `font-variant-numeric: tabular-nums`，数字列右对齐 |
| 单位 | 千/万/百万/亿，上提到**表头/列标题**，单元格只放数字 |
| 百分比 | 1 位小数；YoY 带符号（`+21.9%` / `(18.0%)`） |
| 数据截止 | `meta.dataAsOf` 渲染到 source line（D3） |

## 3. IBCS 场景编码（`scenario`：AC/BU/FC/PY）

| 场景 | 含义 | 编码（图表/标记） |
|---|---|---|
| AC | 实际 | 实心深色 |
| BU | 预算 | 白底 + 描边 |
| FC | 预测 | 半透 + 虚线；数字后缀 `E` |
| PY | 去年同期 | 浅灰实心 |

差异方向：**有利→绿(favorable)、不利→红(unfavorable)**（管理口径）。

## 4. 语义双轨（同页禁混用）

- **轨道1 预算差异**（管理口径）：超收入/省成本=有利→绿；不足/超支=不利→红。
- **轨道2 股价/IR**（A股口径）：上涨→红、下跌→绿。
- 同一看板若两种口径并存 → 按 block 隔离 + 表头标口径。**默认财务报表走轨道1**。
- ⚠️ 注意：费用行的 YoY%（如营业成本 `(18.0%)`）是**有符号值的变化**；若要按"费用增加=不利红"语义着色，需按行 `direction` 单独配（规划项，当前 YoY 按数值正负着色）。

## 5. 期间对比

YoY（本期 vs 去年同期）/ QoQ（环比）/ YTD（年初至今）/ MTD。`statement-grid` 自动插 YoY%（有 AC+PY 时）；其他对比列按 `opts.columns` 派生扩展。

## 6. CFO KPI 分组（首屏 4-6 卡）

| 分组 | 指标 |
|---|---|
| 收益质量 | 营收 / 毛利率 / 营业利润率 / 净利率 |
| 现金健康 | 经营现金流 / 自由现金流 / 现金余额 |
| 财务杠杆 | 资产负债率 / 利息覆盖率 / 流动比率 |
| 运营效率 | 应收/应付/存货周转 |
| 增长 | 营收/EBITDA/利润 YoY% |
| 执行 vs 计划 | 营收/利润/现金达成率 |

KPI 卡：当期值 + 前期值 + YTD + 预算 + 达成% + sparkline。`direction:"higher_better"|"lower_better"` 决定 delta 配色。

## 7. 管理层纪律 D1-D6（继承 executive-discipline）
口径徽章（YoY/QoQ/vs Budget）· Source 行 · 数据截止日 · 预测数 E 后缀 · 加总闭合脚注 · 百分数分母可答 · 货币单位唯一。看板顶栏/卡片落地这些。

## 8. 设计纪律（继承 kenhtml）
单一亮色 Dual-Blue 主题、禁整页深底（CFO 认深色为科技发布）、表格里坚决不用品牌蓝大色块、小计/总计走中性灰梯度对标纸质快报、正文 7:1 对比度、十字高亮不污染财务原色。
