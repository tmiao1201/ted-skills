# kenfindash 网格三轨选型决策

"超越 AG Grid" 不靠包一层 ag-grid，而是**按场景分轨 + 免费拿到 ag-grid 收费(Enterprise)的 pivot/聚合 + 财务域原生定制 + 自研内核灵活性**。先判轨，再选引擎。

---

## 选轨决策树

```
数据是「固定结构的财务报表」（三表/P&L，行=科目层级、列=期间/主体）？
  └─ 是 → 轨A 自研 sticky 报表网格（statement-grid.js）
数据是「扁平明细，要透视/分组/聚合」（订单/流水/Backlog）？
  ├─ 数据量中等（≤十万行）/ 要 file:// 离线 / 要深度定制小计 → 轨C 自研 pivot（pivot-core.js）【默认】
  └─ 数据量极大（百万行）/ 要拖拽透视 / 流式 → 轨B Perspective（opt-in，需 HTTP）
要标准「可编辑明细表格」且用户点名 ag-grid？
  └─ (可选) AG Grid Community（明细编辑/树/CSV，pivot 不走它）
```

---

## 轨A · 自研 sticky 报表网格（`scripts/statement-grid.js`）

**为什么自研对**：P&L/三表结构固定且已知，运行期不需动态列/虚拟化；用库反要为"会计师认可的小计分层、缩进、总计描边"和库默认样式死磕。原生 `<table>` + `position:sticky` 是 payload 最小、语义最好（无障碍 + 导出友好）的解。

**能力**：冻结表头(top sticky) + 首列(left sticky) + 小计/总计/emphasis 行样式 + 层级缩进 + 派生列(YoY%) + 十字定位(R8) + zoom(R3) + 数据模型导出(R1)。

**API**：
```js
const g = StatementGrid.render(container, statement, meta, { unit:"万", crosshair:true });
g.setZoom(0.9);             // R3：zoom，不破 sticky
g.toggleCrosshair(false);
const model = g.getExportModel();   // → excel-export（数据模型，非 DOM）
```
**列**：默认 `meta.periods` 全列 + 自动 YoY%（有 AC 与 PY 时）。可传 `opts.columns` 自定义（含 `{kind:'yoy', from, base}` 派生列）。
**边界**：押注行数有界（DOM 全量渲染）。P&L 几十~几百行无压力；若某视图展开到科目级×多主体×多期间上千行 → 改走轨C（自研 pivot 有虚拟化考量）或分页。

## 轨C · 自研灵活 pivot 内核（`scripts/pivot-core.js`）【默认透视轨】

**为什么自研对**：财务小计/总计布局本就要自己控；自研 = 零依赖、file:// 安全、最大灵活性，且**免费拿到 ag-grid Enterprise 才有的行列分组+聚合**。
**算法**：单次扫描，每条记录喂进「全部祖先前缀 × {本列, 全列}」累加器 → sum/avg/count/min/max 对小计/总计**都正确**（不是 avg-of-avgs）。
**能力**：行多维嵌套 + 列多维 + 5 种聚合 + 各级小计 + 总计 + 行/列总计 + zoom + 数据模型导出(R1)。
**API**：
```js
const tm = PivotCore.pivot(rows, { rows:["bu","region"], cols:["product"],
  measure:"amount", agg:"sum", subtotals:true, grandTotal:true });
const inst = PivotCore.render(container, tm, { columns: dataset.columns });
const model = inst.getExportModel();
```
**Arquero 加速器（可选）**：超大数据（百万行）可把聚合层换成 Arquero（MIT，列式，~25KB），但本核心对万行级已够且更可控；不默认引入（保零依赖/file://）。
**已验证**：`golden-test.js` 断言总计==原始全量和、嵌套小计==叶和、avg==over-raw（非 avg-of-avgs）、count 正确。

## 轨B · Perspective 重型透视（`templates/portal/dashboards/perspective-pivot.html`）【opt-in】

**何时用**：百万行级 / 流式更新 / 要拖拽式透视 UI。
**为什么免费能超越 ag-grid**：FINOS Perspective（Apache-2.0，JPMorgan 开源，WASM C++ 引擎 + Arrow 列存）行列 pivot + 含 `PCT_SUM_PARENT` 财务百分比聚合 + 内置 regular-table 虚拟化（百万行）+ 原生全量导出。对等并超越 AG Grid Enterprise（$999/dev）pivot，零成本。
**启用**：`bash assets/vendor/get-perspective.sh` vendoring → 经 HTTP 运行（WASM 不能 file://，这正是 Portal 用 http.server 的原因）。
**状态**：模板按 Perspective 3.x 官方 API 编写，**本次构建未实跑验证**（默认透视用已验证的轨C）；启用时对照 https://perspective.finos.org/ 校 import 路径/restore 配置。

## (可选) AG Grid Community

兑现"结合 ag-grid"：标准可编辑明细网格（虚拟化/排序/筛选/树/CSV 导出，MIT 免费）。**pivot/行分组/聚合/带样式 Excel 导出属 Enterprise 付费，不走它**——那些走轨C/轨B（免费）。需要时 vendored `ag-grid-community.min.js`，按其 API 接 `getExportModel` 适配。

---

## 导出（统一 ExcelJS，见 `excel-export.md`）
所有轨的 `getExportModel()` → `FindashExport`（ExcelJS）：会计 numFmt、加粗小计/总计、冻结窗格、首列缩进、负数括号(R6)。**禁 DOM scrape**(R1)。

## 一句话
固定三表 → 轨A；透视分析默认 → 轨C（免费超 ag-grid pivot）；百万行重型 → 轨B Perspective（opt-in）；标准明细编辑 → AG Grid Community（可选）。
