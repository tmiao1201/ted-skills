# kenfindash 设计系统（继承 kenhtml Corporate Dual-Blue）

视觉与布局**继承 kenhtml**（`~/.claude/commands/kenhtml/design-system.md` / `layouts.md`），本文件只摘出 kenfindash 直接用到的部分 + **财务网格专属扩展**。原始权威以 kenhtml 为准；冲突时财务扩展优先（针对对账场景）。

> 单一**亮色主题**，无暗色。禁整页深底（CFO 认深色为科技发布）、禁 emoji、禁 CDN 图标库（用 inline SVG）。

---

## 1. Color Tokens（精确复制，勿改值）

```javascript
const C = {
  // 核心双蓝（占 90% 视觉面积）
  blue:      "#1226AA",   // 标题/强调/主 CTA/活动行标记
  techBlue:  "#00A0DF",   // 数据高亮/图表/交互强调/链接/输入聚焦
  // 蓝系派生（同色相，不引入新色相）
  blueDeep:  "#091252",   // Header bar / modal 头 / 表格表头 / 最深层
  blueMid:   "#2E4FD0",
  blueLight: "#E8EEFF",   // 选中态/活动 tab 底 / 行 hover
  bluePale:  "#F4F6FF",   // 表格偶数行 / 超浅卡片底
  techLight: "#E0F4FC",
  techPale:  "#CCF0FF",
  // 功能色（仅状态指示，≤10%）
  green:      "#0EA573", greenLight: "#E6F9F0",
  amber:      "#E89820", amberLight: "#FFF8E6",
  redMuted:   "#C85040", redPale:    "#FFF0EE",
  // 中性
  white:   "#FFFFFF",
  bg:      "#F5F7FC",     // 全局页底（蓝调，非纯白/灰）
  textMid: "#3A3F5C",     // 正文（对 bg 对比度 >7:1）
  textLight:"#6B7094",    // 次级/标签/source line
  textMuted:"#9098B8",
  border:  "#D8E2F0",
};
```

### 财务网格专属语义色（kenfindash 扩展）

```javascript
const FIN = {
  // 小计/总计中性灰梯度（替代杂乱色彩，对标专业纸质快报）
  tintSub:   "#EEF1FB",   // 小计行底（浅）
  tintTotal: "#E6EAF0",   // 总计行底（深一档）
  // 十字定位（R8，仅自研 table 轨）
  crossTint: "#EEF1FB",   // 行/列遮罩（极柔和，不污染财务原色）
  crossBrand:"#1226AA",   // 焦点描边 + 行列标签点亮
  // 预算差异语义双轨（轨道1：管理口径）
  favorable:   "#0EA573", // 有利差异（超收入/省成本）→ 绿
  unfavorable: "#C85040", // 不利差异 → 红
  // 数字色层
  inkNum:    "#161C2D",   // 数字正文墨黑（对账高对比）
  negNum:    "#C85040",   // 负数（配合括号）
};
```

> **A股语义双轨提醒**：上表 favorable/unfavorable 是**管理口径**（预算差异）。若同一看板出现**股价/IR 口径**（涨跌），用 A股红涨绿跌——**两套口径同页禁混用**，必须按 block 隔离并在表头标注口径。见 `finance-conventions.md`。

---

## 2. Typography（财务数字排版关键）

```css
font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
```

| 角色 | size / weight / color |
|---|---|
| Section 标题 | 14 / 700 / blue |
| 卡片标题 | 12 / 700 / blue |
| 表头 | 9 / 700 / white，uppercase，letter-spacing .5px |
| 科目名（首列） | 10 / 400 / textMid（小计/总计 700） |
| **数字单元格** | 11 / 400 / **inkNum**，右对齐 |
| KPI 数字 | 22 / 800 / blue 或 techBlue，letter-spacing -.5px |
| source line / 脚注 | 8 / 400 / textLight |

**数字排版铁律**（财务必守，源自 kenslide-perfect）：
```css
/* 所有数字列 */
.fd-num {
  text-align: right;
  font-variant-numeric: tabular-nums;   /* 等宽对齐，对账列必备 */
  font-feature-settings: "tnum" 1;
  padding-right: 12px;
  color: var(--inkNum);
}
.fd-num.neg { color: var(--negNum); }    /* 负数配合 fmtFin 的括号 */
```
- 一律走 `FinFmt.fmtFin()`，禁裸插值 `${value}`。
- 单位（千/万/百万/亿）上提到**表头/列标题**，单元格只放数字。

---

## 3. 间距 / 圆角 / 阴影

- 间距基数 4px：xs4 / sm8 / md12 / lg16 / xl20 / 2xl28 / 3xl40。
- 圆角：卡片 10 / button 6 / badge 4 / modal 12 / input 6。
- 阴影：卡片 `0 2px 8px rgba(0,0,0,.06)`，hover `0 4px 16px rgba(0,0,0,.10)`，modal `0 8px 32px rgba(0,0,0,.2)`。
- 行高：数据行 36px / 表头 40 / 小计 40 / 总计 44（emphasis 关键科目 +4px）。

---

## 4. Mission Control 布局（Portal Shell 骨架，继承 kenhtml layouts §2）

```
┌─ STATUS-BAR (sticky top, 多行：标题·期间·对比模式·数据截止)
├─ LAYOUT: LEFT-NAV (268px ↔ 56px 可折叠) | MAIN (bento grid)
│  ├─ LEFT: 报表选择 / 期间选择 / 科目树（可搜索）
│  └─ MAIN: KPI row + 三表卡 + 透视/明细卡
```

```css
html, body { min-height: 100%; }            /* 不能 height:100% — sticky 会失效 */
.layout { display: grid; grid-template-columns: 268px 1fr; min-height: calc(100vh - var(--header-h)); }
.layout.collapsed { grid-template-columns: 56px 1fr; transition: grid-template-columns .22s cubic-bezier(.4,0,.2,1); }
.status-bar { position: sticky; top: 0; z-index: 200; background: linear-gradient(180deg,#fff,var(--bluePale)); box-shadow: 0 1px 8px rgba(9,18,82,.05); }
.left-nav { position: sticky; top: var(--header-h); height: calc(100vh - var(--header-h)); overflow-y: auto; background:#fff; border-right:1px solid var(--border); }
.nav-row.active { background: var(--blueLight); border-left: 3px solid var(--blue); color: var(--blue); font-weight: 700; }
```

**动态 header 高度同步**（kenhtml 关键 gotcha，直用 — 否则字体加载后 sticky 偏移错）：
```javascript
(function syncHeaderHeight(){
  const sb = document.querySelector('.status-bar');
  const recalc = () => document.documentElement.style.setProperty('--header-h', (sb? sb.offsetHeight : 92) + 'px');
  recalc(); addEventListener('resize', recalc); setTimeout(recalc,80); setTimeout(recalc,400);
})();
```

`localStorage` 持久化折叠态 `findash_nav_collapsed`。

---

## 5. 冻结窗格（轨A 报表网格核心，R3）

```css
/* 表头粘滞 */
.fd-table thead th { position: sticky; top: 0; z-index: 10; background: var(--blueDeep); color:#fff; }
/* 首列（科目名）粘滞 */
.fd-table th.fd-rowlabel, .fd-table td.fd-rowlabel {
  position: sticky; left: 0; z-index: 9; background: #fff;
}
.fd-table thead th.fd-rowlabel { z-index: 11; }   /* 左上角交叉点最高 */
/* 偶数行 */
.fd-table tbody tr:nth-child(even) td { background: var(--bluePale); }
.fd-table tbody tr.subtotal td { background: var(--tintSub); font-weight: 700; border-top: 1px solid var(--border); }
.fd-table tbody tr.total td    { background: var(--tintTotal); font-weight: 700; border-top: 2px solid var(--blueDeep); border-bottom: 2px solid var(--blueDeep); }
.fd-table tbody tr.emphasis td { font-weight: 700; }

/* 缩放：用 zoom，禁 transform:scale (R3) */
.fd-zoomwrap { zoom: 1; }   /* JS 调 0.8~1.4，sticky 不破、不糊 */
```

> **禁** `transform: scale()` 缩放表格——它改变 stacking context、破 `position:sticky`、非整数倍字糊（对账最忌）。Chromium 用 `zoom`；需跨 Firefox 时退 `font-size`/rem 缩放。

---

## 6. 打印样式（R5）

```css
@media print {
  @page { size: A4; margin: 15mm; }
  .no-print, button, input, .toolbar, .left-nav { display: none !important; }
  .fd-table { width: 100%; border-collapse: collapse; }
  .fd-table thead { display: table-header-group; }   /* 每页重复表头 */
  .fd-table tr.subtotal, .fd-table tr.total { page-break-inside: avoid; }
  .statement-block { page-break-before: always; }    /* 三表分页 */
  * { print-color-adjust: exact; -webkit-print-color-adjust: exact; }  /* 保背景色 */
}
```

---

## 7. 图标（inline SVG，禁 CDN/emoji）

Lucide-style，24×24 viewBox，`stroke="currentColor"` `stroke-width="1.7"`。kenfindash 常用：`bar-chart-2`(总览)、`file-text`(报表)、`trending-up`(KPI)、`table`(明细)、`filter`(透视)、`download`(导出)、`printer`(打印)、`crosshair`(十字定位)、`maximize`(缩放)。

---

## 8. 单文件工程规范（继承 kenhtml）

- React@18.3.1 + Babel standalone，多 `<script type="text/babel">` block。
- **跨 block 共享组件**：每个 block 末尾 `Object.assign(window, {CompA, CompB})`；变量名加前缀防重声明（`const dashStyles` 而非 `const styles`）。
- token 放 `:root` CSS vars + `window.C`/`window.FIN`，全站引用。
- 数据内联 `window.FINDASH_DATA`（单文件离线）或 Portal `loadPayload` 加载。
- vendored 库（fin-format/pivot-core/exceljs/perspective）放 `assets/vendor/`，单文件可内联（R2 无 CDN）。
