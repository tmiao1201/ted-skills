# kenfindash 透视引擎参考（轨C v2 自研 + 轨B Perspective）

补 `grid-tracks.md` 的透视细节。**v2 = 真 Excel 级动态透视**：拖拽四区字段面板 + 多度量 + 折叠 + 排序 + 筛选 + 下钻 + 数据条 + 十字。

---

## 轨C v2 · 计算层（`PivotCore.pivot(rows, cfg)`）

| cfg 字段 | 取值 | 说明 |
|---|---|---|
| `rows` | `["bu","product"]` | 行维度，按序嵌套；非叶层生成**组头行**（Excel compact：组头在前、自带小计、▸/▾ 可折叠） |
| `cols` | `["region"]` | 列维度；空 = 单"合计"列 |
| `measures` | `[{field:"amount",agg:"sum"},{field:"qty",agg:"sum"}]` | **多度量值区**；>1 个且有列维时渲染两层 sticky 表头（colKey 跨列 + 度量子列） |
| `filters` | `{region:["华东","华南"]}` | 维度筛选（扫描前过滤）；空数组/缺省 = 不过滤 |
| `sort` | `{key:flatIdx, dir:"desc"}` | 按展平列号排序（组/叶分别递归排）；`key >= flatCols` 自动取合计列 totals；`key:"label"` 按标签 |
| `measure`+`agg` | （v1 兼容） | 自动转 `measures=[{field,agg}]` |

返回 `tableModel`：`{rowDims, colDims, colKeys, colLabels, lines[], measures, flatCols, hasColTotal, cfg}`。
`lines[]`：`{type:'group'|'data'|'grandtotal', level, label, path, cells[flatCols], totals[M]}`——`cells` 按 colKey×measure 展平。

**正确性保证**：单次扫描喂「全部行前缀 × {本列,全列}」per-measure 累加器 → 所有 agg（含 avg=over-raw）对组头小计/总计正确。golden-test 守门（多度量和/组头==Σ叶/筛选/下钻/合计列排序）。

## 轨C v2 · 渲染层（`PivotCore.render(container, tm, opts)`）

```js
const inst = PivotCore.render(grid, tm, {
  columns: ds.columns,
  collapsedSet: mySet,      // 折叠态（跨 rebuild 持久；导出不受影响 R1）
  dataBars: false,          // 数据条条件格式（列内 |值|/max 比例染底，负红正青）
  crosshair: true,          // 十字定位（GridKit 共享，R8）
  onSort: (s) => { sort=s; rebuild(); },          // 列头点击：none→desc→asc
  onDrill: (line, colIdx) => { ... }              // 双击数值格
});
inst.expandAll(); inst.collapseAll(); inst.toggleDataBars(true); inst.setZoom(0.9);
inst.getExportModel();      // R1：始终全量展平，忽略折叠/数据条显示态
```

## 轨C v2 · 交互层（`PivotUI`，pivot-ui.js）

```js
const ui = PivotUI.create(panelEl, dataset, { onChange: rebuild });
const cfg = ui.getCfg();    // {rows, cols, measures, filters} → PivotCore.pivot
```
- **拖拽四区**：字段列表（维度蓝 chip / 度量青 chip）→「筛选器/列/行/值」wells；HTML5 DnD 拖进/拖出/跨区/区内重排；维度只进筛选/行/列，数值只进值区。
- **值 chip 聚合徽标**：点击循环 求和→平均→计数→最小→最大。
- **筛选 chip**：点徽标开浮层 checklist（distinct 值 + 全选/清空；全选=不过滤，徽标显"N 项"）。
- **下钻 modal**：`PivotUI.showDrillModal(records, columns, title)`——明细表（≤500 行显示，导出全量）+ ExcelJS 导出按钮 + Esc/遮罩关闭。
- **样式注入**：`pvt-*`/caret/hover/两层表头样式由 pivot-ui.js `injectCSS()` 注入（单文件/Portal 共用一份防漂移）。

**host 接线样板**（single-file/index.html 与 portal/board.html 同构）：
```js
function rebuild(){
  const cfg = ui.getCfg(); cfg.sort = sortState;
  const tm = PivotCore.pivot(ds.rows, cfg);
  inst = PivotCore.render(grid, tm, { columns: ds.columns, collapsedSet, dataBars, crosshair,
    onSort: s => { sortState = s; rebuild(); },
    onDrill: (line, ci) => {
      const recs = PivotCore.drillThrough(ds.rows, cfg, line, tm.hasColTotal && ci>=tm.flatCols ? null : ci);
      PivotUI.showDrillModal(recs, ds.columns, line.path.join(' / '));
    }});
}
```

## 下钻语义（`PivotCore.drillThrough(rawData, cfg, line, colFlatIdx)`）
纯函数重过滤：行 = line.path 与 rows 维逐位相等；列 = colFlatIdx→colKey 元组相等（合计列传 null 不过滤）；叠加 cfg.filters。零内存驻留，golden 断言 Σ明细==格值。

---

## 财务聚合模式

| 需求 | 怎么做 |
|---|---|
| 金额+数量并看 | 值区拖两个度量（多度量两层表头） |
| 各组占比 | 组头 totals / 总计 totals（前端算）；或扩展 `pct_of_parent`（pivot-core 预留位） |
| 加权平均 | 扩展累加器存 Σ(v×w)/Σw（预留位） |
| 期间×科目热力 | 行=科目、列=期间 + 数据条开 |

---

## 轨B Perspective（opt-in，百万行重型档）

启用见 `grid-tracks.md`。与轨C 概念对照：`rows→group_by`、`cols→split_by`、`measures→aggregates+columns`、下钻→Perspective 自带、财务百分比→`pct_sum_parent` 原生。仅当百万行级/流式才升级；轨C v2 已覆盖拖拽透视+折叠+下钻的"真 Excel"体验。
