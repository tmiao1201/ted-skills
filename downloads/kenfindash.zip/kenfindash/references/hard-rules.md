# kenfindash 9 条硬性设计铁律 + golden 测试 + 能力矩阵

这 9 条是把参考框架的 8 个工程风险（用户初步分析指出）固化成的设计规则，**全部已联网验证为真**。每条都对应「证伪它的测试」。违反任一条 = 不达"完美级"。

---

## R1 · 全数据集导出，禁 DOM scrape
**坑**：虚拟化网格任意时刻 DOM 只有可见行；导出靠抓 DOM table → 经理点"导出 3000 行 Backlog" 拿到 30 行，拿错数据做决策。
**做法**：导出一律从**数据模型**或**库原生 API**（AG Grid `exportDataAsExcel({exportedRows:'all'})` / Tabulator/Perspective 原生 download / kenfindash 的 `getExportModel()`）。
**测试**：`golden-test.js` 断言 `导出模型行数 == 数据源行数`。本仓自研轨 `statement-grid.buildExportModel` / `pivot-core.buildExportModel` 均从数据构建，已绿。

## R2 · 全本地 vendored，无 CDN
**坑**：卖点是离线双击，但库走 CDN → 真离线时裂。
**做法**：Perspective/ExcelJS/自研脚本全部落 `assets/vendor/` 与 `scripts/`；Portal 自包含 `assets/js/`。单文件交付时内联。**禁运行期 CDN**。
**测试**：断网后单文件 + Portal 全功能。`grep -r "cdn\.\|unpkg\|jsdelivr" templates/` 应只出现在注释/可选 Perspective 文档里。

## R3 · 缩放用 `zoom`/`font-size`，禁 `transform:scale`
**坑**：`transform` 改 stacking context、破 `position:sticky`、非整数倍字糊（对账最忌）。
**做法**：表格缩放用 CSS `zoom`（Chromium 不破 sticky、基于逻辑像素清晰）；跨 Firefox 退 `font-size`/rem。`statement-grid` / `pivot-core` 的 `setZoom()` 设 `wrap.style.zoom`。
**测试**：browse 实测 zoom 0.9/1.3 下表头/首列仍 `position:sticky` 钉住、不糊（本次已验，截图存档）。

## R4 · 缓存版本戳 + TTL + BroadcastChannel 失效
**坑**：`window.top` 跨域 SecurityError；无 TTL/版本 → 用户开着门户跨过结账看 in-session 旧数据。
**做法**：`loadPayload.serve()` 给 payload 打 `version=(dataAsOf)@(ts)` + TTL（默认 10min）；跨标签 BroadcastChannel `invalidate`；`window.top` 访问包 try/catch。
**测试**：Portal 加载无 SecurityError（本次已验）；刷新按钮触发 invalidate 重载。

## R5 · `@media print` 财务打印
**坑**：缺打印样式 → 表头不重复、背景丢、关键行被截断。
**做法**：`<thead>{display:table-header-group}` 每页重复 + `tr.subtotal/.total{page-break-inside:avoid}` + `print-color-adjust:exact` + `@page{size;margin}` + 三表 `page-break-before`。
**测试**：browse `pdf` / 打印预览，表头每页在、背景色在、小计不被切。

## R6 · 会计负数存真实 -1234 + numFmt
**坑**：把 `(1,234)` 当格式化字符串存/导出 → Excel 里是文本不是数，不能算。
**做法**：数据层存**真实负值**（费用/成本为负）；前端 `FinFmt.fmtFin` 渲染成括号 `(1,234)`；导出 `excel-export` 写真实负值 + numFmt `#,##0;(#,##0)`；解析用 `parseAccountingNumber`。
**测试**：`golden-test.js` round-trip：营业成本写 xlsx → 读回 == `-768000000`（真实负数）。已绿。

## R7 · golden 测试：小计闭合 + 导出一致性
**坑**：对账是高 stakes，却零测试层。
**做法**：`scripts/golden-test.js` 必跑：① 每个 subtotal/total `== Σ子项`（±0.5%）② BS 平衡 ③ 导出行数==数据源 ④ 透视总计==原始全量和 ⑤ ExcelJS round-trip 数值一致。
**门**：交付前 `node scripts/golden-test.js` 退出码必须 0。

## R8 · 双轨能力一致性矩阵
**坑**：十字定位/排序/导出在不同轨行为不同（crosshair 扫 `<table>` 在 Perspective 的 div 渲染上失效），用户不知道哪块板能用什么。
**做法**：十字定位**仅自研 table 轨（轨A/轨C 渲染）**启用；维护下方能力矩阵，每加一种看板按矩阵声明。
**测试**：人工对照矩阵。

### 能力一致性矩阵（v2，随看板增补）
| 能力 | 轨A 报表网格 | 轨C 自研 pivot v2 | 轨B Perspective | (可选) AG Grid Community |
|---|---|---|---|---|
| 冻结表头/首列 | ✓ sticky | ✓ sticky（多度量两层表头亦 sticky） | ✓ 内置 | ✓ pinned |
| zoom 缩放(R3) | ✓ | ✓ | 用 viewer 缩放 | 用 zoom |
| 十字定位(R8) | ✓ GridKit | ✓ GridKit | ✗（div 渲染） | ✗ |
| 拖拽透视字段面板 | —（固定结构） | ✓ PivotUI 四区 DnD | ✓ 自带 | Enterprise 才有 |
| 多度量值区 | —（期间列即多列） | ✓ 两层表头 | ✓ | Enterprise |
| 分组折叠 ▸/▾ | —（科目层级固定展示） | ✓（折叠不影响导出 R1） | ✓ | Enterprise |
| 列头排序 | ✗（科目顺序=会计准则） | ✓ none→desc→asc | ✓ | ✓ |
| 维度筛选器 | ✗ | ✓ checklist 浮层 | ✓ | ✓ |
| 双击下钻明细 | ✗ | ✓ modal + 导出 | 部分 | Enterprise(master/detail) |
| 数据条条件格式 | ✗（财务原色克制） | ✓ 可开关 | 主题有限 | ✓ |
| 全量导出(R1) | ✓ 数据模型 | ✓ 数据模型（与折叠/筛选显示态解耦：筛选影响数据集=导出所见即所选；折叠纯显示=导出恒全量） | ✓ 原生 API | ✓ exportedRows:all |
| 会计括号(R6) | ✓ | ✓ | 需配 numFmt | 需配 |
| @media print(R5) | ✓ | ✓ | 有限 | 有限 |

## R9 · Portal 跨板用 postMessage + 版本戳
**坑**：`window.top.__CACHE` 同源小技巧一旦跨域部署/深链/跨板钻取就撞墙。
**做法**：`loadPayload.get()` 同源直读为快路径，**失败回退 `postMessage` 协议**（`findash:req-payload`/`findash:payload`）；顶层 `serve()` 应答。为跨域/深链留路。
**测试**：Portal iframe 取数无 SecurityError（本次已验）；跨域场景走 postMessage 分支。

---

## 交付前必跑
```bash
node scripts/golden-test.js          # R1/R6/R7 机械门，退出码必须 0
# browse 视觉门：zoom 不破 sticky(R3) / @media print(R5) / 响应式三档 / Portal 无 SecurityError(R4/R9)
grep -rn "cdn\.\|unpkg\|jsdelivr" templates/ scripts/   # R2：运行期不应命中（注释/Perspective 文档除外）
```
