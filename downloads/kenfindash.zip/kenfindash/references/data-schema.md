# kenfindash 数据契约（data-schema）

kenfindash **纯前端、零后端**。所有看板由一份 JSON（或客户端解析的 Excel）驱动。本文件定义这份 JSON 的结构——它是轨A/B/C 与导出、格式化、golden 测试共用的**单一事实源**。

参考实现：`examples/sample-financials.json`（已通过闭合自检：P&L/BS/CF 小计=Σ子项、BS 资产=负债+权益）。

---

## 顶层结构

```jsonc
{
  "meta":       { ... },   // 公司/币种/单位/数据截止/期间定义
  "statements": { ... },   // 三表结构化数据（轨A 报表网格）
  "kpis":       [ ... ],   // CFO KPI 卡（首屏指标）
  "datasets":   { ... }    // 扁平明细记录（轨B/C 透视分析网格）
}
```

`statements` 与 `datasets` 至少存在其一。三者都缺 = 空看板（报错）。

---

## 1. `meta` — 元数据（驱动管理层纪律 D1-D6）

```jsonc
{
  "company": "示例科技股份有限公司",   // 必填
  "ticker": "688999.SH",              // 选填
  "currency": "CNY",                  // 必填 → 货币单位唯一(D6)
  "displayUnit": "万",                // 默认显示单位: "raw"|"千"|"万"|"百万"|"亿"
  "dataAsOf": "2026-03-31",           // 必填 → 数据截止日(D3)，渲染到 source line
  "reportType": "consolidated",       // "consolidated"合并 | "parent"母公司
  "fiscalYearEnd": "12-31",
  "periods": [                        // 必填，列序即默认展示列序
    { "id": "2025A", "label": "2025 实际", "scenario": "AC" },
    { "id": "2024A", "label": "2024 实际", "scenario": "PY" },
    { "id": "2025B", "label": "2025 预算", "scenario": "BU" },
    { "id": "2026F", "label": "2026 预测", "scenario": "FC" }
  ]
}
```

- `scenario` ∈ `AC`(实际)/`PY`(去年同期)/`BU`(预算)/`FC`(预测) → 驱动 **IBCS 视觉编码**（见 `finance-conventions.md`）。预测期(FC)的标签/数字自动加 `E` 后缀语义。
- `periods[].id` 是 `statements.*.rows[].values` 和 `kpis[].values` 的键。**列定义在此一处，行数据按 id 引用**，避免列序散落各行。

---

## 2. `statements` — 三表结构化数据（轨A）

每张表 `{ title, key, rows[], balanceCheck? }`。`key` ∈ `pl`/`bs`/`cf`（决定默认 Waterfall 拆解语义）。

### 行对象（row）

```jsonc
{
  "id": "gross",            // 必填，表内唯一，被 children / formula 引用
  "label": "毛利",          // 必填，科目名（首列）
  "level": 0,               // 缩进层级 0..3（每级 16-20px）
  "type": "subtotal",       // "line"|"subtotal"|"total"|"header"
  "emphasis": true,         // 选填，关键科目（毛利/营业利润/净利润）+1行高+加粗+底色
  "children": ["rev","cogs"], // subtotal/total 必填其一：子行 id 列表 → 闭合校验 值==Σ子项
  "formula": "rev + cogs",  //   或：表达式（引用其他 row id）→ 更灵活（含乘除）；二选一
  "values": { "2025A": 512000000, "2024A": 399000000 }  // 必填，period.id → 数值
}
```

**铁律（R6/R7）**：
- `values` 存**真实有符号数值**（费用/成本存**负数**，如营业成本 `-768000000`）。
  - 好处：① subtotal=Σ子项是纯加法，闭合校验简单；② fmtFin 自动把负数渲染成会计括号 `(76,800)`；③ 导出 Excel 写真实负值 + numFmt，不存格式化字符串。
- `type` 为 `subtotal`/`total` 的行**必须**带 `children` 或 `formula`，供 golden 测试做**闭合校验**（值 == Σ子项 / formula 求值，容差 ±0.5%）。
- `balanceCheck: { left, right }`（仅 BS）：断言 `left` 行值 == `right` 行值（资产总计 == 负债和所有者权益总计）。

---

## 3. `kpis` — CFO 指标卡（首屏）

```jsonc
{
  "id": "gross_margin",
  "label": "毛利率",
  "group": "收益质量",        // 收益质量|现金健康|财务杠杆|运营效率|增长|执行vs计划
  "format": "pct",            // "pct"|"ratio"|"auto"(亿/万/千分位)|"raw"
  "values": { "2025A": 40.0, "2024A": 38.0 },  // pct 按"已是百分数"处理 (40.0 → "40.0%")
  "budget": { "2025A": 40.0 },// 选填，用于达成率/variance
  "direction": "higher_better" // "higher_better"|"lower_better" → 决定好/坏配色方向
}
```

KPI 卡渲染：当期值 + 前期值 + YTD + 预算 + 达成% + sparkline 趋势。`direction` 配合预算差异语义双轨（有利→绿/不利→红）。

---

## 4. `datasets` — 扁平明细（轨B/C 透视分析）

```jsonc
{
  "orders": {
    "title": "新签订单明细",
    "primaryAmount": "amount",   // 默认聚合度量字段
    "columns": [
      { "field": "date",   "title": "签约日期", "type": "date" },
      { "field": "bu",     "title": "事业部",   "type": "string" },   // 可作 pivot 行/列维度
      { "field": "amount", "title": "金额",     "type": "number", "numFmt": "accounting" }
    ],
    "rows": [
      { "date": "2025-01-08", "bu": "医疗器械", "amount": 12800000 }
      // ... 任意行数（轨B Perspective / 轨C Arquero 均虚拟化，万行级无压力）
    ]
  }
}
```

- `columns[].type` ∈ `date`/`string`/`number`/`bool`。`string`/`date` 列默认可作 pivot 行/列维度；`number` 列默认可作度量（聚合）。
- `columns[].numFmt`：`accounting`(会计括号负数)/`integer`/`pct`/`raw` → 透视单元格 + Excel 导出共用。
- 行是**纯扁平记录**（无嵌套）。透视的行列分组、聚合（SUM/AVG/COUNT/小计/总计）由 pivot 引擎在运行期计算，**不预聚合**（保留下钻能力）。

---

## 数据来源（用户拍板：仅用户提供 JSON/Excel）

1. **JSON 直填**：用户把上述结构 JSON 内联进单文件模板的 `window.FINDASH_DATA`，或放 `data/*.json` 供 Portal 加载。
2. **Excel 导入**：用户上传 `.xlsx` → 客户端 **SheetJS 读取** → 映射器转成本 schema（见 `excel-export.md` §导入侧）。映射器需用户指明哪个 sheet/列对应科目/期间/数值。

> 无 Python、无 API、无外部数据源。脱敏后可绿色双击离线运行。
