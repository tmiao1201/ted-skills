/*
 * kenfindash · golden-test.js — 交付前必跑（R7）
 *
 *   node scripts/golden-test.js [path/to/financials.json]
 *
 * 校验：
 *   1) 三表闭合：subtotal/total == Σchildren（±0.5%）
 *   2) 资产负债表平衡：资产总计 == 负债和所有者权益总计
 *   3) 导出 parity：导出模型行数 == 数据源行数（R1，证伪"只导可见行"）
 *   4) 会计负数保真：负值科目导出为真实负数（R6，证伪"存成格式化字符串"）
 *   5) ExcelJS round-trip：写 xlsx → 读回，数值与模型一致（端到端 R1/R6）
 * 退出码 0=全过，1=有失败。
 */
"use strict";
const path = require("path");
const FinFmt = require("./fin-format.js");
const SG = require("./statement-grid.js");
const PC = require("./pivot-core.js");
// 让 excel-export 在 node 拿到 vendored ExcelJS
global.ExcelJS = require(path.join(__dirname, "..", "assets", "vendor", "exceljs.min.js"));
const XP = require("./excel-export.js");

let fails = 0;
const ok = (cond, msg) => { console.log((cond ? "  ✓ " : "  ✗ FAIL ") + msg); if (!cond) fails++; };

async function main() {
  const file = process.argv[2] || path.join(__dirname, "..", "examples", "sample-financials.json");
  const D = require(path.resolve(file));
  const meta = { meta: D.meta, periods: D.meta.periods };

  // 1) 闭合
  console.log("[1] 三表闭合（subtotal/total == Σ子项, ±0.5%）");
  for (const [k, st] of Object.entries(D.statements || {})) {
    const byId = Object.fromEntries(st.rows.map((r) => [r.id, r]));
    for (const r of st.rows) {
      if (!r.children) continue;
      for (const p of Object.keys(r.values)) {
        const sum = r.children.reduce((a, c) => a + (byId[c].values[p] ?? 0), 0);
        ok(Math.abs(sum - r.values[p]) <= 0.5, `${k}.${r.id}[${p}] = ${r.values[p]} == Σ子 ${sum}`);
      }
    }
  }

  // 2) BS 平衡
  console.log("[2] 资产负债表平衡");
  for (const [k, st] of Object.entries(D.statements || {})) {
    if (!st.balanceCheck) continue;
    const byId = Object.fromEntries(st.rows.map((r) => [r.id, r]));
    const L = byId[st.balanceCheck.left], R = byId[st.balanceCheck.right];
    for (const p of Object.keys(L.values)) ok(Math.abs(L.values[p] - R.values[p]) <= 0.5, `${k}[${p}] 资产 ${L.values[p]} == 负债+权益 ${R.values[p]}`);
  }

  // 3) 导出 parity + 4) 负数保真
  console.log("[3] 导出 parity（模型行数 == 数据源）+ [4] 会计负数保真（R1/R6）");
  const models = [];
  for (const [k, st] of Object.entries(D.statements || {})) {
    const cols = SG.defaultColumns(meta);
    const model = SG.buildExportModel(st, meta, cols, "raw"); // raw 保真实数值便于核对
    models.push(model);
    ok(model.rows.length === st.rows.length, `${k}: 导出 ${model.rows.length} 行 == 数据源 ${st.rows.length} 行`);
    // 找一个负值科目验真实负数
    const negRow = st.rows.find((r) => Object.values(r.values).some((v) => v < 0));
    if (negRow) {
      const mr = model.rows.find((r) => r.cells[0].value === negRow.label);
      const hasRealNeg = mr.cells.slice(1).some((c) => typeof c.value === "number" && c.value < 0);
      ok(hasRealNeg, `${k}: 负值科目「${negRow.label}」导出为真实负数（非字符串）`);
    }
  }
  // 透视 v2：多度量/导出全量(与折叠无关)/筛选/下钻/合计列排序
  if (D.datasets) {
    for (const [k, ds] of Object.entries(D.datasets)) {
      const strDims = ds.columns.filter((c) => c.type === "string").map((c) => c.field);
      const numFlds = ds.columns.filter((c) => c.type === "number").map((c) => c.field);
      const rawSum = ds.rows.reduce((a, r) => a + r[ds.primaryAmount], 0);

      // v1 兼容路径
      const tm1 = PC.pivot(ds.rows, { rows: [strDims[0]], cols: [], measure: ds.primaryAmount, agg: "sum", grandTotal: true });
      ok(Math.abs(tm1.lines.find((l) => l.type === "grandtotal").cells[0] - rawSum) <= 0.5, `透视 ${k} v1兼容: 总计 == 全量和 ${rawSum}`);

      // 多度量 + 嵌套组 + 列维
      const cfg = { rows: strDims.slice(0, 2), cols: strDims.slice(2, 3),
        measures: numFlds.slice(0, 2).map((f) => ({ field: f, agg: "sum" })) };
      const tm2 = PC.pivot(ds.rows, cfg);
      const g2 = tm2.lines.find((l) => l.type === "grandtotal");
      numFlds.slice(0, 2).forEach((f, i) => {
        const s = ds.rows.reduce((a, r) => a + r[f], 0);
        ok(Math.abs(g2.totals[i] - s) <= 0.5, `透视 ${k} 多度量[${f}]: 总计 ${g2.totals[i]} == ${s}`);
      });
      // 导出全量（与折叠/显示态无关，R1）：导出行数 == lines 全量（含组头+总计）
      const m2 = PC.buildExportModel(tm2, ds.columns);
      ok(m2.rows.length === tm2.lines.length, `透视 ${k} 导出全量: ${m2.rows.length} == lines ${tm2.lines.length}（折叠不影响导出）`);
      // 组头小计 == 叶和
      const firstGroup = tm2.lines.find((l) => l.type === "group");
      if (firstGroup) {
        const leafSum = tm2.lines.filter((l) => l.type === "data" && l.path[0] === firstGroup.path[0]).reduce((a, l) => a + (l.totals[0] || 0), 0);
        ok(Math.abs(firstGroup.totals[0] - leafSum) <= 0.5, `透视 ${k} 组头小计 == Σ叶 ${leafSum}`);
      }
      // 筛选：限定某维一个值后总计 == 手工过滤和
      const fdim = strDims[1] || strDims[0];
      const fval = ds.rows[0][fdim];
      const tm3 = PC.pivot(ds.rows, { rows: [strDims[0]], cols: [], measures: [{ field: ds.primaryAmount, agg: "sum" }], filters: { [fdim]: [fval] } });
      const fSum = ds.rows.filter((r) => r[fdim] === fval).reduce((a, r) => a + r[ds.primaryAmount], 0);
      ok(Math.abs(tm3.lines.find((l) => l.type === "grandtotal").cells[0] - fSum) <= 0.5, `透视 ${k} 筛选[${fdim}=${fval}]: 总计 == ${fSum}`);
      // 下钻：第一叶行×第一列 的记录和 == 该格值
      // 找一个非空格做下钻（空格则验证零记录一致性）
      let leaf = null, ci = 0;
      outer: for (const l of tm2.lines) {
        if (l.type !== "data") continue;
        for (let c = 0; c < tm2.flatCols; c += tm2.measures.length) {
          if (l.cells[c] != null) { leaf = l; ci = c; break outer; }
        }
      }
      const recs = PC.drillThrough(ds.rows, cfg, leaf, ci);
      const cellVal = leaf.cells[ci];
      const drillSum = recs.reduce((a, r) => a + r[numFlds[0]], 0);
      ok(recs.length > 0 && Math.abs(drillSum - cellVal) <= 0.5, `透视 ${k} 下钻[${leaf.path.join("/")}×col${ci}]: Σ明细 ${drillSum} == 格值 ${cellVal}（${recs.length} 条）`);
      // 合计列排序（flatIdx 越过数据列区取 totals）
      const tm4 = PC.pivot(ds.rows, Object.assign({}, cfg, { sort: { key: tm2.flatCols, dir: "desc" } }));
      const gVals = tm4.lines.filter((l) => l.type === "group").map((l) => l.totals[0]);
      ok(gVals.every((v, i) => i === 0 || gVals[i - 1] >= v), `透视 ${k} 合计列排序 desc: ${gVals.join(",")}`);
    }
  }

  // 5) ExcelJS round-trip
  console.log("[5] ExcelJS round-trip（写 xlsx → 读回，数值一致）");
  const plModel = models[0];
  const wb = await XP.buildWorkbook([plModel]);
  const buf = await wb.xlsx.writeBuffer();
  const ExcelJS = global.ExcelJS;
  const wb2 = new ExcelJS.Workbook();
  await wb2.xlsx.load(buf);
  const ws = wb2.worksheets[0];
  // 校验净利润行（最后数据行）首个数值列 == 模型值
  const lastModelRow = plModel.rows[plModel.rows.length - 1];
  const expectNet = lastModelRow.cells[1].value;
  // ExcelJS 行：第1行表头，数据从第2行起
  let gotNet = null, gotNeg = null;
  ws.eachRow((row, n) => {
    if (n === 1) return;
    const label = row.getCell(1).value;
    if (label === lastModelRow.cells[0].value) gotNet = row.getCell(2).value;
    if (label === "营业成本") gotNeg = row.getCell(2).value;
  });
  ok(gotNet === expectNet, `round-trip 净利润 ${gotNet} == 模型 ${expectNet}`);
  ok(typeof gotNeg === "number" && gotNeg < 0, `round-trip 营业成本读回为真实负数 ${gotNeg}（R6 端到端）`);

  console.log("\n" + (fails === 0 ? "✅ GOLDEN PASS（全部通过）" : `❌ GOLDEN FAIL：${fails} 项未过`));
  process.exit(fails === 0 ? 0 : 1);
}
main().catch((e) => { console.error("golden-test 异常:", e); process.exit(2); });
