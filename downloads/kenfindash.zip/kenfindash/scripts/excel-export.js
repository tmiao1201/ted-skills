/*
 * kenfindash · excel-export.js — ExcelJS 会计级导出（R1 数据模型 / R6 numFmt 负数括号）
 *
 * 消费 statement-grid / pivot-core 的 getExportModel() 产出（数据模型，非 DOM scrape），
 * 生成带样式 xlsx：表头 blueDeep 填充、小计/总计加粗、会计 numFmt（负数括号）、首列缩进、冻结窗格。
 * 浏览器全局：window.FindashExport。依赖 vendored ExcelJS（assets/vendor/exceljs.min.js）+ FinFmt。
 *
 *   FindashExport.exportStatement(model, "利润表.xlsx")     // 单表
 *   FindashExport.exportWorkbook([m1,m2,m3], "三表.xlsx")   // 多 sheet
 */
(function (root, factory) {
  const api = factory(typeof window !== "undefined" ? window.FinFmt : (typeof require === "function" ? require("./fin-format.js") : null));
  if (typeof module === "object" && module.exports) module.exports = api;
  if (typeof window !== "undefined") window.FindashExport = api;
})(this, function (FinFmt) {
  "use strict";

  function getExcelJS() {
    const E = (typeof window !== "undefined" && window.ExcelJS) || (typeof ExcelJS !== "undefined" && ExcelJS) || (typeof require === "function" && require("exceljs"));
    if (!E) throw new Error("ExcelJS 未加载（assets/vendor/exceljs.min.js）");
    return E;
  }

  const FILL_HEADER = { type: "pattern", pattern: "solid", fgColor: { argb: "FF091252" } };
  const FILL_SUB = { type: "pattern", pattern: "solid", fgColor: { argb: "FFEEF1FB" } };
  const FILL_TOTAL = { type: "pattern", pattern: "solid", fgColor: { argb: "FFE6EAF0" } };
  const FONT_HEADER = { bold: true, color: { argb: "FFFFFFFF" }, size: 10 };
  const BORDER_THIN = { style: "thin", color: { argb: "FFD8E2F0" } };

  // numFmt 串：会计负数括号（R6）。导出真实负值，由 numFmt 渲染成 (1,234)。
  function nf(type) {
    switch (type) {
      case "accounting": return '#,##0;(#,##0)';
      case "accounting2": return '#,##0.00;(#,##0.00)';
      case "integer": return '#,##0';
      case "pct": return '0.0%';
      default: return undefined; // text / general
    }
  }

  // 把一个 model 写入一个 worksheet
  function writeSheet(ws, model) {
    const header = model.header || [];
    // 表头
    const hRow = ws.addRow(header.map((h) => h.title));
    hRow.eachCell((cell) => {
      cell.fill = FILL_HEADER; cell.font = FONT_HEADER;
      cell.alignment = { vertical: "middle", horizontal: "right", wrapText: false };
      cell.border = { bottom: BORDER_THIN };
    });
    hRow.getCell(1).alignment = { vertical: "middle", horizontal: "left" };

    // 数据行
    (model.rows || []).forEach((r) => {
      const values = r.cells.map((c) => (c.value == null ? null : c.value));
      const row = ws.addRow(values);
      r.cells.forEach((c, i) => {
        const cell = row.getCell(i + 1);
        if (i === 0) {
          cell.alignment = { horizontal: "left", indent: (c.indent || 0) };
        } else {
          cell.alignment = { horizontal: "right" };
          const fmt = nf(c.type) || nf((header[i] || {}).numFmt);
          if (fmt) cell.numFmt = fmt;
        }
        cell.border = { bottom: BORDER_THIN };
      });
      if (r.style === "subtotal") { row.eachCell((c) => { c.fill = FILL_SUB; c.font = { bold: true }; }); }
      else if (r.style === "total" || r.style === "grandtotal") {
        row.eachCell((c) => { c.fill = FILL_TOTAL; c.font = { bold: true }; c.border = { top: { style: "thin", color: { argb: "FF091252" } }, bottom: { style: "double", color: { argb: "FF091252" } } }; });
      }
      if (r.emphasis) row.eachCell((c) => { c.font = Object.assign({}, c.font, { bold: true }); });
    });

    // 列宽
    ws.columns.forEach((col, i) => { col.width = i === 0 ? 28 : 16; });
    // 冻结窗格（表头 + 首列）
    const fz = model.freeze || { row: 1, col: 1 };
    ws.views = [{ state: "frozen", xSplit: fz.col, ySplit: fz.row }];
    // 元数据脚注行（数据截止/币种）
    if (model.meta) {
      ws.addRow([]);
      const m = model.meta;
      ws.addRow(["Source: kenfindash · " + (m.company || "") + " · " + (m.currency || "") + " · 数据截止 " + (m.dataAsOf || "")]);
    }
    return ws;
  }

  async function buildWorkbook(models) {
    const ExcelJS = getExcelJS();
    const wb = new ExcelJS.Workbook();
    wb.creator = "kenfindash";
    models.forEach((model) => {
      const ws = wb.addWorksheet((model.sheetName || "Sheet").slice(0, 31));
      writeSheet(ws, model);
    });
    return wb;
  }

  async function download(wb, filename) {
    const buf = await wb.xlsx.writeBuffer();
    const blob = new Blob([buf], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = filename || "kenfindash.xlsx";
    document.body.appendChild(a); a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 0);
  }

  async function exportStatement(model, filename) {
    const wb = await buildWorkbook([model]);
    return download(wb, filename || (model.sheetName || "report") + ".xlsx");
  }
  async function exportWorkbook(models, filename) {
    const wb = await buildWorkbook(models);
    return download(wb, filename || "kenfindash.xlsx");
  }

  return { exportStatement, exportWorkbook, buildWorkbook, writeSheet, nf };
});
