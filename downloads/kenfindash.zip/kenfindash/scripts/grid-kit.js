/*
 * kenfindash · grid-kit.js — 网格共享交互件（轨A/轨C 共用）
 *
 * attachCrosshair(table, on)：十字定位（R8）。行/列柔和遮罩 + 焦点描边，不污染财务原色。
 * 列对齐按 cellIndex 遍历数据模型（支持两层表头：以 tbody 行的 cellIndex 为准）。
 * 加载顺序：本文件须在 statement-grid.js / pivot-core.js 之前。
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  if (typeof window !== "undefined") window.GridKit = api;
})(this, function () {
  "use strict";

  function clearCross(table) {
    table.querySelectorAll(".fd-cross-row,.fd-cross-col,.fd-cross-cell").forEach((e) =>
      e.classList.remove("fd-cross-row", "fd-cross-col", "fd-cross-cell"));
  }

  function attachCrosshair(table, on) {
    if (!on) {
      table.onmousemove = null; table.onmouseleave = null;
      clearCross(table);
      return;
    }
    table.onmouseleave = () => clearCross(table);
    table.onmousemove = (e) => {
      const td = e.target.closest("td");
      if (!td || td.closest("table") !== table) return;
      clearCross(table);
      const tr = td.parentElement;
      const ci = td.cellIndex;
      Array.from(tr.cells).forEach((c) => c.classList.add("fd-cross-row"));
      Array.from(table.tBodies[0].rows).forEach((r) => {
        if (r.cells[ci]) r.cells[ci].classList.add("fd-cross-col");
      });
      td.classList.add("fd-cross-cell");
    };
  }

  return { attachCrosshair, clearCross };
});
