/*
 * kenfindash · build-single-file.js — 把单文件模板的外链脚本+数据内联成真·自包含 HTML（file:// 双击可跑，R2 无 CDN）
 *
 *   node scripts/build-single-file.js <data.json> [out.html]
 *
 * 读 templates/single-file/index.html，把 <script src="../../scripts/*.js"> 与 vendored exceljs 内联，
 * 把 data-inline.js 换成传入数据（window.FINDASH_DATA），产出一个可邮件发/双击打开的离线 HTML。
 */
"use strict";
const fs = require("fs");
const path = require("path");

const ROOT = path.join(__dirname, "..");
const TPL = path.join(ROOT, "templates", "single-file", "index.html");

function inlineScript(html, srcAttr, code) {
  const re = new RegExp('<script src="' + srcAttr.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + '"></script>');
  if (!re.test(html)) throw new Error("模板未找到外链: " + srcAttr);
  // 用函数替换器：避免 code 里的 $&/$1 等被当成替换模式（ExcelJS 压缩码含大量 $）
  return html.replace(re, () => "<script>\n/* inlined: " + srcAttr + " */\n" + code + "\n</script>");
}

function main() {
  const dataPath = process.argv[2] || path.join(ROOT, "examples", "sample-financials.json");
  const out = process.argv[3] || path.join(ROOT, "examples", "out-single.html");

  let html = fs.readFileSync(TPL, "utf8");
  const read = (p) => fs.readFileSync(path.join(ROOT, p), "utf8");

  // 顺序内联（grid-kit 先于 statement-grid/pivot-core；exceljs 在 excel-export 之前）
  html = inlineScript(html, "../../scripts/fin-format.js", read("scripts/fin-format.js"));
  html = inlineScript(html, "../../scripts/grid-kit.js", read("scripts/grid-kit.js"));
  html = inlineScript(html, "../../scripts/statement-grid.js", read("scripts/statement-grid.js"));
  html = inlineScript(html, "../../scripts/pivot-core.js", read("scripts/pivot-core.js"));
  html = inlineScript(html, "../../scripts/pivot-ui.js", read("scripts/pivot-ui.js"));
  html = inlineScript(html, "../../assets/vendor/exceljs.min.js", read("assets/vendor/exceljs.min.js"));
  html = inlineScript(html, "../../scripts/excel-export.js", read("scripts/excel-export.js"));

  // 数据内联
  const data = fs.readFileSync(path.resolve(dataPath), "utf8").trim();
  const dataBlock = "<script>\nwindow.FINDASH_DATA = " + data + ";\n</script>";
  html = html.replace('<script src="data-inline.js"></script>', () => dataBlock); // 函数替换器防 $ 模式

  // 残留外链自检（R2）：只查真正的外链资源引用（相对路径/http），不误扫压缩码内字符串
  const leftover = (html.match(/<script\s+src="(\.\.?\/|\/|https?:|data-inline)[^"]*"\s*><\/script>/g) || []);
  if (leftover.length) { console.error("⚠ 仍有未内联外链:", leftover); process.exit(1); }
  const ext = (html.match(/(?:src|href)="https?:\/\/[^"]+"/g) || []);
  if (ext.length) { console.error("⚠ 检出外部 http 资源引用，违反 R2:", ext.slice(0, 3)); process.exit(1); }

  fs.writeFileSync(out, html);
  const kb = Math.round(fs.statSync(out).size / 1024);
  console.log("✓ 自包含单文件已生成:", out, "(" + kb + " KB, 无外链/无 CDN, file:// 可双击)");
}
main();
