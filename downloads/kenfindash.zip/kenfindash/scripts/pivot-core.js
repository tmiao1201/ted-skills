/*
 * kenfindash · pivot-core.js v2 — 轨C 自研 Excel 级 pivot 内核（零依赖，纯 JS，file:// 安全）
 *
 * v2 新增（对标真 Excel 透视表）：
 *   · 多度量值区：cfg.measures=[{field,agg},...]，列轴出现两层表头（colKey 跨列 + 度量子列）
 *   · Excel compact 布局：组头行在前（▸/▾ 可折叠，组头自带小计值），叶行缩进在后，总计收尾
 *   · 折叠状态只影响显示——导出/getExportModel 始终全量展开（R1）
 *   · 列头点击排序（组与叶分别按该列值递归排序，none→desc→asc 循环）
 *   · 维度筛选 cfg.filters={field:[允许值]}（扫描前过滤）
 *   · drillThrough(data,cfg,line,colIdx)：双击单元格 → 该格对应的明细记录（纯函数重过滤，零内存驻留）
 *   · 十字定位接 GridKit（R8）+ 数据条条件格式（列内按 |值|/max 比例染底）
 *
 * 聚合正确性：单次扫描，每条记录喂进「全部行前缀 × {本列,全列}」的 per-measure 累加器
 * → 所有 agg（含 avg=over-raw 非 avg-of-avgs）对小计/总计都正确。golden-test 守门。
 *
 * 向后兼容：cfg.measure+cfg.agg（单数）自动转 measures=[{field,agg}]。
 * 依赖：FinFmt (fin-format.js)、GridKit (grid-kit.js，先加载)。
 */
(function (root, factory) {
  const req = typeof require === "function";
  const api = factory(
    req ? require("./fin-format.js") : (typeof window !== "undefined" ? window.FinFmt : null),
    req ? require("./grid-kit.js") : (typeof window !== "undefined" ? window.GridKit : null)
  );
  if (typeof module === "object" && module.exports) module.exports = api;
  if (typeof window !== "undefined") window.PivotCore = api;
})(this, function (FinFmt, GridKit) {
  "use strict";
  const SEP = "\u0001", KSEP = "\u0002", ALL = "\u0000ALL";

  // ── 聚合器 ──────────────────────────────────────────────
  function newAgg() { return { s: 0, c: 0, mn: Infinity, mx: -Infinity }; }
  function addAgg(a, v) { if (v == null || typeof v !== "number" || isNaN(v)) return; a.s += v; a.c++; if (v < a.mn) a.mn = v; if (v > a.mx) a.mx = v; }
  function finalize(a, agg) {
    if (!a || a.c === 0) return null;
    switch (agg) {
      case "avg": return a.s / a.c;
      case "count": return a.c;
      case "min": return a.mn;
      case "max": return a.mx;
      case "sum": default: return a.s;
    }
  }

  function normMeasures(cfg) {
    if (cfg.measures && cfg.measures.length) return cfg.measures.map((m) => ({ field: m.field, agg: m.agg || "sum" }));
    if (cfg.measure) return [{ field: cfg.measure, agg: cfg.agg || "sum" }];
    throw new Error("pivot: 缺 measures/measure");
  }

  function applyFilters(data, filters) {
    if (!filters) return data;
    const active = Object.entries(filters).filter(([, v]) => Array.isArray(v) && v.length);
    if (!active.length) return data;
    return data.filter((rec) => active.every(([f, allowed]) => allowed.indexOf(rec[f]) >= 0));
  }

  // ── 透视计算 → tableModel ─────────────────────────────────
  function pivot(rawData, cfg) {
    cfg = cfg || {};
    const rowDims = cfg.rows || [];
    const colDims = cfg.cols || [];
    const measures = normMeasures(cfg);
    const M = measures.length;
    const d = rowDims.length;
    const data = applyFilters(rawData, cfg.filters);

    const accum = new Map();           // rowKey+KSEP+colKey → agg[M]
    const colTuples = new Map();
    const leafTuples = new Map();
    const get = (k) => { let a = accum.get(k); if (!a) { a = measures.map(newAgg); accum.set(k, a); } return a; };

    for (const rec of data) {
      const rv = rowDims.map((f) => rec[f]);
      const cv = colDims.map((f) => rec[f]);
      const colKey = colDims.length ? cv.join(SEP) : ALL;
      if (colDims.length && !colTuples.has(colKey)) colTuples.set(colKey, cv);
      const rowKeys = [ALL];
      for (let k = 0; k < d; k++) rowKeys.push(rv.slice(0, k + 1).join(SEP));
      const leafKey = d ? rv.join(SEP) : ALL;
      if (!leafTuples.has(leafKey)) leafTuples.set(leafKey, rv);
      for (const rk of rowKeys) {
        const aCol = get(rk + KSEP + colKey);
        for (let m = 0; m < M; m++) addAgg(aCol[m], rec[measures[m].field]);
        if (colDims.length) {
          const aAll = get(rk + KSEP + ALL);
          for (let m = 0; m < M; m++) addAgg(aAll[m], rec[measures[m].field]);
        }
      }
    }

    const colKeys = colDims.length
      ? [...colTuples.keys()].sort((a, b) => (a < b ? -1 : a > b ? 1 : 0))
      : [ALL];
    const colLabels = colDims.length ? colKeys.map((k) => colTuples.get(k).join(" / ")) : ["合计"];
    const hasColTotal = colDims.length > 0;

    // 一行的全部展平 cells：colKeys × measures（+行总计 totals[M]）
    const flatCells = (rowKey) => {
      const cells = [];
      for (const ck of colKeys) {
        const a = accum.get(rowKey + KSEP + ck);
        for (let m = 0; m < M; m++) cells.push(finalize(a && a[m], measures[m].agg));
      }
      const at = accum.get(rowKey + KSEP + ALL);
      const totals = measures.map((ms, m) => finalize(at && at[m], ms.agg));
      return { cells, totals };
    };

    // 叶元组 → 递归树（Excel compact：组头在前，自带小计；叶在后；总计收尾）
    const leaves = [...leafTuples.values()].sort((a, b) => {
      for (let i = 0; i < d; i++) { const x = String(a[i]), y = String(b[i]); if (x < y) return -1; if (x > y) return 1; }
      return 0;
    });

    function buildNodes(tuples, level, prefix) {
      if (level === d - 1 || d === 0) {
        return tuples.map((t) => {
          const v = flatCells(d ? t.join(SEP) : ALL);
          return { kind: "leaf", level, label: d ? t[level] : "合计", path: t.slice(), cells: v.cells, totals: v.totals };
        });
      }
      const groups = [];
      let cur = null;
      for (const t of tuples) {
        if (!cur || cur.val !== t[level]) { cur = { val: t[level], tuples: [] }; groups.push(cur); }
        cur.tuples.push(t);
      }
      return groups.map((g) => {
        const p = prefix.concat([g.val]);
        const v = flatCells(p.join(SEP));
        return { kind: "group", level, label: g.val, path: p, cells: v.cells, totals: v.totals,
                 children: buildNodes(g.tuples, level + 1, p) };
      });
    }
    const tree = d === 0 ? [] : buildNodes(leaves, 0, []);

    // 排序（递归：同层按指定列值排；'label' 按标签）
    if (cfg.sort && cfg.sort.key != null && cfg.sort.dir) {
      const { key, dir } = cfg.sort;
      const mul = dir === "asc" ? 1 : -1;
      const nFlat = colKeys.length * M;
      const val = (n) => key === "label" ? n.label
        : key === "total" ? (n.totals[cfg.sort.measureIdx || 0])
        : (typeof key === "number" && key >= nFlat) ? n.totals[key - nFlat]   // 合计列（flatIdx 越过数据列区）
        : n.cells[key];
      const cmp = (a, b) => {
        const x = val(a), y = val(b);
        if (x == null && y == null) return 0; if (x == null) return 1; if (y == null) return -1;
        return (x < y ? -1 : x > y ? 1 : 0) * mul;
      };
      (function sortRec(nodes) { nodes.sort(cmp); nodes.forEach((n) => n.children && sortRec(n.children)); })(tree);
    }

    // 展平为 lines（全量；折叠在 render 层处理）
    const lines = [];
    (function emit(nodes) {
      for (const n of nodes) {
        lines.push({ type: n.kind === "group" ? "group" : "data", level: n.level, label: n.label,
                     path: n.path, cells: n.cells, totals: n.totals, hasChildren: !!n.children });
        if (n.children) emit(n.children);
      }
    })(tree);
    {
      const v = flatCells(ALL);
      lines.push({ type: "grandtotal", level: 0, label: "总计", path: [], cells: v.cells, totals: v.totals });
    }

    return { rowDims, colDims, colKeys, colTuples, colLabels, lines, measures, hasColTotal,
             flatCols: colKeys.length * M, cfg };
  }

  // ── 下钻：单元格 → 明细记录（纯函数重过滤，R1 全量语义）────
  // colFlatIdx：展平列号（colKeys×measures 序）；行总计列传 null/超界 → 不按列过滤。
  function drillThrough(rawData, cfg, line, colFlatIdx) {
    const data = applyFilters(rawData, cfg && cfg.filters);
    const rowDims = (cfg && cfg.rows) || [];
    const colDims = (cfg && cfg.cols) || [];
    const M = normMeasures(cfg).length;
    let recs = data.filter((rec) => line.path.every((v, i) => rec[rowDims[i]] === v));
    if (colDims.length && colFlatIdx != null && colFlatIdx >= 0) {
      const ckIdx = Math.floor(colFlatIdx / M);
      // colKeys 序按与 pivot() 相同的「过滤后数据 + 字典序」重建，保证 ckIdx 对位一致
      const colKeySet = new Map();
      for (const rec of data) {
        const cv = colDims.map((f) => rec[f]); const k = cv.join(SEP);
        if (!colKeySet.has(k)) colKeySet.set(k, cv);
      }
      const keys = [...colKeySet.keys()].sort((a, b) => (a < b ? -1 : a > b ? 1 : 0));
      if (ckIdx < keys.length) {
        const tuple = colKeySet.get(keys[ckIdx]);
        recs = recs.filter((rec) => tuple.every((v, i) => rec[colDims[i]] === v));
      }
    }
    return recs;
  }

  // ── 渲染（Excel compact + 折叠 + 排序 + 数据条 + 十字）──────
  function render(container, tm, opts) {
    opts = opts || {};
    const colDef = (opts.columns || []).reduce((m, c) => { m[c.field] = c; return m; }, {});
    const M = tm.measures.length;
    const dimTitle = tm.rowDims.map((f) => (colDef[f] ? colDef[f].title : f)).join(" / ") || "维度";
    const mTitle = (m) => (colDef[m.field] ? colDef[m.field].title : m.field) + "·" + AGG_CN[m.agg];
    const collapsed = opts.collapsedSet || new Set();
    let dataBars = !!opts.dataBars;
    let crossOn = opts.crosshair !== false;
    const state = { sort: (tm.cfg && tm.cfg.sort) || null };

    const wrap = document.createElement("div");
    wrap.className = "fd-zoomwrap"; wrap.style.overflow = "auto";
    const table = document.createElement("table");
    table.className = "fd-table fd-pivot";
    wrap.appendChild(table);
    container.innerHTML = ""; container.appendChild(wrap);

    // 列内 max|值|（数据条）
    const colMax = [];
    for (let c = 0; c < tm.flatCols + M; c++) {
      let mx = 0;
      tm.lines.forEach((ln) => {
        const v = c < tm.flatCols ? ln.cells[c] : ln.totals[c - tm.flatCols];
        if (ln.type !== "grandtotal" && v != null && Math.abs(v) > mx) mx = Math.abs(v);
      });
      colMax.push(mx);
    }

    function thCell(text, opts2) {
      const el = document.createElement("th");
      Object.assign(el.style, { textAlign: (opts2 && opts2.align) || "right" }, (opts2 && opts2.style) || {});
      if (opts2 && opts2.cls) el.className = opts2.cls;
      if (opts2 && opts2.colspan) el.colSpan = opts2.colspan;
      if (opts2 && opts2.rowspan) el.rowSpan = opts2.rowspan;
      el.textContent = text;
      return el;
    }

    function fmtVal(v, m) {
      if (v == null) return "—";
      if (m.agg === "count") return FinFmt.fmtFin(v, { unit: "raw", dec: 0 });
      const nf = colDef[m.field] && colDef[m.field].numFmt;
      if (nf === "pct") return FinFmt.fmtFin(v, { pct: true });
      if (nf === "integer") return FinFmt.fmtFin(v, { unit: "raw", dec: 0 });
      return FinFmt.fmtFin(v);
    }

    function sortMark(flatIdx) {
      if (!state.sort || state.sort.key !== flatIdx) return "";
      return state.sort.dir === "desc" ? " ▼" : " ▲";
    }

    function drawHead() {
      const thead = document.createElement("thead");
      if (M > 1 && tm.hasColTotal) {
        // 两层表头：colKey 跨列 + 度量子列
        const r1 = document.createElement("tr");
        r1.appendChild(thCell(dimTitle, { align: "left", cls: "fd-rowlabel", rowspan: 2 }));
        tm.colLabels.forEach((l) => r1.appendChild(thCell(l, { colspan: M })));
        r1.appendChild(thCell("合计", { colspan: M, cls: "fd-coltotal" }));
        const r2 = document.createElement("tr");
        for (let g = 0; g <= tm.colLabels.length; g++) {
          tm.measures.forEach((m, mi) => {
            const flatIdx = g < tm.colLabels.length ? g * M + mi : tm.flatCols + mi;
            const th = thCell(mTitle(m) + sortMark(flatIdx), { cls: "fd-sub" });
            th.style.cursor = "pointer"; th.title = "点击排序";
            th.onclick = () => cycleSort(flatIdx);
            r2.appendChild(th);
          });
        }
        thead.appendChild(r1); thead.appendChild(r2);
        thead.setAttribute("data-two-row", "1");
      } else {
        const r1 = document.createElement("tr");
        r1.appendChild(thCell(dimTitle, { align: "left", cls: "fd-rowlabel" }));
        const labels = M > 1
          ? tm.measures.map((m) => mTitle(m))
          : tm.colLabels.slice();
        if (M > 1 && !tm.hasColTotal) {
          labels.forEach((l, i) => {
            const th = thCell(l + sortMark(i)); th.style.cursor = "pointer"; th.onclick = () => cycleSort(i); r1.appendChild(th);
          });
        } else {
          tm.colLabels.forEach((l, i) => {
            const th = thCell(l + sortMark(i)); th.style.cursor = "pointer"; th.title = "点击排序"; th.onclick = () => cycleSort(i); r1.appendChild(th);
          });
          if (tm.hasColTotal) {
            const th = thCell("合计" + sortMark(tm.flatCols), { cls: "fd-coltotal" });
            th.style.cursor = "pointer"; th.onclick = () => cycleSort(tm.flatCols); r1.appendChild(th);
          }
        }
        thead.appendChild(r1);
      }
      return thead;
    }

    function numTd(v, m, flatIdx, line) {
      const td = document.createElement("td");
      td.className = "fd-num" + (v != null && v < 0 ? " neg" : "");
      td.textContent = fmtVal(v, m);
      if (dataBars && v != null && line.type !== "grandtotal" && colMax[flatIdx] > 0) {
        const pct = Math.min(100, Math.round(Math.abs(v) / colMax[flatIdx] * 100));
        const color = v < 0 ? "rgba(200,80,64,.14)" : "rgba(0,160,223,.14)";
        td.style.backgroundImage = "linear-gradient(to left," + color + " " + pct + "%, transparent " + pct + "%)";
      }
      td.dataset.flatIdx = String(flatIdx);
      return td;
    }

    function isHidden(line) {
      // 祖先任一前缀被折叠 → 隐藏
      for (let k = 1; k < line.path.length; k++) {
        if (collapsed.has(line.path.slice(0, k).join(SEP))) return true;
      }
      return false;
    }

    function drawBody() {
      const tbody = document.createElement("tbody");
      tm.lines.forEach((ln, li) => {
        if (ln.type !== "grandtotal" && isHidden(ln)) return;
        const key = ln.path.join(SEP);
        if (ln.type === "data" && collapsed.has(key)) return; // 防御（叶无 children 不会进 set）
        const tr = document.createElement("tr");
        tr.className = ln.type === "group" ? "subtotal" : ln.type === "grandtotal" ? "total" : "";
        const lab = document.createElement("td");
        lab.className = "fd-rowlabel";
        lab.style.paddingLeft = 10 + (ln.level || 0) * 18 + "px";
        if (ln.type === "group") {
          const caret = document.createElement("span");
          caret.className = "fd-caret" + (collapsed.has(key) ? " closed" : "");
          caret.textContent = collapsed.has(key) ? "▸" : "▾";
          caret.onclick = (e) => { e.stopPropagation(); collapsed.has(key) ? collapsed.delete(key) : collapsed.add(key); redrawBody(); };
          lab.appendChild(caret);
          lab.appendChild(document.createTextNode(" " + ln.label));
          lab.style.cursor = "pointer";
          lab.onclick = caret.onclick;
        } else {
          lab.textContent = ln.label;
        }
        tr.appendChild(lab);
        for (let c = 0; c < tm.flatCols; c++) tr.appendChild(numTd(ln.cells[c], tm.measures[c % M], c, ln));
        if (tm.hasColTotal) tm.measures.forEach((m, mi) => tr.appendChild(numTd(ln.totals[mi], m, tm.flatCols + mi, ln)));
        // 双击下钻
        tr.ondblclick = (e) => {
          if (!opts.onDrill) return;
          const td = e.target.closest("td"); if (!td || td.dataset.flatIdx == null) return;
          opts.onDrill(ln, parseInt(td.dataset.flatIdx, 10));
        };
        tbody.appendChild(tr);
      });
      return tbody;
    }

    function redrawBody() {
      const old = table.tBodies[0];
      const nb = drawBody();
      old ? table.replaceChild(nb, old) : table.appendChild(nb);
      GridKit && GridKit.attachCrosshair(table, crossOn);
    }

    function cycleSort(flatIdx) {
      const s = state.sort;
      state.sort = (!s || s.key !== flatIdx) ? { key: flatIdx, dir: "desc" }
        : s.dir === "desc" ? { key: flatIdx, dir: "asc" } : null;
      if (opts.onSort) { opts.onSort(state.sort); return; } // 外层重算 pivot（推荐：排序需重建树序）
    }

    table.appendChild(drawHead());
    redrawBody();
    // 两层表头 sticky 第二行偏移
    if (table.tHead && table.tHead.getAttribute("data-two-row")) {
      requestAnimationFrame(() => {
        const h1 = table.tHead.rows[0].getBoundingClientRect().height || 38;
        Array.from(table.tHead.rows[1].cells).forEach((c) => { c.style.top = h1 + "px"; });
      });
    }

    return {
      el: wrap, table, tableModel: tm, collapsedSet: collapsed,
      setZoom: (z) => { wrap.style.zoom = String(z); },
      toggleCrosshair: (on) => { crossOn = on; GridKit && GridKit.attachCrosshair(table, on); },
      toggleDataBars: (on) => { dataBars = on; redrawBody(); },
      expandAll: () => { collapsed.clear(); redrawBody(); },
      collapseAll: () => { tm.lines.forEach((l) => { if (l.type === "group") collapsed.add(l.path.join(SEP)); }); redrawBody(); },
      getExportModel: () => buildExportModel(tm, opts.columns),   // 始终全量（R1，与折叠无关）
    };
  }

  const AGG_CN = { sum: "求和", avg: "平均", count: "计数", min: "最小", max: "最大" };

  // ── 导出数据模型（R1：全量展平，忽略折叠/数据条等显示态）────
  function buildExportModel(tm, columns) {
    const colDef = (columns || []).reduce((m, c) => { m[c.field] = c; return m; }, {});
    const M = tm.measures.length;
    const mTitle = (m) => (colDef[m.field] ? colDef[m.field].title : m.field) + "·" + AGG_CN[m.agg];
    const dimTitle = tm.rowDims.map((f) => (colDef[f] ? colDef[f].title : f)).join(" / ") || "维度";
    const numType = (m) => (m.agg === "count" ? "integer" : "accounting");
    const header = [{ title: dimTitle, numFmt: "text" }];
    for (const cl of tm.colLabels) for (const m of tm.measures) header.push({ title: M > 1 ? cl + "·" + mTitle(m) : cl, numFmt: numType(m) });
    if (tm.hasColTotal) for (const m of tm.measures) header.push({ title: M > 1 ? "合计·" + mTitle(m) : "合计", numFmt: numType(m) });
    const rows = tm.lines.map((ln) => {
      const cells = [{ value: ln.label, type: "string", indent: ln.level || 0 }];
      for (let c = 0; c < tm.flatCols; c++) cells.push({ value: ln.cells[c], type: numType(tm.measures[c % M]) });
      if (tm.hasColTotal) tm.measures.forEach((m, mi) => cells.push({ value: ln.totals[mi], type: numType(m) }));
      return { cells, style: ln.type === "group" ? "subtotal" : ln.type === "grandtotal" ? "total" : "line" };
    });
    return { sheetName: "Pivot", header, rows, freeze: { row: M > 1 && tm.hasColTotal ? 2 : 1, col: 1 } };
  }

  return { pivot, render, buildExportModel, drillThrough, AGG_CN };
});
