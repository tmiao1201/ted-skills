/*
 * kenfindash · pivot-ui.js — Excel 式拖拽透视字段面板（轨C 配套 UI，零依赖）
 *
 * 完整复刻 Excel 数据透视表交互：
 *   · 字段列表（维度=蓝 chip / 度量=青 chip）+「筛选器/列/行/值」四个拖放区
 *   · HTML5 DnD：chip 拖进/拖出/跨区移动/区内重排；值区 chip 点击聚合徽标循环 求和→平均→计数→最小→最大
 *   · 筛选器 chip 点击 → 浮层 checklist（distinct 值多选 + 全选/清空）
 *   · 下钻 modal：showDrillModal(records, columns, title)（双击单元格的明细，含导出按钮）
 *
 * 用法（host 模板）：
 *   const ui = PivotUI.create(panelEl, dataset, { onChange: rebuild });
 *   const cfg = ui.getCfg();   // {rows, cols, measures, filters} → PivotCore.pivot
 * 依赖：FinFmt；下钻导出可选依赖 FindashExport。
 */
(function (root, factory) {
  const api = factory(typeof window !== "undefined" ? window.FinFmt : (typeof require === "function" ? require("./fin-format.js") : null));
  if (typeof module === "object" && module.exports) module.exports = api;
  if (typeof window !== "undefined") window.PivotUI = api;
})(this, function (FinFmt) {
  "use strict";
  const AGGS = ["sum", "avg", "count", "min", "max"];
  const AGG_CN = { sum: "求和", avg: "平均", count: "计数", min: "最小", max: "最大" };

  // ── 注入式样式（单文件/Portal 共用一份，防两模板 CSS 漂移）────
  const CSS = `
.pvt-panel{display:grid;grid-template-columns:minmax(220px,1fr) minmax(320px,1.4fr);gap:12px;padding:12px 16px;border-bottom:1px solid var(--border,#D8E2F0);background:linear-gradient(180deg,var(--bluePale,#F4F6FF),#fff)}
.pvt-fields{border:1px dashed var(--border,#D8E2F0);border-radius:8px;padding:8px 10px;background:#fff;min-height:74px;transition:border-color .15s,box-shadow .15s}
.pvt-fields.dragover{border-color:var(--techBlue,#00A0DF);box-shadow:0 0 0 3px var(--techLight,#E0F4FC)}
.pvt-fields-body{display:flex;flex-wrap:wrap;gap:6px;margin-top:6px}
.pvt-wells{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.pvt-well{border:1px dashed var(--border,#D8E2F0);border-radius:8px;padding:6px 10px 8px;background:#fff;min-height:58px;transition:border-color .15s,box-shadow .15s}
.pvt-well.dragover{border-color:var(--blue,#1226AA);box-shadow:0 0 0 3px var(--blueLight,#E8EEFF);background:var(--bluePale,#F4F6FF)}
.pvt-well-title{font-size:9px;font-weight:700;color:var(--textMuted,#9098B8);letter-spacing:.6px;text-transform:uppercase}
.pvt-well-body{display:flex;flex-wrap:wrap;gap:6px;margin-top:6px;min-height:24px}
.pvt-hint{font-size:10px;color:var(--textMuted,#9098B8);padding:3px 2px}
.pvt-chip{display:inline-flex;align-items:center;gap:5px;padding:3px 8px;border-radius:14px;font-size:11px;cursor:grab;user-select:none;background:var(--blueLight,#E8EEFF);color:var(--blue,#1226AA);border:1px solid transparent;box-shadow:0 1px 2px rgba(9,18,82,.08);transition:box-shadow .12s,transform .12s}
.pvt-chip.num{background:var(--techLight,#E0F4FC);color:#066d96}
.pvt-chip:hover{box-shadow:0 2px 6px rgba(9,18,82,.16);transform:translateY(-1px)}
.pvt-chip.dragging{opacity:.45}
.pvt-chip.inuse{opacity:.38}
.pvt-grip{font-size:8px;opacity:.5;cursor:grab}
.pvt-x{border:none;background:none;color:inherit;opacity:.55;font-size:12px;cursor:pointer;padding:0 0 0 2px;line-height:1}
.pvt-x:hover{opacity:1}
.pvt-agg{border:none;border-radius:9px;background:rgba(255,255,255,.85);color:inherit;font-size:9px;font-weight:700;padding:1px 6px;cursor:pointer;box-shadow:inset 0 0 0 1px rgba(9,18,82,.12)}
.pvt-agg:hover{background:#fff}
.pvt-pop{position:fixed;z-index:1000;background:#fff;border:1px solid var(--border,#D8E2F0);border-radius:8px;box-shadow:0 8px 32px rgba(0,0,0,.18);width:220px;font-size:11px}
.pvt-pop-head{display:flex;gap:6px;padding:8px 10px;border-bottom:1px solid var(--border,#D8E2F0)}
.pvt-pop-btn{border:1px solid var(--border,#D8E2F0);background:#fff;border-radius:5px;font-size:10px;padding:2px 8px;cursor:pointer;color:var(--textMid,#3A3F5C)}
.pvt-pop-btn:hover{background:var(--blueLight,#E8EEFF);color:var(--blue,#1226AA)}
.pvt-pop-list{max-height:220px;overflow-y:auto;padding:6px 10px}
.pvt-pop-row{display:block;padding:3px 0;cursor:pointer;color:var(--textMid,#3A3F5C)}
.pvt-modal-ov{position:fixed;inset:0;z-index:1100;background:rgba(9,18,82,.35);display:flex;align-items:center;justify-content:center;backdrop-filter:blur(2px)}
.pvt-modal{background:#fff;border-radius:12px;box-shadow:0 8px 32px rgba(0,0,0,.25);width:min(860px,92vw);max-height:80vh;display:flex;flex-direction:column;overflow:hidden}
.pvt-modal-head{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:12px 16px;border-bottom:1px solid var(--border,#D8E2F0);background:linear-gradient(180deg,#fff,var(--bluePale,#F4F6FF))}
.pvt-modal-title{font-size:13px;font-weight:700;color:var(--blue,#1226AA)}
.pvt-modal-head .tbtn{margin-left:6px}
.pvt-modal-body{overflow:auto;padding:8px}
.fd-caret{display:inline-block;width:14px;color:var(--techBlue,#00A0DF);font-size:10px;cursor:pointer;transition:transform .12s}
.fd-table tbody tr:not(.total):hover td{background:var(--blueLight,#E8EEFF)}
.fd-table thead th.fd-sub{height:26px;font-size:8px;background:var(--blueMid,#2E4FD0)}
.fd-table thead th.fd-coltotal{background:#0B1640}
`;
  function injectCSS() {
    if (typeof document === "undefined" || document.getElementById("pvt-ui-css")) return;
    const st = document.createElement("style");
    st.id = "pvt-ui-css"; st.textContent = CSS;
    document.head.appendChild(st);
  }

  function create(panelEl, dataset, opts) {
    opts = opts || {};
    injectCSS();
    const cols = dataset.columns || [];
    const dims = cols.filter((c) => c.type === "string" || c.type === "date");
    const nums = cols.filter((c) => c.type === "number");
    const byField = cols.reduce((m, c) => { m[c.field] = c; return m; }, {});
    const strDims = dims.filter((c) => c.type === "string");

    // 默认布局：首字符串维→行，次字符串维→列，primaryAmount→值
    const state = {
      filters: [],                                  // [field]
      rows: strDims[0] ? [strDims[0].field] : (dims[0] ? [dims[0].field] : []),
      cols: strDims[1] ? [strDims[1].field] : [],
      values: [{ field: dataset.primaryAmount || (nums[0] && nums[0].field), agg: "sum" }].filter((v) => v.field),
      filterValues: {},                             // field -> [allowed] (缺省=全选)
    };

    const WELLS = [
      { key: "filters", title: "筛选器", accept: "dim" },
      { key: "cols", title: "列", accept: "dim" },
      { key: "rows", title: "行", accept: "dim" },
      { key: "values", title: "值", accept: "num" },
    ];

    function distinct(field) {
      const s = new Set();
      (dataset.rows || []).forEach((r) => s.add(r[field]));
      return [...s].sort();
    }

    function fireChange() { if (opts.onChange) opts.onChange(); }

    // ── 拖拽协议 ─────────────────────────────────────────
    function chipDragStart(e, field, from) {
      e.dataTransfer.setData("text/plain", JSON.stringify({ field, from }));
      e.dataTransfer.effectAllowed = "move";
      e.target.classList.add("dragging");
    }
    function removeFrom(well, field) {
      if (well === "values") state.values = state.values.filter((v) => v.field !== field);
      else if (well) state[well] = state[well].filter((f) => f !== field);
    }
    function acceptable(wellKey, field) {
      const isNum = !!(byField[field] && byField[field].type === "number");
      return wellKey === "values" ? isNum : !isNum;
    }
    function dropInto(wellKey, payload, beforeField) {
      const { field, from } = payload;
      if (!acceptable(wellKey, field)) return;
      removeFrom(from, field);
      if (wellKey === "values") {
        if (!state.values.some((v) => v.field === field)) {
          const item = { field, agg: "sum" };
          const idx = beforeField ? state.values.findIndex((v) => v.field === beforeField) : -1;
          idx >= 0 ? state.values.splice(idx, 0, item) : state.values.push(item);
        }
      } else {
        if (state[wellKey].indexOf(field) < 0) {
          const idx = beforeField ? state[wellKey].indexOf(beforeField) : -1;
          idx >= 0 ? state[wellKey].splice(idx, 0, field) : state[wellKey].push(field);
        }
      }
      renderPanel(); fireChange();
    }

    // ── 渲染面板 ─────────────────────────────────────────
    function chip(field, fromWell, extra) {
      const c = byField[field] || { title: field, type: "string" };
      const el = document.createElement("span");
      el.className = "pvt-chip " + (c.type === "number" ? "num" : "dim");
      el.draggable = true;
      el.addEventListener("dragstart", (e) => chipDragStart(e, field, fromWell));
      el.addEventListener("dragend", (e) => e.target.classList.remove("dragging"));
      el.addEventListener("dragover", (e) => { e.preventDefault(); e.stopPropagation(); });
      el.addEventListener("drop", (e) => {
        e.preventDefault(); e.stopPropagation();
        try { dropInto(fromWell || wellOfField(field), JSON.parse(e.dataTransfer.getData("text/plain")), field); } catch (_) {}
      });
      const grip = document.createElement("span"); grip.className = "pvt-grip"; grip.textContent = "⠿";
      el.appendChild(grip);
      const lab = document.createElement("span"); lab.textContent = c.title; el.appendChild(lab);
      if (extra) extra(el, field);
      if (fromWell) {
        const x = document.createElement("button"); x.className = "pvt-x"; x.textContent = "×"; x.title = "移除";
        x.onclick = () => { removeFrom(fromWell, field); renderPanel(); fireChange(); };
        el.appendChild(x);
      }
      return el;
    }
    function wellOfField(field) {
      if (state.values.some((v) => v.field === field)) return "values";
      for (const k of ["filters", "rows", "cols"]) if (state[k].indexOf(field) >= 0) return k;
      return null;
    }

    function renderPanel() {
      panelEl.innerHTML = "";
      panelEl.className = "pvt-panel";

      // 字段列表
      const fl = document.createElement("div"); fl.className = "pvt-fields";
      const flTitle = document.createElement("div"); flTitle.className = "pvt-well-title"; flTitle.textContent = "字段（拖入下方区域）";
      fl.appendChild(flTitle);
      const flBody = document.createElement("div"); flBody.className = "pvt-fields-body";
      cols.forEach((c) => {
        const el = chip(c.field, null);
        if (wellOfField(c.field)) el.classList.add("inuse");
        flBody.appendChild(el);
      });
      fl.appendChild(flBody);
      // 字段列表也可作为"移出"目标
      fl.addEventListener("dragover", (e) => { e.preventDefault(); fl.classList.add("dragover"); });
      fl.addEventListener("dragleave", () => fl.classList.remove("dragover"));
      fl.addEventListener("drop", (e) => {
        e.preventDefault(); fl.classList.remove("dragover");
        try { const p = JSON.parse(e.dataTransfer.getData("text/plain")); removeFrom(p.from, p.field); renderPanel(); fireChange(); } catch (_) {}
      });
      panelEl.appendChild(fl);

      // 四 wells
      const grid = document.createElement("div"); grid.className = "pvt-wells";
      WELLS.forEach((w) => {
        const box = document.createElement("div"); box.className = "pvt-well";
        const t = document.createElement("div"); t.className = "pvt-well-title"; t.textContent = w.title; box.appendChild(t);
        const body = document.createElement("div"); body.className = "pvt-well-body";
        const items = w.key === "values" ? state.values.map((v) => v.field) : state[w.key];
        if (!items.length) { const hint = document.createElement("span"); hint.className = "pvt-hint"; hint.textContent = w.accept === "num" ? "拖入数值字段" : "拖入维度字段"; body.appendChild(hint); }
        items.forEach((field) => {
          const el = chip(field, w.key, (chipEl, f) => {
            if (w.key === "values") {
              const v = state.values.find((x) => x.field === f);
              const badge = document.createElement("button");
              badge.className = "pvt-agg"; badge.textContent = AGG_CN[v.agg]; badge.title = "点击切换聚合";
              badge.onclick = (e) => { e.stopPropagation(); v.agg = AGGS[(AGGS.indexOf(v.agg) + 1) % AGGS.length]; renderPanel(); fireChange(); };
              chipEl.insertBefore(badge, chipEl.querySelector(".pvt-x"));
            }
            if (w.key === "filters") {
              const n = (state.filterValues[f] || []).length;
              const badge = document.createElement("button");
              badge.className = "pvt-agg pvt-filterbadge"; badge.textContent = n ? n + " 项" : "全部"; badge.title = "点击选择筛选值";
              badge.onclick = (e) => { e.stopPropagation(); openFilterPop(badge, f); };
              chipEl.insertBefore(badge, chipEl.querySelector(".pvt-x"));
            }
          });
          body.appendChild(el);
        });
        box.appendChild(body);
        box.addEventListener("dragover", (e) => {
          e.preventDefault();
          try { box.classList.add("dragover"); } catch (_) {}
        });
        box.addEventListener("dragleave", () => box.classList.remove("dragover"));
        box.addEventListener("drop", (e) => {
          e.preventDefault(); box.classList.remove("dragover");
          try { dropInto(w.key, JSON.parse(e.dataTransfer.getData("text/plain")), null); } catch (_) {}
        });
        grid.appendChild(box);
      });
      panelEl.appendChild(grid);
    }

    // ── 筛选浮层 ─────────────────────────────────────────
    let pop = null;
    function closePop() { if (pop) { pop.remove(); pop = null; document.removeEventListener("mousedown", outside); } }
    function outside(e) { if (pop && !pop.contains(e.target)) closePop(); }
    function openFilterPop(anchor, field) {
      closePop();
      const vals = distinct(field);
      const allowed = state.filterValues[field];
      const checked = new Set(allowed && allowed.length ? allowed : vals);
      pop = document.createElement("div"); pop.className = "pvt-pop";
      const head = document.createElement("div"); head.className = "pvt-pop-head";
      const all = document.createElement("button"); all.textContent = "全选"; all.className = "pvt-pop-btn";
      const none = document.createElement("button"); none.textContent = "清空"; none.className = "pvt-pop-btn";
      head.appendChild(all); head.appendChild(none); pop.appendChild(head);
      const list = document.createElement("div"); list.className = "pvt-pop-list";
      const boxes = vals.map((v) => {
        const row = document.createElement("label"); row.className = "pvt-pop-row";
        const cb = document.createElement("input"); cb.type = "checkbox"; cb.checked = checked.has(v);
        cb.onchange = apply;
        row.appendChild(cb); row.appendChild(document.createTextNode(" " + v));
        list.appendChild(row);
        return { cb, v };
      });
      pop.appendChild(list);
      all.onclick = () => { boxes.forEach((b) => b.cb.checked = true); apply(); };
      none.onclick = () => { boxes.forEach((b) => b.cb.checked = false); apply(); };
      function apply() {
        const sel = boxes.filter((b) => b.cb.checked).map((b) => b.v);
        state.filterValues[field] = sel.length === vals.length ? [] : sel;   // 全选=无过滤
        renderPanel(); fireChange();
        // 浮层挂在 body 上，renderPanel 重建面板不影响它——保持打开便于连续勾选
      }
      document.body.appendChild(pop);
      const r = anchor.getBoundingClientRect();
      pop.style.left = Math.min(r.left, window.innerWidth - 240) + "px";
      pop.style.top = (r.bottom + 6) + "px";
      setTimeout(() => document.addEventListener("mousedown", outside), 0);
    }

    // ── 对外 ────────────────────────────────────────────
    function getCfg() {
      const filters = {};
      state.filters.forEach((f) => { const v = state.filterValues[f]; if (v && v.length) filters[f] = v; });
      return {
        rows: state.rows.slice(), cols: state.cols.slice(),
        measures: state.values.map((v) => ({ field: v.field, agg: v.agg })),
        filters,
      };
    }

    renderPanel();
    return { getCfg, rerender: renderPanel, state, destroy: closePop };
  }

  // ── 下钻明细 modal（双击单元格）──────────────────────────
  function showDrillModal(records, columns, title, opts) {
    opts = opts || {};
    injectCSS();
    const MAXN = 500;
    const old = document.getElementById("pvt-drill"); if (old) old.remove();
    const ov = document.createElement("div"); ov.id = "pvt-drill"; ov.className = "pvt-modal-ov";
    const md = document.createElement("div"); md.className = "pvt-modal";
    const head = document.createElement("div"); head.className = "pvt-modal-head";
    const h = document.createElement("span"); h.className = "pvt-modal-title";
    h.textContent = title + " · " + records.length + " 条明细" + (records.length > MAXN ? "（显示前 " + MAXN + " 条，导出为全量）" : "");
    head.appendChild(h);
    const btns = document.createElement("div");
    if (typeof window !== "undefined" && window.FindashExport) {
      const ex = document.createElement("button"); ex.className = "tbtn"; ex.textContent = "导出明细";
      ex.onclick = () => {
        const header = columns.map((c) => ({ title: c.title, numFmt: c.type === "number" ? (c.numFmt === "integer" ? "integer" : "accounting") : "text" }));
        const rows = records.map((r) => ({ cells: columns.map((c) => ({ value: r[c.field], type: c.type === "number" ? (c.numFmt === "integer" ? "integer" : "accounting") : "string" })), style: "line" }));
        window.FindashExport.exportStatement({ sheetName: "明细", header, rows, freeze: { row: 1, col: 0 } }, (title || "drill") + ".xlsx");
      };
      btns.appendChild(ex);
    }
    const x = document.createElement("button"); x.className = "tbtn"; x.textContent = "关闭";
    x.onclick = () => ov.remove();
    btns.appendChild(x); head.appendChild(btns); md.appendChild(head);

    const body = document.createElement("div"); body.className = "pvt-modal-body";
    const table = document.createElement("table"); table.className = "fd-table";
    const thead = document.createElement("thead"); const htr = document.createElement("tr");
    columns.forEach((c, i) => { const th = document.createElement("th"); th.textContent = c.title; th.style.textAlign = c.type === "number" ? "right" : "left"; htr.appendChild(th); });
    thead.appendChild(htr); table.appendChild(thead);
    const tbody = document.createElement("tbody");
    records.slice(0, MAXN).forEach((r) => {
      const tr = document.createElement("tr");
      columns.forEach((c) => {
        const td = document.createElement("td");
        const v = r[c.field];
        if (c.type === "number") { td.className = "fd-num" + (v < 0 ? " neg" : ""); td.textContent = FinFmt ? FinFmt.fmtCell(v, c) : String(v); }
        else { td.textContent = v == null ? "—" : String(v); }
        tr.appendChild(td);
      });
      tbody.appendChild(tr);
    });
    table.appendChild(tbody); body.appendChild(table); md.appendChild(body);
    ov.appendChild(md);
    ov.onclick = (e) => { if (e.target === ov) ov.remove(); };
    document.addEventListener("keydown", function esc(e) { if (e.key === "Escape") { ov.remove(); document.removeEventListener("keydown", esc); } });
    document.body.appendChild(ov);
  }

  return { create, showDrillModal, AGG_CN };
});
