/*
 * kenfindash · fin-format.js — 财务数字格式化层（轨A/B/C + 导出共用）
 *
 * 双形态可用：浏览器 <script> 挂 window.FinFmt；Node require 走 module.exports（供 golden 测试）。
 * 纯函数、无副作用、无依赖。fmtFin 主体移植自 kenslide-perfect/scripts/visual-helpers.js（纯 helper）。
 *
 * 导出：
 *   fmtFin(v, opts)              财务数字 → 字符串（千分位/亿万/负数括号/百分比/signed）
 *   parseAccountingNumber(str)   "(1,234)" | "1,234" | "-1234" → number  (R6 解析侧)
 *   excelNumFmt(kind)            返回 ExcelJS/SheetJS numFmt 字符串  (R6 导出侧)
 *   unitDivisor(unit)            "亿"|"万"|"百万"|"千"|"raw" → 除数
 *   fmtCell(v, col)              按列 numFmt 渲染单元格文本（透视/明细共用）
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  if (typeof window !== "undefined") window.FinFmt = api;
})(this, function () {
  "use strict";

  // ── fmtFin：财务口径数字格式化 ───────────────────────────────
  // unit:   "auto"(默认)|"亿"|"万"|"百万"|"千"|"raw"
  //         auto: |v|≥1e8→亿；≥1e4→万；否则 raw 千分位
  // dec:    小数位（auto 亿/万默认 1；raw 默认 0；pct 默认 1）
  // pct:    true → 百分比（v 按"已是百分数值"处理，12.3 → "12.3%"）
  // signed: true → 正值带 "+"
  // 负数一律返回会计括号制 "(1,234)" / "(12.3亿)"（颜色由调用方配）。
  function fmtFin(v, opts) {
    opts = opts || {};
    for (const k of Object.keys(opts)) {
      if (!["unit", "dec", "pct", "signed"].includes(k)) {
        throw new Error('fmtFin 未知选项 "' + k + '"（合法: unit/dec/pct/signed）');
      }
    }
    let unit = opts.unit == null ? "auto" : opts.unit;
    let dec = opts.dec;
    const pct = !!opts.pct;
    const signed = !!opts.signed;
    if (dec != null) dec = Math.max(0, Math.floor(dec));
    if (v == null || typeof v !== "number" || !isFinite(v)) return "—";

    // 对称舍入：±0.25→±0.3（Math.round 半值向 +∞ 不对称，伤数字诚实性）
    const round = (x, d) => {
      const k = Math.pow(10, d);
      const sign = x < 0 ? -1 : 1;
      return (sign * Math.round((Math.abs(x) + Number.EPSILON) * k)) / k;
    };
    const wrap = (body, neg) => (neg ? "(" + body + ")" : signed ? "+" + body : body);

    if (pct) {
      const d = dec != null ? dec : 1;
      const r = round(v, d);
      if (r === 0) return "0" + (d > 0 ? "." + "0".repeat(d) : "") + "%";
      return wrap(Math.abs(r).toFixed(d) + "%", r < 0);
    }

    const abs = Math.abs(v);
    let u = unit;
    if (u === "auto") u = abs >= 1e8 ? "亿" : abs >= 1e4 ? "万" : "raw";

    const UNIT_DIV = { "亿": 1e8, "万": 1e4, "百万": 1e6, "千": 1e3 };
    if (UNIT_DIV[u]) {
      const div = UNIT_DIV[u];
      const d = dec != null ? dec : 1;
      const r = round(v / div, d);
      if (r === 0) return "0" + (d > 0 ? "." + "0".repeat(d) : "") + u;
      // 千分位 + 单位后缀（如 12,345.6万）
      const body = Math.abs(r).toLocaleString("en-US", {
        minimumFractionDigits: d, maximumFractionDigits: d,
      });
      return wrap(body + u, r < 0);
    }

    // raw：千分位
    const d = dec != null ? dec : 0;
    const r = round(v, d);
    if (r === 0) return d > 0 ? "0." + "0".repeat(d) : "0";
    const body = Math.abs(r).toLocaleString("en-US", {
      minimumFractionDigits: d, maximumFractionDigits: d,
    });
    return wrap(body, r < 0);
  }

  // ── parseAccountingNumber：括号/千分位字符串 → 真实数值 (R6) ──
  function parseAccountingNumber(str) {
    if (typeof str === "number") return str;
    if (str == null) return null;
    let s = String(str).trim();
    if (s === "" || s === "—" || s === "-") return null;
    const neg = /^\(.*\)$/.test(s) || /^-/.test(s);
    s = s.replace(/[(),\s¥$]/g, "").replace(/^-/, "");
    // 去掉中文单位后缀并还原（如 "12.3万"）
    const unitMap = { "亿": 1e8, "万": 1e4, "百万": 1e6, "千": 1e3 };
    let mult = 1;
    const m = s.match(/(亿|百万|万|千)$/);
    if (m) { mult = unitMap[m[1]]; s = s.slice(0, -m[1].length); }
    if (s.endsWith("%")) { s = s.slice(0, -1); } // 百分数原样数值
    const n = parseFloat(s);
    if (!isFinite(n)) return null;
    return (neg ? -n : n) * mult;
  }

  // ── excelNumFmt：列类型 → Excel numFmt (R6 导出侧) ───────────
  // accounting：负数括号、千分位；零显示 "-"（会计惯例）
  function excelNumFmt(kind) {
    switch (kind) {
      case "accounting": return '#,##0_);[Red](#,##0)';     // 负数红色括号
      case "accounting2": return '#,##0.00_);[Red](#,##0.00)';
      case "integer":    return '#,##0';
      case "pct":        return '0.0%';
      case "pct2":       return '0.00%';
      case "raw":        return '#,##0.00';
      default:           return 'General';
    }
  }

  function unitDivisor(unit) {
    return { "亿": 1e8, "百万": 1e6, "万": 1e4, "千": 1e3, "raw": 1 }[unit] || 1;
  }

  // ── fmtCell：按列定义渲染单元格文本（透视/明细共用）───────────
  function fmtCell(v, col) {
    col = col || {};
    if (v == null || v === "") return "—";
    const t = col.type, nf = col.numFmt;
    if (t === "number") {
      if (nf === "integer") return fmtFin(v, { unit: "raw", dec: 0 });
      if (nf === "pct") return fmtFin(v, { pct: true });
      if (nf === "accounting" || nf === "raw") return fmtFin(v, { unit: "raw", dec: 0 });
      return fmtFin(v); // auto
    }
    return String(v);
  }

  return { fmtFin, parseAccountingNumber, excelNumFmt, unitDivisor, fmtCell };
});
