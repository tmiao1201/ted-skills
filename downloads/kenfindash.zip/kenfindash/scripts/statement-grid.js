/*
 * kenfindash · statement-grid.js — 轨A 自研 sticky 报表网格
 *
 * 固定结构三表/P&L 渲染器：原生 <table> + position:sticky 冻结表头与首列 + 会计级小计/缩进/总计描边
 * + 十字定位(R8) + zoom 缩放(R3) + 数据模型导出(R1，非 DOM scrape)。
 * 依赖：FinFmt (fin-format.js)。纯 vanilla，浏览器挂 window.StatementGrid，单文件/Portal 共用。
 *
 * 用法：
 *   const g = StatementGrid.render(containerEl, statement, meta, {
 *     columns: [...],        // 列定义（缺省=meta.periods 全列 + 可选 YoY）
 *     unit: "万",            // 显示单位
 *     crosshair: true,       // 十字定位
 *   });
 *   g.setZoom(0.9); g.toggleCrosshair(false);
 *   const model = g.getExportModel();   // → excel-export.js（数据模型，R1）
 */
(function (root, factory) {
  const req = typeof require === "function";
  const api = factory(
    req ? require("./fin-format.js") : (typeof window !== "undefined" ? window.FinFmt : null),
    req ? require("./grid-kit.js") : (typeof window !== "undefined" ? window.GridKit : null)
  );
  if (typeof module === "object" && module.exports) module.exports = api;
  if (typeof window !== "undefined") window.StatementGrid = api;
})(this, function (FinFmt, GridKit) {
  "use strict";

  // ── 列模型 ──────────────────────────────────────────────
  // 默认：每个 period 一列；可加派生列（YoY%）。scenario 用于 IBCS 编码。
  function defaultColumns(meta) {
    const cols = (meta.periods || []).map((p) => ({
      key: p.id, title: p.label, scenario: p.scenario, kind: "value",
    }));
    // 自动插入 YoY%（若有 AC 与 PY）
    const ac = (meta.periods || []).find((p) => p.scenario === "AC");
    const py = (meta.periods || []).find((p) => p.scenario === "PY");
    if (ac && py) {
      const acIdx = cols.findIndex((c) => c.key === ac.id);
      cols.splice(acIdx + 1, 0, { key: "_yoy", title: "YoY%", kind: "yoy", from: ac.id, base: py.id });
    }
    return cols;
  }

  function cellValue(row, col) {
    if (col.kind === "value") return row.values ? row.values[col.key] : null;
    if (col.kind === "yoy") {
      const a = row.values && row.values[col.from];
      const b = row.values && row.values[col.base];
      if (a == null || b == null || b === 0) return null;
      return ((a - b) / Math.abs(b)) * 100; // 百分数值
    }
    return null;
  }

  // ── 渲染 ────────────────────────────────────────────────
  function render(container, statement, meta, opts) {
    opts = opts || {};
    if (!FinFmt) throw new Error("statement-grid 需要 FinFmt (fin-format.js) 先加载");
    const unit = opts.unit || (meta.meta && meta.meta.displayUnit) || "万";
    const columns = opts.columns || defaultColumns(meta);
    const crosshairOn = opts.crosshair !== false;

    const wrap = document.createElement("div");
    wrap.className = "fd-zoomwrap";
    wrap.style.overflow = "auto";

    const table = document.createElement("table");
    table.className = "fd-table";
    table.setAttribute("data-statement", statement.key || "");

    // thead
    const thead = document.createElement("thead");
    const htr = document.createElement("tr");
    htr.appendChild(th(statement.title || "科目", "fd-rowlabel", "left"));
    columns.forEach((c) => {
      const el = th(unitTitle(c, unit), null, "right");
      el.setAttribute("data-scenario", c.scenario || "");
      htr.appendChild(el);
    });
    thead.appendChild(htr);
    table.appendChild(thead);

    // tbody
    const tbody = document.createElement("tbody");
    (statement.rows || []).forEach((row) => {
      const tr = document.createElement("tr");
      tr.className = [row.type, row.emphasis ? "emphasis" : ""].filter(Boolean).join(" ");
      // 科目名（首列，缩进）
      const labelTd = document.createElement("td");
      labelTd.className = "fd-rowlabel";
      labelTd.style.paddingLeft = 12 + (row.level || 0) * 18 + "px";
      labelTd.textContent = row.label;
      tr.appendChild(labelTd);
      // 数值列
      columns.forEach((c) => {
        const v = cellValue(row, c);
        const td = document.createElement("td");
        td.className = "fd-num" + (v != null && v < 0 ? " neg" : "");
        td.textContent = formatCell(v, c, unit);
        tr.appendChild(td);
      });
      tbody.appendChild(tr);
    });
    table.appendChild(tbody);
    wrap.appendChild(table);

    container.innerHTML = "";
    container.appendChild(wrap);

    const inst = {
      el: wrap, table, statement, meta, columns, unit,
      setZoom: (z) => { wrap.style.zoom = String(z); },             // R3：zoom 不破 sticky
      toggleCrosshair: (on) => GridKit && GridKit.attachCrosshair(table, on),
      getExportModel: () => buildExportModel(statement, meta, columns, unit),
    };
    if (crosshairOn && GridKit) GridKit.attachCrosshair(table, true);
    return inst;
  }

  function th(text, cls, align) {
    const el = document.createElement("th");
    if (cls) el.className = cls;
    el.style.textAlign = align || "left";
    el.textContent = text;
    return el;
  }
  function unitTitle(col, unit) {
    if (col.kind === "yoy") return col.title;
    return col.title + (unit && unit !== "raw" ? "（" + unit + "）" : "");
  }
  function formatCell(v, col, unit) {
    if (v == null) return "—";
    if (col.kind === "yoy") return FinFmt.fmtFin(v, { pct: true, signed: true });
    return FinFmt.fmtFin(v, { unit: unit, dec: unit === "raw" ? 0 : 1 });
  }

  // 十字定位已抽至 grid-kit.js（GridKit.attachCrosshair，轨A/轨C 共用，R8）

  // ── 导出数据模型（R1：从 statement 数据构建，非抓 DOM）──────
  function buildExportModel(statement, meta, columns, unit) {
    const div = FinFmt.unitDivisor(unit);
    const header = [{ title: statement.title || "科目", numFmt: "text" }].concat(
      columns.map((c) => ({
        title: c.kind === "yoy" ? c.title : c.title + (unit !== "raw" ? "（" + unit + "）" : ""),
        numFmt: c.kind === "yoy" ? "pct" : "accounting",
      }))
    );
    const rows = (statement.rows || []).map((row) => {
      const cells = [{ value: row.label, type: "string", indent: row.level || 0 }];
      columns.forEach((c) => {
        let v = cellValue(row, c);
        if (v != null && c.kind === "value") v = v / div; // 按显示单位缩放，保真实数值（R6）
        if (c.kind === "yoy" && v != null) v = v / 100;     // pct numFmt 吃小数
        cells.push({ value: v, type: c.kind === "yoy" ? "pct" : "accounting" });
      });
      return { cells, style: row.type, emphasis: !!row.emphasis };
    });
    return {
      sheetName: statement.title || "Statement",
      meta: meta.meta,
      header, rows,
      freeze: { row: 1, col: 1 }, // 冻结表头 + 首列
    };
  }

  return { render, defaultColumns, buildExportModel };
});
