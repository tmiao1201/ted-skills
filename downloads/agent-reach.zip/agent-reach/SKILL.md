---
name: agent-reach
description: "按平台和可用后端获取互联网内容：网页搜索、社交平台讨论、GitHub 信息、招聘信息、视频字幕与 RSS。用于需要这些内容的检索或读取任务；按需选择平台参考文档。已有专用工具或 skill 时优先复用。仅提及平台名、处理用户已提供的材料或修改本地代码，不触发联网工作。"
metadata:
  openclaw:
    homepage: https://github.com/Panniantong/Agent-Reach
---

# Agent Reach — 互联网内容获取与后端路由

按用户需要的平台和内容选择可用后端。平台覆盖和命令以本机工具能力为准。

## 使用方式

1. 优先使用当前会话中已提供、适合任务的专用工具或 skill；需要平台 CLI 或备用读取路径时再查本 skill。
2. 多后端或需要登录的平台，当前任务第一次使用前运行 `agent-reach doctor --json`，按 `active_backend` 读取对应参考。已有本轮检查结果时复用；后端失败或环境变化后再检查。
3. 只阅读本次平台对应的参考。广泛调研按问题选择有增量价值的平台，不固定要求遍历所有平台。
4. 失败时按参考中的备用路径处理，同一失败路径不无条件重复；可用路径耗尽后说明覆盖缺口，继续处理已取得的材料。
5. 保留原始来源链接、发布日期和抓取时间；结论只引用实际取得的内容。
6. 用户要求更新或诊断工具版本时再检查更新。此技能负责读取；发布、评论等写操作按用户当前授权处理。

## Routing table

| User intent | Category | Details |
|---------|------|---------|
| Web / code search | search | [references/search.md](references/search.md) |
| XiaoHongShu / Twitter / Bilibili / V2EX / Reddit / Facebook / Instagram | social | [references/social.md](references/social.md) |
| Jobs / LinkedIn | career | [references/career.md](references/career.md) |
| GitHub / code | dev | [references/dev.md](references/dev.md) |
| Web pages / articles / RSS | web | [references/web.md](references/web.md) |
| YouTube / Bilibili / podcast transcripts | video | [references/video.md](references/video.md) |

## Zero-config quick commands

```bash
# Exa web search
mcporter call 'exa.web_search_exa(query: "query", numResults: 5)'

# Read any web page
curl -s "https://r.jina.ai/URL"

# GitHub search
gh search repos "query" --sort stars --limit 10

# YouTube subtitles (NOTE: never use yt-dlp for Bilibili — see video.md)
yt-dlp --write-sub --skip-download -o "/tmp/%(id)s" "URL"

# V2EX hot topics
curl -s "https://www.v2ex.com/api/topics/hot.json" -H "User-Agent: agent-reach/1.0"

# Bilibili search (bili-cli, no login needed)
bili search "query" --type video -n 5
```

## Login-backed platforms (pick by doctor's active_backend)

```bash
# Twitter search (twitter-cli preferred; retry chain in social.md)
twitter search "query" -n 10

# Reddit (NO zero-config path — OpenCLI or rdt-cli, login required)
opencli reddit search "query" -f yaml   # desktop
rdt search "query" --limit 10            # legacy/server

# XiaoHongShu (desktop prefers OpenCLI)
opencli xiaohongshu search "query" -f yaml

# Facebook / Instagram (desktop OpenCLI, browser session)
opencli facebook search "query" -f yaml
opencli facebook groups -f yaml
opencli instagram search "query" -f yaml       # user search
opencli instagram user USERNAME -f yaml        # recent posts from one user
```

## Environment check

```bash
# Channel availability + which backend serves each platform
agent-reach doctor --json
```

## Workspace rules

Use `/tmp/` for temporary captures and the user’s project directory for deliverables or reusable research. Keep tool caches in their existing configured location.

## Detailed references

Read the matching file when you need specifics (commands above cover the
common cases; references hold per-backend command groups, caveats, retry
chains — note: reference docs are written in Chinese, commands are universal):

- [Search](references/search.md) — Exa AI search
- [Social](references/social.md) — XiaoHongShu, Twitter, Bilibili, V2EX, Reddit, Facebook, Instagram (multi-backend/login-backed groups)
- [Career](references/career.md) — LinkedIn
- [Dev](references/dev.md) — GitHub CLI
- [Web](references/web.md) — Jina Reader, RSS
- [Video](references/video.md) — YouTube, Bilibili, Xiaoyuzhou

## Configure a channel

If a channel needs setup, fetch the install guide:
https://raw.githubusercontent.com/Panniantong/agent-reach/main/docs/install.md

When login is needed, prefer the tool’s supported login flow; do not ask the user to paste session cookies into chat.
